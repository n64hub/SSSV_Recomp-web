#include "recomp.h"
#include "funcs.h"

RECOMP_FUNC void heli_rabbit_drop_bomb(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80302120: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x80302124: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x80302128: sw          $a0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r4;
    // 0x8030212C: sw          $a1, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r5;
    // 0x80302130: sw          $a2, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r6;
    // 0x80302134: addiu       $t6, $zero, -0x9
    ctx->r14 = ADD32(0, -0X9);
    // 0x80302138: addiu       $t7, $zero, 0x14
    ctx->r15 = ADD32(0, 0X14);
    // 0x8030213C: sw          $t7, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r15;
    // 0x80302140: sw          $t6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r14;
    // 0x80302144: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80302148: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x8030214C: addiu       $a0, $zero, 0x11
    ctx->r4 = ADD32(0, 0X11);
    // 0x80302150: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x80302154: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x80302158: jal         0x80321E60
    // 0x8030215C: addiu       $a3, $zero, -0x1E
    ctx->r7 = ADD32(0, -0X1E);
    fire_cannonball_1(rdram, ctx);
        goto after_0;
    // 0x8030215C: addiu       $a3, $zero, -0x1E
    ctx->r7 = ADD32(0, -0X1E);
    after_0:
    // 0x80302160: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80302164: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80302168: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8030216C: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80302170: lh          $t8, 0x8($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X8);
    // 0x80302174: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x80302178: addiu       $a0, $zero, 0x7C
    ctx->r4 = ADD32(0, 0X7C);
    // 0x8030217C: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80302180: lh          $t9, 0xC($v0)
    ctx->r25 = MEM_H(ctx->r2, 0XC);
    // 0x80302184: addiu       $a1, $zero, 0x4000
    ctx->r5 = ADD32(0, 0X4000);
    // 0x80302188: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x8030218C: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    // 0x80302190: jal         0x8032C360
    // 0x80302194: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    play_sound_effect_at_location(rdram, ctx);
        goto after_1;
    // 0x80302194: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_1:
    // 0x80302198: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    // 0x8030219C: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x803021A0: jr          $ra
    // 0x803021A4: nop

    return;
    // 0x803021A4: nop

;}
RECOMP_FUNC void func_803021A8_713858(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803021A8: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x803021AC: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x803021B0: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803021B4: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x803021B8: lbu         $t7, 0x162($t6)
    ctx->r15 = MEM_BU(ctx->r14, 0X162);
    // 0x803021BC: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x803021C0: bne         $t7, $at, L_803021F0
    if (ctx->r15 != ctx->r1) {
        // 0x803021C4: nop
    
            goto L_803021F0;
    }
    // 0x803021C4: nop

    // 0x803021C8: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x803021CC: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x803021D0: lbu         $t8, 0x365($v0)
    ctx->r24 = MEM_BU(ctx->r2, 0X365);
    // 0x803021D4: bne         $t8, $zero, L_803021F0
    if (ctx->r24 != 0) {
        // 0x803021D8: nop
    
            goto L_803021F0;
    }
    // 0x803021D8: nop

    // 0x803021DC: lhu         $t9, 0x5544($t9)
    ctx->r25 = MEM_HU(ctx->r25, 0X5544);
    // 0x803021E0: addiu       $t0, $zero, 0x1D
    ctx->r8 = ADD32(0, 0X1D);
    // 0x803021E4: sh          $t9, 0x32A($v0)
    MEM_H(0X32A, ctx->r2) = ctx->r25;
    // 0x803021E8: lw          $t1, 0x0($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X0);
    // 0x803021EC: sb          $t0, 0x365($t1)
    MEM_B(0X365, ctx->r9) = ctx->r8;
L_803021F0:
    // 0x803021F0: jr          $ra
    // 0x803021F4: nop

    return;
    // 0x803021F4: nop

;}
RECOMP_FUNC void func_80302200_7138B0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80302200: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80302204: lbu         $t6, 0x5538($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X5538);
    // 0x80302208: addiu       $sp, $sp, -0x78
    ctx->r29 = ADD32(ctx->r29, -0X78);
    // 0x8030220C: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x80302210: beq         $t6, $zero, L_80302268
    if (ctx->r14 == 0) {
        // 0x80302214: lui         $t7, 0x803D
        ctx->r15 = S32(0X803D << 16);
            goto L_80302268;
    }
    // 0x80302214: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80302218: lw          $t7, 0x5524($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5524);
    // 0x8030221C: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x80302220: lh          $v1, 0x2D70($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X2D70);
    // 0x80302224: lh          $v0, 0xD6($t7)
    ctx->r2 = MEM_H(ctx->r15, 0XD6);
    // 0x80302228: beq         $v1, $v0, L_80302248
    if (ctx->r3 == ctx->r2) {
        // 0x8030222C: nop
    
            goto L_80302248;
    }
    // 0x8030222C: nop

    // 0x80302230: bne         $v0, $zero, L_80302250
    if (ctx->r2 != 0) {
        // 0x80302234: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_80302250;
    }
    // 0x80302234: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x80302238: beq         $v1, $at, L_80302248
    if (ctx->r3 == ctx->r1) {
        // 0x8030223C: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_80302248;
    }
    // 0x8030223C: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80302240: bnel        $v1, $at, L_80302254
    if (ctx->r3 != ctx->r1) {
        // 0x80302244: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80302254;
    }
    goto skip_0;
    // 0x80302244: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_0:
L_80302248:
    // 0x80302248: b           L_80302254
    // 0x8030224C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_80302254;
    // 0x8030224C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_80302250:
    // 0x80302250: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80302254:
    // 0x80302254: beq         $v0, $zero, L_80302268
    if (ctx->r2 == 0) {
        // 0x80302258: lui         $at, 0x803F
        ctx->r1 = S32(0X803F << 16);
            goto L_80302268;
    }
    // 0x80302258: lui         $at, 0x803F
    ctx->r1 = S32(0X803F << 16);
    // 0x8030225C: sh          $zero, 0x70($sp)
    MEM_H(0X70, ctx->r29) = 0;
    // 0x80302260: b           L_803022F4
    // 0x80302264: sb          $zero, 0x2EDD($at)
    MEM_B(0X2EDD, ctx->r1) = 0;
        goto L_803022F4;
    // 0x80302264: sb          $zero, 0x2EDD($at)
    MEM_B(0X2EDD, ctx->r1) = 0;
L_80302268:
    // 0x80302268: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030226C: lw          $t0, 0x5524($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5524);
    // 0x80302270: lui         $v1, 0x803F
    ctx->r3 = S32(0X803F << 16);
    // 0x80302274: lh          $v1, 0x2D70($v1)
    ctx->r3 = MEM_H(ctx->r3, 0X2D70);
    // 0x80302278: lh          $v0, 0xD6($t0)
    ctx->r2 = MEM_H(ctx->r8, 0XD6);
    // 0x8030227C: addiu       $a3, $zero, 0x730
    ctx->r7 = ADD32(0, 0X730);
    // 0x80302280: addiu       $t5, $zero, 0x9E
    ctx->r13 = ADD32(0, 0X9E);
    // 0x80302284: beq         $v1, $v0, L_803022A4
    if (ctx->r3 == ctx->r2) {
        // 0x80302288: addiu       $t6, $zero, 0x1
        ctx->r14 = ADD32(0, 0X1);
            goto L_803022A4;
    }
    // 0x80302288: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x8030228C: bne         $v0, $zero, L_803022AC
    if (ctx->r2 != 0) {
        // 0x80302290: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_803022AC;
    }
    // 0x80302290: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x80302294: beq         $v1, $at, L_803022A4
    if (ctx->r3 == ctx->r1) {
        // 0x80302298: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_803022A4;
    }
    // 0x80302298: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x8030229C: bnel        $v1, $at, L_803022B0
    if (ctx->r3 != ctx->r1) {
        // 0x803022A0: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_803022B0;
    }
    goto skip_1;
    // 0x803022A0: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_1:
L_803022A4:
    // 0x803022A4: b           L_803022B0
    // 0x803022A8: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_803022B0;
    // 0x803022A8: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_803022AC:
    // 0x803022AC: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_803022B0:
    // 0x803022B0: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x803022B4: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x803022B8: lhu         $t9, 0xBA($t0)
    ctx->r25 = MEM_HU(ctx->r8, 0XBA);
    // 0x803022BC: sltiu       $t7, $v0, 0x1
    ctx->r15 = ctx->r2 < 0X1 ? 1 : 0;
    // 0x803022C0: lw          $t8, 0xC($v1)
    ctx->r24 = MEM_W(ctx->r3, 0XC);
    // 0x803022C4: lw          $a0, 0x4($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X4);
    // 0x803022C8: lw          $a1, 0x8($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X8);
    // 0x803022CC: sll         $t4, $t9, 15
    ctx->r12 = S32(ctx->r25 << 15);
    // 0x803022D0: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    // 0x803022D4: sw          $t6, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r14;
    // 0x803022D8: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x803022DC: sw          $t5, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r13;
    // 0x803022E0: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x803022E4: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x803022E8: jal         0x802E89F0
    // 0x803022EC: addu        $a2, $t8, $t4
    ctx->r6 = ADD32(ctx->r24, ctx->r12);
    classify_object_visibility_6FA0A0(rdram, ctx);
        goto after_0;
    // 0x803022EC: addu        $a2, $t8, $t4
    ctx->r6 = ADD32(ctx->r24, ctx->r12);
    after_0:
    // 0x803022F0: sh          $v0, 0x70($sp)
    MEM_H(0X70, ctx->r29) = ctx->r2;
L_803022F4:
    // 0x803022F4: lh          $t9, 0x70($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X70);
    // 0x803022F8: bne         $t9, $zero, L_80302C68
    if (ctx->r25 != 0) {
        // 0x803022FC: nop
    
            goto L_80302C68;
    }
    // 0x803022FC: nop

    // 0x80302300: jal         0x8034B298
    // 0x80302304: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    func_8034B298_75C948(rdram, ctx);
        goto after_1;
    // 0x80302304: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_1:
    // 0x80302308: jal         0x8035D120
    // 0x8030230C: nop

    func_8035D120_76E7D0(rdram, ctx);
        goto after_2;
    // 0x8030230C: nop

    after_2:
    // 0x80302310: jal         0x8035D734
    // 0x80302314: nop

    func_8035D734_76EDE4(rdram, ctx);
        goto after_3;
    // 0x80302314: nop

    after_3:
    // 0x80302318: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8030231C: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x80302320: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80302324: lbu         $v0, 0x365($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X365);
    // 0x80302328: beq         $v0, $zero, L_80302474
    if (ctx->r2 == 0) {
        // 0x8030232C: nop
    
            goto L_80302474;
    }
    // 0x8030232C: nop

    // 0x80302330: beq         $v0, $at, L_80302340
    if (ctx->r2 == ctx->r1) {
        // 0x80302334: nop
    
            goto L_80302340;
    }
    // 0x80302334: nop

    // 0x80302338: b           L_80302474
    // 0x8030233C: sb          $zero, 0x365($v1)
    MEM_B(0X365, ctx->r3) = 0;
        goto L_80302474;
    // 0x8030233C: sb          $zero, 0x365($v1)
    MEM_B(0X365, ctx->r3) = 0;
L_80302340:
    // 0x80302340: jal         0x802DCCAC
    // 0x80302344: addiu       $a0, $zero, 0x10
    ctx->r4 = ADD32(0, 0X10);
    func_802DCCAC_6EE35C(rdram, ctx);
        goto after_4;
    // 0x80302344: addiu       $a0, $zero, 0x10
    ctx->r4 = ADD32(0, 0X10);
    after_4:
    // 0x80302348: lui         $t4, 0x803D
    ctx->r12 = S32(0X803D << 16);
    // 0x8030234C: lw          $t4, 0x552C($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X552C);
    // 0x80302350: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x80302354: lhu         $t8, 0x5544($t8)
    ctx->r24 = MEM_HU(ctx->r24, 0X5544);
    // 0x80302358: lhu         $t5, 0x32A($t4)
    ctx->r13 = MEM_HU(ctx->r12, 0X32A);
    // 0x8030235C: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x80302360: addiu       $a0, $zero, 0x16
    ctx->r4 = ADD32(0, 0X16);
    // 0x80302364: subu        $t6, $t8, $t5
    ctx->r14 = SUB32(ctx->r24, ctx->r13);
    // 0x80302368: bne         $t6, $at, L_80302474
    if (ctx->r14 != ctx->r1) {
        // 0x8030236C: addiu       $a1, $zero, 0x54
        ctx->r5 = ADD32(0, 0X54);
            goto L_80302474;
    }
    // 0x8030236C: addiu       $a1, $zero, 0x54
    ctx->r5 = ADD32(0, 0X54);
    // 0x80302370: addiu       $t7, $zero, 0xF
    ctx->r15 = ADD32(0, 0XF);
    // 0x80302374: addiu       $t9, $zero, 0x4
    ctx->r25 = ADD32(0, 0X4);
    // 0x80302378: sw          $t9, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r25;
    // 0x8030237C: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80302380: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80302384: addiu       $a3, $zero, 0x1A
    ctx->r7 = ADD32(0, 0X1A);
    // 0x80302388: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x8030238C: jal         0x803224C4
    // 0x80302390: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    func_803224C4_733B74(rdram, ctx);
        goto after_5;
    // 0x80302390: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    after_5:
    // 0x80302394: sll         $v1, $v0, 16
    ctx->r3 = S32(ctx->r2 << 16);
    // 0x80302398: sra         $t4, $v1, 16
    ctx->r12 = S32(SIGNED(ctx->r3) >> 16);
    // 0x8030239C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x803023A0: beq         $v0, $at, L_80302434
    if (ctx->r2 == ctx->r1) {
        // 0x803023A4: or          $v1, $t4, $zero
        ctx->r3 = ctx->r12 | 0;
            goto L_80302434;
    }
    // 0x803023A4: or          $v1, $t4, $zero
    ctx->r3 = ctx->r12 | 0;
    // 0x803023A8: addiu       $t8, $zero, 0xF
    ctx->r24 = ADD32(0, 0XF);
    // 0x803023AC: addiu       $t5, $zero, 0x4
    ctx->r13 = ADD32(0, 0X4);
    // 0x803023B0: sw          $t5, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r13;
    // 0x803023B4: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x803023B8: addiu       $a0, $zero, 0x16
    ctx->r4 = ADD32(0, 0X16);
    // 0x803023BC: addiu       $a1, $zero, 0x38
    ctx->r5 = ADD32(0, 0X38);
    // 0x803023C0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x803023C4: addiu       $a3, $zero, 0x1A
    ctx->r7 = ADD32(0, 0X1A);
    // 0x803023C8: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x803023CC: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x803023D0: jal         0x803224C4
    // 0x803023D4: sh          $t4, 0x6A($sp)
    MEM_H(0X6A, ctx->r29) = ctx->r12;
    func_803224C4_733B74(rdram, ctx);
        goto after_6;
    // 0x803023D4: sh          $t4, 0x6A($sp)
    MEM_H(0X6A, ctx->r29) = ctx->r12;
    after_6:
    // 0x803023D8: lh          $v1, 0x6A($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X6A);
    // 0x803023DC: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x803023E0: addiu       $a0, $zero, 0x16
    ctx->r4 = ADD32(0, 0X16);
    // 0x803023E4: or          $v1, $v1, $v0
    ctx->r3 = ctx->r3 | ctx->r2;
    // 0x803023E8: sll         $t6, $v1, 16
    ctx->r14 = S32(ctx->r3 << 16);
    // 0x803023EC: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x803023F0: beq         $v0, $at, L_80302434
    if (ctx->r2 == ctx->r1) {
        // 0x803023F4: or          $v1, $t7, $zero
        ctx->r3 = ctx->r15 | 0;
            goto L_80302434;
    }
    // 0x803023F4: or          $v1, $t7, $zero
    ctx->r3 = ctx->r15 | 0;
    // 0x803023F8: addiu       $t9, $zero, 0xF
    ctx->r25 = ADD32(0, 0XF);
    // 0x803023FC: addiu       $t4, $zero, 0x4
    ctx->r12 = ADD32(0, 0X4);
    // 0x80302400: sw          $t4, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r12;
    // 0x80302404: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x80302408: addiu       $a1, $zero, 0x1C
    ctx->r5 = ADD32(0, 0X1C);
    // 0x8030240C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80302410: addiu       $a3, $zero, 0x1A
    ctx->r7 = ADD32(0, 0X1A);
    // 0x80302414: sw          $zero, 0x14($sp)
    MEM_W(0X14, ctx->r29) = 0;
    // 0x80302418: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x8030241C: jal         0x803224C4
    // 0x80302420: sh          $t7, 0x6A($sp)
    MEM_H(0X6A, ctx->r29) = ctx->r15;
    func_803224C4_733B74(rdram, ctx);
        goto after_7;
    // 0x80302420: sh          $t7, 0x6A($sp)
    MEM_H(0X6A, ctx->r29) = ctx->r15;
    after_7:
    // 0x80302424: lh          $v1, 0x6A($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X6A);
    // 0x80302428: or          $v1, $v1, $v0
    ctx->r3 = ctx->r3 | ctx->r2;
    // 0x8030242C: sll         $t8, $v1, 16
    ctx->r24 = S32(ctx->r3 << 16);
    // 0x80302430: sra         $v1, $t8, 16
    ctx->r3 = S32(SIGNED(ctx->r24) >> 16);
L_80302434:
    // 0x80302434: andi        $t6, $v1, 0x2
    ctx->r14 = ctx->r3 & 0X2;
    // 0x80302438: beq         $t6, $zero, L_80302474
    if (ctx->r14 == 0) {
        // 0x8030243C: addiu       $a0, $zero, 0x44
        ctx->r4 = ADD32(0, 0X44);
            goto L_80302474;
    }
    // 0x8030243C: addiu       $a0, $zero, 0x44
    ctx->r4 = ADD32(0, 0X44);
    // 0x80302440: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80302444: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80302448: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x8030244C: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80302450: lh          $t7, 0x8($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X8);
    // 0x80302454: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x80302458: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x8030245C: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80302460: lh          $t9, 0xC($v0)
    ctx->r25 = MEM_H(ctx->r2, 0XC);
    // 0x80302464: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80302468: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    // 0x8030246C: jal         0x8032C360
    // 0x80302470: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    play_sound_effect_at_location(rdram, ctx);
        goto after_8;
    // 0x80302470: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_8:
L_80302474:
    // 0x80302474: lui         $t4, 0x803F
    ctx->r12 = S32(0X803F << 16);
    // 0x80302478: lhu         $t4, 0x2ECE($t4)
    ctx->r12 = MEM_HU(ctx->r12, 0X2ECE);
    // 0x8030247C: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80302480: addiu       $a0, $sp, 0x74
    ctx->r4 = ADD32(ctx->r29, 0X74);
    // 0x80302484: beq         $t4, $zero, L_80302498
    if (ctx->r12 == 0) {
        // 0x80302488: addiu       $a1, $zero, 0x167
        ctx->r5 = ADD32(0, 0X167);
            goto L_80302498;
    }
    // 0x80302488: addiu       $a1, $zero, 0x167
    ctx->r5 = ADD32(0, 0X167);
    // 0x8030248C: lhu         $v0, 0x2ECC($v0)
    ctx->r2 = MEM_HU(ctx->r2, 0X2ECC);
    // 0x80302490: slti        $at, $v0, 0x1F
    ctx->r1 = SIGNED(ctx->r2) < 0X1F ? 1 : 0;
    // 0x80302494: beq         $at, $zero, L_803024BC
    if (ctx->r1 == 0) {
        // 0x80302498: addiu       $a2, $zero, 0x262
        ctx->r6 = ADD32(0, 0X262);
            goto L_803024BC;
    }
L_80302498:
    // 0x80302498: addiu       $a2, $zero, 0x262
    ctx->r6 = ADD32(0, 0X262);
    // 0x8030249C: jal         0x802B96D0
    // 0x803024A0: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    func_802B96D0_6CAD80(rdram, ctx);
        goto after_9;
    // 0x803024A0: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    after_9:
    // 0x803024A4: addiu       $a0, $zero, 0x262
    ctx->r4 = ADD32(0, 0X262);
    // 0x803024A8: addiu       $a1, $zero, 0x6B
    ctx->r5 = ADD32(0, 0X6B);
    // 0x803024AC: jal         0x802C1A44
    // 0x803024B0: addiu       $a2, $sp, 0x74
    ctx->r6 = ADD32(ctx->r29, 0X74);
    func_802C1A44_6D30F4(rdram, ctx);
        goto after_10;
    // 0x803024B0: addiu       $a2, $sp, 0x74
    ctx->r6 = ADD32(ctx->r29, 0X74);
    after_10:
    // 0x803024B4: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x803024B8: lhu         $v0, 0x2ECC($v0)
    ctx->r2 = MEM_HU(ctx->r2, 0X2ECC);
L_803024BC:
    // 0x803024BC: beq         $v0, $zero, L_8030253C
    if (ctx->r2 == 0) {
        // 0x803024C0: nop
    
            goto L_8030253C;
    }
    // 0x803024C0: nop

    // 0x803024C4: jal         0x802DB8DC
    // 0x803024C8: nop

    backup_joint_positions(rdram, ctx);
        goto after_11;
    // 0x803024C8: nop

    after_11:
    // 0x803024CC: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x803024D0: lhu         $v0, 0x2ECE($v0)
    ctx->r2 = MEM_HU(ctx->r2, 0X2ECE);
    // 0x803024D4: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803024D8: lui         $a0, 0x803A
    ctx->r4 = S32(0X803A << 16);
    // 0x803024DC: beq         $v0, $at, L_803024F8
    if (ctx->r2 == ctx->r1) {
        // 0x803024E0: addiu       $a0, $a0, 0x5520
        ctx->r4 = ADD32(ctx->r4, 0X5520);
            goto L_803024F8;
    }
    // 0x803024E0: addiu       $a0, $a0, 0x5520
    ctx->r4 = ADD32(ctx->r4, 0X5520);
    // 0x803024E4: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x803024E8: beq         $v0, $at, L_8030251C
    if (ctx->r2 == ctx->r1) {
        // 0x803024EC: lui         $a0, 0x803A
        ctx->r4 = S32(0X803A << 16);
            goto L_8030251C;
    }
    // 0x803024EC: lui         $a0, 0x803A
    ctx->r4 = S32(0X803A << 16);
    // 0x803024F0: b           L_8030253C
    // 0x803024F4: nop

        goto L_8030253C;
    // 0x803024F4: nop

L_803024F8:
    // 0x803024F8: lui         $a1, 0x803A
    ctx->r5 = S32(0X803A << 16);
    // 0x803024FC: lui         $a2, 0x803A
    ctx->r6 = S32(0X803A << 16);
    // 0x80302500: lui         $a3, 0x803A
    ctx->r7 = S32(0X803A << 16);
    // 0x80302504: addiu       $a3, $a3, 0x5530
    ctx->r7 = ADD32(ctx->r7, 0X5530);
    // 0x80302508: addiu       $a2, $a2, 0x5528
    ctx->r6 = ADD32(ctx->r6, 0X5528);
    // 0x8030250C: jal         0x802DB670
    // 0x80302510: addiu       $a1, $a1, 0x5524
    ctx->r5 = ADD32(ctx->r5, 0X5524);
    func_802DB670_6ECD20(rdram, ctx);
        goto after_12;
    // 0x80302510: addiu       $a1, $a1, 0x5524
    ctx->r5 = ADD32(ctx->r5, 0X5524);
    after_12:
    // 0x80302514: b           L_8030253C
    // 0x80302518: nop

        goto L_8030253C;
    // 0x80302518: nop

L_8030251C:
    // 0x8030251C: lui         $a1, 0x803A
    ctx->r5 = S32(0X803A << 16);
    // 0x80302520: lui         $a2, 0x803A
    ctx->r6 = S32(0X803A << 16);
    // 0x80302524: lui         $a3, 0x803A
    ctx->r7 = S32(0X803A << 16);
    // 0x80302528: addiu       $a3, $a3, 0x5544
    ctx->r7 = ADD32(ctx->r7, 0X5544);
    // 0x8030252C: addiu       $a2, $a2, 0x5528
    ctx->r6 = ADD32(ctx->r6, 0X5528);
    // 0x80302530: addiu       $a1, $a1, 0x5524
    ctx->r5 = ADD32(ctx->r5, 0X5524);
    // 0x80302534: jal         0x802DB670
    // 0x80302538: addiu       $a0, $a0, 0x5520
    ctx->r4 = ADD32(ctx->r4, 0X5520);
    func_802DB670_6ECD20(rdram, ctx);
        goto after_13;
    // 0x80302538: addiu       $a0, $a0, 0x5520
    ctx->r4 = ADD32(ctx->r4, 0X5520);
    after_13:
L_8030253C:
    // 0x8030253C: jal         0x8038064C
    // 0x80302540: nop

    func_8038064C_791CFC(rdram, ctx);
        goto after_14;
    // 0x80302540: nop

    after_14:
    // 0x80302544: lui         $t2, 0x8020
    ctx->r10 = S32(0X8020 << 16);
    // 0x80302548: addiu       $t2, $t2, 0x4278
    ctx->r10 = ADD32(ctx->r10, 0X4278);
    // 0x8030254C: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x80302550: lui         $t3, 0x3
    ctx->r11 = S32(0X3 << 16);
    // 0x80302554: ori         $t3, $t3, 0x8000
    ctx->r11 = ctx->r11 | 0X8000;
    // 0x80302558: addu        $t8, $t0, $t3
    ctx->r24 = ADD32(ctx->r8, ctx->r11);
    // 0x8030255C: lw          $t1, 0x918($t8)
    ctx->r9 = MEM_W(ctx->r24, 0X918);
    // 0x80302560: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80302564: addiu       $t5, $t1, 0x1E
    ctx->r13 = ADD32(ctx->r9, 0X1E);
    // 0x80302568: slti        $at, $t5, 0xFA
    ctx->r1 = SIGNED(ctx->r13) < 0XFA ? 1 : 0;
    // 0x8030256C: beq         $at, $zero, L_80302C58
    if (ctx->r1 == 0) {
        // 0x80302570: nop
    
            goto L_80302C58;
    }
    // 0x80302570: nop

    // 0x80302574: lbu         $t6, 0x2EDA($t6)
    ctx->r14 = MEM_BU(ctx->r14, 0X2EDA);
    // 0x80302578: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8030257C: beq         $t6, $zero, L_80302C58
    if (ctx->r14 == 0) {
        // 0x80302580: nop
    
            goto L_80302C58;
    }
    // 0x80302580: nop

    // 0x80302584: lbu         $a0, 0x5538($a0)
    ctx->r4 = MEM_BU(ctx->r4, 0X5538);
    // 0x80302588: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x8030258C: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x80302590: bne         $a0, $zero, L_803025C8
    if (ctx->r4 != 0) {
        // 0x80302594: nop
    
            goto L_803025C8;
    }
    // 0x80302594: nop

    // 0x80302598: lbu         $v0, 0x2AA2($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X2AA2);
    // 0x8030259C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x803025A0: beq         $v0, $zero, L_803025C8
    if (ctx->r2 == 0) {
        // 0x803025A4: nop
    
            goto L_803025C8;
    }
    // 0x803025A4: nop

    // 0x803025A8: beq         $v0, $at, L_803025C8
    if (ctx->r2 == ctx->r1) {
        // 0x803025AC: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_803025C8;
    }
    // 0x803025AC: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803025B0: bne         $v0, $at, L_80302C58
    if (ctx->r2 != ctx->r1) {
        // 0x803025B4: lui         $t7, 0x803F
        ctx->r15 = S32(0X803F << 16);
            goto L_80302C58;
    }
    // 0x803025B4: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x803025B8: lbu         $t7, 0x2AA3($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X2AA3);
    // 0x803025BC: slti        $at, $t7, 0xB
    ctx->r1 = SIGNED(ctx->r15) < 0XB ? 1 : 0;
    // 0x803025C0: bne         $at, $zero, L_80302C58
    if (ctx->r1 != 0) {
        // 0x803025C4: nop
    
            goto L_80302C58;
    }
    // 0x803025C4: nop

L_803025C8:
    // 0x803025C8: lh          $t9, 0x2C18($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X2C18);
    // 0x803025CC: sll         $t7, $t1, 6
    ctx->r15 = S32(ctx->r9 << 6);
    // 0x803025D0: bne         $t9, $zero, L_80302628
    if (ctx->r25 != 0) {
        // 0x803025D4: nop
    
            goto L_80302628;
    }
    // 0x803025D4: nop

    // 0x803025D8: beq         $a0, $zero, L_80302628
    if (ctx->r4 == 0) {
        // 0x803025DC: lui         $t4, 0x803F
        ctx->r12 = S32(0X803F << 16);
            goto L_80302628;
    }
    // 0x803025DC: lui         $t4, 0x803F
    ctx->r12 = S32(0X803F << 16);
    // 0x803025E0: lh          $t4, 0x2A98($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X2A98);
    // 0x803025E4: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x803025E8: addiu       $t5, $t5, 0x28E0
    ctx->r13 = ADD32(ctx->r13, 0X28E0);
    // 0x803025EC: sll         $t8, $t4, 3
    ctx->r24 = S32(ctx->r12 << 3);
    // 0x803025F0: subu        $t8, $t8, $t4
    ctx->r24 = SUB32(ctx->r24, ctx->r12);
    // 0x803025F4: sll         $t8, $t8, 3
    ctx->r24 = S32(ctx->r24 << 3);
    // 0x803025F8: subu        $t8, $t8, $t4
    ctx->r24 = SUB32(ctx->r24, ctx->r12);
    // 0x803025FC: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x80302600: addu        $v0, $t8, $t5
    ctx->r2 = ADD32(ctx->r24, ctx->r13);
    // 0x80302604: lh          $v1, 0x0($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X0);
    // 0x80302608: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8030260C: beq         $v1, $at, L_8030261C
    if (ctx->r3 == ctx->r1) {
        // 0x80302610: addiu       $at, $zero, 0x11
        ctx->r1 = ADD32(0, 0X11);
            goto L_8030261C;
    }
    // 0x80302610: addiu       $at, $zero, 0x11
    ctx->r1 = ADD32(0, 0X11);
    // 0x80302614: bne         $v1, $at, L_80302628
    if (ctx->r3 != ctx->r1) {
        // 0x80302618: nop
    
            goto L_80302628;
    }
    // 0x80302618: nop

L_8030261C:
    // 0x8030261C: lb          $t6, 0x64($v0)
    ctx->r14 = MEM_B(ctx->r2, 0X64);
    // 0x80302620: addiu       $at, $zero, -0x3
    ctx->r1 = ADD32(0, -0X3);
    // 0x80302624: beq         $t6, $at, L_80302C58
    if (ctx->r14 == ctx->r1) {
        // 0x80302628: lui         $t9, 0x803D
        ctx->r25 = S32(0X803D << 16);
            goto L_80302C58;
    }
L_80302628:
    // 0x80302628: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x8030262C: lw          $t9, 0x552C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X552C);
    // 0x80302630: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x80302634: lw          $t5, 0x2EB0($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X2EB0);
    // 0x80302638: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x8030263C: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x80302640: addu        $a0, $t0, $t7
    ctx->r4 = ADD32(ctx->r8, ctx->r15);
    // 0x80302644: lh          $t4, 0x302($t9)
    ctx->r12 = MEM_H(ctx->r25, 0X302);
    // 0x80302648: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x8030264C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80302650: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80302654: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80302658: lw          $t7, 0x2EB4($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X2EB4);
    // 0x8030265C: negu        $t8, $t4
    ctx->r24 = SUB32(0, ctx->r12);
    // 0x80302660: lui         $t4, 0x803F
    ctx->r12 = S32(0X803F << 16);
    // 0x80302664: lw          $a1, 0x4($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X4);
    // 0x80302668: lw          $a2, 0x8($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X8);
    // 0x8030266C: lw          $a3, 0xC($v0)
    ctx->r7 = MEM_W(ctx->r2, 0XC);
    // 0x80302670: lw          $t4, 0x2EB8($t4)
    ctx->r12 = MEM_W(ctx->r12, 0X2EB8);
    // 0x80302674: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80302678: bgez        $t5, L_80302688
    if (SIGNED(ctx->r13) >= 0) {
        // 0x8030267C: sra         $t6, $t5, 2
        ctx->r14 = S32(SIGNED(ctx->r13) >> 2);
            goto L_80302688;
    }
    // 0x8030267C: sra         $t6, $t5, 2
    ctx->r14 = S32(SIGNED(ctx->r13) >> 2);
    // 0x80302680: addiu       $at, $t5, 0x3
    ctx->r1 = ADD32(ctx->r13, 0X3);
    // 0x80302684: sra         $t6, $at, 2
    ctx->r14 = S32(SIGNED(ctx->r1) >> 2);
L_80302688:
    // 0x80302688: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x8030268C: bgez        $t7, L_8030269C
    if (SIGNED(ctx->r15) >= 0) {
        // 0x80302690: sra         $t9, $t7, 2
        ctx->r25 = S32(SIGNED(ctx->r15) >> 2);
            goto L_8030269C;
    }
    // 0x80302690: sra         $t9, $t7, 2
    ctx->r25 = S32(SIGNED(ctx->r15) >> 2);
    // 0x80302694: addiu       $at, $t7, 0x3
    ctx->r1 = ADD32(ctx->r15, 0X3);
    // 0x80302698: sra         $t9, $at, 2
    ctx->r25 = S32(SIGNED(ctx->r1) >> 2);
L_8030269C:
    // 0x8030269C: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x803026A0: lui         $t5, 0x803F
    ctx->r13 = S32(0X803F << 16);
    // 0x803026A4: lh          $t5, 0x2ED2($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X2ED2);
    // 0x803026A8: lw          $t6, 0x2ED4($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X2ED4);
    // 0x803026AC: sw          $t9, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r25;
    // 0x803026B0: bgez        $t4, L_803026C0
    if (SIGNED(ctx->r12) >= 0) {
        // 0x803026B4: sra         $t8, $t4, 2
        ctx->r24 = S32(SIGNED(ctx->r12) >> 2);
            goto L_803026C0;
    }
    // 0x803026B4: sra         $t8, $t4, 2
    ctx->r24 = S32(SIGNED(ctx->r12) >> 2);
    // 0x803026B8: addiu       $at, $t4, 0x3
    ctx->r1 = ADD32(ctx->r12, 0X3);
    // 0x803026BC: sra         $t8, $at, 2
    ctx->r24 = S32(SIGNED(ctx->r1) >> 2);
L_803026C0:
    // 0x803026C0: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    // 0x803026C4: sw          $t5, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r13;
    // 0x803026C8: jal         0x80127640
    // 0x803026CC: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    func_80127640(rdram, ctx);
        goto after_15;
    // 0x803026CC: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    after_15:
    // 0x803026D0: lui         $t1, 0x801E
    ctx->r9 = S32(0X801E << 16);
    // 0x803026D4: addiu       $t1, $t1, -0x6178
    ctx->r9 = ADD32(ctx->r9, -0X6178);
    // 0x803026D8: lw          $v1, 0x0($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X0);
    // 0x803026DC: lui         $t9, 0x104
    ctx->r25 = S32(0X104 << 16);
    // 0x803026E0: lui         $t2, 0x8020
    ctx->r10 = S32(0X8020 << 16);
    // 0x803026E4: addiu       $t7, $v1, 0x8
    ctx->r15 = ADD32(ctx->r3, 0X8);
    // 0x803026E8: sw          $t7, 0x0($t1)
    MEM_W(0X0, ctx->r9) = ctx->r15;
    // 0x803026EC: ori         $t9, $t9, 0x40
    ctx->r25 = ctx->r25 | 0X40;
    // 0x803026F0: addiu       $t2, $t2, 0x4278
    ctx->r10 = ADD32(ctx->r10, 0X4278);
    // 0x803026F4: sw          $t9, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r25;
    // 0x803026F8: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x803026FC: lui         $t3, 0x3
    ctx->r11 = S32(0X3 << 16);
    // 0x80302700: ori         $t3, $t3, 0x8000
    ctx->r11 = ctx->r11 | 0X8000;
    // 0x80302704: addu        $t4, $t0, $t3
    ctx->r12 = ADD32(ctx->r8, ctx->r11);
    // 0x80302708: lw          $t8, 0x918($t4)
    ctx->r24 = MEM_W(ctx->r12, 0X918);
    // 0x8030270C: lui         $at, 0x8003
    ctx->r1 = S32(0X8003 << 16);
    // 0x80302710: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x80302714: sll         $t5, $t8, 6
    ctx->r13 = S32(ctx->r24 << 6);
    // 0x80302718: addu        $t6, $t0, $t5
    ctx->r14 = ADD32(ctx->r8, ctx->r13);
    // 0x8030271C: addu        $t7, $t6, $at
    ctx->r15 = ADD32(ctx->r14, ctx->r1);
    // 0x80302720: sw          $t7, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r15;
    // 0x80302724: lw          $t0, 0x0($t2)
    ctx->r8 = MEM_W(ctx->r10, 0X0);
    // 0x80302728: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x8030272C: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x80302730: addu        $t9, $t0, $t3
    ctx->r25 = ADD32(ctx->r8, ctx->r11);
    // 0x80302734: lw          $t4, 0x918($t9)
    ctx->r12 = MEM_W(ctx->r25, 0X918);
    // 0x80302738: addu        $at, $at, $t0
    ctx->r1 = ADD32(ctx->r1, ctx->r8);
    // 0x8030273C: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80302740: addiu       $t8, $t4, 0x1
    ctx->r24 = ADD32(ctx->r12, 0X1);
    // 0x80302744: sw          $t8, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r24;
    // 0x80302748: lw          $t5, 0x5524($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5524);
    // 0x8030274C: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80302750: addiu       $a2, $zero, 0x3
    ctx->r6 = ADD32(0, 0X3);
    // 0x80302754: lhu         $a0, 0xBA($t5)
    ctx->r4 = MEM_HU(ctx->r13, 0XBA);
    // 0x80302758: addiu       $a3, $zero, 0x3
    ctx->r7 = ADD32(0, 0X3);
    // 0x8030275C: sll         $t6, $a0, 3
    ctx->r14 = S32(ctx->r4 << 3);
    // 0x80302760: div         $zero, $t6, $at
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r1)));
    // 0x80302764: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80302768: lwc1        $f6, -0x3030($at)
    ctx->f6.u32l = MEM_W(ctx->r1, -0X3030);
    // 0x8030276C: mflo        $t7
    ctx->r15 = lo;
    // 0x80302770: sll         $t9, $t7, 16
    ctx->r25 = S32(ctx->r15 << 16);
    // 0x80302774: sra         $a0, $t9, 16
    ctx->r4 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80302778: jal         0x8038C230
    // 0x8030277C: swc1        $f6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f6.u32l;
    func_8038C230_79D8E0(rdram, ctx);
        goto after_16;
    // 0x8030277C: swc1        $f6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->f6.u32l;
    after_16:
    // 0x80302780: lui         $a3, 0xBEC2
    ctx->r7 = S32(0XBEC2 << 16);
    // 0x80302784: addiu       $t8, $zero, -0xBB8
    ctx->r24 = ADD32(0, -0XBB8);
    // 0x80302788: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x8030278C: ori         $a3, $a3, 0x8F5C
    ctx->r7 = ctx->r7 | 0X8F5C;
    // 0x80302790: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x80302794: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x80302798: jal         0x8038C484
    // 0x8030279C: addiu       $a2, $zero, 0x3
    ctx->r6 = ADD32(0, 0X3);
    func_8038C484_79DB34(rdram, ctx);
        goto after_17;
    // 0x8030279C: addiu       $a2, $zero, 0x3
    ctx->r6 = ADD32(0, 0X3);
    after_17:
    // 0x803027A0: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x803027A4: lw          $t5, 0x5530($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5530);
    // 0x803027A8: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x803027AC: lhu         $v0, 0x0($t5)
    ctx->r2 = MEM_HU(ctx->r13, 0X0);
    // 0x803027B0: slti        $at, $v0, 0x2C
    ctx->r1 = SIGNED(ctx->r2) < 0X2C ? 1 : 0;
    // 0x803027B4: beq         $at, $zero, L_803027E0
    if (ctx->r1 == 0) {
        // 0x803027B8: slti        $at, $v0, 0x29
        ctx->r1 = SIGNED(ctx->r2) < 0X29 ? 1 : 0;
            goto L_803027E0;
    }
    // 0x803027B8: slti        $at, $v0, 0x29
    ctx->r1 = SIGNED(ctx->r2) < 0X29 ? 1 : 0;
    // 0x803027BC: bne         $at, $zero, L_803027E0
    if (ctx->r1 != 0) {
        // 0x803027C0: lui         $v1, 0x803D
        ctx->r3 = S32(0X803D << 16);
            goto L_803027E0;
    }
    // 0x803027C0: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x803027C4: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x803027C8: lh          $t7, 0x30E($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X30E);
    // 0x803027CC: lh          $t6, 0x30A($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X30A);
    // 0x803027D0: sll         $t9, $t7, 3
    ctx->r25 = S32(ctx->r15 << 3);
    // 0x803027D4: subu        $t9, $t9, $t7
    ctx->r25 = SUB32(ctx->r25, ctx->r15);
    // 0x803027D8: subu        $t4, $t6, $t9
    ctx->r12 = SUB32(ctx->r14, ctx->r25);
    // 0x803027DC: sh          $t4, 0x30A($v1)
    MEM_H(0X30A, ctx->r3) = ctx->r12;
L_803027E0:
    // 0x803027E0: lb          $t8, 0x2D10($t8)
    ctx->r24 = MEM_B(ctx->r24, 0X2D10);
    // 0x803027E4: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x803027E8: bne         $t8, $zero, L_80302870
    if (ctx->r24 != 0) {
        // 0x803027EC: nop
    
            goto L_80302870;
    }
    // 0x803027EC: nop

    // 0x803027F0: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x803027F4: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x803027F8: lbu         $v0, 0x366($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X366);
    // 0x803027FC: beq         $v0, $at, L_80302870
    if (ctx->r2 == ctx->r1) {
        // 0x80302800: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80302870;
    }
    // 0x80302800: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80302804: beq         $v0, $at, L_80302870
    if (ctx->r2 == ctx->r1) {
        // 0x80302808: addiu       $a0, $sp, 0x72
        ctx->r4 = ADD32(ctx->r29, 0X72);
            goto L_80302870;
    }
    // 0x80302808: addiu       $a0, $sp, 0x72
    ctx->r4 = ADD32(ctx->r29, 0X72);
    // 0x8030280C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80302810: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80302814: lh          $t5, 0x308($v1)
    ctx->r13 = MEM_H(ctx->r3, 0X308);
    // 0x80302818: lh          $t7, 0x30A($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X30A);
    // 0x8030281C: lh          $t9, 0x24($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X24);
    // 0x80302820: addiu       $a1, $v1, 0x30A
    ctx->r5 = ADD32(ctx->r3, 0X30A);
    // 0x80302824: addu        $t6, $t5, $t7
    ctx->r14 = ADD32(ctx->r13, ctx->r15);
    // 0x80302828: sll         $t4, $t9, 4
    ctx->r12 = S32(ctx->r25 << 4);
    // 0x8030282C: subu        $t8, $t6, $t4
    ctx->r24 = SUB32(ctx->r14, ctx->r12);
    // 0x80302830: addiu       $t7, $zero, 0x3
    ctx->r15 = ADD32(0, 0X3);
    // 0x80302834: addiu       $t5, $zero, 0x3
    ctx->r13 = ADD32(0, 0X3);
    // 0x80302838: sh          $t8, 0x72($sp)
    MEM_H(0X72, ctx->r29) = ctx->r24;
    // 0x8030283C: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x80302840: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x80302844: lh          $t9, 0x24($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X24);
    // 0x80302848: addiu       $t4, $zero, 0x4
    ctx->r12 = ADD32(0, 0X4);
    // 0x8030284C: sw          $t4, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r12;
    // 0x80302850: sll         $t6, $t9, 4
    ctx->r14 = S32(ctx->r25 << 4);
    // 0x80302854: sw          $t6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r14;
    // 0x80302858: addiu       $a2, $zero, 0x60
    ctx->r6 = ADD32(0, 0X60);
    // 0x8030285C: jal         0x80300130
    // 0x80302860: addiu       $a3, $zero, -0x100
    ctx->r7 = ADD32(0, -0X100);
    func_80300130_7117E0(rdram, ctx);
        goto after_18;
    // 0x80302860: addiu       $a3, $zero, -0x100
    ctx->r7 = ADD32(0, -0X100);
    after_18:
    // 0x80302864: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80302868: b           L_80302880
    // 0x8030286C: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
        goto L_80302880;
    // 0x8030286C: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
L_80302870:
    // 0x80302870: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80302874: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x80302878: lh          $t8, 0x308($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X308);
    // 0x8030287C: sh          $t8, 0x72($sp)
    MEM_H(0X72, ctx->r29) = ctx->r24;
L_80302880:
    // 0x80302880: lh          $t5, 0x72($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X72);
    // 0x80302884: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80302888: addiu       $at, $zero, 0x8E
    ctx->r1 = ADD32(0, 0X8E);
    // 0x8030288C: sh          $t5, 0x308($v1)
    MEM_H(0X308, ctx->r3) = ctx->r13;
    // 0x80302890: lw          $t7, 0x5530($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5530);
    // 0x80302894: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80302898: lhu         $v0, 0x0($t7)
    ctx->r2 = MEM_HU(ctx->r15, 0X0);
    // 0x8030289C: beq         $v0, $at, L_803028AC
    if (ctx->r2 == ctx->r1) {
        // 0x803028A0: addiu       $at, $zero, 0x90
        ctx->r1 = ADD32(0, 0X90);
            goto L_803028AC;
    }
    // 0x803028A0: addiu       $at, $zero, 0x90
    ctx->r1 = ADD32(0, 0X90);
    // 0x803028A4: bnel        $v0, $at, L_803028D0
    if (ctx->r2 != ctx->r1) {
        // 0x803028A8: addiu       $at, $zero, 0x8F
        ctx->r1 = ADD32(0, 0X8F);
            goto L_803028D0;
    }
    goto skip_2;
    // 0x803028A8: addiu       $at, $zero, 0x8F
    ctx->r1 = ADD32(0, 0X8F);
    skip_2:
L_803028AC:
    // 0x803028AC: lh          $t9, 0x5540($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X5540);
    // 0x803028B0: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x803028B4: sll         $t6, $t9, 5
    ctx->r14 = S32(ctx->r25 << 5);
    // 0x803028B8: andi        $t4, $t6, 0xFF
    ctx->r12 = ctx->r14 & 0XFF;
    // 0x803028BC: jal         0x8034B848
    // 0x803028C0: sh          $t4, 0x6E($sp)
    MEM_H(0X6E, ctx->r29) = ctx->r12;
    func_8034B848_75CEF8(rdram, ctx);
        goto after_19;
    // 0x803028C0: sh          $t4, 0x6E($sp)
    MEM_H(0X6E, ctx->r29) = ctx->r12;
    after_19:
    // 0x803028C4: b           L_803028FC
    // 0x803028C8: nop

        goto L_803028FC;
    // 0x803028C8: nop

    // 0x803028CC: addiu       $at, $zero, 0x8F
    ctx->r1 = ADD32(0, 0X8F);
L_803028D0:
    // 0x803028D0: bne         $v0, $at, L_803028F8
    if (ctx->r2 != ctx->r1) {
        // 0x803028D4: lui         $t8, 0x803D
        ctx->r24 = S32(0X803D << 16);
            goto L_803028F8;
    }
    // 0x803028D4: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x803028D8: lh          $t8, 0x5540($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X5540);
    // 0x803028DC: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x803028E0: sll         $t5, $t8, 6
    ctx->r13 = S32(ctx->r24 << 6);
    // 0x803028E4: andi        $t7, $t5, 0xFF
    ctx->r15 = ctx->r13 & 0XFF;
    // 0x803028E8: jal         0x8034B848
    // 0x803028EC: sh          $t7, 0x6E($sp)
    MEM_H(0X6E, ctx->r29) = ctx->r15;
    func_8034B848_75CEF8(rdram, ctx);
        goto after_20;
    // 0x803028EC: sh          $t7, 0x6E($sp)
    MEM_H(0X6E, ctx->r29) = ctx->r15;
    after_20:
    // 0x803028F0: b           L_803028FC
    // 0x803028F4: nop

        goto L_803028FC;
    // 0x803028F4: nop

L_803028F8:
    // 0x803028F8: sh          $zero, 0x6E($sp)
    MEM_H(0X6E, ctx->r29) = 0;
L_803028FC:
    // 0x803028FC: lui         $t9, 0x803F
    ctx->r25 = S32(0X803F << 16);
    // 0x80302900: lbu         $t9, 0x2EDD($t9)
    ctx->r25 = MEM_BU(ctx->r25, 0X2EDD);
    // 0x80302904: lh          $v1, 0x72($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X72);
    // 0x80302908: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x8030290C: bne         $t9, $zero, L_80302970
    if (ctx->r25 != 0) {
        // 0x80302910: addiu       $a1, $zero, 0xE
        ctx->r5 = ADD32(0, 0XE);
            goto L_80302970;
    }
    // 0x80302910: addiu       $a1, $zero, 0xE
    ctx->r5 = ADD32(0, 0XE);
    // 0x80302914: sll         $t6, $v1, 5
    ctx->r14 = S32(ctx->r3 << 5);
    // 0x80302918: sll         $t4, $t6, 2
    ctx->r12 = S32(ctx->r14 << 2);
    // 0x8030291C: subu        $t4, $t4, $t6
    ctx->r12 = SUB32(ctx->r12, ctx->r14);
    // 0x80302920: sll         $t4, $t4, 3
    ctx->r12 = S32(ctx->r12 << 3);
    // 0x80302924: subu        $t4, $t4, $t6
    ctx->r12 = SUB32(ctx->r12, ctx->r14);
    // 0x80302928: sll         $t4, $t4, 1
    ctx->r12 = S32(ctx->r12 << 1);
    // 0x8030292C: lui         $at, 0x2E
    ctx->r1 = S32(0X2E << 16);
    // 0x80302930: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80302934: lh          $t7, 0x2ED0($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X2ED0);
    // 0x80302938: lh          $t9, 0x6E($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X6E);
    // 0x8030293C: addu        $t8, $t4, $at
    ctx->r24 = ADD32(ctx->r12, ctx->r1);
    // 0x80302940: lui         $t6, 0x401
    ctx->r14 = S32(0X401 << 16);
    // 0x80302944: addiu       $t6, $t6, -0x7710
    ctx->r14 = ADD32(ctx->r14, -0X7710);
    // 0x80302948: sra         $t5, $t8, 6
    ctx->r13 = S32(SIGNED(ctx->r24) >> 6);
    // 0x8030294C: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x80302950: sw          $t6, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r14;
    // 0x80302954: ori         $a2, $zero, 0xB800
    ctx->r6 = 0 | 0XB800;
    // 0x80302958: ori         $a3, $zero, 0xB800
    ctx->r7 = 0 | 0XB800;
    // 0x8030295C: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80302960: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80302964: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x80302968: jal         0x802C78B0
    // 0x8030296C: sw          $t9, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r25;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_21;
    // 0x8030296C: sw          $t9, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r25;
    after_21:
L_80302970:
    // 0x80302970: lh          $v1, 0x72($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X72);
    // 0x80302974: lui         $t1, 0x8020
    ctx->r9 = S32(0X8020 << 16);
    // 0x80302978: addiu       $t1, $t1, 0x3FE0
    ctx->r9 = ADD32(ctx->r9, 0X3FE0);
    // 0x8030297C: lh          $t4, 0x14($t1)
    ctx->r12 = MEM_H(ctx->r9, 0X14);
    // 0x80302980: lh          $t5, 0xC($t1)
    ctx->r13 = MEM_H(ctx->r9, 0XC);
    // 0x80302984: sll         $v0, $v1, 2
    ctx->r2 = S32(ctx->r3 << 2);
    // 0x80302988: subu        $v0, $v0, $v1
    ctx->r2 = SUB32(ctx->r2, ctx->r3);
    // 0x8030298C: addu        $t8, $t4, $v0
    ctx->r24 = ADD32(ctx->r12, ctx->r2);
    // 0x80302990: addu        $t7, $t5, $v0
    ctx->r15 = ADD32(ctx->r13, ctx->r2);
    // 0x80302994: sh          $t8, 0x14($t1)
    MEM_H(0X14, ctx->r9) = ctx->r24;
    // 0x80302998: sh          $t7, 0xC($t1)
    MEM_H(0XC, ctx->r9) = ctx->r15;
    // 0x8030299C: lui         $t0, 0x803F
    ctx->r8 = S32(0X803F << 16);
    // 0x803029A0: lh          $t0, 0x2ED8($t0)
    ctx->r8 = MEM_H(ctx->r8, 0X2ED8);
    // 0x803029A4: addiu       $t2, $zero, 0x2E
    ctx->r10 = ADD32(0, 0X2E);
    // 0x803029A8: sll         $t9, $v1, 5
    ctx->r25 = S32(ctx->r3 << 5);
    // 0x803029AC: beq         $t0, $zero, L_80302A10
    if (ctx->r8 == 0) {
        // 0x803029B0: sll         $v0, $t0, 11
        ctx->r2 = S32(ctx->r8 << 11);
            goto L_80302A10;
    }
    // 0x803029B0: sll         $v0, $t0, 11
    ctx->r2 = S32(ctx->r8 << 11);
    // 0x803029B4: subu        $t6, $v0, $t9
    ctx->r14 = SUB32(ctx->r2, ctx->r25);
    // 0x803029B8: multu       $t6, $t2
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803029BC: sll         $t8, $v1, 6
    ctx->r24 = S32(ctx->r3 << 6);
    // 0x803029C0: addu        $t5, $v0, $t8
    ctx->r13 = ADD32(ctx->r2, ctx->r24);
    // 0x803029C4: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x803029C8: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x803029CC: lui         $t4, 0x401
    ctx->r12 = S32(0X401 << 16);
    // 0x803029D0: addiu       $t4, $t4, -0x7620
    ctx->r12 = ADD32(ctx->r12, -0X7620);
    // 0x803029D4: sw          $t4, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r12;
    // 0x803029D8: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x803029DC: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x803029E0: mflo        $a2
    ctx->r6 = lo;
    // 0x803029E4: sra         $a3, $a2, 6
    ctx->r7 = S32(SIGNED(ctx->r6) >> 6);
    // 0x803029E8: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x803029EC: multu       $t5, $t2
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803029F0: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x803029F4: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x803029F8: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x803029FC: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x80302A00: mflo        $t7
    ctx->r15 = lo;
    // 0x80302A04: sra         $t9, $t7, 6
    ctx->r25 = S32(SIGNED(ctx->r15) >> 6);
    // 0x80302A08: jal         0x802C78B0
    // 0x80302A0C: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_22;
    // 0x80302A0C: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    after_22:
L_80302A10:
    // 0x80302A10: lui         $a0, 0x401
    ctx->r4 = S32(0X401 << 16);
    // 0x80302A14: lui         $a1, 0x401
    ctx->r5 = S32(0X401 << 16);
    // 0x80302A18: addiu       $a1, $a1, -0x75F0
    ctx->r5 = ADD32(ctx->r5, -0X75F0);
    // 0x80302A1C: jal         0x80356410
    // 0x80302A20: addiu       $a0, $a0, -0x73F0
    ctx->r4 = ADD32(ctx->r4, -0X73F0);
    load_1_tile(rdram, ctx);
        goto after_23;
    // 0x80302A20: addiu       $a0, $a0, -0x73F0
    ctx->r4 = ADD32(ctx->r4, -0X73F0);
    after_23:
    // 0x80302A24: lh          $v1, 0x72($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X72);
    // 0x80302A28: lui         $t5, 0x1
    ctx->r13 = S32(0X1 << 16);
    // 0x80302A2C: addiu       $v0, $zero, 0x2E
    ctx->r2 = ADD32(0, 0X2E);
    // 0x80302A30: sll         $t8, $v1, 5
    ctx->r24 = S32(ctx->r3 << 5);
    // 0x80302A34: subu        $t7, $t5, $t8
    ctx->r15 = SUB32(ctx->r13, ctx->r24);
    // 0x80302A38: multu       $t7, $v0
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80302A3C: sll         $t6, $v1, 6
    ctx->r14 = S32(ctx->r3 << 6);
    // 0x80302A40: lui         $t7, 0x803F
    ctx->r15 = S32(0X803F << 16);
    // 0x80302A44: lui         $at, 0x2E
    ctx->r1 = S32(0X2E << 16);
    // 0x80302A48: lh          $t7, 0x2ED0($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X2ED0);
    // 0x80302A4C: lui         $t9, 0x401
    ctx->r25 = S32(0X401 << 16);
    // 0x80302A50: addiu       $t9, $t9, -0x7D70
    ctx->r25 = ADD32(ctx->r25, -0X7D70);
    // 0x80302A54: sw          $t9, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r25;
    // 0x80302A58: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80302A5C: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80302A60: mflo        $a2
    ctx->r6 = lo;
    // 0x80302A64: sra         $a3, $a2, 6
    ctx->r7 = S32(SIGNED(ctx->r6) >> 6);
    // 0x80302A68: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x80302A6C: multu       $t6, $v0
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80302A70: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80302A74: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80302A78: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80302A7C: sw          $t7, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r15;
    // 0x80302A80: mflo        $t4
    ctx->r12 = lo;
    // 0x80302A84: addu        $t5, $t4, $at
    ctx->r13 = ADD32(ctx->r12, ctx->r1);
    // 0x80302A88: sra         $t8, $t5, 6
    ctx->r24 = S32(SIGNED(ctx->r13) >> 6);
    // 0x80302A8C: jal         0x802C78B0
    // 0x80302A90: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_24;
    // 0x80302A90: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    after_24:
    // 0x80302A94: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80302A98: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x80302A9C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80302AA0: lh          $v0, 0x5540($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X5540);
    // 0x80302AA4: lh          $t0, 0x30E($v1)
    ctx->r8 = MEM_H(ctx->r3, 0X30E);
    // 0x80302AA8: lui         $t1, 0x8020
    ctx->r9 = S32(0X8020 << 16);
    // 0x80302AAC: andi        $t8, $v0, 0x7F
    ctx->r24 = ctx->r2 & 0X7F;
    // 0x80302AB0: sll         $t6, $t0, 2
    ctx->r14 = S32(ctx->r8 << 2);
    // 0x80302AB4: subu        $t6, $t6, $t0
    ctx->r14 = SUB32(ctx->r14, ctx->r8);
    // 0x80302AB8: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x80302ABC: addu        $t6, $t6, $t0
    ctx->r14 = ADD32(ctx->r14, ctx->r8);
    // 0x80302AC0: sll         $t4, $t6, 17
    ctx->r12 = S32(ctx->r14 << 17);
    // 0x80302AC4: sra         $t5, $t4, 16
    ctx->r13 = S32(SIGNED(ctx->r12) >> 16);
    // 0x80302AC8: slti        $at, $t8, 0x8
    ctx->r1 = SIGNED(ctx->r24) < 0X8 ? 1 : 0;
    // 0x80302ACC: addiu       $t1, $t1, 0x3FE0
    ctx->r9 = ADD32(ctx->r9, 0X3FE0);
    // 0x80302AD0: or          $t0, $t5, $zero
    ctx->r8 = ctx->r13 | 0;
    // 0x80302AD4: beq         $at, $zero, L_80302AFC
    if (ctx->r1 == 0) {
        // 0x80302AD8: or          $v0, $t8, $zero
        ctx->r2 = ctx->r24 | 0;
            goto L_80302AFC;
    }
    // 0x80302AD8: or          $v0, $t8, $zero
    ctx->r2 = ctx->r24 | 0;
    // 0x80302ADC: sll         $a0, $t8, 5
    ctx->r4 = S32(ctx->r24 << 5);
    // 0x80302AE0: slt         $at, $a0, $t5
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r13) ? 1 : 0;
    // 0x80302AE4: bnel        $at, $zero, L_80302B40
    if (ctx->r1 != 0) {
        // 0x80302AE8: lbu         $v0, 0x366($v1)
        ctx->r2 = MEM_BU(ctx->r3, 0X366);
            goto L_80302B40;
    }
    goto skip_3;
    // 0x80302AE8: lbu         $v0, 0x366($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X366);
    skip_3:
    // 0x80302AEC: sll         $t0, $a0, 16
    ctx->r8 = S32(ctx->r4 << 16);
    // 0x80302AF0: sra         $t7, $t0, 16
    ctx->r15 = S32(SIGNED(ctx->r8) >> 16);
    // 0x80302AF4: b           L_80302B3C
    // 0x80302AF8: or          $t0, $t7, $zero
    ctx->r8 = ctx->r15 | 0;
        goto L_80302B3C;
    // 0x80302AF8: or          $t0, $t7, $zero
    ctx->r8 = ctx->r15 | 0;
L_80302AFC:
    // 0x80302AFC: slti        $at, $v0, 0x10
    ctx->r1 = SIGNED(ctx->r2) < 0X10 ? 1 : 0;
    // 0x80302B00: beql        $at, $zero, L_80302B14
    if (ctx->r1 == 0) {
        // 0x80302B04: slti        $at, $v0, 0x18
        ctx->r1 = SIGNED(ctx->r2) < 0X18 ? 1 : 0;
            goto L_80302B14;
    }
    goto skip_4;
    // 0x80302B04: slti        $at, $v0, 0x18
    ctx->r1 = SIGNED(ctx->r2) < 0X18 ? 1 : 0;
    skip_4:
    // 0x80302B08: b           L_80302B3C
    // 0x80302B0C: addiu       $t0, $zero, 0x100
    ctx->r8 = ADD32(0, 0X100);
        goto L_80302B3C;
    // 0x80302B0C: addiu       $t0, $zero, 0x100
    ctx->r8 = ADD32(0, 0X100);
    // 0x80302B10: slti        $at, $v0, 0x18
    ctx->r1 = SIGNED(ctx->r2) < 0X18 ? 1 : 0;
L_80302B14:
    // 0x80302B14: beq         $at, $zero, L_80302B3C
    if (ctx->r1 == 0) {
        // 0x80302B18: sll         $t9, $v0, 5
        ctx->r25 = S32(ctx->r2 << 5);
            goto L_80302B3C;
    }
    // 0x80302B18: sll         $t9, $v0, 5
    ctx->r25 = S32(ctx->r2 << 5);
    // 0x80302B1C: addiu       $t6, $zero, 0x300
    ctx->r14 = ADD32(0, 0X300);
    // 0x80302B20: subu        $a0, $t6, $t9
    ctx->r4 = SUB32(ctx->r14, ctx->r25);
    // 0x80302B24: slt         $at, $a0, $t0
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r8) ? 1 : 0;
    // 0x80302B28: bnel        $at, $zero, L_80302B40
    if (ctx->r1 != 0) {
        // 0x80302B2C: lbu         $v0, 0x366($v1)
        ctx->r2 = MEM_BU(ctx->r3, 0X366);
            goto L_80302B40;
    }
    goto skip_5;
    // 0x80302B2C: lbu         $v0, 0x366($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X366);
    skip_5:
    // 0x80302B30: sll         $t0, $a0, 16
    ctx->r8 = S32(ctx->r4 << 16);
    // 0x80302B34: sra         $t4, $t0, 16
    ctx->r12 = S32(SIGNED(ctx->r8) >> 16);
    // 0x80302B38: or          $t0, $t4, $zero
    ctx->r8 = ctx->r12 | 0;
L_80302B3C:
    // 0x80302B3C: lbu         $v0, 0x366($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X366);
L_80302B40:
    // 0x80302B40: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80302B44: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    // 0x80302B48: beq         $v0, $at, L_80302B5C
    if (ctx->r2 == ctx->r1) {
        // 0x80302B4C: addiu       $a1, $zero, 0x2
        ctx->r5 = ADD32(0, 0X2);
            goto L_80302B5C;
    }
    // 0x80302B4C: addiu       $a1, $zero, 0x2
    ctx->r5 = ADD32(0, 0X2);
    // 0x80302B50: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80302B54: bnel        $v0, $at, L_80302B64
    if (ctx->r2 != ctx->r1) {
        // 0x80302B58: sll         $v0, $t0, 2
        ctx->r2 = S32(ctx->r8 << 2);
            goto L_80302B64;
    }
    goto skip_6;
    // 0x80302B58: sll         $v0, $t0, 2
    ctx->r2 = S32(ctx->r8 << 2);
    skip_6:
L_80302B5C:
    // 0x80302B5C: addiu       $t0, $zero, 0xFF
    ctx->r8 = ADD32(0, 0XFF);
    // 0x80302B60: sll         $v0, $t0, 2
    ctx->r2 = S32(ctx->r8 << 2);
L_80302B64:
    // 0x80302B64: subu        $v0, $v0, $t0
    ctx->r2 = SUB32(ctx->r2, ctx->r8);
    // 0x80302B68: sll         $v0, $v0, 2
    ctx->r2 = S32(ctx->r2 << 2);
    // 0x80302B6C: subu        $v0, $v0, $t0
    ctx->r2 = SUB32(ctx->r2, ctx->r8);
    // 0x80302B70: sll         $v0, $v0, 2
    ctx->r2 = S32(ctx->r2 << 2);
    // 0x80302B74: addu        $v0, $v0, $t0
    ctx->r2 = ADD32(ctx->r2, ctx->r8);
    // 0x80302B78: sll         $v0, $v0, 3
    ctx->r2 = S32(ctx->r2 << 3);
    // 0x80302B7C: subu        $v0, $v0, $t0
    ctx->r2 = SUB32(ctx->r2, ctx->r8);
    // 0x80302B80: lh          $t8, 0xC($t1)
    ctx->r24 = MEM_H(ctx->r9, 0XC);
    // 0x80302B84: lh          $t6, 0x14($t1)
    ctx->r14 = MEM_H(ctx->r9, 0X14);
    // 0x80302B88: sll         $v0, $v0, 3
    ctx->r2 = S32(ctx->r2 << 3);
    // 0x80302B8C: sra         $t5, $v0, 12
    ctx->r13 = S32(SIGNED(ctx->r2) >> 12);
    // 0x80302B90: slti        $at, $t0, 0x100
    ctx->r1 = SIGNED(ctx->r8) < 0X100 ? 1 : 0;
    // 0x80302B94: addu        $t7, $t8, $t5
    ctx->r15 = ADD32(ctx->r24, ctx->r13);
    // 0x80302B98: addu        $t9, $t6, $t5
    ctx->r25 = ADD32(ctx->r14, ctx->r13);
    // 0x80302B9C: sh          $t7, 0xC($t1)
    MEM_H(0XC, ctx->r9) = ctx->r15;
    // 0x80302BA0: beq         $at, $zero, L_80302C38
    if (ctx->r1 == 0) {
        // 0x80302BA4: sh          $t9, 0x14($t1)
        MEM_H(0X14, ctx->r9) = ctx->r25;
            goto L_80302C38;
    }
    // 0x80302BA4: sh          $t9, 0x14($t1)
    MEM_H(0X14, ctx->r9) = ctx->r25;
    // 0x80302BA8: lh          $v1, 0x72($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X72);
    // 0x80302BAC: lui         $v0, 0x803F
    ctx->r2 = S32(0X803F << 16);
    // 0x80302BB0: lw          $v0, 0x2EC8($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X2EC8);
    // 0x80302BB4: sll         $t4, $v1, 5
    ctx->r12 = S32(ctx->r3 << 5);
    // 0x80302BB8: addiu       $t7, $zero, 0x100
    ctx->r15 = ADD32(0, 0X100);
    // 0x80302BBC: sll         $t9, $v1, 6
    ctx->r25 = S32(ctx->r3 << 6);
    // 0x80302BC0: subu        $a2, $v0, $t4
    ctx->r6 = SUB32(ctx->r2, ctx->r12);
    // 0x80302BC4: subu        $t6, $t7, $t0
    ctx->r14 = SUB32(ctx->r15, ctx->r8);
    // 0x80302BC8: addu        $t4, $v0, $t9
    ctx->r12 = ADD32(ctx->r2, ctx->r25);
    // 0x80302BCC: multu       $t6, $t4
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r12)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80302BD0: sll         $t5, $a2, 2
    ctx->r13 = S32(ctx->r6 << 2);
    // 0x80302BD4: subu        $t5, $t5, $a2
    ctx->r13 = SUB32(ctx->r13, ctx->r6);
    // 0x80302BD8: sll         $t5, $t5, 3
    ctx->r13 = S32(ctx->r13 << 3);
    // 0x80302BDC: subu        $t5, $t5, $a2
    ctx->r13 = SUB32(ctx->r13, ctx->r6);
    // 0x80302BE0: sll         $t5, $t5, 1
    ctx->r13 = S32(ctx->r13 << 1);
    // 0x80302BE4: sra         $a3, $t5, 6
    ctx->r7 = S32(SIGNED(ctx->r13) >> 6);
    // 0x80302BE8: lui         $t6, 0x803F
    ctx->r14 = S32(0X803F << 16);
    // 0x80302BEC: lh          $t6, 0x2ED0($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X2ED0);
    // 0x80302BF0: lui         $t4, 0x401
    ctx->r12 = S32(0X401 << 16);
    // 0x80302BF4: mflo        $t5
    ctx->r13 = lo;
    // 0x80302BF8: sra         $t8, $t5, 8
    ctx->r24 = S32(SIGNED(ctx->r13) >> 8);
    // 0x80302BFC: sll         $t7, $t8, 2
    ctx->r15 = S32(ctx->r24 << 2);
    // 0x80302C00: subu        $t7, $t7, $t8
    ctx->r15 = SUB32(ctx->r15, ctx->r24);
    // 0x80302C04: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x80302C08: subu        $t7, $t7, $t8
    ctx->r15 = SUB32(ctx->r15, ctx->r24);
    // 0x80302C0C: sll         $t7, $t7, 1
    ctx->r15 = S32(ctx->r15 << 1);
    // 0x80302C10: sra         $t9, $t7, 6
    ctx->r25 = S32(SIGNED(ctx->r15) >> 6);
    // 0x80302C14: addiu       $t4, $t4, -0x7BE0
    ctx->r12 = ADD32(ctx->r12, -0X7BE0);
    // 0x80302C18: sw          $t4, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r12;
    // 0x80302C1C: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x80302C20: or          $a2, $a3, $zero
    ctx->r6 = ctx->r7 | 0;
    // 0x80302C24: sw          $zero, 0x18($sp)
    MEM_W(0X18, ctx->r29) = 0;
    // 0x80302C28: sw          $zero, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = 0;
    // 0x80302C2C: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80302C30: jal         0x802C78B0
    // 0x80302C34: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    func_802C78B0_6D8F60(rdram, ctx);
        goto after_25;
    // 0x80302C34: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    after_25:
L_80302C38:
    // 0x80302C38: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x80302C3C: addiu       $a0, $a0, -0x6178
    ctx->r4 = ADD32(ctx->r4, -0X6178);
    // 0x80302C40: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x80302C44: lui         $t8, 0xBD00
    ctx->r24 = S32(0XBD00 << 16);
    // 0x80302C48: addiu       $t5, $v1, 0x8
    ctx->r13 = ADD32(ctx->r3, 0X8);
    // 0x80302C4C: sw          $t5, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r13;
    // 0x80302C50: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x80302C54: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
L_80302C58:
    // 0x80302C58: jal         0x8035D6A0
    // 0x80302C5C: nop

    func_8035D6A0_76ED50(rdram, ctx);
        goto after_26;
    // 0x80302C5C: nop

    after_26:
    // 0x80302C60: b           L_80302C74
    // 0x80302C64: lh          $v0, 0x70($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X70);
        goto L_80302C74;
    // 0x80302C64: lh          $v0, 0x70($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X70);
L_80302C68:
    // 0x80302C68: jal         0x8035D6D0
    // 0x80302C6C: nop

    func_8035D6D0_76ED80(rdram, ctx);
        goto after_27;
    // 0x80302C6C: nop

    after_27:
    // 0x80302C70: lh          $v0, 0x70($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X70);
L_80302C74:
    // 0x80302C74: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80302C78: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80302C7C: beq         $v0, $zero, L_80302C8C
    if (ctx->r2 == 0) {
        // 0x80302C80: lui         $t9, 0x803D
        ctx->r25 = S32(0X803D << 16);
            goto L_80302C8C;
    }
    // 0x80302C80: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80302C84: bne         $v0, $at, L_80302D00
    if (ctx->r2 != ctx->r1) {
        // 0x80302C88: nop
    
            goto L_80302D00;
    }
    // 0x80302C88: nop

L_80302C8C:
    // 0x80302C8C: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x80302C90: lw          $t9, 0x5524($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5524);
    // 0x80302C94: lh          $t7, 0xC($v1)
    ctx->r15 = MEM_H(ctx->r3, 0XC);
    // 0x80302C98: lhu         $t6, 0xBA($t9)
    ctx->r14 = MEM_HU(ctx->r25, 0XBA);
    // 0x80302C9C: lh          $a0, 0x4($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X4);
    // 0x80302CA0: lh          $a1, 0x8($v1)
    ctx->r5 = MEM_H(ctx->r3, 0X8);
    // 0x80302CA4: lh          $a3, 0x302($v1)
    ctx->r7 = MEM_H(ctx->r3, 0X302);
    // 0x80302CA8: sra         $t4, $t6, 1
    ctx->r12 = S32(SIGNED(ctx->r14) >> 1);
    // 0x80302CAC: addu        $a2, $t7, $t4
    ctx->r6 = ADD32(ctx->r15, ctx->r12);
    // 0x80302CB0: sll         $t5, $a2, 16
    ctx->r13 = S32(ctx->r6 << 16);
    // 0x80302CB4: sra         $a2, $t5, 16
    ctx->r6 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80302CB8: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x80302CBC: lbu         $t5, 0x5538($t5)
    ctx->r13 = MEM_BU(ctx->r13, 0X5538);
    // 0x80302CC0: lui         $t9, 0x103
    ctx->r25 = S32(0X103 << 16);
    // 0x80302CC4: addiu       $t9, $t9, 0x3190
    ctx->r25 = ADD32(ctx->r25, 0X3190);
    // 0x80302CC8: addiu       $t4, $zero, 0x9B
    ctx->r12 = ADD32(0, 0X9B);
    // 0x80302CCC: addiu       $t7, $zero, 0xF
    ctx->r15 = ADD32(0, 0XF);
    // 0x80302CD0: addiu       $t6, $zero, 0xF
    ctx->r14 = ADD32(0, 0XF);
    // 0x80302CD4: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x80302CD8: sw          $t7, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r15;
    // 0x80302CDC: sw          $t4, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r12;
    // 0x80302CE0: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x80302CE4: sw          $zero, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = 0;
    // 0x80302CE8: sw          $zero, 0x28($sp)
    MEM_W(0X28, ctx->r29) = 0;
    // 0x80302CEC: sw          $zero, 0x24($sp)
    MEM_W(0X24, ctx->r29) = 0;
    // 0x80302CF0: sw          $zero, 0x20($sp)
    MEM_W(0X20, ctx->r29) = 0;
    // 0x80302CF4: jal         0x8034BD20
    // 0x80302CF8: sw          $t5, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r13;
    func_8034BD20_75D3D0(rdram, ctx);
        goto after_28;
    // 0x80302CF8: sw          $t5, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r13;
    after_28:
    // 0x80302CFC: lh          $v0, 0x70($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X70);
L_80302D00:
    // 0x80302D00: bne         $v0, $zero, L_80302D3C
    if (ctx->r2 != 0) {
        // 0x80302D04: lui         $a0, 0x803D
        ctx->r4 = S32(0X803D << 16);
            goto L_80302D3C;
    }
    // 0x80302D04: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80302D08: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80302D0C: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x80302D10: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    // 0x80302D14: addiu       $a2, $zero, 0x2
    ctx->r6 = ADD32(0, 0X2);
    // 0x80302D18: addiu       $a3, $zero, 0x21A
    ctx->r7 = ADD32(0, 0X21A);
    // 0x80302D1C: jal         0x80303820
    // 0x80302D20: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    func_80303820_714ED0(rdram, ctx);
        goto after_29;
    // 0x80302D20: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_29:
    // 0x80302D24: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80302D28: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x80302D2C: jal         0x80303D50
    // 0x80302D30: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    func_80303D50_715400(rdram, ctx);
        goto after_30;
    // 0x80302D30: addiu       $a1, $zero, 0x1
    ctx->r5 = ADD32(0, 0X1);
    after_30:
    // 0x80302D34: b           L_80302D50
    // 0x80302D38: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
        goto L_80302D50;
    // 0x80302D38: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
L_80302D3C:
    // 0x80302D3C: lw          $a0, 0x552C($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X552C);
    // 0x80302D40: addiu       $a1, $zero, 0x21A
    ctx->r5 = ADD32(0, 0X21A);
    // 0x80302D44: jal         0x80303D00
    // 0x80302D48: addiu       $a2, $zero, 0x262
    ctx->r6 = ADD32(0, 0X262);
    func_80303D00_7153B0(rdram, ctx);
        goto after_31;
    // 0x80302D48: addiu       $a2, $zero, 0x262
    ctx->r6 = ADD32(0, 0X262);
    after_31:
    // 0x80302D4C: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
L_80302D50:
    // 0x80302D50: addiu       $sp, $sp, 0x78
    ctx->r29 = ADD32(ctx->r29, 0X78);
    // 0x80302D54: jr          $ra
    // 0x80302D58: nop

    return;
    // 0x80302D58: nop

;}
RECOMP_FUNC void func_80302D5C_71440C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80302D5C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80302D60: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x80302D64: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80302D68: lhu         $t6, 0x5544($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X5544);
    // 0x80302D6C: lw          $t7, 0x0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X0);
    // 0x80302D70: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x80302D74: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x80302D78: sh          $t6, 0x32A($t7)
    MEM_H(0X32A, ctx->r15) = ctx->r14;
    // 0x80302D7C: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x80302D80: addiu       $t8, $zero, 0x2
    ctx->r24 = ADD32(0, 0X2);
    // 0x80302D84: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80302D88: sb          $t8, 0x365($t9)
    MEM_B(0X365, ctx->r25) = ctx->r24;
    // 0x80302D8C: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80302D90: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80302D94: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80302D98: lh          $t0, 0x8($v0)
    ctx->r8 = MEM_H(ctx->r2, 0X8);
    // 0x80302D9C: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x80302DA0: addiu       $a0, $zero, 0x39
    ctx->r4 = ADD32(0, 0X39);
    // 0x80302DA4: sw          $t0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r8;
    // 0x80302DA8: lh          $t1, 0xC($v0)
    ctx->r9 = MEM_H(ctx->r2, 0XC);
    // 0x80302DAC: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x80302DB0: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80302DB4: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    // 0x80302DB8: jal         0x8032C360
    // 0x80302DBC: sw          $t1, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r9;
    play_sound_effect_at_location(rdram, ctx);
        goto after_0;
    // 0x80302DBC: sw          $t1, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r9;
    after_0:
    // 0x80302DC0: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    // 0x80302DC4: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x80302DC8: jr          $ra
    // 0x80302DCC: nop

    return;
    // 0x80302DCC: nop

;}
RECOMP_FUNC void frog_croak(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80302DD0: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80302DD4: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x80302DD8: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80302DDC: lhu         $t6, 0x5544($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X5544);
    // 0x80302DE0: lw          $t7, 0x0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X0);
    // 0x80302DE4: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x80302DE8: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x80302DEC: sh          $t6, 0x32A($t7)
    MEM_H(0X32A, ctx->r15) = ctx->r14;
    // 0x80302DF0: lw          $t9, 0x0($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X0);
    // 0x80302DF4: addiu       $t8, $zero, 0x2
    ctx->r24 = ADD32(0, 0X2);
    // 0x80302DF8: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80302DFC: sb          $t8, 0x365($t9)
    MEM_B(0X365, ctx->r25) = ctx->r24;
    // 0x80302E00: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80302E04: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80302E08: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80302E0C: lh          $t0, 0x8($v0)
    ctx->r8 = MEM_H(ctx->r2, 0X8);
    // 0x80302E10: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x80302E14: addiu       $a0, $zero, 0x39
    ctx->r4 = ADD32(0, 0X39);
    // 0x80302E18: sw          $t0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r8;
    // 0x80302E1C: lh          $t1, 0xC($v0)
    ctx->r9 = MEM_H(ctx->r2, 0XC);
    // 0x80302E20: addiu       $a1, $zero, 0x5000
    ctx->r5 = ADD32(0, 0X5000);
    // 0x80302E24: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80302E28: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    // 0x80302E2C: jal         0x8032C360
    // 0x80302E30: sw          $t1, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r9;
    play_sound_effect_at_location(rdram, ctx);
        goto after_0;
    // 0x80302E30: sw          $t1, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r9;
    after_0:
    // 0x80302E34: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    // 0x80302E38: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    // 0x80302E3C: jr          $ra
    // 0x80302E40: nop

    return;
    // 0x80302E40: nop

;}
RECOMP_FUNC void func_80302E50_714500(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80302E50: addiu       $sp, $sp, -0x30
    ctx->r29 = ADD32(ctx->r29, -0X30);
    // 0x80302E54: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80302E58: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80302E5C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80302E60: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x80302E64: sw          $s0, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r16;
    // 0x80302E68: sw          $a0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r4;
    // 0x80302E6C: sw          $a1, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r5;
    // 0x80302E70: sw          $a2, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r6;
    // 0x80302E74: lh          $v1, 0x310($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X310);
    // 0x80302E78: lh          $t7, 0x30C($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X30C);
    // 0x80302E7C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80302E80: sll         $a3, $v1, 16
    ctx->r7 = S32(ctx->r3 << 16);
    // 0x80302E84: addu        $t8, $v1, $t7
    ctx->r24 = ADD32(ctx->r3, ctx->r15);
    // 0x80302E88: andi        $t9, $t8, 0x3FF
    ctx->r25 = ctx->r24 & 0X3FF;
    // 0x80302E8C: sh          $t9, 0x310($v0)
    MEM_H(0X310, ctx->r2) = ctx->r25;
    // 0x80302E90: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80302E94: sra         $t6, $a3, 16
    ctx->r14 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80302E98: or          $a3, $t6, $zero
    ctx->r7 = ctx->r14 | 0;
    // 0x80302E9C: lh          $s0, 0x30E($v0)
    ctx->r16 = MEM_H(ctx->r2, 0X30E);
    // 0x80302EA0: beq         $s0, $zero, L_80302FD0
    if (ctx->r16 == 0) {
        // 0x80302EA4: nop
    
            goto L_80302FD0;
    }
    // 0x80302EA4: nop

    // 0x80302EA8: lbu         $a0, 0x5538($a0)
    ctx->r4 = MEM_BU(ctx->r4, 0X5538);
    // 0x80302EAC: beq         $a0, $zero, L_80302F14
    if (ctx->r4 == 0) {
        // 0x80302EB0: nop
    
            goto L_80302F14;
    }
    // 0x80302EB0: nop

    // 0x80302EB4: lh          $t5, 0x310($v0)
    ctx->r13 = MEM_H(ctx->r2, 0X310);
    // 0x80302EB8: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x80302EBC: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80302EC0: slt         $at, $t5, $t6
    ctx->r1 = SIGNED(ctx->r13) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x80302EC4: beq         $at, $zero, L_80302F14
    if (ctx->r1 == 0) {
        // 0x80302EC8: sll         $t6, $a1, 26
        ctx->r14 = S32(ctx->r5 << 26);
            goto L_80302F14;
    }
    // 0x80302EC8: sll         $t6, $a1, 26
    ctx->r14 = S32(ctx->r5 << 26);
    // 0x80302ECC: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80302ED0: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80302ED4: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80302ED8: mtc1        $at, $f4
    ctx->f4.u32l = ctx->r1;
    // 0x80302EDC: lh          $t8, 0x8($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X8);
    // 0x80302EE0: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x80302EE4: addiu       $a0, $zero, 0x9
    ctx->r4 = ADD32(0, 0X9);
    // 0x80302EE8: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80302EEC: lh          $t9, 0xC($v0)
    ctx->r25 = MEM_H(ctx->r2, 0XC);
    // 0x80302EF0: sra         $a1, $t6, 16
    ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80302EF4: swc1        $f4, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f4.u32l;
    // 0x80302EF8: jal         0x8032C360
    // 0x80302EFC: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    play_sound_effect_at_location(rdram, ctx);
        goto after_0;
    // 0x80302EFC: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_0:
    // 0x80302F00: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x80302F04: lw          $t5, 0x552C($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X552C);
    // 0x80302F08: lh          $v1, 0x310($t5)
    ctx->r3 = MEM_H(ctx->r13, 0X310);
    // 0x80302F0C: b           L_80302F7C
    // 0x80302F10: lh          $s0, 0x30E($t5)
    ctx->r16 = MEM_H(ctx->r13, 0X30E);
        goto L_80302F7C;
    // 0x80302F10: lh          $s0, 0x30E($t5)
    ctx->r16 = MEM_H(ctx->r13, 0X30E);
L_80302F14:
    // 0x80302F14: beq         $a0, $zero, L_80302F7C
    if (ctx->r4 == 0) {
        // 0x80302F18: lh          $v1, 0x310($v0)
        ctx->r3 = MEM_H(ctx->r2, 0X310);
            goto L_80302F7C;
    }
    // 0x80302F18: lh          $v1, 0x310($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X310);
    // 0x80302F1C: slti        $at, $v1, 0x201
    ctx->r1 = SIGNED(ctx->r3) < 0X201 ? 1 : 0;
    // 0x80302F20: bne         $at, $zero, L_80302F7C
    if (ctx->r1 != 0) {
        // 0x80302F24: slti        $at, $a3, 0x201
        ctx->r1 = SIGNED(ctx->r7) < 0X201 ? 1 : 0;
            goto L_80302F7C;
    }
    // 0x80302F24: slti        $at, $a3, 0x201
    ctx->r1 = SIGNED(ctx->r7) < 0X201 ? 1 : 0;
    // 0x80302F28: beq         $at, $zero, L_80302F7C
    if (ctx->r1 == 0) {
        // 0x80302F2C: addiu       $a0, $zero, 0xA
        ctx->r4 = ADD32(0, 0XA);
            goto L_80302F7C;
    }
    // 0x80302F2C: addiu       $a0, $zero, 0xA
    ctx->r4 = ADD32(0, 0XA);
    // 0x80302F30: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80302F34: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80302F38: lui         $at, 0x3F80
    ctx->r1 = S32(0X3F80 << 16);
    // 0x80302F3C: mtc1        $at, $f6
    ctx->f6.u32l = ctx->r1;
    // 0x80302F40: lh          $t8, 0x8($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X8);
    // 0x80302F44: lh          $a3, 0x4($v0)
    ctx->r7 = MEM_H(ctx->r2, 0X4);
    // 0x80302F48: or          $a1, $s0, $zero
    ctx->r5 = ctx->r16 | 0;
    // 0x80302F4C: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80302F50: lh          $t9, 0xC($v0)
    ctx->r25 = MEM_H(ctx->r2, 0XC);
    // 0x80302F54: sll         $t6, $a1, 26
    ctx->r14 = S32(ctx->r5 << 26);
    // 0x80302F58: sra         $a1, $t6, 16
    ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80302F5C: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80302F60: swc1        $f6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->f6.u32l;
    // 0x80302F64: jal         0x8032C360
    // 0x80302F68: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    play_sound_effect_at_location(rdram, ctx);
        goto after_1;
    // 0x80302F68: sw          $t9, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r25;
    after_1:
    // 0x80302F6C: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x80302F70: lw          $t5, 0x552C($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X552C);
    // 0x80302F74: lh          $v1, 0x310($t5)
    ctx->r3 = MEM_H(ctx->r13, 0X310);
    // 0x80302F78: lh          $s0, 0x30E($t5)
    ctx->r16 = MEM_H(ctx->r13, 0X30E);
L_80302F7C:
    // 0x80302F7C: sra         $t8, $v1, 2
    ctx->r24 = S32(SIGNED(ctx->r3) >> 2);
    // 0x80302F80: lui         $t1, 0x8015
    ctx->r9 = S32(0X8015 << 16);
    // 0x80302F84: andi        $t9, $t8, 0xFF
    ctx->r25 = ctx->r24 & 0XFF;
    // 0x80302F88: addiu       $t1, $t1, 0x2C78
    ctx->r9 = ADD32(ctx->r9, 0X2C78);
    // 0x80302F8C: sll         $t5, $t9, 1
    ctx->r13 = S32(ctx->r25 << 1);
    // 0x80302F90: addu        $t6, $t1, $t5
    ctx->r14 = ADD32(ctx->r9, ctx->r13);
    // 0x80302F94: lh          $t7, 0x0($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X0);
    // 0x80302F98: sra         $t8, $t7, 7
    ctx->r24 = S32(SIGNED(ctx->r15) >> 7);
    // 0x80302F9C: multu       $t8, $s0
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r16)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80302FA0: mflo        $v0
    ctx->r2 = lo;
    // 0x80302FA4: sra         $t2, $v0, 9
    ctx->r10 = S32(SIGNED(ctx->r2) >> 9);
    // 0x80302FA8: sll         $t9, $t2, 16
    ctx->r25 = S32(ctx->r10 << 16);
    // 0x80302FAC: negu        $t4, $v0
    ctx->r12 = SUB32(0, ctx->r2);
    // 0x80302FB0: sra         $t2, $t9, 16
    ctx->r10 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80302FB4: sra         $t3, $v0, 10
    ctx->r11 = S32(SIGNED(ctx->r2) >> 10);
    // 0x80302FB8: sra         $t8, $t4, 7
    ctx->r24 = S32(SIGNED(ctx->r12) >> 7);
    // 0x80302FBC: sll         $t6, $t3, 16
    ctx->r14 = S32(ctx->r11 << 16);
    // 0x80302FC0: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x80302FC4: sra         $t3, $t6, 16
    ctx->r11 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80302FC8: b           L_80302FE4
    // 0x80302FCC: sra         $t4, $t9, 16
    ctx->r12 = S32(SIGNED(ctx->r25) >> 16);
        goto L_80302FE4;
    // 0x80302FCC: sra         $t4, $t9, 16
    ctx->r12 = S32(SIGNED(ctx->r25) >> 16);
L_80302FD0:
    // 0x80302FD0: lui         $t1, 0x8015
    ctx->r9 = S32(0X8015 << 16);
    // 0x80302FD4: addiu       $t1, $t1, 0x2C78
    ctx->r9 = ADD32(ctx->r9, 0X2C78);
    // 0x80302FD8: or          $t4, $zero, $zero
    ctx->r12 = 0 | 0;
    // 0x80302FDC: or          $t3, $zero, $zero
    ctx->r11 = 0 | 0;
    // 0x80302FE0: or          $t2, $zero, $zero
    ctx->r10 = 0 | 0;
L_80302FE4:
    // 0x80302FE4: andi        $t6, $t3, 0xFF
    ctx->r14 = ctx->r11 & 0XFF;
    // 0x80302FE8: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x80302FEC: addu        $t8, $t1, $t7
    ctx->r24 = ADD32(ctx->r9, ctx->r15);
    // 0x80302FF0: lh          $t9, 0x0($t8)
    ctx->r25 = MEM_H(ctx->r24, 0X0);
    // 0x80302FF4: lh          $t6, 0x36($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X36);
    // 0x80302FF8: lui         $s0, 0x8020
    ctx->r16 = S32(0X8020 << 16);
    // 0x80302FFC: sra         $t5, $t9, 7
    ctx->r13 = S32(SIGNED(ctx->r25) >> 7);
    // 0x80303000: multu       $t5, $t6
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r14)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80303004: addiu       $t9, $t3, 0x40
    ctx->r25 = ADD32(ctx->r11, 0X40);
    // 0x80303008: andi        $t5, $t9, 0xFF
    ctx->r13 = ctx->r25 & 0XFF;
    // 0x8030300C: addiu       $s0, $s0, 0x3FE0
    ctx->r16 = ADD32(ctx->r16, 0X3FE0);
    // 0x80303010: sll         $t6, $t5, 1
    ctx->r14 = S32(ctx->r13 << 1);
    // 0x80303014: lh          $t5, 0x36($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X36);
    // 0x80303018: or          $a0, $s0, $zero
    ctx->r4 = ctx->r16 | 0;
    // 0x8030301C: mflo        $t7
    ctx->r15 = lo;
    // 0x80303020: sra         $t8, $t7, 9
    ctx->r24 = S32(SIGNED(ctx->r15) >> 9);
    // 0x80303024: sh          $t8, 0x8($s0)
    MEM_H(0X8, ctx->r16) = ctx->r24;
    // 0x80303028: addu        $t7, $t1, $t6
    ctx->r15 = ADD32(ctx->r9, ctx->r14);
    // 0x8030302C: lh          $t8, 0x0($t7)
    ctx->r24 = MEM_H(ctx->r15, 0X0);
    // 0x80303030: lh          $v1, 0x8($s0)
    ctx->r3 = MEM_H(ctx->r16, 0X8);
    // 0x80303034: sh          $zero, 0xC($s0)
    MEM_H(0XC, ctx->r16) = 0;
    // 0x80303038: sra         $t9, $t8, 7
    ctx->r25 = S32(SIGNED(ctx->r24) >> 7);
    // 0x8030303C: multu       $t9, $t5
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r13)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80303040: andi        $t5, $t2, 0xFF
    ctx->r13 = ctx->r10 & 0XFF;
    // 0x80303044: negu        $t8, $v1
    ctx->r24 = SUB32(0, ctx->r3);
    // 0x80303048: sh          $t8, 0x10($s0)
    MEM_H(0X10, ctx->r16) = ctx->r24;
    // 0x8030304C: sh          $zero, 0x14($s0)
    MEM_H(0X14, ctx->r16) = 0;
    // 0x80303050: mflo        $t6
    ctx->r14 = lo;
    // 0x80303054: sra         $t7, $t6, 9
    ctx->r15 = S32(SIGNED(ctx->r14) >> 9);
    // 0x80303058: sh          $t7, 0xA($s0)
    MEM_H(0XA, ctx->r16) = ctx->r15;
    // 0x8030305C: lh          $a2, 0xA($s0)
    ctx->r6 = MEM_H(ctx->r16, 0XA);
    // 0x80303060: sll         $t6, $t5, 1
    ctx->r14 = S32(ctx->r13 << 1);
    // 0x80303064: addu        $t7, $t1, $t6
    ctx->r15 = ADD32(ctx->r9, ctx->r14);
    // 0x80303068: lh          $t8, 0x0($t7)
    ctx->r24 = MEM_H(ctx->r15, 0X0);
    // 0x8030306C: lh          $t5, 0x32($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X32);
    // 0x80303070: negu        $t9, $a2
    ctx->r25 = SUB32(0, ctx->r6);
    // 0x80303074: sh          $t9, 0x12($s0)
    MEM_H(0X12, ctx->r16) = ctx->r25;
    // 0x80303078: sra         $t9, $t8, 7
    ctx->r25 = S32(SIGNED(ctx->r24) >> 7);
    // 0x8030307C: multu       $t9, $t5
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r13)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80303080: addiu       $t9, $t2, 0x40
    ctx->r25 = ADD32(ctx->r10, 0X40);
    // 0x80303084: andi        $t5, $t9, 0xFF
    ctx->r13 = ctx->r25 & 0XFF;
    // 0x80303088: mflo        $t6
    ctx->r14 = lo;
    // 0x8030308C: sra         $t7, $t6, 8
    ctx->r15 = S32(SIGNED(ctx->r14) >> 8);
    // 0x80303090: addu        $t8, $t7, $v1
    ctx->r24 = ADD32(ctx->r15, ctx->r3);
    // 0x80303094: sll         $t6, $t5, 1
    ctx->r14 = S32(ctx->r13 << 1);
    // 0x80303098: sh          $t8, 0x0($s0)
    MEM_H(0X0, ctx->r16) = ctx->r24;
    // 0x8030309C: addu        $t7, $t1, $t6
    ctx->r15 = ADD32(ctx->r9, ctx->r14);
    // 0x803030A0: lh          $t8, 0x0($t7)
    ctx->r24 = MEM_H(ctx->r15, 0X0);
    // 0x803030A4: lh          $t5, 0x32($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X32);
    // 0x803030A8: sh          $zero, 0x4($s0)
    MEM_H(0X4, ctx->r16) = 0;
    // 0x803030AC: sra         $t9, $t8, 7
    ctx->r25 = S32(SIGNED(ctx->r24) >> 7);
    // 0x803030B0: multu       $t9, $t5
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r13)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803030B4: andi        $t9, $t4, 0xFF
    ctx->r25 = ctx->r12 & 0XFF;
    // 0x803030B8: sll         $t5, $t9, 1
    ctx->r13 = S32(ctx->r25 << 1);
    // 0x803030BC: lh          $t9, 0x3A($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X3A);
    // 0x803030C0: mflo        $t6
    ctx->r14 = lo;
    // 0x803030C4: sra         $t7, $t6, 8
    ctx->r15 = S32(SIGNED(ctx->r14) >> 8);
    // 0x803030C8: addu        $t6, $t1, $t5
    ctx->r14 = ADD32(ctx->r9, ctx->r13);
    // 0x803030CC: addu        $t8, $t7, $a2
    ctx->r24 = ADD32(ctx->r15, ctx->r6);
    // 0x803030D0: lh          $t7, 0x0($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X0);
    // 0x803030D4: sh          $t8, 0x2($s0)
    MEM_H(0X2, ctx->r16) = ctx->r24;
    // 0x803030D8: sra         $t8, $t7, 7
    ctx->r24 = S32(SIGNED(ctx->r15) >> 7);
    // 0x803030DC: multu       $t8, $t9
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803030E0: lh          $t7, 0x10($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X10);
    // 0x803030E4: addiu       $t9, $t4, 0x40
    ctx->r25 = ADD32(ctx->r12, 0X40);
    // 0x803030E8: mflo        $t5
    ctx->r13 = lo;
    // 0x803030EC: sra         $t6, $t5, 8
    ctx->r14 = S32(SIGNED(ctx->r13) >> 8);
    // 0x803030F0: subu        $t8, $t7, $t6
    ctx->r24 = SUB32(ctx->r15, ctx->r14);
    // 0x803030F4: andi        $t5, $t9, 0xFF
    ctx->r13 = ctx->r25 & 0XFF;
    // 0x803030F8: sll         $t7, $t5, 1
    ctx->r15 = S32(ctx->r13 << 1);
    // 0x803030FC: sh          $t8, 0x18($s0)
    MEM_H(0X18, ctx->r16) = ctx->r24;
    // 0x80303100: addu        $t6, $t1, $t7
    ctx->r14 = ADD32(ctx->r9, ctx->r15);
    // 0x80303104: lh          $t8, 0x0($t6)
    ctx->r24 = MEM_H(ctx->r14, 0X0);
    // 0x80303108: lh          $t5, 0x3A($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X3A);
    // 0x8030310C: sh          $zero, 0x1C($s0)
    MEM_H(0X1C, ctx->r16) = 0;
    // 0x80303110: sra         $t9, $t8, 7
    ctx->r25 = S32(SIGNED(ctx->r24) >> 7);
    // 0x80303114: multu       $t9, $t5
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r13)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80303118: lh          $t8, 0x12($s0)
    ctx->r24 = MEM_H(ctx->r16, 0X12);
    // 0x8030311C: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x80303120: mflo        $t7
    ctx->r15 = lo;
    // 0x80303124: sra         $t6, $t7, 8
    ctx->r14 = S32(SIGNED(ctx->r15) >> 8);
    // 0x80303128: subu        $t9, $t8, $t6
    ctx->r25 = SUB32(ctx->r24, ctx->r14);
    // 0x8030312C: sh          $t9, 0x1A($s0)
    MEM_H(0X1A, ctx->r16) = ctx->r25;
    // 0x80303130: lw          $t5, 0x5530($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5530);
    // 0x80303134: lh          $a1, 0x28($t5)
    ctx->r5 = MEM_H(ctx->r13, 0X28);
    // 0x80303138: negu        $a1, $a1
    ctx->r5 = SUB32(0, ctx->r5);
    // 0x8030313C: sra         $t7, $a1, 1
    ctx->r15 = S32(SIGNED(ctx->r5) >> 1);
    // 0x80303140: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x80303144: jal         0x802C79E0
    // 0x80303148: sra         $a1, $t8, 16
    ctx->r5 = S32(SIGNED(ctx->r24) >> 16);
    func_802C79E0_6D9090(rdram, ctx);
        goto after_2;
    // 0x80303148: sra         $a1, $t8, 16
    ctx->r5 = S32(SIGNED(ctx->r24) >> 16);
    after_2:
    // 0x8030314C: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80303150: lw          $t9, 0x5530($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5530);
    // 0x80303154: lui         $a0, 0x8020
    ctx->r4 = S32(0X8020 << 16);
    // 0x80303158: addiu       $a0, $a0, 0x3FE8
    ctx->r4 = ADD32(ctx->r4, 0X3FE8);
    // 0x8030315C: lh          $a1, 0x28($t9)
    ctx->r5 = MEM_H(ctx->r25, 0X28);
    // 0x80303160: negu        $a1, $a1
    ctx->r5 = SUB32(0, ctx->r5);
    // 0x80303164: sra         $t5, $a1, 1
    ctx->r13 = S32(SIGNED(ctx->r5) >> 1);
    // 0x80303168: sll         $t7, $t5, 16
    ctx->r15 = S32(ctx->r13 << 16);
    // 0x8030316C: jal         0x802C79E0
    // 0x80303170: sra         $a1, $t7, 16
    ctx->r5 = S32(SIGNED(ctx->r15) >> 16);
    func_802C79E0_6D9090(rdram, ctx);
        goto after_3;
    // 0x80303170: sra         $a1, $t7, 16
    ctx->r5 = S32(SIGNED(ctx->r15) >> 16);
    after_3:
    // 0x80303174: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80303178: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x8030317C: lui         $a0, 0x8020
    ctx->r4 = S32(0X8020 << 16);
    // 0x80303180: addiu       $a0, $a0, 0x3FF0
    ctx->r4 = ADD32(ctx->r4, 0X3FF0);
    // 0x80303184: lh          $a1, 0x28($t6)
    ctx->r5 = MEM_H(ctx->r14, 0X28);
    // 0x80303188: negu        $a1, $a1
    ctx->r5 = SUB32(0, ctx->r5);
    // 0x8030318C: sra         $t9, $a1, 1
    ctx->r25 = S32(SIGNED(ctx->r5) >> 1);
    // 0x80303190: sll         $t5, $t9, 16
    ctx->r13 = S32(ctx->r25 << 16);
    // 0x80303194: jal         0x802C79E0
    // 0x80303198: sra         $a1, $t5, 16
    ctx->r5 = S32(SIGNED(ctx->r13) >> 16);
    func_802C79E0_6D9090(rdram, ctx);
        goto after_4;
    // 0x80303198: sra         $a1, $t5, 16
    ctx->r5 = S32(SIGNED(ctx->r13) >> 16);
    after_4:
    // 0x8030319C: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x803031A0: lw          $t8, 0x5530($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5530);
    // 0x803031A4: lui         $a0, 0x8020
    ctx->r4 = S32(0X8020 << 16);
    // 0x803031A8: addiu       $a0, $a0, 0x3FF8
    ctx->r4 = ADD32(ctx->r4, 0X3FF8);
    // 0x803031AC: lh          $a1, 0x28($t8)
    ctx->r5 = MEM_H(ctx->r24, 0X28);
    // 0x803031B0: negu        $a1, $a1
    ctx->r5 = SUB32(0, ctx->r5);
    // 0x803031B4: sra         $t6, $a1, 1
    ctx->r14 = S32(SIGNED(ctx->r5) >> 1);
    // 0x803031B8: sll         $t9, $t6, 16
    ctx->r25 = S32(ctx->r14 << 16);
    // 0x803031BC: jal         0x802C79E0
    // 0x803031C0: sra         $a1, $t9, 16
    ctx->r5 = S32(SIGNED(ctx->r25) >> 16);
    func_802C79E0_6D9090(rdram, ctx);
        goto after_5;
    // 0x803031C0: sra         $a1, $t9, 16
    ctx->r5 = S32(SIGNED(ctx->r25) >> 16);
    after_5:
    // 0x803031C4: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x803031C8: lw          $v0, 0x5524($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5524);
    // 0x803031CC: lh          $t7, 0x4($s0)
    ctx->r15 = MEM_H(ctx->r16, 0X4);
    // 0x803031D0: lh          $t5, 0xC($s0)
    ctx->r13 = MEM_H(ctx->r16, 0XC);
    // 0x803031D4: lhu         $t8, 0xB8($v0)
    ctx->r24 = MEM_HU(ctx->r2, 0XB8);
    // 0x803031D8: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    // 0x803031DC: sll         $t6, $t8, 5
    ctx->r14 = S32(ctx->r24 << 5);
    // 0x803031E0: addu        $t9, $t7, $t6
    ctx->r25 = ADD32(ctx->r15, ctx->r14);
    // 0x803031E4: sh          $t9, 0x4($s0)
    MEM_H(0X4, ctx->r16) = ctx->r25;
    // 0x803031E8: lhu         $t8, 0xB8($v0)
    ctx->r24 = MEM_HU(ctx->r2, 0XB8);
    // 0x803031EC: lh          $t9, 0x14($s0)
    ctx->r25 = MEM_H(ctx->r16, 0X14);
    // 0x803031F0: sll         $t7, $t8, 5
    ctx->r15 = S32(ctx->r24 << 5);
    // 0x803031F4: addu        $t6, $t5, $t7
    ctx->r14 = ADD32(ctx->r13, ctx->r15);
    // 0x803031F8: sh          $t6, 0xC($s0)
    MEM_H(0XC, ctx->r16) = ctx->r14;
    // 0x803031FC: lhu         $t8, 0xB8($v0)
    ctx->r24 = MEM_HU(ctx->r2, 0XB8);
    // 0x80303200: lh          $t6, 0x1C($s0)
    ctx->r14 = MEM_H(ctx->r16, 0X1C);
    // 0x80303204: sll         $t5, $t8, 5
    ctx->r13 = S32(ctx->r24 << 5);
    // 0x80303208: addu        $t7, $t9, $t5
    ctx->r15 = ADD32(ctx->r25, ctx->r13);
    // 0x8030320C: sh          $t7, 0x14($s0)
    MEM_H(0X14, ctx->r16) = ctx->r15;
    // 0x80303210: lhu         $t8, 0xB8($v0)
    ctx->r24 = MEM_HU(ctx->r2, 0XB8);
    // 0x80303214: sll         $t9, $t8, 5
    ctx->r25 = S32(ctx->r24 << 5);
    // 0x80303218: addu        $t5, $t6, $t9
    ctx->r13 = ADD32(ctx->r14, ctx->r25);
    // 0x8030321C: sh          $t5, 0x1C($s0)
    MEM_H(0X1C, ctx->r16) = ctx->r13;
    // 0x80303220: lw          $s0, 0x28($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X28);
    // 0x80303224: jr          $ra
    // 0x80303228: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
    return;
    // 0x80303228: addiu       $sp, $sp, 0x30
    ctx->r29 = ADD32(ctx->r29, 0X30);
;}
RECOMP_FUNC void func_8030322C_7148DC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8030322C: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x80303230: lui         $t0, 0x8015
    ctx->r8 = S32(0X8015 << 16);
    // 0x80303234: andi        $t3, $a1, 0xFF
    ctx->r11 = ctx->r5 & 0XFF;
    // 0x80303238: addiu       $t0, $t0, 0x2C78
    ctx->r8 = ADD32(ctx->r8, 0X2C78);
    // 0x8030323C: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80303240: sll         $t4, $t3, 1
    ctx->r12 = S32(ctx->r11 << 1);
    // 0x80303244: lui         $t2, 0x8020
    ctx->r10 = S32(0X8020 << 16);
    // 0x80303248: addiu       $t2, $t2, 0x3FE0
    ctx->r10 = ADD32(ctx->r10, 0X3FE0);
    // 0x8030324C: addu        $t5, $t0, $t4
    ctx->r13 = ADD32(ctx->r8, ctx->r12);
    // 0x80303250: sll         $t1, $t7, 3
    ctx->r9 = S32(ctx->r15 << 3);
    // 0x80303254: lh          $a2, 0x0($t5)
    ctx->r6 = MEM_H(ctx->r13, 0X0);
    // 0x80303258: addu        $v0, $t1, $t2
    ctx->r2 = ADD32(ctx->r9, ctx->r10);
    // 0x8030325C: lh          $v1, 0x4($v0)
    ctx->r3 = MEM_H(ctx->r2, 0X4);
    // 0x80303260: sra         $t6, $a2, 7
    ctx->r14 = S32(SIGNED(ctx->r6) >> 7);
    // 0x80303264: addiu       $t7, $a1, 0x40
    ctx->r15 = ADD32(ctx->r5, 0X40);
    // 0x80303268: multu       $t6, $v1
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8030326C: andi        $t8, $t7, 0xFF
    ctx->r24 = ctx->r15 & 0XFF;
    // 0x80303270: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x80303274: addu        $t1, $t0, $t9
    ctx->r9 = ADD32(ctx->r8, ctx->r25);
    // 0x80303278: lh          $a3, 0x0($t1)
    ctx->r7 = MEM_H(ctx->r9, 0X0);
    // 0x8030327C: lh          $t4, 0x2($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X2);
    // 0x80303280: or          $a2, $t6, $zero
    ctx->r6 = ctx->r14 | 0;
    // 0x80303284: sra         $t2, $a3, 7
    ctx->r10 = S32(SIGNED(ctx->r7) >> 7);
    // 0x80303288: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x8030328C: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x80303290: mflo        $t3
    ctx->r11 = lo;
    // 0x80303294: nop

    // 0x80303298: nop

    // 0x8030329C: multu       $t4, $t2
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803032A0: mflo        $t5
    ctx->r13 = lo;
    // 0x803032A4: addu        $t6, $t3, $t5
    ctx->r14 = ADD32(ctx->r11, ctx->r13);
    // 0x803032A8: sra         $t7, $t6, 8
    ctx->r15 = S32(SIGNED(ctx->r14) >> 8);
    // 0x803032AC: multu       $v1, $t2
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803032B0: sh          $t7, 0x2($v0)
    MEM_H(0X2, ctx->r2) = ctx->r15;
    // 0x803032B4: lh          $t9, 0x2($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X2);
    // 0x803032B8: mflo        $t8
    ctx->r24 = lo;
    // 0x803032BC: nop

    // 0x803032C0: nop

    // 0x803032C4: multu       $a2, $t9
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803032C8: mflo        $t1
    ctx->r9 = lo;
    // 0x803032CC: subu        $t2, $t8, $t1
    ctx->r10 = SUB32(ctx->r24, ctx->r9);
    // 0x803032D0: sra         $t4, $t2, 8
    ctx->r12 = S32(SIGNED(ctx->r10) >> 8);
    // 0x803032D4: jr          $ra
    // 0x803032D8: sh          $t4, 0x4($v0)
    MEM_H(0X4, ctx->r2) = ctx->r12;
    return;
    // 0x803032D8: sh          $t4, 0x4($v0)
    MEM_H(0X4, ctx->r2) = ctx->r12;
;}
RECOMP_FUNC void func_803032DC_71498C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803032DC: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x803032E0: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x803032E4: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x803032E8: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x803032EC: sra         $a0, $t6, 16
    ctx->r4 = S32(SIGNED(ctx->r14) >> 16);
    // 0x803032F0: lui         $t4, 0x8020
    ctx->r12 = S32(0X8020 << 16);
    // 0x803032F4: addiu       $t4, $t4, 0x3FE0
    ctx->r12 = ADD32(ctx->r12, 0X3FE0);
    // 0x803032F8: or          $t6, $a2, $zero
    ctx->r14 = ctx->r6 | 0;
    // 0x803032FC: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x80303300: sll         $t8, $a0, 3
    ctx->r24 = S32(ctx->r4 << 3);
    // 0x80303304: sll         $t9, $t9, 3
    ctx->r25 = S32(ctx->r25 << 3);
    // 0x80303308: or          $a2, $t6, $zero
    ctx->r6 = ctx->r14 | 0;
    // 0x8030330C: addu        $a3, $t4, $t9
    ctx->r7 = ADD32(ctx->r12, ctx->r25);
    // 0x80303310: addu        $v1, $t4, $t8
    ctx->r3 = ADD32(ctx->r12, ctx->r24);
    // 0x80303314: lh          $t6, 0x2($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X2);
    // 0x80303318: lh          $t0, 0x2($a3)
    ctx->r8 = MEM_H(ctx->r7, 0X2);
    // 0x8030331C: lh          $t9, 0x4($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X4);
    // 0x80303320: lui         $t5, 0x8015
    ctx->r13 = S32(0X8015 << 16);
    // 0x80303324: subu        $v0, $t6, $t0
    ctx->r2 = SUB32(ctx->r14, ctx->r8);
    // 0x80303328: lh          $t6, 0x4($a3)
    ctx->r14 = MEM_H(ctx->r7, 0X4);
    // 0x8030332C: sll         $t7, $v0, 16
    ctx->r15 = S32(ctx->r2 << 16);
    // 0x80303330: sra         $v0, $t7, 16
    ctx->r2 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80303334: subu        $t1, $t9, $t6
    ctx->r9 = SUB32(ctx->r25, ctx->r14);
    // 0x80303338: sll         $t7, $t1, 16
    ctx->r15 = S32(ctx->r9 << 16);
    // 0x8030333C: andi        $t9, $a2, 0xFF
    ctx->r25 = ctx->r6 & 0XFF;
    // 0x80303340: addiu       $t5, $t5, 0x2C78
    ctx->r13 = ADD32(ctx->r13, 0X2C78);
    // 0x80303344: sra         $t1, $t7, 16
    ctx->r9 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80303348: sll         $t6, $t9, 1
    ctx->r14 = S32(ctx->r25 << 1);
    // 0x8030334C: addu        $t7, $t5, $t6
    ctx->r15 = ADD32(ctx->r13, ctx->r14);
    // 0x80303350: lh          $t2, 0x0($t7)
    ctx->r10 = MEM_H(ctx->r15, 0X0);
    // 0x80303354: addiu       $t9, $a2, 0x40
    ctx->r25 = ADD32(ctx->r6, 0X40);
    // 0x80303358: andi        $t6, $t9, 0xFF
    ctx->r14 = ctx->r25 & 0XFF;
    // 0x8030335C: sra         $t8, $t2, 7
    ctx->r24 = S32(SIGNED(ctx->r10) >> 7);
    // 0x80303360: or          $t2, $t8, $zero
    ctx->r10 = ctx->r24 | 0;
    // 0x80303364: multu       $t2, $t1
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80303368: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x8030336C: addu        $t8, $t5, $t7
    ctx->r24 = ADD32(ctx->r13, ctx->r15);
    // 0x80303370: lh          $t3, 0x0($t8)
    ctx->r11 = MEM_H(ctx->r24, 0X0);
    // 0x80303374: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x80303378: sra         $t9, $t3, 7
    ctx->r25 = S32(SIGNED(ctx->r11) >> 7);
    // 0x8030337C: or          $t3, $t9, $zero
    ctx->r11 = ctx->r25 | 0;
    // 0x80303380: mflo        $t6
    ctx->r14 = lo;
    // 0x80303384: nop

    // 0x80303388: nop

    // 0x8030338C: multu       $v0, $t9
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80303390: mflo        $t7
    ctx->r15 = lo;
    // 0x80303394: addu        $t8, $t6, $t7
    ctx->r24 = ADD32(ctx->r14, ctx->r15);
    // 0x80303398: sra         $t9, $t8, 8
    ctx->r25 = S32(SIGNED(ctx->r24) >> 8);
    // 0x8030339C: multu       $t1, $t3
    result = U64(U32(ctx->r9)) * U64(U32(ctx->r11)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803033A0: addu        $t6, $t9, $t0
    ctx->r14 = ADD32(ctx->r25, ctx->r8);
    // 0x803033A4: sh          $t6, 0x2($v1)
    MEM_H(0X2, ctx->r3) = ctx->r14;
    // 0x803033A8: mflo        $t7
    ctx->r15 = lo;
    // 0x803033AC: nop

    // 0x803033B0: nop

    // 0x803033B4: multu       $t2, $v0
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803033B8: mflo        $t8
    ctx->r24 = lo;
    // 0x803033BC: subu        $t9, $t7, $t8
    ctx->r25 = SUB32(ctx->r15, ctx->r24);
    // 0x803033C0: lh          $t7, 0x4($a3)
    ctx->r15 = MEM_H(ctx->r7, 0X4);
    // 0x803033C4: sra         $t6, $t9, 8
    ctx->r14 = S32(SIGNED(ctx->r25) >> 8);
    // 0x803033C8: addu        $t8, $t6, $t7
    ctx->r24 = ADD32(ctx->r14, ctx->r15);
    // 0x803033CC: jr          $ra
    // 0x803033D0: sh          $t8, 0x4($v1)
    MEM_H(0X4, ctx->r3) = ctx->r24;
    return;
    // 0x803033D0: sh          $t8, 0x4($v1)
    MEM_H(0X4, ctx->r3) = ctx->r24;
;}
RECOMP_FUNC void func_803033D4_714A84(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803033D4: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x803033D8: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x803033DC: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x803033E0: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x803033E4: sra         $a0, $t6, 16
    ctx->r4 = S32(SIGNED(ctx->r14) >> 16);
    // 0x803033E8: lui         $t4, 0x8020
    ctx->r12 = S32(0X8020 << 16);
    // 0x803033EC: addiu       $t4, $t4, 0x3FE0
    ctx->r12 = ADD32(ctx->r12, 0X3FE0);
    // 0x803033F0: or          $t6, $a2, $zero
    ctx->r14 = ctx->r6 | 0;
    // 0x803033F4: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x803033F8: sll         $t8, $a0, 3
    ctx->r24 = S32(ctx->r4 << 3);
    // 0x803033FC: sll         $t9, $t9, 3
    ctx->r25 = S32(ctx->r25 << 3);
    // 0x80303400: or          $a2, $t6, $zero
    ctx->r6 = ctx->r14 | 0;
    // 0x80303404: addu        $a3, $t4, $t9
    ctx->r7 = ADD32(ctx->r12, ctx->r25);
    // 0x80303408: addu        $v1, $t4, $t8
    ctx->r3 = ADD32(ctx->r12, ctx->r24);
    // 0x8030340C: lh          $t6, 0x0($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X0);
    // 0x80303410: lh          $t0, 0x0($a3)
    ctx->r8 = MEM_H(ctx->r7, 0X0);
    // 0x80303414: lh          $t9, 0x2($v1)
    ctx->r25 = MEM_H(ctx->r3, 0X2);
    // 0x80303418: lui         $t5, 0x8015
    ctx->r13 = S32(0X8015 << 16);
    // 0x8030341C: subu        $v0, $t6, $t0
    ctx->r2 = SUB32(ctx->r14, ctx->r8);
    // 0x80303420: lh          $t6, 0x2($a3)
    ctx->r14 = MEM_H(ctx->r7, 0X2);
    // 0x80303424: sll         $t7, $v0, 16
    ctx->r15 = S32(ctx->r2 << 16);
    // 0x80303428: sra         $v0, $t7, 16
    ctx->r2 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8030342C: subu        $t1, $t9, $t6
    ctx->r9 = SUB32(ctx->r25, ctx->r14);
    // 0x80303430: sll         $t7, $t1, 16
    ctx->r15 = S32(ctx->r9 << 16);
    // 0x80303434: andi        $t9, $a2, 0xFF
    ctx->r25 = ctx->r6 & 0XFF;
    // 0x80303438: addiu       $t5, $t5, 0x2C78
    ctx->r13 = ADD32(ctx->r13, 0X2C78);
    // 0x8030343C: sra         $t1, $t7, 16
    ctx->r9 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80303440: sll         $t6, $t9, 1
    ctx->r14 = S32(ctx->r25 << 1);
    // 0x80303444: addu        $t7, $t5, $t6
    ctx->r15 = ADD32(ctx->r13, ctx->r14);
    // 0x80303448: lh          $t2, 0x0($t7)
    ctx->r10 = MEM_H(ctx->r15, 0X0);
    // 0x8030344C: addiu       $t9, $a2, 0x40
    ctx->r25 = ADD32(ctx->r6, 0X40);
    // 0x80303450: andi        $t6, $t9, 0xFF
    ctx->r14 = ctx->r25 & 0XFF;
    // 0x80303454: sra         $t8, $t2, 7
    ctx->r24 = S32(SIGNED(ctx->r10) >> 7);
    // 0x80303458: or          $t2, $t8, $zero
    ctx->r10 = ctx->r24 | 0;
    // 0x8030345C: multu       $t2, $t1
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80303460: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x80303464: addu        $t8, $t5, $t7
    ctx->r24 = ADD32(ctx->r13, ctx->r15);
    // 0x80303468: lh          $t3, 0x0($t8)
    ctx->r11 = MEM_H(ctx->r24, 0X0);
    // 0x8030346C: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x80303470: sra         $t9, $t3, 7
    ctx->r25 = S32(SIGNED(ctx->r11) >> 7);
    // 0x80303474: or          $t3, $t9, $zero
    ctx->r11 = ctx->r25 | 0;
    // 0x80303478: mflo        $t6
    ctx->r14 = lo;
    // 0x8030347C: nop

    // 0x80303480: nop

    // 0x80303484: multu       $v0, $t9
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80303488: mflo        $t7
    ctx->r15 = lo;
    // 0x8030348C: addu        $t8, $t6, $t7
    ctx->r24 = ADD32(ctx->r14, ctx->r15);
    // 0x80303490: sra         $t9, $t8, 8
    ctx->r25 = S32(SIGNED(ctx->r24) >> 8);
    // 0x80303494: multu       $t1, $t3
    result = U64(U32(ctx->r9)) * U64(U32(ctx->r11)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80303498: addu        $t6, $t9, $t0
    ctx->r14 = ADD32(ctx->r25, ctx->r8);
    // 0x8030349C: sh          $t6, 0x0($v1)
    MEM_H(0X0, ctx->r3) = ctx->r14;
    // 0x803034A0: mflo        $t7
    ctx->r15 = lo;
    // 0x803034A4: nop

    // 0x803034A8: nop

    // 0x803034AC: multu       $t2, $v0
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803034B0: mflo        $t8
    ctx->r24 = lo;
    // 0x803034B4: subu        $t9, $t7, $t8
    ctx->r25 = SUB32(ctx->r15, ctx->r24);
    // 0x803034B8: lh          $t7, 0x2($a3)
    ctx->r15 = MEM_H(ctx->r7, 0X2);
    // 0x803034BC: sra         $t6, $t9, 8
    ctx->r14 = S32(SIGNED(ctx->r25) >> 8);
    // 0x803034C0: addu        $t8, $t6, $t7
    ctx->r24 = ADD32(ctx->r14, ctx->r15);
    // 0x803034C4: jr          $ra
    // 0x803034C8: sh          $t8, 0x2($v1)
    MEM_H(0X2, ctx->r3) = ctx->r24;
    return;
    // 0x803034C8: sh          $t8, 0x2($v1)
    MEM_H(0X2, ctx->r3) = ctx->r24;
;}
RECOMP_FUNC void func_803034D0_714B80(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803034D0: addiu       $sp, $sp, -0x50
    ctx->r29 = ADD32(ctx->r29, -0X50);
    // 0x803034D4: sw          $s2, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r18;
    // 0x803034D8: sw          $s1, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r17;
    // 0x803034DC: sw          $s0, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r16;
    // 0x803034E0: sw          $a1, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r5;
    // 0x803034E4: sw          $a2, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r6;
    // 0x803034E8: sw          $a3, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r7;
    // 0x803034EC: lh          $t1, 0x302($a0)
    ctx->r9 = MEM_H(ctx->r4, 0X302);
    // 0x803034F0: andi        $t6, $a1, 0xFFFF
    ctx->r14 = ctx->r5 & 0XFFFF;
    // 0x803034F4: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x803034F8: sll         $t9, $a2, 16
    ctx->r25 = S32(ctx->r6 << 16);
    // 0x803034FC: andi        $t7, $a3, 0xFFFF
    ctx->r15 = ctx->r7 & 0XFFFF;
    // 0x80303500: or          $a3, $t7, $zero
    ctx->r7 = ctx->r15 | 0;
    // 0x80303504: sra         $a2, $t9, 16
    ctx->r6 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80303508: addiu       $t6, $t1, 0x40
    ctx->r14 = ADD32(ctx->r9, 0X40);
    // 0x8030350C: andi        $t9, $t6, 0xFF
    ctx->r25 = ctx->r14 & 0XFF;
    // 0x80303510: lui         $t7, 0x8015
    ctx->r15 = S32(0X8015 << 16);
    // 0x80303514: addiu       $t7, $t7, 0x2C78
    ctx->r15 = ADD32(ctx->r15, 0X2C78);
    // 0x80303518: sll         $t8, $t9, 1
    ctx->r24 = S32(ctx->r25 << 1);
    // 0x8030351C: addu        $t6, $t8, $t7
    ctx->r14 = ADD32(ctx->r24, ctx->r15);
    // 0x80303520: lh          $v0, 0x0($t6)
    ctx->r2 = MEM_H(ctx->r14, 0X0);
    // 0x80303524: lui         $t0, 0x8020
    ctx->r8 = S32(0X8020 << 16);
    // 0x80303528: addiu       $t0, $t0, 0x3FE0
    ctx->r8 = ADD32(ctx->r8, 0X3FE0);
    // 0x8030352C: sra         $t9, $v0, 8
    ctx->r25 = S32(SIGNED(ctx->r2) >> 8);
    // 0x80303530: sll         $t8, $t9, 16
    ctx->r24 = S32(ctx->r25 << 16);
    // 0x80303534: sra         $v0, $t8, 16
    ctx->r2 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80303538: andi        $t9, $t1, 0xFF
    ctx->r25 = ctx->r9 & 0XFF;
    // 0x8030353C: sll         $t8, $t9, 1
    ctx->r24 = S32(ctx->r25 << 1);
    // 0x80303540: addu        $t6, $t8, $t7
    ctx->r14 = ADD32(ctx->r24, ctx->r15);
    // 0x80303544: lh          $v1, 0x0($t6)
    ctx->r3 = MEM_H(ctx->r14, 0X0);
    // 0x80303548: lh          $t2, 0xA($t0)
    ctx->r10 = MEM_H(ctx->r8, 0XA);
    // 0x8030354C: lh          $t3, 0x8($t0)
    ctx->r11 = MEM_H(ctx->r8, 0X8);
    // 0x80303550: sra         $t9, $v1, 8
    ctx->r25 = S32(SIGNED(ctx->r3) >> 8);
    // 0x80303554: sll         $t8, $t9, 16
    ctx->r24 = S32(ctx->r25 << 16);
    // 0x80303558: sra         $t7, $t8, 16
    ctx->r15 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8030355C: multu       $t2, $t7
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80303560: or          $v1, $t7, $zero
    ctx->r3 = ctx->r15 | 0;
    // 0x80303564: lh          $t4, 0x12($t0)
    ctx->r12 = MEM_H(ctx->r8, 0X12);
    // 0x80303568: lh          $t5, 0x10($t0)
    ctx->r13 = MEM_H(ctx->r8, 0X10);
    // 0x8030356C: addiu       $s1, $zero, 0x5
    ctx->r17 = ADD32(0, 0X5);
    // 0x80303570: addiu       $s2, $zero, 0xC0
    ctx->r18 = ADD32(0, 0XC0);
    // 0x80303574: mflo        $t6
    ctx->r14 = lo;
    // 0x80303578: nop

    // 0x8030357C: nop

    // 0x80303580: multu       $t3, $v0
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80303584: mflo        $t9
    ctx->r25 = lo;
    // 0x80303588: addu        $t8, $t6, $t9
    ctx->r24 = ADD32(ctx->r14, ctx->r25);
    // 0x8030358C: sra         $t7, $t8, 7
    ctx->r15 = S32(SIGNED(ctx->r24) >> 7);
    // 0x80303590: multu       $t2, $v0
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80303594: sw          $t7, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r15;
    // 0x80303598: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x8030359C: mflo        $t6
    ctx->r14 = lo;
    // 0x803035A0: nop

    // 0x803035A4: nop

    // 0x803035A8: multu       $t3, $v1
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803035AC: mflo        $t9
    ctx->r25 = lo;
    // 0x803035B0: subu        $t8, $t6, $t9
    ctx->r24 = SUB32(ctx->r14, ctx->r25);
    // 0x803035B4: sra         $t6, $t8, 7
    ctx->r14 = S32(SIGNED(ctx->r24) >> 7);
    // 0x803035B8: multu       $t4, $v1
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803035BC: sw          $t6, 0x48($sp)
    MEM_W(0X48, ctx->r29) = ctx->r14;
    // 0x803035C0: mflo        $t9
    ctx->r25 = lo;
    // 0x803035C4: nop

    // 0x803035C8: nop

    // 0x803035CC: multu       $t5, $v0
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803035D0: mflo        $t8
    ctx->r24 = lo;
    // 0x803035D4: addu        $t6, $t9, $t8
    ctx->r14 = ADD32(ctx->r25, ctx->r24);
    // 0x803035D8: sra         $t9, $t6, 7
    ctx->r25 = S32(SIGNED(ctx->r14) >> 7);
    // 0x803035DC: multu       $t4, $v0
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803035E0: sw          $t9, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r25;
    // 0x803035E4: mflo        $t8
    ctx->r24 = lo;
    // 0x803035E8: nop

    // 0x803035EC: nop

    // 0x803035F0: multu       $t5, $v1
    result = U64(U32(ctx->r13)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803035F4: sll         $v1, $a1, 3
    ctx->r3 = S32(ctx->r5 << 3);
    // 0x803035F8: subu        $v1, $v1, $a1
    ctx->r3 = SUB32(ctx->r3, ctx->r5);
    // 0x803035FC: mflo        $t6
    ctx->r14 = lo;
    // 0x80303600: subu        $t8, $t8, $t6
    ctx->r24 = SUB32(ctx->r24, ctx->r14);
    // 0x80303604: sra         $t6, $t8, 7
    ctx->r14 = S32(SIGNED(ctx->r24) >> 7);
    // 0x80303608: lh          $t8, 0x14($t0)
    ctx->r24 = MEM_H(ctx->r8, 0X14);
    // 0x8030360C: sw          $t6, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r14;
    // 0x80303610: lh          $t6, 0xC($t0)
    ctx->r14 = MEM_H(ctx->r8, 0XC);
    // 0x80303614: multu       $t8, $s1
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r17)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80303618: sw          $t8, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r24;
    // 0x8030361C: sw          $t6, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r14;
    // 0x80303620: lw          $t7, 0x18($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X18);
    // 0x80303624: mflo        $t6
    ctx->r14 = lo;
    // 0x80303628: addu        $t6, $t6, $t7
    ctx->r14 = ADD32(ctx->r14, ctx->r15);
    // 0x8030362C: nop

    // 0x80303630: div         $zero, $t6, $s2
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r18))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r18)));
    // 0x80303634: bne         $s2, $zero, L_80303640
    if (ctx->r18 != 0) {
        // 0x80303638: nop
    
            goto L_80303640;
    }
    // 0x80303638: nop

    // 0x8030363C: break       7
    do_break(2150643260);
L_80303640:
    // 0x80303640: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80303644: bne         $s2, $at, L_80303658
    if (ctx->r18 != ctx->r1) {
        // 0x80303648: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80303658;
    }
    // 0x80303648: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8030364C: bne         $t6, $at, L_80303658
    if (ctx->r14 != ctx->r1) {
        // 0x80303650: nop
    
            goto L_80303658;
    }
    // 0x80303650: nop

    // 0x80303654: break       6
    do_break(2150643284);
L_80303658:
    // 0x80303658: mflo        $t6
    ctx->r14 = lo;
    // 0x8030365C: sw          $t6, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r14;
    // 0x80303660: nop

    // 0x80303664: multu       $t7, $s1
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r17)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80303668: mflo        $t6
    ctx->r14 = lo;
    // 0x8030366C: addu        $t7, $t8, $t6
    ctx->r15 = ADD32(ctx->r24, ctx->r14);
    // 0x80303670: sll         $t6, $a3, 4
    ctx->r14 = S32(ctx->r7 << 4);
    // 0x80303674: div         $zero, $t7, $s2
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r18))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r18)));
    // 0x80303678: bne         $s2, $zero, L_80303684
    if (ctx->r18 != 0) {
        // 0x8030367C: nop
    
            goto L_80303684;
    }
    // 0x8030367C: nop

    // 0x80303680: break       7
    do_break(2150643328);
L_80303684:
    // 0x80303684: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80303688: bne         $s2, $at, L_8030369C
    if (ctx->r18 != ctx->r1) {
        // 0x8030368C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8030369C;
    }
    // 0x8030368C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80303690: bne         $t7, $at, L_8030369C
    if (ctx->r15 != ctx->r1) {
        // 0x80303694: nop
    
            goto L_8030369C;
    }
    // 0x80303694: nop

    // 0x80303698: break       6
    do_break(2150643352);
L_8030369C:
    // 0x8030369C: mflo        $t8
    ctx->r24 = lo;
    // 0x803036A0: lw          $t7, 0x10($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X10);
    // 0x803036A4: sw          $t8, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r24;
    // 0x803036A8: addu        $s0, $a0, $t6
    ctx->r16 = ADD32(ctx->r4, ctx->r14);
    // 0x803036AC: multu       $t7, $s1
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r17)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803036B0: mflo        $t8
    ctx->r24 = lo;
    // 0x803036B4: addu        $t6, $t8, $t9
    ctx->r14 = ADD32(ctx->r24, ctx->r25);
    // 0x803036B8: nop

    // 0x803036BC: div         $zero, $t6, $s2
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r18))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r18)));
    // 0x803036C0: mflo        $t7
    ctx->r15 = lo;
    // 0x803036C4: sh          $t7, 0xC4($s0)
    MEM_H(0XC4, ctx->r16) = ctx->r15;
    // 0x803036C8: lw          $t1, 0x48($sp)
    ctx->r9 = MEM_W(ctx->r29, 0X48);
    // 0x803036CC: lw          $t2, 0x40($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X40);
    // 0x803036D0: bne         $s2, $zero, L_803036DC
    if (ctx->r18 != 0) {
        // 0x803036D4: nop
    
            goto L_803036DC;
    }
    // 0x803036D4: nop

    // 0x803036D8: break       7
    do_break(2150643416);
L_803036DC:
    // 0x803036DC: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x803036E0: bne         $s2, $at, L_803036F4
    if (ctx->r18 != ctx->r1) {
        // 0x803036E4: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_803036F4;
    }
    // 0x803036E4: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x803036E8: bne         $t6, $at, L_803036F4
    if (ctx->r14 != ctx->r1) {
        // 0x803036EC: nop
    
            goto L_803036F4;
    }
    // 0x803036EC: nop

    // 0x803036F0: break       6
    do_break(2150643440);
L_803036F4:
    // 0x803036F4: multu       $t1, $s1
    result = U64(U32(ctx->r9)) * U64(U32(ctx->r17)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803036F8: mflo        $t8
    ctx->r24 = lo;
    // 0x803036FC: addu        $t9, $t8, $t2
    ctx->r25 = ADD32(ctx->r24, ctx->r10);
    // 0x80303700: nop

    // 0x80303704: div         $zero, $t9, $s2
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r18))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r18)));
    // 0x80303708: bne         $s2, $zero, L_80303714
    if (ctx->r18 != 0) {
        // 0x8030370C: nop
    
            goto L_80303714;
    }
    // 0x8030370C: nop

    // 0x80303710: break       7
    do_break(2150643472);
L_80303714:
    // 0x80303714: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80303718: bne         $s2, $at, L_8030372C
    if (ctx->r18 != ctx->r1) {
        // 0x8030371C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_8030372C;
    }
    // 0x8030371C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80303720: bne         $t9, $at, L_8030372C
    if (ctx->r25 != ctx->r1) {
        // 0x80303724: nop
    
            goto L_8030372C;
    }
    // 0x80303724: nop

    // 0x80303728: break       6
    do_break(2150643496);
L_8030372C:
    // 0x8030372C: mflo        $t6
    ctx->r14 = lo;
    // 0x80303730: sh          $t6, 0xC8($s0)
    MEM_H(0XC8, ctx->r16) = ctx->r14;
    // 0x80303734: bgez        $a2, L_80303744
    if (SIGNED(ctx->r6) >= 0) {
        // 0x80303738: sra         $v0, $a2, 5
        ctx->r2 = S32(SIGNED(ctx->r6) >> 5);
            goto L_80303744;
    }
    // 0x80303738: sra         $v0, $a2, 5
    ctx->r2 = S32(SIGNED(ctx->r6) >> 5);
    // 0x8030373C: addiu       $at, $a2, 0x1F
    ctx->r1 = ADD32(ctx->r6, 0X1F);
    // 0x80303740: sra         $v0, $at, 5
    ctx->r2 = S32(SIGNED(ctx->r1) >> 5);
L_80303744:
    // 0x80303744: lw          $t7, 0x34($sp)
    ctx->r15 = MEM_W(ctx->r29, 0X34);
    // 0x80303748: addu        $t8, $v0, $t7
    ctx->r24 = ADD32(ctx->r2, ctx->r15);
    // 0x8030374C: sh          $t8, 0xCC($s0)
    MEM_H(0XCC, ctx->r16) = ctx->r24;
    // 0x80303750: bgez        $v1, L_80303760
    if (SIGNED(ctx->r3) >= 0) {
        // 0x80303754: sra         $t9, $v1, 5
        ctx->r25 = S32(SIGNED(ctx->r3) >> 5);
            goto L_80303760;
    }
    // 0x80303754: sra         $t9, $v1, 5
    ctx->r25 = S32(SIGNED(ctx->r3) >> 5);
    // 0x80303758: addiu       $at, $v1, 0x1F
    ctx->r1 = ADD32(ctx->r3, 0X1F);
    // 0x8030375C: sra         $t9, $at, 5
    ctx->r25 = S32(SIGNED(ctx->r1) >> 5);
L_80303760:
    // 0x80303760: sra         $t6, $t9, 4
    ctx->r14 = S32(SIGNED(ctx->r25) >> 4);
    // 0x80303764: sw          $t6, 0xD0($s0)
    MEM_W(0XD0, ctx->r16) = ctx->r14;
    // 0x80303768: lw          $t8, 0x44($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X44);
    // 0x8030376C: or          $v1, $t6, $zero
    ctx->r3 = ctx->r14 | 0;
    // 0x80303770: lw          $t6, 0x4C($sp)
    ctx->r14 = MEM_W(ctx->r29, 0X4C);
    // 0x80303774: multu       $t8, $s1
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r17)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80303778: sll         $t7, $a3, 4
    ctx->r15 = S32(ctx->r7 << 4);
    // 0x8030377C: addu        $t0, $a0, $t7
    ctx->r8 = ADD32(ctx->r4, ctx->r15);
    // 0x80303780: mflo        $t9
    ctx->r25 = lo;
    // 0x80303784: addu        $t7, $t9, $t6
    ctx->r15 = ADD32(ctx->r25, ctx->r14);
    // 0x80303788: nop

    // 0x8030378C: div         $zero, $t7, $s2
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r18))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r18)));
    // 0x80303790: mflo        $t8
    ctx->r24 = lo;
    // 0x80303794: sh          $t8, 0xD4($t0)
    MEM_H(0XD4, ctx->r8) = ctx->r24;
    // 0x80303798: bne         $s2, $zero, L_803037A4
    if (ctx->r18 != 0) {
        // 0x8030379C: nop
    
            goto L_803037A4;
    }
    // 0x8030379C: nop

    // 0x803037A0: break       7
    do_break(2150643616);
L_803037A4:
    // 0x803037A4: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x803037A8: bne         $s2, $at, L_803037BC
    if (ctx->r18 != ctx->r1) {
        // 0x803037AC: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_803037BC;
    }
    // 0x803037AC: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x803037B0: bne         $t7, $at, L_803037BC
    if (ctx->r15 != ctx->r1) {
        // 0x803037B4: nop
    
            goto L_803037BC;
    }
    // 0x803037B4: nop

    // 0x803037B8: break       6
    do_break(2150643640);
L_803037BC:
    // 0x803037BC: multu       $t2, $s1
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r17)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803037C0: mflo        $t9
    ctx->r25 = lo;
    // 0x803037C4: addu        $t6, $t9, $t1
    ctx->r14 = ADD32(ctx->r25, ctx->r9);
    // 0x803037C8: nop

    // 0x803037CC: div         $zero, $t6, $s2
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r18))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r18)));
    // 0x803037D0: mflo        $t7
    ctx->r15 = lo;
    // 0x803037D4: sh          $t7, 0xD8($t0)
    MEM_H(0XD8, ctx->r8) = ctx->r15;
    // 0x803037D8: lw          $t8, 0x28($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X28);
    // 0x803037DC: sw          $v1, 0xE0($t0)
    MEM_W(0XE0, ctx->r8) = ctx->r3;
    // 0x803037E0: bne         $s2, $zero, L_803037EC
    if (ctx->r18 != 0) {
        // 0x803037E4: nop
    
            goto L_803037EC;
    }
    // 0x803037E4: nop

    // 0x803037E8: break       7
    do_break(2150643688);
L_803037EC:
    // 0x803037EC: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x803037F0: bne         $s2, $at, L_80303804
    if (ctx->r18 != ctx->r1) {
        // 0x803037F4: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80303804;
    }
    // 0x803037F4: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x803037F8: bne         $t6, $at, L_80303804
    if (ctx->r14 != ctx->r1) {
        // 0x803037FC: nop
    
            goto L_80303804;
    }
    // 0x803037FC: nop

    // 0x80303800: break       6
    do_break(2150643712);
L_80303804:
    // 0x80303804: addu        $t9, $v0, $t8
    ctx->r25 = ADD32(ctx->r2, ctx->r24);
    // 0x80303808: sh          $t9, 0xDC($t0)
    MEM_H(0XDC, ctx->r8) = ctx->r25;
    // 0x8030380C: lw          $s2, 0xC($sp)
    ctx->r18 = MEM_W(ctx->r29, 0XC);
    // 0x80303810: lw          $s1, 0x8($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X8);
    // 0x80303814: lw          $s0, 0x4($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X4);
    // 0x80303818: jr          $ra
    // 0x8030381C: addiu       $sp, $sp, 0x50
    ctx->r29 = ADD32(ctx->r29, 0X50);
    return;
    // 0x8030381C: addiu       $sp, $sp, 0x50
    ctx->r29 = ADD32(ctx->r29, 0X50);
;}
RECOMP_FUNC void func_80303820_714ED0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80303820: addiu       $sp, $sp, -0x8
    ctx->r29 = ADD32(ctx->r29, -0X8);
    // 0x80303824: sw          $a1, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r5;
    // 0x80303828: andi        $t6, $a1, 0xFFFF
    ctx->r14 = ctx->r5 & 0XFFFF;
    // 0x8030382C: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x80303830: andi        $t7, $a2, 0xFFFF
    ctx->r15 = ctx->r6 & 0XFFFF;
    // 0x80303834: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x80303838: sll         $t9, $t7, 3
    ctx->r25 = S32(ctx->r15 << 3);
    // 0x8030383C: lui         $t6, 0x8020
    ctx->r14 = S32(0X8020 << 16);
    // 0x80303840: or          $a2, $t7, $zero
    ctx->r6 = ctx->r15 | 0;
    // 0x80303844: addiu       $t6, $t6, 0x3FE0
    ctx->r14 = ADD32(ctx->r14, 0X3FE0);
    // 0x80303848: sw          $a3, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r7;
    // 0x8030384C: andi        $t8, $a3, 0xFFFF
    ctx->r24 = ctx->r7 & 0XFFFF;
    // 0x80303850: addu        $v1, $t9, $t6
    ctx->r3 = ADD32(ctx->r25, ctx->r14);
    // 0x80303854: sll         $t7, $a1, 3
    ctx->r15 = S32(ctx->r5 << 3);
    // 0x80303858: or          $a3, $t8, $zero
    ctx->r7 = ctx->r24 | 0;
    // 0x8030385C: addu        $t0, $t7, $t6
    ctx->r8 = ADD32(ctx->r15, ctx->r14);
    // 0x80303860: lh          $t9, 0x0($t0)
    ctx->r25 = MEM_H(ctx->r8, 0X0);
    // 0x80303864: lh          $t8, 0x0($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X0);
    // 0x80303868: lh          $t6, 0x2($v1)
    ctx->r14 = MEM_H(ctx->r3, 0X2);
    // 0x8030386C: sw          $s0, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r16;
    // 0x80303870: addu        $v0, $t8, $t9
    ctx->r2 = ADD32(ctx->r24, ctx->r25);
    // 0x80303874: lh          $t8, 0x2($t0)
    ctx->r24 = MEM_H(ctx->r8, 0X2);
    // 0x80303878: sra         $t7, $v0, 1
    ctx->r15 = S32(SIGNED(ctx->r2) >> 1);
    // 0x8030387C: or          $v0, $t7, $zero
    ctx->r2 = ctx->r15 | 0;
    // 0x80303880: addu        $t1, $t6, $t8
    ctx->r9 = ADD32(ctx->r14, ctx->r24);
    // 0x80303884: lh          $t6, 0x4($t0)
    ctx->r14 = MEM_H(ctx->r8, 0X4);
    // 0x80303888: lh          $t7, 0x4($v1)
    ctx->r15 = MEM_H(ctx->r3, 0X4);
    // 0x8030388C: lh          $t4, 0x302($a0)
    ctx->r12 = MEM_H(ctx->r4, 0X302);
    // 0x80303890: sra         $t9, $t1, 1
    ctx->r25 = S32(SIGNED(ctx->r9) >> 1);
    // 0x80303894: or          $t1, $t9, $zero
    ctx->r9 = ctx->r25 | 0;
    // 0x80303898: addu        $t2, $t7, $t6
    ctx->r10 = ADD32(ctx->r15, ctx->r14);
    // 0x8030389C: addiu       $t9, $t4, 0x40
    ctx->r25 = ADD32(ctx->r12, 0X40);
    // 0x803038A0: andi        $t7, $t9, 0xFF
    ctx->r15 = ctx->r25 & 0XFF;
    // 0x803038A4: sll         $t6, $t7, 1
    ctx->r14 = S32(ctx->r15 << 1);
    // 0x803038A8: lui         $t3, 0x8015
    ctx->r11 = S32(0X8015 << 16);
    // 0x803038AC: addu        $t3, $t3, $t6
    ctx->r11 = ADD32(ctx->r11, ctx->r14);
    // 0x803038B0: lh          $t3, 0x2C78($t3)
    ctx->r11 = MEM_H(ctx->r11, 0X2C78);
    // 0x803038B4: sra         $t8, $t2, 1
    ctx->r24 = S32(SIGNED(ctx->r10) >> 1);
    // 0x803038B8: or          $t2, $t8, $zero
    ctx->r10 = ctx->r24 | 0;
    // 0x803038BC: sra         $t8, $t3, 8
    ctx->r24 = S32(SIGNED(ctx->r11) >> 8);
    // 0x803038C0: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x803038C4: sra         $t3, $t9, 16
    ctx->r11 = S32(SIGNED(ctx->r25) >> 16);
    // 0x803038C8: multu       $t3, $v0
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803038CC: andi        $t6, $t4, 0xFF
    ctx->r14 = ctx->r12 & 0XFF;
    // 0x803038D0: sll         $t8, $t6, 1
    ctx->r24 = S32(ctx->r14 << 1);
    // 0x803038D4: lui         $t5, 0x8015
    ctx->r13 = S32(0X8015 << 16);
    // 0x803038D8: addu        $t5, $t5, $t8
    ctx->r13 = ADD32(ctx->r13, ctx->r24);
    // 0x803038DC: lh          $t5, 0x2C78($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X2C78);
    // 0x803038E0: sra         $t9, $t5, 8
    ctx->r25 = S32(SIGNED(ctx->r13) >> 8);
    // 0x803038E4: sll         $t7, $t9, 16
    ctx->r15 = S32(ctx->r25 << 16);
    // 0x803038E8: sra         $t6, $t7, 16
    ctx->r14 = S32(SIGNED(ctx->r15) >> 16);
    // 0x803038EC: or          $t5, $t6, $zero
    ctx->r13 = ctx->r14 | 0;
    // 0x803038F0: mflo        $t6
    ctx->r14 = lo;
    // 0x803038F4: lhu         $t9, 0x1A($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X1A);
    // 0x803038F8: bgez        $t2, L_80303908
    if (SIGNED(ctx->r10) >= 0) {
        // 0x803038FC: sra         $t8, $t2, 5
        ctx->r24 = S32(SIGNED(ctx->r10) >> 5);
            goto L_80303908;
    }
    // 0x803038FC: sra         $t8, $t2, 5
    ctx->r24 = S32(SIGNED(ctx->r10) >> 5);
    // 0x80303900: addiu       $at, $t2, 0x1F
    ctx->r1 = ADD32(ctx->r10, 0X1F);
    // 0x80303904: sra         $t8, $at, 5
    ctx->r24 = S32(SIGNED(ctx->r1) >> 5);
L_80303908:
    // 0x80303908: multu       $t1, $t5
    result = U64(U32(ctx->r9)) * U64(U32(ctx->r13)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8030390C: or          $t2, $t8, $zero
    ctx->r10 = ctx->r24 | 0;
    // 0x80303910: sll         $t7, $t9, 4
    ctx->r15 = S32(ctx->r25 << 4);
    // 0x80303914: addu        $s0, $a0, $t7
    ctx->r16 = ADD32(ctx->r4, ctx->r15);
    // 0x80303918: sh          $t2, 0xCC($s0)
    MEM_H(0XCC, ctx->r16) = ctx->r10;
    // 0x8030391C: mflo        $t8
    ctx->r24 = lo;
    // 0x80303920: addu        $t9, $t6, $t8
    ctx->r25 = ADD32(ctx->r14, ctx->r24);
    // 0x80303924: sra         $t7, $t9, 7
    ctx->r15 = S32(SIGNED(ctx->r25) >> 7);
    // 0x80303928: multu       $t3, $t1
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8030392C: bgez        $t7, L_8030393C
    if (SIGNED(ctx->r15) >= 0) {
        // 0x80303930: sra         $t6, $t7, 5
        ctx->r14 = S32(SIGNED(ctx->r15) >> 5);
            goto L_8030393C;
    }
    // 0x80303930: sra         $t6, $t7, 5
    ctx->r14 = S32(SIGNED(ctx->r15) >> 5);
    // 0x80303934: addiu       $at, $t7, 0x1F
    ctx->r1 = ADD32(ctx->r15, 0X1F);
    // 0x80303938: sra         $t6, $at, 5
    ctx->r14 = S32(SIGNED(ctx->r1) >> 5);
L_8030393C:
    // 0x8030393C: sh          $t6, 0xC4($s0)
    MEM_H(0XC4, ctx->r16) = ctx->r14;
    // 0x80303940: mflo        $t8
    ctx->r24 = lo;
    // 0x80303944: nop

    // 0x80303948: nop

    // 0x8030394C: multu       $v0, $t5
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r13)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80303950: mflo        $t9
    ctx->r25 = lo;
    // 0x80303954: subu        $t7, $t8, $t9
    ctx->r15 = SUB32(ctx->r24, ctx->r25);
    // 0x80303958: sra         $t6, $t7, 7
    ctx->r14 = S32(SIGNED(ctx->r15) >> 7);
    // 0x8030395C: bgez        $t6, L_8030396C
    if (SIGNED(ctx->r14) >= 0) {
        // 0x80303960: sra         $t8, $t6, 5
        ctx->r24 = S32(SIGNED(ctx->r14) >> 5);
            goto L_8030396C;
    }
    // 0x80303960: sra         $t8, $t6, 5
    ctx->r24 = S32(SIGNED(ctx->r14) >> 5);
    // 0x80303964: addiu       $at, $t6, 0x1F
    ctx->r1 = ADD32(ctx->r14, 0X1F);
    // 0x80303968: sra         $t8, $at, 5
    ctx->r24 = S32(SIGNED(ctx->r1) >> 5);
L_8030396C:
    // 0x8030396C: sh          $t8, 0xC8($s0)
    MEM_H(0XC8, ctx->r16) = ctx->r24;
    // 0x80303970: bgez        $a3, L_80303980
    if (SIGNED(ctx->r7) >= 0) {
        // 0x80303974: sra         $t9, $a3, 5
        ctx->r25 = S32(SIGNED(ctx->r7) >> 5);
            goto L_80303980;
    }
    // 0x80303974: sra         $t9, $a3, 5
    ctx->r25 = S32(SIGNED(ctx->r7) >> 5);
    // 0x80303978: addiu       $at, $a3, 0x1F
    ctx->r1 = ADD32(ctx->r7, 0X1F);
    // 0x8030397C: sra         $t9, $at, 5
    ctx->r25 = S32(SIGNED(ctx->r1) >> 5);
L_80303980:
    // 0x80303980: sw          $t9, 0xD0($s0)
    MEM_W(0XD0, ctx->r16) = ctx->r25;
    // 0x80303984: lw          $s0, 0x4($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X4);
    // 0x80303988: jr          $ra
    // 0x8030398C: addiu       $sp, $sp, 0x8
    ctx->r29 = ADD32(ctx->r29, 0X8);
    return;
    // 0x8030398C: addiu       $sp, $sp, 0x8
    ctx->r29 = ADD32(ctx->r29, 0X8);
;}
RECOMP_FUNC void func_80303990_715040(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80303990: addiu       $sp, $sp, -0x8
    ctx->r29 = ADD32(ctx->r29, -0X8);
    // 0x80303994: sw          $a1, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r5;
    // 0x80303998: andi        $t6, $a1, 0xFFFF
    ctx->r14 = ctx->r5 & 0XFFFF;
    // 0x8030399C: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x803039A0: andi        $t7, $a2, 0xFFFF
    ctx->r15 = ctx->r6 & 0XFFFF;
    // 0x803039A4: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x803039A8: sll         $t9, $t7, 3
    ctx->r25 = S32(ctx->r15 << 3);
    // 0x803039AC: lui         $t6, 0x8020
    ctx->r14 = S32(0X8020 << 16);
    // 0x803039B0: or          $a2, $t7, $zero
    ctx->r6 = ctx->r15 | 0;
    // 0x803039B4: addiu       $t6, $t6, 0x3FE0
    ctx->r14 = ADD32(ctx->r14, 0X3FE0);
    // 0x803039B8: sw          $a3, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r7;
    // 0x803039BC: andi        $t8, $a3, 0xFFFF
    ctx->r24 = ctx->r7 & 0XFFFF;
    // 0x803039C0: addu        $v1, $t9, $t6
    ctx->r3 = ADD32(ctx->r25, ctx->r14);
    // 0x803039C4: sll         $t7, $a1, 3
    ctx->r15 = S32(ctx->r5 << 3);
    // 0x803039C8: or          $a3, $t8, $zero
    ctx->r7 = ctx->r24 | 0;
    // 0x803039CC: addu        $t0, $t7, $t6
    ctx->r8 = ADD32(ctx->r15, ctx->r14);
    // 0x803039D0: lh          $t9, 0x0($t0)
    ctx->r25 = MEM_H(ctx->r8, 0X0);
    // 0x803039D4: lh          $t8, 0x0($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X0);
    // 0x803039D8: sw          $s0, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r16;
    // 0x803039DC: lh          $t4, 0x302($a0)
    ctx->r12 = MEM_H(ctx->r4, 0X302);
    // 0x803039E0: addu        $v0, $t8, $t9
    ctx->r2 = ADD32(ctx->r24, ctx->r25);
    // 0x803039E4: lh          $t9, 0x2($t0)
    ctx->r25 = MEM_H(ctx->r8, 0X2);
    // 0x803039E8: lh          $t8, 0x2($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X2);
    // 0x803039EC: sra         $t7, $v0, 1
    ctx->r15 = S32(SIGNED(ctx->r2) >> 1);
    // 0x803039F0: or          $v0, $t7, $zero
    ctx->r2 = ctx->r15 | 0;
    // 0x803039F4: addu        $t1, $t8, $t9
    ctx->r9 = ADD32(ctx->r24, ctx->r25);
    // 0x803039F8: lhu         $t8, 0x1A($sp)
    ctx->r24 = MEM_HU(ctx->r29, 0X1A);
    // 0x803039FC: sra         $t7, $t1, 1
    ctx->r15 = S32(SIGNED(ctx->r9) >> 1);
    // 0x80303A00: or          $t1, $t7, $zero
    ctx->r9 = ctx->r15 | 0;
    // 0x80303A04: sll         $t9, $t8, 3
    ctx->r25 = S32(ctx->r24 << 3);
    // 0x80303A08: addu        $t7, $t9, $t6
    ctx->r15 = ADD32(ctx->r25, ctx->r14);
    // 0x80303A0C: lh          $t8, 0x4($t7)
    ctx->r24 = MEM_H(ctx->r15, 0X4);
    // 0x80303A10: sll         $t9, $a3, 3
    ctx->r25 = S32(ctx->r7 << 3);
    // 0x80303A14: addu        $t7, $t9, $t6
    ctx->r15 = ADD32(ctx->r25, ctx->r14);
    // 0x80303A18: lh          $t9, 0x4($t7)
    ctx->r25 = MEM_H(ctx->r15, 0X4);
    // 0x80303A1C: addiu       $t7, $t4, 0x40
    ctx->r15 = ADD32(ctx->r12, 0X40);
    // 0x80303A20: lui         $t3, 0x8015
    ctx->r11 = S32(0X8015 << 16);
    // 0x80303A24: addu        $t2, $t8, $t9
    ctx->r10 = ADD32(ctx->r24, ctx->r25);
    // 0x80303A28: andi        $t8, $t7, 0xFF
    ctx->r24 = ctx->r15 & 0XFF;
    // 0x80303A2C: sll         $t9, $t8, 1
    ctx->r25 = S32(ctx->r24 << 1);
    // 0x80303A30: addu        $t3, $t3, $t9
    ctx->r11 = ADD32(ctx->r11, ctx->r25);
    // 0x80303A34: lh          $t3, 0x2C78($t3)
    ctx->r11 = MEM_H(ctx->r11, 0X2C78);
    // 0x80303A38: sra         $t6, $t2, 1
    ctx->r14 = S32(SIGNED(ctx->r10) >> 1);
    // 0x80303A3C: or          $t2, $t6, $zero
    ctx->r10 = ctx->r14 | 0;
    // 0x80303A40: sra         $t6, $t3, 8
    ctx->r14 = S32(SIGNED(ctx->r11) >> 8);
    // 0x80303A44: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x80303A48: sra         $t3, $t7, 16
    ctx->r11 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80303A4C: multu       $t3, $v0
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80303A50: andi        $t9, $t4, 0xFF
    ctx->r25 = ctx->r12 & 0XFF;
    // 0x80303A54: sll         $t6, $t9, 1
    ctx->r14 = S32(ctx->r25 << 1);
    // 0x80303A58: lui         $t5, 0x8015
    ctx->r13 = S32(0X8015 << 16);
    // 0x80303A5C: addu        $t5, $t5, $t6
    ctx->r13 = ADD32(ctx->r13, ctx->r14);
    // 0x80303A60: lh          $t5, 0x2C78($t5)
    ctx->r13 = MEM_H(ctx->r13, 0X2C78);
    // 0x80303A64: sra         $t7, $t5, 8
    ctx->r15 = S32(SIGNED(ctx->r13) >> 8);
    // 0x80303A68: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x80303A6C: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80303A70: or          $t5, $t9, $zero
    ctx->r13 = ctx->r25 | 0;
    // 0x80303A74: mflo        $t9
    ctx->r25 = lo;
    // 0x80303A78: lhu         $t7, 0x22($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X22);
    // 0x80303A7C: bgez        $t2, L_80303A8C
    if (SIGNED(ctx->r10) >= 0) {
        // 0x80303A80: sra         $t6, $t2, 5
        ctx->r14 = S32(SIGNED(ctx->r10) >> 5);
            goto L_80303A8C;
    }
    // 0x80303A80: sra         $t6, $t2, 5
    ctx->r14 = S32(SIGNED(ctx->r10) >> 5);
    // 0x80303A84: addiu       $at, $t2, 0x1F
    ctx->r1 = ADD32(ctx->r10, 0X1F);
    // 0x80303A88: sra         $t6, $at, 5
    ctx->r14 = S32(SIGNED(ctx->r1) >> 5);
L_80303A8C:
    // 0x80303A8C: multu       $t1, $t5
    result = U64(U32(ctx->r9)) * U64(U32(ctx->r13)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80303A90: or          $t2, $t6, $zero
    ctx->r10 = ctx->r14 | 0;
    // 0x80303A94: sll         $t8, $t7, 4
    ctx->r24 = S32(ctx->r15 << 4);
    // 0x80303A98: addu        $s0, $a0, $t8
    ctx->r16 = ADD32(ctx->r4, ctx->r24);
    // 0x80303A9C: sh          $t2, 0xCC($s0)
    MEM_H(0XCC, ctx->r16) = ctx->r10;
    // 0x80303AA0: mflo        $t6
    ctx->r14 = lo;
    // 0x80303AA4: addu        $t7, $t9, $t6
    ctx->r15 = ADD32(ctx->r25, ctx->r14);
    // 0x80303AA8: sra         $t8, $t7, 7
    ctx->r24 = S32(SIGNED(ctx->r15) >> 7);
    // 0x80303AAC: multu       $t3, $t1
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80303AB0: bgez        $t8, L_80303AC0
    if (SIGNED(ctx->r24) >= 0) {
        // 0x80303AB4: sra         $t9, $t8, 5
        ctx->r25 = S32(SIGNED(ctx->r24) >> 5);
            goto L_80303AC0;
    }
    // 0x80303AB4: sra         $t9, $t8, 5
    ctx->r25 = S32(SIGNED(ctx->r24) >> 5);
    // 0x80303AB8: addiu       $at, $t8, 0x1F
    ctx->r1 = ADD32(ctx->r24, 0X1F);
    // 0x80303ABC: sra         $t9, $at, 5
    ctx->r25 = S32(SIGNED(ctx->r1) >> 5);
L_80303AC0:
    // 0x80303AC0: sh          $t9, 0xC4($s0)
    MEM_H(0XC4, ctx->r16) = ctx->r25;
    // 0x80303AC4: mflo        $t6
    ctx->r14 = lo;
    // 0x80303AC8: nop

    // 0x80303ACC: nop

    // 0x80303AD0: multu       $v0, $t5
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r13)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80303AD4: mflo        $t7
    ctx->r15 = lo;
    // 0x80303AD8: subu        $t8, $t6, $t7
    ctx->r24 = SUB32(ctx->r14, ctx->r15);
    // 0x80303ADC: sra         $t9, $t8, 7
    ctx->r25 = S32(SIGNED(ctx->r24) >> 7);
    // 0x80303AE0: bgez        $t9, L_80303AF0
    if (SIGNED(ctx->r25) >= 0) {
        // 0x80303AE4: sra         $t6, $t9, 5
        ctx->r14 = S32(SIGNED(ctx->r25) >> 5);
            goto L_80303AF0;
    }
    // 0x80303AE4: sra         $t6, $t9, 5
    ctx->r14 = S32(SIGNED(ctx->r25) >> 5);
    // 0x80303AE8: addiu       $at, $t9, 0x1F
    ctx->r1 = ADD32(ctx->r25, 0X1F);
    // 0x80303AEC: sra         $t6, $at, 5
    ctx->r14 = S32(SIGNED(ctx->r1) >> 5);
L_80303AF0:
    // 0x80303AF0: sh          $t6, 0xC8($s0)
    MEM_H(0XC8, ctx->r16) = ctx->r14;
    // 0x80303AF4: lhu         $t7, 0x1E($sp)
    ctx->r15 = MEM_HU(ctx->r29, 0X1E);
    // 0x80303AF8: bgez        $t7, L_80303B08
    if (SIGNED(ctx->r15) >= 0) {
        // 0x80303AFC: sra         $t8, $t7, 5
        ctx->r24 = S32(SIGNED(ctx->r15) >> 5);
            goto L_80303B08;
    }
    // 0x80303AFC: sra         $t8, $t7, 5
    ctx->r24 = S32(SIGNED(ctx->r15) >> 5);
    // 0x80303B00: addiu       $at, $t7, 0x1F
    ctx->r1 = ADD32(ctx->r15, 0X1F);
    // 0x80303B04: sra         $t8, $at, 5
    ctx->r24 = S32(SIGNED(ctx->r1) >> 5);
L_80303B08:
    // 0x80303B08: sw          $t8, 0xD0($s0)
    MEM_W(0XD0, ctx->r16) = ctx->r24;
    // 0x80303B0C: lw          $s0, 0x4($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X4);
    // 0x80303B10: jr          $ra
    // 0x80303B14: addiu       $sp, $sp, 0x8
    ctx->r29 = ADD32(ctx->r29, 0X8);
    return;
    // 0x80303B14: addiu       $sp, $sp, 0x8
    ctx->r29 = ADD32(ctx->r29, 0X8);
;}
RECOMP_FUNC void func_80303B18_7151C8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80303B18: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x80303B1C: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x80303B20: sll         $t7, $a2, 16
    ctx->r15 = S32(ctx->r6 << 16);
    // 0x80303B24: sw          $a3, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r7;
    // 0x80303B28: lh          $t3, 0x302($a0)
    ctx->r11 = MEM_H(ctx->r4, 0X302);
    // 0x80303B2C: sra         $a2, $t7, 16
    ctx->r6 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80303B30: andi        $t6, $a1, 0xFFFF
    ctx->r14 = ctx->r5 & 0XFFFF;
    // 0x80303B34: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x80303B38: andi        $t9, $a3, 0xFFFF
    ctx->r25 = ctx->r7 & 0XFFFF;
    // 0x80303B3C: lui         $t7, 0x8020
    ctx->r15 = S32(0X8020 << 16);
    // 0x80303B40: or          $a3, $t9, $zero
    ctx->r7 = ctx->r25 | 0;
    // 0x80303B44: addiu       $t7, $t7, 0x3FE0
    ctx->r15 = ADD32(ctx->r15, 0X3FE0);
    // 0x80303B48: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x80303B4C: addu        $v1, $t6, $t7
    ctx->r3 = ADD32(ctx->r14, ctx->r15);
    // 0x80303B50: addiu       $t9, $t3, 0x40
    ctx->r25 = ADD32(ctx->r11, 0X40);
    // 0x80303B54: andi        $t6, $t9, 0xFF
    ctx->r14 = ctx->r25 & 0XFF;
    // 0x80303B58: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x80303B5C: lui         $t2, 0x8015
    ctx->r10 = S32(0X8015 << 16);
    // 0x80303B60: lh          $t8, 0x4($v1)
    ctx->r24 = MEM_H(ctx->r3, 0X4);
    // 0x80303B64: addu        $t2, $t2, $t7
    ctx->r10 = ADD32(ctx->r10, ctx->r15);
    // 0x80303B68: lh          $t2, 0x2C78($t2)
    ctx->r10 = MEM_H(ctx->r10, 0X2C78);
    // 0x80303B6C: addu        $t1, $t8, $a2
    ctx->r9 = ADD32(ctx->r24, ctx->r6);
    // 0x80303B70: lh          $v0, 0x0($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X0);
    // 0x80303B74: sra         $t8, $t2, 8
    ctx->r24 = S32(SIGNED(ctx->r10) >> 8);
    // 0x80303B78: sll         $t9, $t8, 16
    ctx->r25 = S32(ctx->r24 << 16);
    // 0x80303B7C: sra         $t2, $t9, 16
    ctx->r10 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80303B80: multu       $t2, $v0
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80303B84: andi        $t7, $t3, 0xFF
    ctx->r15 = ctx->r11 & 0XFF;
    // 0x80303B88: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x80303B8C: lui         $t4, 0x8015
    ctx->r12 = S32(0X8015 << 16);
    // 0x80303B90: addu        $t4, $t4, $t8
    ctx->r12 = ADD32(ctx->r12, ctx->r24);
    // 0x80303B94: lh          $t4, 0x2C78($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X2C78);
    // 0x80303B98: lh          $t0, 0x2($v1)
    ctx->r8 = MEM_H(ctx->r3, 0X2);
    // 0x80303B9C: sra         $t9, $t4, 8
    ctx->r25 = S32(SIGNED(ctx->r12) >> 8);
    // 0x80303BA0: sll         $t6, $t9, 16
    ctx->r14 = S32(ctx->r25 << 16);
    // 0x80303BA4: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80303BA8: or          $t4, $t7, $zero
    ctx->r12 = ctx->r15 | 0;
    // 0x80303BAC: mflo        $t7
    ctx->r15 = lo;
    // 0x80303BB0: lhu         $t9, 0x12($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X12);
    // 0x80303BB4: bgez        $t1, L_80303BC4
    if (SIGNED(ctx->r9) >= 0) {
        // 0x80303BB8: sra         $t8, $t1, 5
        ctx->r24 = S32(SIGNED(ctx->r9) >> 5);
            goto L_80303BC4;
    }
    // 0x80303BB8: sra         $t8, $t1, 5
    ctx->r24 = S32(SIGNED(ctx->r9) >> 5);
    // 0x80303BBC: addiu       $at, $t1, 0x1F
    ctx->r1 = ADD32(ctx->r9, 0X1F);
    // 0x80303BC0: sra         $t8, $at, 5
    ctx->r24 = S32(SIGNED(ctx->r1) >> 5);
L_80303BC4:
    // 0x80303BC4: multu       $t0, $t4
    result = U64(U32(ctx->r8)) * U64(U32(ctx->r12)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80303BC8: or          $t1, $t8, $zero
    ctx->r9 = ctx->r24 | 0;
    // 0x80303BCC: sll         $t6, $t9, 4
    ctx->r14 = S32(ctx->r25 << 4);
    // 0x80303BD0: addu        $t5, $a0, $t6
    ctx->r13 = ADD32(ctx->r4, ctx->r14);
    // 0x80303BD4: sh          $t1, 0xCC($t5)
    MEM_H(0XCC, ctx->r13) = ctx->r9;
    // 0x80303BD8: mflo        $t8
    ctx->r24 = lo;
    // 0x80303BDC: addu        $t9, $t7, $t8
    ctx->r25 = ADD32(ctx->r15, ctx->r24);
    // 0x80303BE0: sra         $t6, $t9, 7
    ctx->r14 = S32(SIGNED(ctx->r25) >> 7);
    // 0x80303BE4: multu       $t2, $t0
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r8)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80303BE8: bgez        $t6, L_80303BF8
    if (SIGNED(ctx->r14) >= 0) {
        // 0x80303BEC: sra         $t7, $t6, 5
        ctx->r15 = S32(SIGNED(ctx->r14) >> 5);
            goto L_80303BF8;
    }
    // 0x80303BEC: sra         $t7, $t6, 5
    ctx->r15 = S32(SIGNED(ctx->r14) >> 5);
    // 0x80303BF0: addiu       $at, $t6, 0x1F
    ctx->r1 = ADD32(ctx->r14, 0X1F);
    // 0x80303BF4: sra         $t7, $at, 5
    ctx->r15 = S32(SIGNED(ctx->r1) >> 5);
L_80303BF8:
    // 0x80303BF8: sh          $t7, 0xC4($t5)
    MEM_H(0XC4, ctx->r13) = ctx->r15;
    // 0x80303BFC: mflo        $t8
    ctx->r24 = lo;
    // 0x80303C00: nop

    // 0x80303C04: nop

    // 0x80303C08: multu       $v0, $t4
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r12)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80303C0C: mflo        $t9
    ctx->r25 = lo;
    // 0x80303C10: subu        $t6, $t8, $t9
    ctx->r14 = SUB32(ctx->r24, ctx->r25);
    // 0x80303C14: sra         $t7, $t6, 7
    ctx->r15 = S32(SIGNED(ctx->r14) >> 7);
    // 0x80303C18: bgez        $t7, L_80303C28
    if (SIGNED(ctx->r15) >= 0) {
        // 0x80303C1C: sra         $t8, $t7, 5
        ctx->r24 = S32(SIGNED(ctx->r15) >> 5);
            goto L_80303C28;
    }
    // 0x80303C1C: sra         $t8, $t7, 5
    ctx->r24 = S32(SIGNED(ctx->r15) >> 5);
    // 0x80303C20: addiu       $at, $t7, 0x1F
    ctx->r1 = ADD32(ctx->r15, 0X1F);
    // 0x80303C24: sra         $t8, $at, 5
    ctx->r24 = S32(SIGNED(ctx->r1) >> 5);
L_80303C28:
    // 0x80303C28: sh          $t8, 0xC8($t5)
    MEM_H(0XC8, ctx->r13) = ctx->r24;
    // 0x80303C2C: bgez        $a3, L_80303C3C
    if (SIGNED(ctx->r7) >= 0) {
        // 0x80303C30: sra         $t9, $a3, 5
        ctx->r25 = S32(SIGNED(ctx->r7) >> 5);
            goto L_80303C3C;
    }
    // 0x80303C30: sra         $t9, $a3, 5
    ctx->r25 = S32(SIGNED(ctx->r7) >> 5);
    // 0x80303C34: addiu       $at, $a3, 0x1F
    ctx->r1 = ADD32(ctx->r7, 0X1F);
    // 0x80303C38: sra         $t9, $at, 5
    ctx->r25 = S32(SIGNED(ctx->r1) >> 5);
L_80303C3C:
    // 0x80303C3C: jr          $ra
    // 0x80303C40: sw          $t9, 0xD0($t5)
    MEM_W(0XD0, ctx->r13) = ctx->r25;
    return;
    // 0x80303C40: sw          $t9, 0xD0($t5)
    MEM_W(0XD0, ctx->r13) = ctx->r25;
;}
RECOMP_FUNC void func_80303C44_7152F4(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80303C44: lui         $t1, 0x803D
    ctx->r9 = S32(0X803D << 16);
    // 0x80303C48: addiu       $t1, $t1, 0x552C
    ctx->r9 = ADD32(ctx->r9, 0X552C);
    // 0x80303C4C: lw          $v1, 0x0($t1)
    ctx->r3 = MEM_W(ctx->r9, 0X0);
    // 0x80303C50: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x80303C54: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x80303C58: sw          $a3, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r7;
    // 0x80303C5C: lh          $t5, 0x302($v1)
    ctx->r13 = MEM_H(ctx->r3, 0X302);
    // 0x80303C60: andi        $t6, $a1, 0xFFFF
    ctx->r14 = ctx->r5 & 0XFFFF;
    // 0x80303C64: sll         $t7, $a2, 16
    ctx->r15 = S32(ctx->r6 << 16);
    // 0x80303C68: sll         $t4, $t6, 4
    ctx->r12 = S32(ctx->r14 << 4);
    // 0x80303C6C: sra         $a2, $t7, 16
    ctx->r6 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80303C70: lui         $t2, 0x8015
    ctx->r10 = S32(0X8015 << 16);
    // 0x80303C74: andi        $t6, $t5, 0xFF
    ctx->r14 = ctx->r13 & 0XFF;
    // 0x80303C78: addiu       $t2, $t2, 0x2C78
    ctx->r10 = ADD32(ctx->r10, 0X2C78);
    // 0x80303C7C: or          $t9, $a3, $zero
    ctx->r25 = ctx->r7 | 0;
    // 0x80303C80: sll         $t7, $t6, 1
    ctx->r15 = S32(ctx->r14 << 1);
    // 0x80303C84: or          $a3, $t9, $zero
    ctx->r7 = ctx->r25 | 0;
    // 0x80303C88: addu        $t8, $t2, $t7
    ctx->r24 = ADD32(ctx->r10, ctx->r15);
    // 0x80303C8C: lh          $t9, 0x0($t8)
    ctx->r25 = MEM_H(ctx->r24, 0X0);
    // 0x80303C90: addu        $t0, $a0, $t4
    ctx->r8 = ADD32(ctx->r4, ctx->r12);
    // 0x80303C94: lw          $v0, 0x320($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X320);
    // 0x80303C98: sra         $t3, $t9, 7
    ctx->r11 = S32(SIGNED(ctx->r25) >> 7);
    // 0x80303C9C: multu       $t3, $a2
    result = U64(U32(ctx->r11)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80303CA0: mflo        $t4
    ctx->r12 = lo;
    // 0x80303CA4: sra         $t5, $t4, 8
    ctx->r13 = S32(SIGNED(ctx->r12) >> 8);
    // 0x80303CA8: sh          $t5, 0xC4($t0)
    MEM_H(0XC4, ctx->r8) = ctx->r13;
    // 0x80303CAC: lw          $t6, 0x0($t1)
    ctx->r14 = MEM_W(ctx->r9, 0X0);
    // 0x80303CB0: lh          $t7, 0x302($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X302);
    // 0x80303CB4: addiu       $t8, $t7, 0x40
    ctx->r24 = ADD32(ctx->r15, 0X40);
    // 0x80303CB8: andi        $t9, $t8, 0xFF
    ctx->r25 = ctx->r24 & 0XFF;
    // 0x80303CBC: sll         $t3, $t9, 1
    ctx->r11 = S32(ctx->r25 << 1);
    // 0x80303CC0: addu        $t4, $t2, $t3
    ctx->r12 = ADD32(ctx->r10, ctx->r11);
    // 0x80303CC4: lh          $t5, 0x0($t4)
    ctx->r13 = MEM_H(ctx->r12, 0X0);
    // 0x80303CC8: sra         $t6, $t5, 7
    ctx->r14 = S32(SIGNED(ctx->r13) >> 7);
    // 0x80303CCC: multu       $t6, $a2
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80303CD0: mflo        $t7
    ctx->r15 = lo;
    // 0x80303CD4: sra         $t8, $t7, 8
    ctx->r24 = S32(SIGNED(ctx->r15) >> 8);
    // 0x80303CD8: sh          $t8, 0xC8($t0)
    MEM_H(0XC8, ctx->r8) = ctx->r24;
    // 0x80303CDC: lh          $t9, 0x7C($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X7C);
    // 0x80303CE0: addu        $t3, $t9, $a3
    ctx->r11 = ADD32(ctx->r25, ctx->r7);
    // 0x80303CE4: sh          $t3, 0xCC($t0)
    MEM_H(0XCC, ctx->r8) = ctx->r11;
    // 0x80303CE8: lw          $t4, 0x80($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X80);
    // 0x80303CEC: sll         $t5, $t4, 2
    ctx->r13 = S32(ctx->r12 << 2);
    // 0x80303CF0: subu        $t5, $t5, $t4
    ctx->r13 = SUB32(ctx->r13, ctx->r12);
    // 0x80303CF4: sra         $t6, $t5, 2
    ctx->r14 = S32(SIGNED(ctx->r13) >> 2);
    // 0x80303CF8: jr          $ra
    // 0x80303CFC: sw          $t6, 0xD0($t0)
    MEM_W(0XD0, ctx->r8) = ctx->r14;
    return;
    // 0x80303CFC: sw          $t6, 0xD0($t0)
    MEM_W(0XD0, ctx->r8) = ctx->r14;
;}
RECOMP_FUNC void func_80303D00_7153B0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80303D00: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x80303D04: andi        $t7, $a2, 0xFFFF
    ctx->r15 = ctx->r6 & 0XFFFF;
    // 0x80303D08: or          $a2, $t7, $zero
    ctx->r6 = ctx->r15 | 0;
    // 0x80303D0C: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x80303D10: andi        $t6, $a1, 0xFFFF
    ctx->r14 = ctx->r5 & 0XFFFF;
    // 0x80303D14: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x80303D18: sh          $zero, 0xC4($a0)
    MEM_H(0XC4, ctx->r4) = 0;
    // 0x80303D1C: sh          $zero, 0xC8($a0)
    MEM_H(0XC8, ctx->r4) = 0;
    // 0x80303D20: bgez        $a2, L_80303D30
    if (SIGNED(ctx->r6) >= 0) {
        // 0x80303D24: sra         $t8, $a2, 5
        ctx->r24 = S32(SIGNED(ctx->r6) >> 5);
            goto L_80303D30;
    }
    // 0x80303D24: sra         $t8, $a2, 5
    ctx->r24 = S32(SIGNED(ctx->r6) >> 5);
    // 0x80303D28: addiu       $at, $a2, 0x1F
    ctx->r1 = ADD32(ctx->r6, 0X1F);
    // 0x80303D2C: sra         $t8, $at, 5
    ctx->r24 = S32(SIGNED(ctx->r1) >> 5);
L_80303D30:
    // 0x80303D30: sh          $t8, 0xCC($a0)
    MEM_H(0XCC, ctx->r4) = ctx->r24;
    // 0x80303D34: bgez        $a1, L_80303D44
    if (SIGNED(ctx->r5) >= 0) {
        // 0x80303D38: sra         $t9, $a1, 5
        ctx->r25 = S32(SIGNED(ctx->r5) >> 5);
            goto L_80303D44;
    }
    // 0x80303D38: sra         $t9, $a1, 5
    ctx->r25 = S32(SIGNED(ctx->r5) >> 5);
    // 0x80303D3C: addiu       $at, $a1, 0x1F
    ctx->r1 = ADD32(ctx->r5, 0X1F);
    // 0x80303D40: sra         $t9, $at, 5
    ctx->r25 = S32(SIGNED(ctx->r1) >> 5);
L_80303D44:
    // 0x80303D44: sw          $t9, 0xD0($a0)
    MEM_W(0XD0, ctx->r4) = ctx->r25;
    // 0x80303D48: jr          $ra
    // 0x80303D4C: sw          $zero, 0xE0($a0)
    MEM_W(0XE0, ctx->r4) = 0;
    return;
    // 0x80303D4C: sw          $zero, 0xE0($a0)
    MEM_W(0XE0, ctx->r4) = 0;
;}
RECOMP_FUNC void func_80303D50_715400(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80303D50: andi        $t6, $a1, 0xFFFF
    ctx->r14 = ctx->r5 & 0XFFFF;
    // 0x80303D54: sll         $t7, $t6, 4
    ctx->r15 = S32(ctx->r14 << 4);
    // 0x80303D58: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x80303D5C: addu        $t8, $a0, $t7
    ctx->r24 = ADD32(ctx->r4, ctx->r15);
    // 0x80303D60: jr          $ra
    // 0x80303D64: sw          $zero, 0xD0($t8)
    MEM_W(0XD0, ctx->r24) = 0;
    return;
    // 0x80303D64: sw          $zero, 0xD0($t8)
    MEM_W(0XD0, ctx->r24) = 0;
;}
RECOMP_FUNC void func_80303D68_715418(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80303D68: addiu       $sp, $sp, -0x40
    ctx->r29 = ADD32(ctx->r29, -0X40);
    // 0x80303D6C: sw          $a1, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r5;
    // 0x80303D70: lhu         $t9, 0x46($sp)
    ctx->r25 = MEM_HU(ctx->r29, 0X46);
    // 0x80303D74: sw          $a0, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r4;
    // 0x80303D78: lw          $t8, 0x40($sp)
    ctx->r24 = MEM_W(ctx->r29, 0X40);
    // 0x80303D7C: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80303D80: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80303D84: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80303D88: ori         $at, $at, 0x8000
    ctx->r1 = ctx->r1 | 0X8000;
    // 0x80303D8C: addu        $t0, $a2, $at
    ctx->r8 = ADD32(ctx->r6, ctx->r1);
    // 0x80303D90: sll         $t3, $t9, 4
    ctx->r11 = S32(ctx->r25 << 4);
    // 0x80303D94: lw          $t6, 0x918($t0)
    ctx->r14 = MEM_W(ctx->r8, 0X918);
    // 0x80303D98: addu        $t2, $t8, $t3
    ctx->r10 = ADD32(ctx->r24, ctx->r11);
    // 0x80303D9C: lh          $t4, 0xC4($t2)
    ctx->r12 = MEM_H(ctx->r10, 0XC4);
    // 0x80303DA0: lh          $t5, 0x4($t8)
    ctx->r13 = MEM_H(ctx->r24, 0X4);
    // 0x80303DA4: sll         $t7, $t6, 6
    ctx->r15 = S32(ctx->r14 << 6);
    // 0x80303DA8: addu        $a0, $a2, $t7
    ctx->r4 = ADD32(ctx->r6, ctx->r15);
    // 0x80303DAC: addu        $t6, $t4, $t5
    ctx->r14 = ADD32(ctx->r12, ctx->r13);
    // 0x80303DB0: lh          $t4, 0xCC($t2)
    ctx->r12 = MEM_H(ctx->r10, 0XCC);
    // 0x80303DB4: lh          $t7, 0xC8($t2)
    ctx->r15 = MEM_H(ctx->r10, 0XC8);
    // 0x80303DB8: lh          $t5, 0xC($t8)
    ctx->r13 = MEM_H(ctx->r24, 0XC);
    // 0x80303DBC: lh          $t9, 0x8($t8)
    ctx->r25 = MEM_H(ctx->r24, 0X8);
    // 0x80303DC0: mtc1        $t6, $f4
    ctx->f4.u32l = ctx->r14;
    // 0x80303DC4: addu        $t6, $t4, $t5
    ctx->r14 = ADD32(ctx->r12, ctx->r13);
    // 0x80303DC8: addu        $t3, $t7, $t9
    ctx->r11 = ADD32(ctx->r15, ctx->r25);
    // 0x80303DCC: mtc1        $t3, $f6
    ctx->f6.u32l = ctx->r11;
    // 0x80303DD0: mtc1        $t6, $f8
    ctx->f8.u32l = ctx->r14;
    // 0x80303DD4: cvt.s.w     $f4, $f4
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 4);
    ctx->f4.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80303DD8: or          $s0, $a2, $zero
    ctx->r16 = ctx->r6 | 0;
    // 0x80303DDC: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80303DE0: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x80303DE4: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x80303DE8: cvt.s.w     $f6, $f6
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 6);
    ctx->f6.fl = CVT_S_W(ctx->f6.u32l);
    // 0x80303DEC: mfc1        $a1, $f4
    ctx->r5 = (int32_t)ctx->f4.u32l;
    // 0x80303DF0: sw          $t2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r10;
    // 0x80303DF4: sw          $t0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r8;
    // 0x80303DF8: cvt.s.w     $f8, $f8
    CHECK_FR(ctx, 8);
    CHECK_FR(ctx, 8);
    ctx->f8.fl = CVT_S_W(ctx->f8.u32l);
    // 0x80303DFC: mfc1        $a2, $f6
    ctx->r6 = (int32_t)ctx->f6.u32l;
    // 0x80303E00: mfc1        $a3, $f8
    ctx->r7 = (int32_t)ctx->f8.u32l;
    // 0x80303E04: jal         0x8013F328
    // 0x80303E08: nop

    guTranslate(rdram, ctx);
        goto after_0;
    // 0x80303E08: nop

    after_0:
    // 0x80303E0C: lui         $v1, 0x801E
    ctx->r3 = S32(0X801E << 16);
    // 0x80303E10: addiu       $v1, $v1, -0x6178
    ctx->r3 = ADD32(ctx->r3, -0X6178);
    // 0x80303E14: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x80303E18: lw          $t0, 0x24($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X24);
    // 0x80303E1C: lui         $t9, 0x104
    ctx->r25 = S32(0X104 << 16);
    // 0x80303E20: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80303E24: lw          $t2, 0x20($sp)
    ctx->r10 = MEM_W(ctx->r29, 0X20);
    // 0x80303E28: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x80303E2C: ori         $t9, $t9, 0x40
    ctx->r25 = ctx->r25 | 0X40;
    // 0x80303E30: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x80303E34: lw          $t3, 0x918($t0)
    ctx->r11 = MEM_W(ctx->r8, 0X918);
    // 0x80303E38: lui         $at, 0x8003
    ctx->r1 = S32(0X8003 << 16);
    // 0x80303E3C: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x80303E40: sll         $t8, $t3, 6
    ctx->r24 = S32(ctx->r11 << 6);
    // 0x80303E44: addu        $t4, $s0, $t8
    ctx->r12 = ADD32(ctx->r16, ctx->r24);
    // 0x80303E48: addu        $t5, $t4, $at
    ctx->r13 = ADD32(ctx->r12, ctx->r1);
    // 0x80303E4C: sw          $t5, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r13;
    // 0x80303E50: lw          $t6, 0x918($t0)
    ctx->r14 = MEM_W(ctx->r8, 0X918);
    // 0x80303E54: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x80303E58: addu        $at, $at, $s0
    ctx->r1 = ADD32(ctx->r1, ctx->r16);
    // 0x80303E5C: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x80303E60: sw          $t7, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r15;
    // 0x80303E64: lw          $t8, 0xD0($t2)
    ctx->r24 = MEM_W(ctx->r10, 0XD0);
    // 0x80303E68: lw          $t9, 0x918($t0)
    ctx->r25 = MEM_W(ctx->r8, 0X918);
    // 0x80303E6C: lui         $at, 0x3
    ctx->r1 = S32(0X3 << 16);
    // 0x80303E70: mtc1        $t8, $f10
    ctx->f10.u32l = ctx->r24;
    // 0x80303E74: sll         $t3, $t9, 6
    ctx->r11 = S32(ctx->r25 << 6);
    // 0x80303E78: addu        $a0, $s0, $t3
    ctx->r4 = ADD32(ctx->r16, ctx->r11);
    // 0x80303E7C: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x80303E80: cvt.d.w     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.d = CVT_D_W(ctx->f10.u32l);
    // 0x80303E84: addu        $a0, $a0, $at
    ctx->r4 = ADD32(ctx->r4, ctx->r1);
    // 0x80303E88: lui         $at, 0x3FF0
    ctx->r1 = S32(0X3FF0 << 16);
    // 0x80303E8C: mtc1        $at, $f19
    ctx->f_odd[(19 - 1) * 2] = ctx->r1;
    // 0x80303E90: mtc1        $zero, $f18
    ctx->f18.u32l = 0;
    // 0x80303E94: nop

    // 0x80303E98: mul.d       $f4, $f16, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 18);
    NAN_CHECK(ctx->f16.d); NAN_CHECK(ctx->f18.d); 
    ctx->f4.d = MUL_D(ctx->f16.d, ctx->f18.d);
    // 0x80303E9C: cvt.s.d     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    NAN_CHECK(ctx->f4.d); 
    ctx->f0.fl = CVT_S_D(ctx->f4.d);
    // 0x80303EA0: mfc1        $a1, $f0
    ctx->r5 = (int32_t)ctx->f0.u32l;
    // 0x80303EA4: mfc1        $a2, $f0
    ctx->r6 = (int32_t)ctx->f0.u32l;
    // 0x80303EA8: mfc1        $a3, $f0
    ctx->r7 = (int32_t)ctx->f0.u32l;
    // 0x80303EAC: jal         0x8013F664
    // 0x80303EB0: nop

    guScale(rdram, ctx);
        goto after_1;
    // 0x80303EB0: nop

    after_1:
    // 0x80303EB4: lui         $v1, 0x801E
    ctx->r3 = S32(0X801E << 16);
    // 0x80303EB8: addiu       $v1, $v1, -0x6178
    ctx->r3 = ADD32(ctx->r3, -0X6178);
    // 0x80303EBC: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x80303EC0: lw          $t0, 0x24($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X24);
    // 0x80303EC4: lui         $t5, 0x100
    ctx->r13 = S32(0X100 << 16);
    // 0x80303EC8: addiu       $t4, $v0, 0x8
    ctx->r12 = ADD32(ctx->r2, 0X8);
    // 0x80303ECC: sw          $t4, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r12;
    // 0x80303ED0: ori         $t5, $t5, 0x40
    ctx->r13 = ctx->r13 | 0X40;
    // 0x80303ED4: sw          $t5, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r13;
    // 0x80303ED8: lw          $t6, 0x918($t0)
    ctx->r14 = MEM_W(ctx->r8, 0X918);
    // 0x80303EDC: lui         $at, 0x8003
    ctx->r1 = S32(0X8003 << 16);
    // 0x80303EE0: ori         $at, $at, 0x3590
    ctx->r1 = ctx->r1 | 0X3590;
    // 0x80303EE4: sll         $t7, $t6, 6
    ctx->r15 = S32(ctx->r14 << 6);
    // 0x80303EE8: addu        $t9, $s0, $t7
    ctx->r25 = ADD32(ctx->r16, ctx->r15);
    // 0x80303EEC: addu        $t3, $t9, $at
    ctx->r11 = ADD32(ctx->r25, ctx->r1);
    // 0x80303EF0: sw          $t3, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r11;
    // 0x80303EF4: lw          $t8, 0x918($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X918);
    // 0x80303EF8: lui         $at, 0x4
    ctx->r1 = S32(0X4 << 16);
    // 0x80303EFC: addu        $at, $at, $s0
    ctx->r1 = ADD32(ctx->r1, ctx->r16);
    // 0x80303F00: addiu       $t4, $t8, 0x1
    ctx->r12 = ADD32(ctx->r24, 0X1);
    // 0x80303F04: sw          $t4, -0x76E8($at)
    MEM_W(-0X76E8, ctx->r1) = ctx->r12;
    // 0x80303F08: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x80303F0C: lui         $t6, 0x100
    ctx->r14 = S32(0X100 << 16);
    // 0x80303F10: lui         $t2, 0x600
    ctx->r10 = S32(0X600 << 16);
    // 0x80303F14: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x80303F18: sw          $t5, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r13;
    // 0x80303F1C: addiu       $t6, $t6, 0x3618
    ctx->r14 = ADD32(ctx->r14, 0X3618);
    // 0x80303F20: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x80303F24: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
    // 0x80303F28: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x80303F2C: lui         $t3, 0xFF00
    ctx->r11 = S32(0XFF00 << 16);
    // 0x80303F30: ori         $t3, $t3, 0xFF
    ctx->r11 = ctx->r11 | 0XFF;
    // 0x80303F34: addiu       $t7, $v0, 0x8
    ctx->r15 = ADD32(ctx->r2, 0X8);
    // 0x80303F38: sw          $t7, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r15;
    // 0x80303F3C: lui         $t9, 0xFA00
    ctx->r25 = S32(0XFA00 << 16);
    // 0x80303F40: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x80303F44: sw          $t3, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r11;
    // 0x80303F48: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x80303F4C: lui         $t4, 0x103
    ctx->r12 = S32(0X103 << 16);
    // 0x80303F50: addiu       $t4, $t4, 0x7700
    ctx->r12 = ADD32(ctx->r12, 0X7700);
    // 0x80303F54: addiu       $t8, $v0, 0x8
    ctx->r24 = ADD32(ctx->r2, 0X8);
    // 0x80303F58: sw          $t8, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r24;
    // 0x80303F5C: sw          $t4, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r12;
    // 0x80303F60: sw          $t2, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r10;
    // 0x80303F64: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x80303F68: lui         $t6, 0xBD00
    ctx->r14 = S32(0XBD00 << 16);
    // 0x80303F6C: addiu       $t5, $v0, 0x8
    ctx->r13 = ADD32(ctx->r2, 0X8);
    // 0x80303F70: sw          $t5, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r13;
    // 0x80303F74: sw          $zero, 0x4($v0)
    MEM_W(0X4, ctx->r2) = 0;
    // 0x80303F78: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x80303F7C: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x80303F80: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80303F84: addiu       $sp, $sp, 0x40
    ctx->r29 = ADD32(ctx->r29, 0X40);
    // 0x80303F88: jr          $ra
    // 0x80303F8C: nop

    return;
    // 0x80303F8C: nop

;}
RECOMP_FUNC void func_80303F90_715640(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80303F90: addiu       $sp, $sp, -0x28
    ctx->r29 = ADD32(ctx->r29, -0X28);
    // 0x80303F94: sw          $ra, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r31;
    // 0x80303F98: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x80303F9C: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x80303FA0: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80303FA4: lw          $t6, 0xD0($a0)
    ctx->r14 = MEM_W(ctx->r4, 0XD0);
    // 0x80303FA8: or          $s1, $a0, $zero
    ctx->r17 = ctx->r4 | 0;
    // 0x80303FAC: or          $s2, $a1, $zero
    ctx->r18 = ctx->r5 | 0;
    // 0x80303FB0: beq         $t6, $zero, L_80303FF4
    if (ctx->r14 == 0) {
        // 0x80303FB4: or          $s0, $zero, $zero
        ctx->r16 = 0 | 0;
            goto L_80303FF4;
    }
    // 0x80303FB4: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x80303FB8: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
L_80303FBC:
    // 0x80303FBC: andi        $a1, $s0, 0xFFFF
    ctx->r5 = ctx->r16 & 0XFFFF;
    // 0x80303FC0: jal         0x80303D68
    // 0x80303FC4: or          $a2, $s2, $zero
    ctx->r6 = ctx->r18 | 0;
    func_80303D68_715418(rdram, ctx);
        goto after_0;
    // 0x80303FC4: or          $a2, $s2, $zero
    ctx->r6 = ctx->r18 | 0;
    after_0:
    // 0x80303FC8: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    // 0x80303FCC: sll         $t7, $s0, 16
    ctx->r15 = S32(ctx->r16 << 16);
    // 0x80303FD0: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80303FD4: slti        $at, $t8, 0x5
    ctx->r1 = SIGNED(ctx->r24) < 0X5 ? 1 : 0;
    // 0x80303FD8: beq         $at, $zero, L_80303FF4
    if (ctx->r1 == 0) {
        // 0x80303FDC: or          $s0, $t8, $zero
        ctx->r16 = ctx->r24 | 0;
            goto L_80303FF4;
    }
    // 0x80303FDC: or          $s0, $t8, $zero
    ctx->r16 = ctx->r24 | 0;
    // 0x80303FE0: sll         $t9, $t8, 4
    ctx->r25 = S32(ctx->r24 << 4);
    // 0x80303FE4: addu        $t0, $s1, $t9
    ctx->r8 = ADD32(ctx->r17, ctx->r25);
    // 0x80303FE8: lw          $t1, 0xD0($t0)
    ctx->r9 = MEM_W(ctx->r8, 0XD0);
    // 0x80303FEC: bnel        $t1, $zero, L_80303FBC
    if (ctx->r9 != 0) {
        // 0x80303FF0: or          $a0, $s1, $zero
        ctx->r4 = ctx->r17 | 0;
            goto L_80303FBC;
    }
    goto skip_0;
    // 0x80303FF0: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    skip_0:
L_80303FF4:
    // 0x80303FF4: lw          $ra, 0x24($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X24);
    // 0x80303FF8: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80303FFC: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x80304000: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x80304004: jr          $ra
    // 0x80304008: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
    return;
    // 0x80304008: addiu       $sp, $sp, 0x28
    ctx->r29 = ADD32(ctx->r29, 0X28);
;}
RECOMP_FUNC void func_8030400C_7156BC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8030400C: addiu       $sp, $sp, -0x8
    ctx->r29 = ADD32(ctx->r29, -0X8);
    // 0x80304010: sw          $s0, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r16;
    // 0x80304014: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80304018: sw          $a1, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r5;
    // 0x8030401C: or          $t6, $a1, $zero
    ctx->r14 = ctx->r5 | 0;
    // 0x80304020: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x80304024: sw          $a2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r6;
    // 0x80304028: lui         $t6, 0x4000
    ctx->r14 = S32(0X4000 << 16);
    // 0x8030402C: sw          $t6, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r14;
    // 0x80304030: sw          $zero, 0x0($a3)
    MEM_W(0X0, ctx->r7) = 0;
    // 0x80304034: lh          $t7, 0x4($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X4);
    // 0x80304038: lh          $t6, 0x8($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X8);
    // 0x8030403C: or          $t8, $a2, $zero
    ctx->r24 = ctx->r6 | 0;
    // 0x80304040: addiu       $t1, $a0, 0xD4
    ctx->r9 = ADD32(ctx->r4, 0XD4);
    // 0x80304044: lw          $t9, 0xC($t1)
    ctx->r25 = MEM_W(ctx->r9, 0XC);
    // 0x80304048: or          $a2, $t8, $zero
    ctx->r6 = ctx->r24 | 0;
    // 0x8030404C: subu        $a1, $a1, $t7
    ctx->r5 = SUB32(ctx->r5, ctx->r15);
    // 0x80304050: subu        $a2, $a2, $t6
    ctx->r6 = SUB32(ctx->r6, ctx->r14);
    // 0x80304054: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x80304058: sll         $t7, $a2, 16
    ctx->r15 = S32(ctx->r6 << 16);
    // 0x8030405C: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x80304060: sra         $a1, $t8, 16
    ctx->r5 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80304064: sra         $a2, $t7, 16
    ctx->r6 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80304068: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x8030406C: beq         $t9, $zero, L_80304154
    if (ctx->r25 == 0) {
        // 0x80304070: or          $t0, $t1, $zero
        ctx->r8 = ctx->r9 | 0;
            goto L_80304154;
    }
    // 0x80304070: or          $t0, $t1, $zero
    ctx->r8 = ctx->r9 | 0;
    // 0x80304074: lw          $t1, 0xC($t1)
    ctx->r9 = MEM_W(ctx->r9, 0XC);
    // 0x80304078: lh          $t6, 0x0($t0)
    ctx->r14 = MEM_H(ctx->r8, 0X0);
L_8030407C:
    // 0x8030407C: lh          $t9, 0x4($t0)
    ctx->r25 = MEM_H(ctx->r8, 0X4);
    // 0x80304080: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x80304084: subu        $t2, $a1, $t6
    ctx->r10 = SUB32(ctx->r5, ctx->r14);
    // 0x80304088: sll         $t7, $t2, 16
    ctx->r15 = S32(ctx->r10 << 16);
    // 0x8030408C: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80304090: multu       $t8, $t8
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80304094: subu        $t3, $a2, $t9
    ctx->r11 = SUB32(ctx->r6, ctx->r25);
    // 0x80304098: sll         $t6, $t3, 16
    ctx->r14 = S32(ctx->r11 << 16);
    // 0x8030409C: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x803040A0: mflo        $t8
    ctx->r24 = lo;
    // 0x803040A4: nop

    // 0x803040A8: nop

    // 0x803040AC: multu       $t7, $t7
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803040B0: mflo        $t9
    ctx->r25 = lo;
    // 0x803040B4: addu        $t6, $t8, $t9
    ctx->r14 = ADD32(ctx->r24, ctx->r25);
    // 0x803040B8: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x803040BC: multu       $t1, $t1
    result = U64(U32(ctx->r9)) * U64(U32(ctx->r9)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803040C0: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x803040C4: mflo        $t9
    ctx->r25 = lo;
    // 0x803040C8: slt         $at, $t8, $t9
    ctx->r1 = SIGNED(ctx->r24) < SIGNED(ctx->r25) ? 1 : 0;
    // 0x803040CC: beq         $at, $zero, L_80304138
    if (ctx->r1 == 0) {
        // 0x803040D0: sll         $t8, $v0, 16
        ctx->r24 = S32(ctx->r2 << 16);
            goto L_80304138;
    }
    // 0x803040D0: sll         $t8, $v0, 16
    ctx->r24 = S32(ctx->r2 << 16);
    // 0x803040D4: lw          $t6, 0xC($a0)
    ctx->r14 = MEM_W(ctx->r4, 0XC);
    // 0x803040D8: lw          $t7, 0x8($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X8);
    // 0x803040DC: sll         $t4, $t1, 16
    ctx->r12 = S32(ctx->r9 << 16);
    // 0x803040E0: addu        $t3, $t6, $t7
    ctx->r11 = ADD32(ctx->r14, ctx->r15);
    // 0x803040E4: addu        $t2, $t3, $t4
    ctx->r10 = ADD32(ctx->r11, ctx->r12);
    // 0x803040E8: beq         $v1, $zero, L_8030412C
    if (ctx->r3 == 0) {
        // 0x803040EC: subu        $t5, $t3, $t4
        ctx->r13 = SUB32(ctx->r11, ctx->r12);
            goto L_8030412C;
    }
    // 0x803040EC: subu        $t5, $t3, $t4
    ctx->r13 = SUB32(ctx->r11, ctx->r12);
    // 0x803040F0: lw          $t1, 0x0($a3)
    ctx->r9 = MEM_W(ctx->r7, 0X0);
    // 0x803040F4: slt         $at, $t2, $t1
    ctx->r1 = SIGNED(ctx->r10) < SIGNED(ctx->r9) ? 1 : 0;
    // 0x803040F8: beql        $at, $zero, L_8030410C
    if (ctx->r1 == 0) {
        // 0x803040FC: sw          $t2, 0x0($a3)
        MEM_W(0X0, ctx->r7) = ctx->r10;
            goto L_8030410C;
    }
    goto skip_0;
    // 0x803040FC: sw          $t2, 0x0($a3)
    MEM_W(0X0, ctx->r7) = ctx->r10;
    skip_0:
    // 0x80304100: b           L_8030410C
    // 0x80304104: sw          $t1, 0x0($a3)
    MEM_W(0X0, ctx->r7) = ctx->r9;
        goto L_8030410C;
    // 0x80304104: sw          $t1, 0x0($a3)
    MEM_W(0X0, ctx->r7) = ctx->r9;
    // 0x80304108: sw          $t2, 0x0($a3)
    MEM_W(0X0, ctx->r7) = ctx->r10;
L_8030410C:
    // 0x8030410C: lw          $t1, 0x0($s0)
    ctx->r9 = MEM_W(ctx->r16, 0X0);
    // 0x80304110: slt         $at, $t1, $t5
    ctx->r1 = SIGNED(ctx->r9) < SIGNED(ctx->r13) ? 1 : 0;
    // 0x80304114: beq         $at, $zero, L_80304124
    if (ctx->r1 == 0) {
        // 0x80304118: nop
    
            goto L_80304124;
    }
    // 0x80304118: nop

    // 0x8030411C: b           L_80304138
    // 0x80304120: sw          $t1, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r9;
        goto L_80304138;
    // 0x80304120: sw          $t1, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r9;
L_80304124:
    // 0x80304124: b           L_80304138
    // 0x80304128: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
        goto L_80304138;
    // 0x80304128: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
L_8030412C:
    // 0x8030412C: sw          $t2, 0x0($a3)
    MEM_W(0X0, ctx->r7) = ctx->r10;
    // 0x80304130: sw          $t5, 0x0($s0)
    MEM_W(0X0, ctx->r16) = ctx->r13;
    // 0x80304134: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
L_80304138:
    // 0x80304138: sra         $v0, $t8, 16
    ctx->r2 = S32(SIGNED(ctx->r24) >> 16);
    // 0x8030413C: slti        $at, $v0, 0x5
    ctx->r1 = SIGNED(ctx->r2) < 0X5 ? 1 : 0;
    // 0x80304140: beq         $at, $zero, L_80304154
    if (ctx->r1 == 0) {
        // 0x80304144: addiu       $t0, $t0, 0x10
        ctx->r8 = ADD32(ctx->r8, 0X10);
            goto L_80304154;
    }
    // 0x80304144: addiu       $t0, $t0, 0x10
    ctx->r8 = ADD32(ctx->r8, 0X10);
    // 0x80304148: lw          $t1, 0xC($t0)
    ctx->r9 = MEM_W(ctx->r8, 0XC);
    // 0x8030414C: bnel        $t1, $zero, L_8030407C
    if (ctx->r9 != 0) {
        // 0x80304150: lh          $t6, 0x0($t0)
        ctx->r14 = MEM_H(ctx->r8, 0X0);
            goto L_8030407C;
    }
    goto skip_1;
    // 0x80304150: lh          $t6, 0x0($t0)
    ctx->r14 = MEM_H(ctx->r8, 0X0);
    skip_1:
L_80304154:
    // 0x80304154: lw          $s0, 0x4($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X4);
    // 0x80304158: addiu       $sp, $sp, 0x8
    ctx->r29 = ADD32(ctx->r29, 0X8);
    // 0x8030415C: jr          $ra
    // 0x80304160: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    return;
    // 0x80304160: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
;}
RECOMP_FUNC void func_80304170_715820(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80304170: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x80304174: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
L_80304178:
    // 0x80304178: sll         $t6, $v0, 16
    ctx->r14 = S32(ctx->r2 << 16);
    // 0x8030417C: sra         $v0, $t6, 16
    ctx->r2 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80304180: slti        $at, $v0, 0x100
    ctx->r1 = SIGNED(ctx->r2) < 0X100 ? 1 : 0;
    // 0x80304184: bnel        $at, $zero, L_80304178
    if (ctx->r1 != 0) {
        // 0x80304188: addiu       $v0, $v0, 0x1
        ctx->r2 = ADD32(ctx->r2, 0X1);
            goto L_80304178;
    }
    goto skip_0;
    // 0x80304188: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    skip_0:
    // 0x8030418C: jr          $ra
    // 0x80304190: nop

    return;
    // 0x80304190: nop

;}
RECOMP_FUNC void func_80304194_715844(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80304194: lui         $a2, 0x803E
    ctx->r6 = S32(0X803E << 16);
    // 0x80304198: lui         $a0, 0x803E
    ctx->r4 = S32(0X803E << 16);
    // 0x8030419C: addiu       $a0, $a0, 0x3130
    ctx->r4 = ADD32(ctx->r4, 0X3130);
    // 0x803041A0: addiu       $a2, $a2, 0x4AD0
    ctx->r6 = ADD32(ctx->r6, 0X4AD0);
    // 0x803041A4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x803041A8: addiu       $a3, $zero, 0x1
    ctx->r7 = ADD32(0, 0X1);
    // 0x803041AC: addiu       $a1, $zero, 0x18
    ctx->r5 = ADD32(0, 0X18);
L_803041B0:
    // 0x803041B0: multu       $v0, $a1
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803041B4: addu        $t7, $a2, $v0
    ctx->r15 = ADD32(ctx->r6, ctx->r2);
    // 0x803041B8: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x803041BC: sll         $t8, $v0, 16
    ctx->r24 = S32(ctx->r2 << 16);
    // 0x803041C0: sra         $v0, $t8, 16
    ctx->r2 = S32(SIGNED(ctx->r24) >> 16);
    // 0x803041C4: slti        $at, $v0, 0x100
    ctx->r1 = SIGNED(ctx->r2) < 0X100 ? 1 : 0;
    // 0x803041C8: sb          $a3, 0x0($t7)
    MEM_B(0X0, ctx->r15) = ctx->r7;
    // 0x803041CC: mflo        $t6
    ctx->r14 = lo;
    // 0x803041D0: addu        $v1, $a0, $t6
    ctx->r3 = ADD32(ctx->r4, ctx->r14);
    // 0x803041D4: sb          $zero, 0x0($v1)
    MEM_B(0X0, ctx->r3) = 0;
    // 0x803041D8: sw          $zero, 0x4($v1)
    MEM_W(0X4, ctx->r3) = 0;
    // 0x803041DC: sw          $zero, 0x8($v1)
    MEM_W(0X8, ctx->r3) = 0;
    // 0x803041E0: sw          $zero, 0xC($v1)
    MEM_W(0XC, ctx->r3) = 0;
    // 0x803041E4: sw          $zero, 0x10($v1)
    MEM_W(0X10, ctx->r3) = 0;
    // 0x803041E8: sh          $zero, 0x2($v1)
    MEM_H(0X2, ctx->r3) = 0;
    // 0x803041EC: bne         $at, $zero, L_803041B0
    if (ctx->r1 != 0) {
        // 0x803041F0: sw          $zero, 0x14($v1)
        MEM_W(0X14, ctx->r3) = 0;
            goto L_803041B0;
    }
    // 0x803041F0: sw          $zero, 0x14($v1)
    MEM_W(0X14, ctx->r3) = 0;
    // 0x803041F4: jr          $ra
    // 0x803041F8: nop

    return;
    // 0x803041F8: nop

;}
RECOMP_FUNC void func_803041FC_7158AC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803041FC: lui         $a0, 0x803E
    ctx->r4 = S32(0X803E << 16);
    // 0x80304200: addiu       $a0, $a0, 0x4BD4
    ctx->r4 = ADD32(ctx->r4, 0X4BD4);
    // 0x80304204: lh          $v1, 0x0($a0)
    ctx->r3 = MEM_H(ctx->r4, 0X0);
    // 0x80304208: lui         $v0, 0x8015
    ctx->r2 = S32(0X8015 << 16);
    // 0x8030420C: addiu       $t4, $zero, 0x168
    ctx->r12 = ADD32(0, 0X168);
    // 0x80304210: sll         $t6, $v1, 1
    ctx->r14 = S32(ctx->r3 << 1);
    // 0x80304214: addu        $v0, $v0, $t6
    ctx->r2 = ADD32(ctx->r2, ctx->r14);
    // 0x80304218: lh          $v0, 0x2620($v0)
    ctx->r2 = MEM_H(ctx->r2, 0X2620);
    // 0x8030421C: addiu       $t6, $v1, 0xA
    ctx->r14 = ADD32(ctx->r3, 0XA);
    // 0x80304220: sh          $t6, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r14;
    // 0x80304224: addiu       $sp, $sp, -0x58
    ctx->r29 = ADD32(ctx->r29, -0X58);
    // 0x80304228: lui         $t3, 0x803E
    ctx->r11 = S32(0X803E << 16);
    // 0x8030422C: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x80304230: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x80304234: sw          $fp, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r30;
    // 0x80304238: sw          $s7, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r23;
    // 0x8030423C: sw          $s6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r22;
    // 0x80304240: sw          $s5, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r21;
    // 0x80304244: sw          $s4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r20;
    // 0x80304248: sw          $s3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r19;
    // 0x8030424C: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x80304250: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x80304254: bgez        $v0, L_80304264
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80304258: sra         $t7, $v0, 1
        ctx->r15 = S32(SIGNED(ctx->r2) >> 1);
            goto L_80304264;
    }
    // 0x80304258: sra         $t7, $v0, 1
    ctx->r15 = S32(SIGNED(ctx->r2) >> 1);
    // 0x8030425C: addiu       $at, $v0, 0x1
    ctx->r1 = ADD32(ctx->r2, 0X1);
    // 0x80304260: sra         $t7, $at, 1
    ctx->r15 = S32(SIGNED(ctx->r1) >> 1);
L_80304264:
    // 0x80304264: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x80304268: lh          $t7, 0x0($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X0);
    // 0x8030426C: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80304270: or          $v0, $t9, $zero
    ctx->r2 = ctx->r25 | 0;
    // 0x80304274: div         $zero, $t7, $t4
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r12))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r12)));
    // 0x80304278: mfhi        $t8
    ctx->r24 = hi;
    // 0x8030427C: sh          $t8, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r24;
    // 0x80304280: lh          $t3, 0x4AC8($t3)
    ctx->r11 = MEM_H(ctx->r11, 0X4AC8);
    // 0x80304284: bne         $t4, $zero, L_80304290
    if (ctx->r12 != 0) {
        // 0x80304288: nop
    
            goto L_80304290;
    }
    // 0x80304288: nop

    // 0x8030428C: break       7
    do_break(2150646412);
L_80304290:
    // 0x80304290: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80304294: bne         $t4, $at, L_803042A8
    if (ctx->r12 != ctx->r1) {
        // 0x80304298: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_803042A8;
    }
    // 0x80304298: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8030429C: bne         $t7, $at, L_803042A8
    if (ctx->r15 != ctx->r1) {
        // 0x803042A0: nop
    
            goto L_803042A8;
    }
    // 0x803042A0: nop

    // 0x803042A4: break       6
    do_break(2150646436);
L_803042A8:
    // 0x803042A8: lui         $s0, 0x803E
    ctx->r16 = S32(0X803E << 16);
    // 0x803042AC: blez        $t3, L_80304368
    if (SIGNED(ctx->r11) <= 0) {
        // 0x803042B0: or          $t2, $zero, $zero
        ctx->r10 = 0 | 0;
            goto L_80304368;
    }
    // 0x803042B0: or          $t2, $zero, $zero
    ctx->r10 = 0 | 0;
    // 0x803042B4: lui         $t1, 0x803E
    ctx->r9 = S32(0X803E << 16);
    // 0x803042B8: lui         $t0, 0x8023
    ctx->r8 = S32(0X8023 << 16);
    // 0x803042BC: lui         $a3, 0x803E
    ctx->r7 = S32(0X803E << 16);
    // 0x803042C0: lui         $a2, 0x803E
    ctx->r6 = S32(0X803E << 16);
    // 0x803042C4: lui         $a1, 0x803C
    ctx->r5 = S32(0X803C << 16);
    // 0x803042C8: addiu       $a1, $a1, 0x740
    ctx->r5 = ADD32(ctx->r5, 0X740);
    // 0x803042CC: addiu       $a2, $a2, 0x4930
    ctx->r6 = ADD32(ctx->r6, 0X4930);
    // 0x803042D0: addiu       $a3, $a3, 0x4998
    ctx->r7 = ADD32(ctx->r7, 0X4998);
    // 0x803042D4: addiu       $t0, $t0, -0x6B30
    ctx->r8 = ADD32(ctx->r8, -0X6B30);
    // 0x803042D8: addiu       $t1, $t1, 0x4A00
    ctx->r9 = ADD32(ctx->r9, 0X4A00);
    // 0x803042DC: addu        $t9, $a2, $t2
    ctx->r25 = ADD32(ctx->r6, ctx->r10);
L_803042E0:
    // 0x803042E0: lbu         $t6, 0x0($t9)
    ctx->r14 = MEM_BU(ctx->r25, 0X0);
    // 0x803042E4: addu        $t9, $a3, $t2
    ctx->r25 = ADD32(ctx->r7, ctx->r10);
    // 0x803042E8: sll         $t7, $t6, 7
    ctx->r15 = S32(ctx->r14 << 7);
    // 0x803042EC: addu        $t7, $t7, $t6
    ctx->r15 = ADD32(ctx->r15, ctx->r14);
    // 0x803042F0: lbu         $t6, 0x0($t9)
    ctx->r14 = MEM_BU(ctx->r25, 0X0);
    // 0x803042F4: sll         $t7, $t7, 3
    ctx->r15 = S32(ctx->r15 << 3);
    // 0x803042F8: addu        $t8, $a1, $t7
    ctx->r24 = ADD32(ctx->r5, ctx->r15);
    // 0x803042FC: sll         $t7, $t6, 3
    ctx->r15 = S32(ctx->r14 << 3);
    // 0x80304300: addu        $t9, $t8, $t7
    ctx->r25 = ADD32(ctx->r24, ctx->r15);
    // 0x80304304: lbu         $t6, 0x6($t9)
    ctx->r14 = MEM_BU(ctx->r25, 0X6);
    // 0x80304308: sll         $t9, $t2, 1
    ctx->r25 = S32(ctx->r10 << 1);
    // 0x8030430C: addiu       $t2, $t2, 0x1
    ctx->r10 = ADD32(ctx->r10, 0X1);
    // 0x80304310: sll         $t8, $t6, 18
    ctx->r24 = S32(ctx->r14 << 18);
    // 0x80304314: sra         $a0, $t8, 16
    ctx->r4 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80304318: addu        $t6, $t1, $t9
    ctx->r14 = ADD32(ctx->r9, ctx->r25);
    // 0x8030431C: lhu         $t8, 0x0($t6)
    ctx->r24 = MEM_HU(ctx->r14, 0X0);
    // 0x80304320: sll         $t7, $t8, 4
    ctx->r15 = S32(ctx->r24 << 4);
    // 0x80304324: addu        $v1, $t0, $t7
    ctx->r3 = ADD32(ctx->r8, ctx->r15);
    // 0x80304328: lh          $v0, 0x4($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X4);
    // 0x8030432C: sll         $t8, $t2, 16
    ctx->r24 = S32(ctx->r10 << 16);
    // 0x80304330: sra         $t2, $t8, 16
    ctx->r10 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80304334: slt         $at, $v0, $a0
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x80304338: beq         $at, $zero, L_80304348
    if (ctx->r1 == 0) {
        // 0x8030433C: addiu       $t9, $v0, 0x1
        ctx->r25 = ADD32(ctx->r2, 0X1);
            goto L_80304348;
    }
    // 0x8030433C: addiu       $t9, $v0, 0x1
    ctx->r25 = ADD32(ctx->r2, 0X1);
    // 0x80304340: b           L_80304358
    // 0x80304344: sh          $t9, 0x4($v1)
    MEM_H(0X4, ctx->r3) = ctx->r25;
        goto L_80304358;
    // 0x80304344: sh          $t9, 0x4($v1)
    MEM_H(0X4, ctx->r3) = ctx->r25;
L_80304348:
    // 0x80304348: slt         $at, $a0, $v0
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x8030434C: beq         $at, $zero, L_80304358
    if (ctx->r1 == 0) {
        // 0x80304350: addiu       $t6, $v0, -0x1
        ctx->r14 = ADD32(ctx->r2, -0X1);
            goto L_80304358;
    }
    // 0x80304350: addiu       $t6, $v0, -0x1
    ctx->r14 = ADD32(ctx->r2, -0X1);
    // 0x80304354: sh          $t6, 0x4($v1)
    MEM_H(0X4, ctx->r3) = ctx->r14;
L_80304358:
    // 0x80304358: slt         $at, $t2, $t3
    ctx->r1 = SIGNED(ctx->r10) < SIGNED(ctx->r11) ? 1 : 0;
    // 0x8030435C: bnel        $at, $zero, L_803042E0
    if (ctx->r1 != 0) {
        // 0x80304360: addu        $t9, $a2, $t2
        ctx->r25 = ADD32(ctx->r6, ctx->r10);
            goto L_803042E0;
    }
    goto skip_0;
    // 0x80304360: addu        $t9, $a2, $t2
    ctx->r25 = ADD32(ctx->r6, ctx->r10);
    skip_0:
    // 0x80304364: or          $t2, $zero, $zero
    ctx->r10 = 0 | 0;
L_80304368:
    // 0x80304368: lui         $t9, 0x803E
    ctx->r25 = S32(0X803E << 16);
    // 0x8030436C: lh          $t9, 0x4BD6($t9)
    ctx->r25 = MEM_H(ctx->r25, 0X4BD6);
    // 0x80304370: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x80304374: addiu       $s0, $s0, 0x4BD0
    ctx->r16 = ADD32(ctx->r16, 0X4BD0);
    // 0x80304378: addiu       $t6, $t9, 0x2
    ctx->r14 = ADD32(ctx->r25, 0X2);
    // 0x8030437C: sll         $t8, $t6, 16
    ctx->r24 = S32(ctx->r14 << 16);
    // 0x80304380: sra         $t7, $t8, 16
    ctx->r15 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80304384: div         $zero, $t7, $t4
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r12))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r12)));
    // 0x80304388: sh          $t6, 0x4BD6($at)
    MEM_H(0X4BD6, ctx->r1) = ctx->r14;
    // 0x8030438C: lui         $t6, 0x803E
    ctx->r14 = S32(0X803E << 16);
    // 0x80304390: lh          $t6, 0x4BD8($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X4BD8);
    // 0x80304394: mfhi        $t9
    ctx->r25 = hi;
    // 0x80304398: lui         $s1, 0x803E
    ctx->r17 = S32(0X803E << 16);
    // 0x8030439C: addiu       $t8, $t6, 0x3
    ctx->r24 = ADD32(ctx->r14, 0X3);
    // 0x803043A0: addiu       $s1, $s1, 0x4BD2
    ctx->r17 = ADD32(ctx->r17, 0X4BD2);
    // 0x803043A4: bne         $t4, $zero, L_803043B0
    if (ctx->r12 != 0) {
        // 0x803043A8: nop
    
            goto L_803043B0;
    }
    // 0x803043A8: nop

    // 0x803043AC: break       7
    do_break(2150646700);
L_803043B0:
    // 0x803043B0: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x803043B4: bne         $t4, $at, L_803043C8
    if (ctx->r12 != ctx->r1) {
        // 0x803043B8: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_803043C8;
    }
    // 0x803043B8: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x803043BC: bne         $t7, $at, L_803043C8
    if (ctx->r15 != ctx->r1) {
        // 0x803043C0: nop
    
            goto L_803043C8;
    }
    // 0x803043C0: nop

    // 0x803043C4: break       6
    do_break(2150646724);
L_803043C8:
    // 0x803043C8: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x803043CC: sh          $t9, 0x4BD6($at)
    MEM_H(0X4BD6, ctx->r1) = ctx->r25;
    // 0x803043D0: sll         $t7, $t8, 16
    ctx->r15 = S32(ctx->r24 << 16);
    // 0x803043D4: sra         $t9, $t7, 16
    ctx->r25 = S32(SIGNED(ctx->r15) >> 16);
    // 0x803043D8: div         $zero, $t9, $t4
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r12))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r12)));
    // 0x803043DC: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x803043E0: sh          $t8, 0x4BD8($at)
    MEM_H(0X4BD8, ctx->r1) = ctx->r24;
    // 0x803043E4: bne         $t4, $zero, L_803043F0
    if (ctx->r12 != 0) {
        // 0x803043E8: nop
    
            goto L_803043F0;
    }
    // 0x803043E8: nop

    // 0x803043EC: break       7
    do_break(2150646764);
L_803043F0:
    // 0x803043F0: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x803043F4: bne         $t4, $at, L_80304408
    if (ctx->r12 != ctx->r1) {
        // 0x803043F8: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80304408;
    }
    // 0x803043F8: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x803043FC: bne         $t9, $at, L_80304408
    if (ctx->r25 != ctx->r1) {
        // 0x80304400: nop
    
            goto L_80304408;
    }
    // 0x80304400: nop

    // 0x80304404: break       6
    do_break(2150646788);
L_80304408:
    // 0x80304408: lui         $t8, 0x803E
    ctx->r24 = S32(0X803E << 16);
    // 0x8030440C: lh          $t8, 0x4BDA($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X4BDA);
    // 0x80304410: mfhi        $t6
    ctx->r14 = hi;
    // 0x80304414: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x80304418: addiu       $t7, $t8, 0xA
    ctx->r15 = ADD32(ctx->r24, 0XA);
    // 0x8030441C: sh          $t6, 0x4BD8($at)
    MEM_H(0X4BD8, ctx->r1) = ctx->r14;
    // 0x80304420: sll         $t9, $t7, 16
    ctx->r25 = S32(ctx->r15 << 16);
    // 0x80304424: sra         $t6, $t9, 16
    ctx->r14 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80304428: div         $zero, $t6, $t4
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r12))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r12)));
    // 0x8030442C: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x80304430: sh          $t7, 0x4BDA($at)
    MEM_H(0X4BDA, ctx->r1) = ctx->r15;
    // 0x80304434: bne         $t4, $zero, L_80304440
    if (ctx->r12 != 0) {
        // 0x80304438: nop
    
            goto L_80304440;
    }
    // 0x80304438: nop

    // 0x8030443C: break       7
    do_break(2150646844);
L_80304440:
    // 0x80304440: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80304444: bne         $t4, $at, L_80304458
    if (ctx->r12 != ctx->r1) {
        // 0x80304448: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80304458;
    }
    // 0x80304448: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8030444C: bne         $t6, $at, L_80304458
    if (ctx->r14 != ctx->r1) {
        // 0x80304450: nop
    
            goto L_80304458;
    }
    // 0x80304450: nop

    // 0x80304454: break       6
    do_break(2150646868);
L_80304458:
    // 0x80304458: mfhi        $t8
    ctx->r24 = hi;
    // 0x8030445C: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x80304460: sh          $t8, 0x4BDA($at)
    MEM_H(0X4BDA, ctx->r1) = ctx->r24;
    // 0x80304464: lb          $t7, 0x0($s0)
    ctx->r15 = MEM_B(ctx->r16, 0X0);
    // 0x80304468: addiu       $at, $zero, 0x9
    ctx->r1 = ADD32(0, 0X9);
    // 0x8030446C: addiu       $t9, $t7, 0x1
    ctx->r25 = ADD32(ctx->r15, 0X1);
    // 0x80304470: sb          $t9, 0x0($s0)
    MEM_B(0X0, ctx->r16) = ctx->r25;
    // 0x80304474: lb          $t6, 0x0($s0)
    ctx->r14 = MEM_B(ctx->r16, 0X0);
    // 0x80304478: lb          $t7, 0x0($s1)
    ctx->r15 = MEM_B(ctx->r17, 0X0);
    // 0x8030447C: bgez        $t6, L_80304490
    if (SIGNED(ctx->r14) >= 0) {
        // 0x80304480: andi        $t8, $t6, 0x3
        ctx->r24 = ctx->r14 & 0X3;
            goto L_80304490;
    }
    // 0x80304480: andi        $t8, $t6, 0x3
    ctx->r24 = ctx->r14 & 0X3;
    // 0x80304484: beq         $t8, $zero, L_80304490
    if (ctx->r24 == 0) {
        // 0x80304488: nop
    
            goto L_80304490;
    }
    // 0x80304488: nop

    // 0x8030448C: addiu       $t8, $t8, -0x4
    ctx->r24 = ADD32(ctx->r24, -0X4);
L_80304490:
    // 0x80304490: addiu       $t9, $t7, 0x1
    ctx->r25 = ADD32(ctx->r15, 0X1);
    // 0x80304494: sb          $t9, 0x0($s1)
    MEM_B(0X0, ctx->r17) = ctx->r25;
    // 0x80304498: lb          $t6, 0x0($s1)
    ctx->r14 = MEM_B(ctx->r17, 0X0);
    // 0x8030449C: sb          $t8, 0x0($s0)
    MEM_B(0X0, ctx->r16) = ctx->r24;
    // 0x803044A0: lb          $t7, 0x0($s0)
    ctx->r15 = MEM_B(ctx->r16, 0X0);
    // 0x803044A4: div         $zero, $t6, $at
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r1)));
    // 0x803044A8: mfhi        $t8
    ctx->r24 = hi;
    // 0x803044AC: andi        $t9, $t7, 0x1
    ctx->r25 = ctx->r15 & 0X1;
    // 0x803044B0: beq         $t9, $zero, L_803044D8
    if (ctx->r25 == 0) {
        // 0x803044B4: sb          $t8, 0x0($s1)
        MEM_B(0X0, ctx->r17) = ctx->r24;
            goto L_803044D8;
    }
    // 0x803044B4: sb          $t8, 0x0($s1)
    MEM_B(0X0, ctx->r17) = ctx->r24;
    // 0x803044B8: jal         0x80140D20
    // 0x803044BC: sh          $t2, 0x56($sp)
    MEM_H(0X56, ctx->r29) = ctx->r10;
    guRandom(rdram, ctx);
        goto after_0;
    // 0x803044BC: sh          $t2, 0x56($sp)
    MEM_H(0X56, ctx->r29) = ctx->r10;
    after_0:
    // 0x803044C0: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x803044C4: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x803044C8: mfhi        $t6
    ctx->r14 = hi;
    // 0x803044CC: lui         $at, 0x803E
    ctx->r1 = S32(0X803E << 16);
    // 0x803044D0: sb          $t6, 0x4BD1($at)
    MEM_B(0X4BD1, ctx->r1) = ctx->r14;
    // 0x803044D4: lh          $t2, 0x56($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X56);
L_803044D8:
    // 0x803044D8: lui         $t1, 0x803F
    ctx->r9 = S32(0X803F << 16);
    // 0x803044DC: lh          $t1, 0x2CA6($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X2CA6);
    // 0x803044E0: lui         $fp, 0x80
    ctx->r30 = S32(0X80 << 16);
    // 0x803044E4: ori         $fp, $fp, 0x1
    ctx->r30 = ctx->r30 | 0X1;
    // 0x803044E8: blez        $t1, L_80304E48
    if (SIGNED(ctx->r9) <= 0) {
        // 0x803044EC: lui         $s7, 0x601
        ctx->r23 = S32(0X601 << 16);
            goto L_80304E48;
    }
    // 0x803044EC: lui         $s7, 0x601
    ctx->r23 = S32(0X601 << 16);
    // 0x803044F0: lui         $s6, 0xF588
    ctx->r22 = S32(0XF588 << 16);
    // 0x803044F4: lui         $s4, 0x71F
    ctx->r20 = S32(0X71F << 16);
    // 0x803044F8: lui         $s1, 0x701
    ctx->r17 = S32(0X701 << 16);
    // 0x803044FC: lui         $t3, 0x607
    ctx->r11 = S32(0X607 << 16);
    // 0x80304500: ori         $t3, $t3, 0xC07C
    ctx->r11 = ctx->r11 | 0XC07C;
    // 0x80304504: ori         $s1, $s1, 0x4050
    ctx->r17 = ctx->r17 | 0X4050;
    // 0x80304508: ori         $s4, $s4, 0xF200
    ctx->r20 = ctx->r20 | 0XF200;
    // 0x8030450C: ori         $s6, $s6, 0x800
    ctx->r22 = ctx->r22 | 0X800;
    // 0x80304510: ori         $s7, $s7, 0x4050
    ctx->r23 = ctx->r23 | 0X4050;
    // 0x80304514: lui         $s5, 0xE700
    ctx->r21 = S32(0XE700 << 16);
    // 0x80304518: lui         $s3, 0xF300
    ctx->r19 = S32(0XF300 << 16);
    // 0x8030451C: lui         $s2, 0xE600
    ctx->r18 = S32(0XE600 << 16);
    // 0x80304520: lui         $s0, 0xF590
    ctx->r16 = S32(0XF590 << 16);
    // 0x80304524: lui         $ra, 0xFD90
    ctx->r31 = S32(0XFD90 << 16);
    // 0x80304528: lw          $t5, 0x40($sp)
    ctx->r13 = MEM_W(ctx->r29, 0X40);
    // 0x8030452C: lw          $t4, 0x44($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X44);
    // 0x80304530: lui         $t0, 0xF200
    ctx->r8 = S32(0XF200 << 16);
    // 0x80304534: sll         $t8, $t2, 2
    ctx->r24 = S32(ctx->r10 << 2);
L_80304538:
    // 0x80304538: subu        $t8, $t8, $t2
    ctx->r24 = SUB32(ctx->r24, ctx->r10);
    // 0x8030453C: lui         $t7, 0x803E
    ctx->r15 = S32(0X803E << 16);
    // 0x80304540: addiu       $t7, $t7, 0x3130
    ctx->r15 = ADD32(ctx->r15, 0X3130);
    // 0x80304544: sll         $t8, $t8, 3
    ctx->r24 = S32(ctx->r24 << 3);
    // 0x80304548: addu        $v1, $t8, $t7
    ctx->r3 = ADD32(ctx->r24, ctx->r15);
    // 0x8030454C: lh          $a0, 0x2($v1)
    ctx->r4 = MEM_H(ctx->r3, 0X2);
    // 0x80304550: lui         $t9, 0x803E
    ctx->r25 = S32(0X803E << 16);
    // 0x80304554: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80304558: addu        $t9, $t9, $a0
    ctx->r25 = ADD32(ctx->r25, ctx->r4);
    // 0x8030455C: lb          $t9, 0x4AD0($t9)
    ctx->r25 = MEM_B(ctx->r25, 0X4AD0);
    // 0x80304560: sll         $a1, $a0, 16
    ctx->r5 = S32(ctx->r4 << 16);
    // 0x80304564: sra         $t6, $a1, 16
    ctx->r14 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80304568: bne         $t9, $at, L_80304E28
    if (ctx->r25 != ctx->r1) {
        // 0x8030456C: or          $a1, $t6, $zero
        ctx->r5 = ctx->r14 | 0;
            goto L_80304E28;
    }
    // 0x8030456C: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x80304570: slti        $at, $t6, 0x12C
    ctx->r1 = SIGNED(ctx->r14) < 0X12C ? 1 : 0;
    // 0x80304574: bne         $at, $zero, L_8030459C
    if (ctx->r1 != 0) {
        // 0x80304578: lw          $v0, 0x14($v1)
        ctx->r2 = MEM_W(ctx->r3, 0X14);
            goto L_8030459C;
    }
    // 0x80304578: lw          $v0, 0x14($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X14);
    // 0x8030457C: addiu       $at, $zero, 0x12C
    ctx->r1 = ADD32(0, 0X12C);
    // 0x80304580: bnel        $t6, $at, L_80304594
    if (ctx->r14 != ctx->r1) {
        // 0x80304584: sra         $a2, $t4, 1
        ctx->r6 = S32(SIGNED(ctx->r12) >> 1);
            goto L_80304594;
    }
    goto skip_1;
    // 0x80304584: sra         $a2, $t4, 1
    ctx->r6 = S32(SIGNED(ctx->r12) >> 1);
    skip_1:
    // 0x80304588: or          $t4, $zero, $zero
    ctx->r12 = 0 | 0;
    // 0x8030458C: lui         $t5, 0x1
    ctx->r13 = S32(0X1 << 16);
    // 0x80304590: sra         $a2, $t4, 1
    ctx->r6 = S32(SIGNED(ctx->r12) >> 1);
L_80304594:
    // 0x80304594: b           L_803045CC
    // 0x80304598: sra         $a3, $t5, 1
    ctx->r7 = S32(SIGNED(ctx->r13) >> 1);
        goto L_803045CC;
    // 0x80304598: sra         $a3, $t5, 1
    ctx->r7 = S32(SIGNED(ctx->r13) >> 1);
L_8030459C:
    // 0x8030459C: lui         $t7, 0x803E
    ctx->r15 = S32(0X803E << 16);
    // 0x803045A0: addiu       $t7, $t7, 0x2930
    ctx->r15 = ADD32(ctx->r15, 0X2930);
    // 0x803045A4: sll         $t8, $a1, 3
    ctx->r24 = S32(ctx->r5 << 3);
    // 0x803045A8: addu        $a0, $t8, $t7
    ctx->r4 = ADD32(ctx->r24, ctx->r15);
    // 0x803045AC: lw          $t4, 0x0($a0)
    ctx->r12 = MEM_W(ctx->r4, 0X0);
    // 0x803045B0: lw          $t5, 0x4($a0)
    ctx->r13 = MEM_W(ctx->r4, 0X4);
    // 0x803045B4: sll         $t9, $t4, 4
    ctx->r25 = S32(ctx->r12 << 4);
    // 0x803045B8: sll         $t6, $t5, 4
    ctx->r14 = S32(ctx->r13 << 4);
    // 0x803045BC: or          $t4, $t9, $zero
    ctx->r12 = ctx->r25 | 0;
    // 0x803045C0: or          $t5, $t6, $zero
    ctx->r13 = ctx->r14 | 0;
    // 0x803045C4: sra         $a3, $t6, 1
    ctx->r7 = S32(SIGNED(ctx->r14) >> 1);
    // 0x803045C8: sra         $a2, $t9, 1
    ctx->r6 = S32(SIGNED(ctx->r25) >> 1);
L_803045CC:
    // 0x803045CC: lw          $t8, 0x4($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X4);
    // 0x803045D0: lw          $t9, 0x8($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X8);
    // 0x803045D4: addu        $t7, $t8, $t4
    ctx->r15 = ADD32(ctx->r24, ctx->r12);
    // 0x803045D8: sw          $t7, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r15;
    // 0x803045DC: addu        $t6, $t9, $t5
    ctx->r14 = ADD32(ctx->r25, ctx->r13);
    // 0x803045E0: lw          $t8, 0xC($v1)
    ctx->r24 = MEM_W(ctx->r3, 0XC);
    // 0x803045E4: lw          $t9, 0x10($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X10);
    // 0x803045E8: lw          $a0, 0x4($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X4);
    // 0x803045EC: sw          $t6, 0x8($v1)
    MEM_W(0X8, ctx->r3) = ctx->r14;
    // 0x803045F0: addu        $t7, $t8, $a2
    ctx->r15 = ADD32(ctx->r24, ctx->r6);
    // 0x803045F4: addu        $t6, $t9, $a3
    ctx->r14 = ADD32(ctx->r25, ctx->r7);
    // 0x803045F8: slt         $at, $a0, $fp
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r30) ? 1 : 0;
    // 0x803045FC: sw          $t7, 0xC($v1)
    MEM_W(0XC, ctx->r3) = ctx->r15;
    // 0x80304600: bne         $at, $zero, L_80304614
    if (ctx->r1 != 0) {
        // 0x80304604: sw          $t6, 0x10($v1)
        MEM_W(0X10, ctx->r3) = ctx->r14;
            goto L_80304614;
    }
    // 0x80304604: sw          $t6, 0x10($v1)
    MEM_W(0X10, ctx->r3) = ctx->r14;
    // 0x80304608: lui         $at, 0xFF80
    ctx->r1 = S32(0XFF80 << 16);
    // 0x8030460C: addu        $t8, $a0, $at
    ctx->r24 = ADD32(ctx->r4, ctx->r1);
    // 0x80304610: sw          $t8, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r24;
L_80304614:
    // 0x80304614: lw          $a0, 0x8($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X8);
    // 0x80304618: slt         $at, $a0, $fp
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r30) ? 1 : 0;
    // 0x8030461C: bne         $at, $zero, L_8030462C
    if (ctx->r1 != 0) {
        // 0x80304620: lui         $at, 0xFF80
        ctx->r1 = S32(0XFF80 << 16);
            goto L_8030462C;
    }
    // 0x80304620: lui         $at, 0xFF80
    ctx->r1 = S32(0XFF80 << 16);
    // 0x80304624: addu        $t7, $a0, $at
    ctx->r15 = ADD32(ctx->r4, ctx->r1);
    // 0x80304628: sw          $t7, 0x8($v1)
    MEM_W(0X8, ctx->r3) = ctx->r15;
L_8030462C:
    // 0x8030462C: lw          $a0, 0xC($v1)
    ctx->r4 = MEM_W(ctx->r3, 0XC);
    // 0x80304630: slt         $at, $a0, $fp
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r30) ? 1 : 0;
    // 0x80304634: bne         $at, $zero, L_80304644
    if (ctx->r1 != 0) {
        // 0x80304638: lui         $at, 0xFF80
        ctx->r1 = S32(0XFF80 << 16);
            goto L_80304644;
    }
    // 0x80304638: lui         $at, 0xFF80
    ctx->r1 = S32(0XFF80 << 16);
    // 0x8030463C: addu        $t9, $a0, $at
    ctx->r25 = ADD32(ctx->r4, ctx->r1);
    // 0x80304640: sw          $t9, 0xC($v1)
    MEM_W(0XC, ctx->r3) = ctx->r25;
L_80304644:
    // 0x80304644: lw          $a0, 0x10($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X10);
    // 0x80304648: slt         $at, $a0, $fp
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r30) ? 1 : 0;
    // 0x8030464C: bne         $at, $zero, L_8030465C
    if (ctx->r1 != 0) {
        // 0x80304650: lui         $at, 0xFF80
        ctx->r1 = S32(0XFF80 << 16);
            goto L_8030465C;
    }
    // 0x80304650: lui         $at, 0xFF80
    ctx->r1 = S32(0XFF80 << 16);
    // 0x80304654: addu        $t6, $a0, $at
    ctx->r14 = ADD32(ctx->r4, ctx->r1);
    // 0x80304658: sw          $t6, 0x10($v1)
    MEM_W(0X10, ctx->r3) = ctx->r14;
L_8030465C:
    // 0x8030465C: lbu         $t8, 0x1($v1)
    ctx->r24 = MEM_BU(ctx->r3, 0X1);
    // 0x80304660: sltiu       $at, $t8, 0xC
    ctx->r1 = ctx->r24 < 0XC ? 1 : 0;
    // 0x80304664: beq         $at, $zero, L_80304E28
    if (ctx->r1 == 0) {
        // 0x80304668: sll         $t8, $t8, 2
        ctx->r24 = S32(ctx->r24 << 2);
            goto L_80304E28;
    }
    // 0x80304668: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x8030466C: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80304670: addu        $at, $at, $t8
    gpr jr_addend_80304678 = ctx->r24;
    ctx->r1 = ADD32(ctx->r1, ctx->r24);
    // 0x80304674: lw          $t8, -0x3020($at)
    ctx->r24 = ADD32(ctx->r1, -0X3020);
    // 0x80304678: jr          $t8
    // 0x8030467C: nop

    switch (jr_addend_80304678 >> 2) {
        case 0: goto L_803046D4; break;
        case 1: goto L_80304794; break;
        case 2: goto L_80304858; break;
        case 3: goto L_80304960; break;
        case 4: goto L_80304A20; break;
        case 5: goto L_80304AE4; break;
        case 6: goto L_80304B38; break;
        case 7: goto L_80304680; break;
        case 8: goto L_80304B78; break;
        case 9: goto L_80304D3C; break;
        case 10: goto L_80304C58; break;
        case 11: goto L_80304794; break;
        default: switch_error(__func__, 0x80304678, 0x803BCFE0);
    }
    // 0x8030467C: nop

L_80304680:
    // 0x80304680: lui         $t7, 0xFA00
    ctx->r15 = S32(0XFA00 << 16);
    // 0x80304684: ori         $t7, $t7, 0x8080
    ctx->r15 = ctx->r15 | 0X8080;
    // 0x80304688: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x8030468C: lui         $t9, 0x803E
    ctx->r25 = S32(0X803E << 16);
    // 0x80304690: lbu         $t6, 0x1BBA($t9)
    ctx->r14 = MEM_BU(ctx->r25, 0X1BBA);
    // 0x80304694: lui         $t7, 0x803E
    ctx->r15 = S32(0X803E << 16);
    // 0x80304698: lbu         $t9, 0x1BBB($t7)
    ctx->r25 = MEM_BU(ctx->r15, 0X1BBB);
    // 0x8030469C: sll         $t8, $t6, 24
    ctx->r24 = S32(ctx->r14 << 24);
    // 0x803046A0: lui         $t1, 0x803F
    ctx->r9 = S32(0X803F << 16);
    // 0x803046A4: sll         $t6, $t9, 16
    ctx->r14 = S32(ctx->r25 << 16);
    // 0x803046A8: or          $t7, $t8, $t6
    ctx->r15 = ctx->r24 | ctx->r14;
    // 0x803046AC: lui         $t9, 0x803E
    ctx->r25 = S32(0X803E << 16);
    // 0x803046B0: lbu         $t8, 0x1BBC($t9)
    ctx->r24 = MEM_BU(ctx->r25, 0X1BBC);
    // 0x803046B4: sll         $t6, $t8, 8
    ctx->r14 = S32(ctx->r24 << 8);
    // 0x803046B8: or          $t9, $t7, $t6
    ctx->r25 = ctx->r15 | ctx->r14;
    // 0x803046BC: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x803046C0: lbu         $t7, 0x2DA7($t8)
    ctx->r15 = MEM_BU(ctx->r24, 0X2DA7);
    // 0x803046C4: or          $t6, $t9, $t7
    ctx->r14 = ctx->r25 | ctx->r15;
    // 0x803046C8: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x803046CC: b           L_80304E28
    // 0x803046D0: lh          $t1, 0x2CA6($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X2CA6);
        goto L_80304E28;
    // 0x803046D0: lh          $t1, 0x2CA6($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X2CA6);
L_803046D4:
    // 0x803046D4: lw          $t8, 0x8($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X8);
    // 0x803046D8: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x803046DC: addiu       $a1, $v0, 0x8
    ctx->r5 = ADD32(ctx->r2, 0X8);
    // 0x803046E0: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x803046E4: lw          $t8, 0x4($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X4);
    // 0x803046E8: andi        $t7, $t9, 0xFFF
    ctx->r15 = ctx->r25 & 0XFFF;
    // 0x803046EC: or          $t6, $t7, $t0
    ctx->r14 = ctx->r15 | ctx->r8;
    // 0x803046F0: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x803046F4: andi        $t7, $t9, 0xFFF
    ctx->r15 = ctx->r25 & 0XFFF;
    // 0x803046F8: sll         $t8, $t7, 12
    ctx->r24 = S32(ctx->r15 << 12);
    // 0x803046FC: lui         $t7, 0x507
    ctx->r15 = S32(0X507 << 16);
    // 0x80304700: ori         $t7, $t7, 0xC07C
    ctx->r15 = ctx->r15 | 0XC07C;
    // 0x80304704: or          $t9, $t6, $t8
    ctx->r25 = ctx->r14 | ctx->r24;
    // 0x80304708: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x8030470C: sw          $t7, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r15;
    // 0x80304710: lw          $t6, 0x10($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X10);
    // 0x80304714: addiu       $v0, $a1, 0x8
    ctx->r2 = ADD32(ctx->r5, 0X8);
    // 0x80304718: lui         $t1, 0x803F
    ctx->r9 = S32(0X803F << 16);
    // 0x8030471C: sra         $t8, $t6, 16
    ctx->r24 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80304720: lw          $t6, 0xC($v1)
    ctx->r14 = MEM_W(ctx->r3, 0XC);
    // 0x80304724: andi        $t9, $t8, 0xFFF
    ctx->r25 = ctx->r24 & 0XFFF;
    // 0x80304728: or          $t7, $t9, $t0
    ctx->r15 = ctx->r25 | ctx->r8;
    // 0x8030472C: sra         $t8, $t6, 16
    ctx->r24 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80304730: andi        $t9, $t8, 0xFFF
    ctx->r25 = ctx->r24 & 0XFFF;
    // 0x80304734: sll         $t6, $t9, 12
    ctx->r14 = S32(ctx->r25 << 12);
    // 0x80304738: or          $t8, $t7, $t6
    ctx->r24 = ctx->r15 | ctx->r14;
    // 0x8030473C: lui         $t9, 0xFA00
    ctx->r25 = S32(0XFA00 << 16);
    // 0x80304740: sw          $t8, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r24;
    // 0x80304744: sw          $t3, 0x4($a1)
    MEM_W(0X4, ctx->r5) = ctx->r11;
    // 0x80304748: ori         $t9, $t9, 0x8080
    ctx->r25 = ctx->r25 | 0X8080;
    // 0x8030474C: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x80304750: lui         $t7, 0x803E
    ctx->r15 = S32(0X803E << 16);
    // 0x80304754: lbu         $t6, 0x1BBA($t7)
    ctx->r14 = MEM_BU(ctx->r15, 0X1BBA);
    // 0x80304758: lui         $t9, 0x803E
    ctx->r25 = S32(0X803E << 16);
    // 0x8030475C: lbu         $t7, 0x1BBB($t9)
    ctx->r15 = MEM_BU(ctx->r25, 0X1BBB);
    // 0x80304760: sll         $t8, $t6, 24
    ctx->r24 = S32(ctx->r14 << 24);
    // 0x80304764: sll         $t6, $t7, 16
    ctx->r14 = S32(ctx->r15 << 16);
    // 0x80304768: or          $t9, $t8, $t6
    ctx->r25 = ctx->r24 | ctx->r14;
    // 0x8030476C: lui         $t7, 0x803E
    ctx->r15 = S32(0X803E << 16);
    // 0x80304770: lbu         $t8, 0x1BBC($t7)
    ctx->r24 = MEM_BU(ctx->r15, 0X1BBC);
    // 0x80304774: sll         $t6, $t8, 8
    ctx->r14 = S32(ctx->r24 << 8);
    // 0x80304778: or          $t7, $t9, $t6
    ctx->r15 = ctx->r25 | ctx->r14;
    // 0x8030477C: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80304780: lbu         $t9, 0x2DA7($t8)
    ctx->r25 = MEM_BU(ctx->r24, 0X2DA7);
    // 0x80304784: or          $t6, $t7, $t9
    ctx->r14 = ctx->r15 | ctx->r25;
    // 0x80304788: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x8030478C: b           L_80304E28
    // 0x80304790: lh          $t1, 0x2CA6($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X2CA6);
        goto L_80304E28;
    // 0x80304790: lh          $t1, 0x2CA6($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X2CA6);
L_80304794:
    // 0x80304794: lw          $t8, 0x8($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X8);
    // 0x80304798: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x8030479C: addiu       $a1, $v0, 0x8
    ctx->r5 = ADD32(ctx->r2, 0X8);
    // 0x803047A0: sra         $t7, $t8, 16
    ctx->r15 = S32(SIGNED(ctx->r24) >> 16);
    // 0x803047A4: lw          $t8, 0x4($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X4);
    // 0x803047A8: andi        $t9, $t7, 0xFFF
    ctx->r25 = ctx->r15 & 0XFFF;
    // 0x803047AC: or          $t6, $t9, $t0
    ctx->r14 = ctx->r25 | ctx->r8;
    // 0x803047B0: sra         $t7, $t8, 16
    ctx->r15 = S32(SIGNED(ctx->r24) >> 16);
    // 0x803047B4: andi        $t9, $t7, 0xFFF
    ctx->r25 = ctx->r15 & 0XFFF;
    // 0x803047B8: sll         $t8, $t9, 12
    ctx->r24 = S32(ctx->r25 << 12);
    // 0x803047BC: lui         $t9, 0x7
    ctx->r25 = S32(0X7 << 16);
    // 0x803047C0: ori         $t9, $t9, 0xC07C
    ctx->r25 = ctx->r25 | 0XC07C;
    // 0x803047C4: or          $t7, $t6, $t8
    ctx->r15 = ctx->r14 | ctx->r24;
    // 0x803047C8: sw          $t7, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r15;
    // 0x803047CC: sw          $t9, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r25;
    // 0x803047D0: lw          $t6, 0x8($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X8);
    // 0x803047D4: addiu       $v0, $a1, 0x8
    ctx->r2 = ADD32(ctx->r5, 0X8);
    // 0x803047D8: lui         $t1, 0x803F
    ctx->r9 = S32(0X803F << 16);
    // 0x803047DC: sra         $t8, $t6, 16
    ctx->r24 = S32(SIGNED(ctx->r14) >> 16);
    // 0x803047E0: sra         $t7, $t8, 1
    ctx->r15 = S32(SIGNED(ctx->r24) >> 1);
    // 0x803047E4: lw          $t8, 0x4($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X4);
    // 0x803047E8: andi        $t9, $t7, 0xFFF
    ctx->r25 = ctx->r15 & 0XFFF;
    // 0x803047EC: or          $t6, $t9, $t0
    ctx->r14 = ctx->r25 | ctx->r8;
    // 0x803047F0: sra         $t7, $t8, 16
    ctx->r15 = S32(SIGNED(ctx->r24) >> 16);
    // 0x803047F4: sra         $t9, $t7, 1
    ctx->r25 = S32(SIGNED(ctx->r15) >> 1);
    // 0x803047F8: andi        $t8, $t9, 0xFFF
    ctx->r24 = ctx->r25 & 0XFFF;
    // 0x803047FC: sll         $t7, $t8, 12
    ctx->r15 = S32(ctx->r24 << 12);
    // 0x80304800: lui         $t8, 0x103
    ctx->r24 = S32(0X103 << 16);
    // 0x80304804: ori         $t8, $t8, 0xC03C
    ctx->r24 = ctx->r24 | 0XC03C;
    // 0x80304808: or          $t9, $t6, $t7
    ctx->r25 = ctx->r14 | ctx->r15;
    // 0x8030480C: sw          $t9, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r25;
    // 0x80304810: sw          $t8, 0x4($a1)
    MEM_W(0X4, ctx->r5) = ctx->r24;
    // 0x80304814: lw          $t6, 0x8($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X8);
    // 0x80304818: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8030481C: sra         $t9, $t7, 2
    ctx->r25 = S32(SIGNED(ctx->r15) >> 2);
    // 0x80304820: lw          $t7, 0x4($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X4);
    // 0x80304824: andi        $t8, $t9, 0xFFF
    ctx->r24 = ctx->r25 & 0XFFF;
    // 0x80304828: or          $t6, $t8, $t0
    ctx->r14 = ctx->r24 | ctx->r8;
    // 0x8030482C: sra         $t9, $t7, 16
    ctx->r25 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80304830: sra         $t8, $t9, 2
    ctx->r24 = S32(SIGNED(ctx->r25) >> 2);
    // 0x80304834: andi        $t7, $t8, 0xFFF
    ctx->r15 = ctx->r24 & 0XFFF;
    // 0x80304838: sll         $t9, $t7, 12
    ctx->r25 = S32(ctx->r15 << 12);
    // 0x8030483C: lui         $t7, 0x201
    ctx->r15 = S32(0X201 << 16);
    // 0x80304840: ori         $t7, $t7, 0xC01C
    ctx->r15 = ctx->r15 | 0XC01C;
    // 0x80304844: or          $t8, $t6, $t9
    ctx->r24 = ctx->r14 | ctx->r25;
    // 0x80304848: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x8030484C: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x80304850: b           L_80304E28
    // 0x80304854: lh          $t1, 0x2CA6($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X2CA6);
        goto L_80304E28;
    // 0x80304854: lh          $t1, 0x2CA6($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X2CA6);
L_80304858:
    // 0x80304858: lui         $t6, 0x803E
    ctx->r14 = S32(0X803E << 16);
    // 0x8030485C: lh          $t6, 0x4BD6($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X4BD6);
    // 0x80304860: lui         $t8, 0x8015
    ctx->r24 = S32(0X8015 << 16);
    // 0x80304864: addiu       $t8, $t8, 0x2350
    ctx->r24 = ADD32(ctx->r24, 0X2350);
    // 0x80304868: sll         $t9, $t6, 1
    ctx->r25 = S32(ctx->r14 << 1);
    // 0x8030486C: addu        $a0, $t9, $t8
    ctx->r4 = ADD32(ctx->r25, ctx->r24);
    // 0x80304870: lh          $t7, 0x384($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X384);
    // 0x80304874: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x80304878: addiu       $a1, $v0, 0x8
    ctx->r5 = ADD32(ctx->r2, 0X8);
    // 0x8030487C: sra         $t6, $t7, 2
    ctx->r14 = S32(SIGNED(ctx->r15) >> 2);
    // 0x80304880: lh          $t7, 0x2D0($a0)
    ctx->r15 = MEM_H(ctx->r4, 0X2D0);
    // 0x80304884: andi        $t9, $t6, 0xFFF
    ctx->r25 = ctx->r14 & 0XFFF;
    // 0x80304888: or          $t8, $t9, $t0
    ctx->r24 = ctx->r25 | ctx->r8;
    // 0x8030488C: sra         $t6, $t7, 2
    ctx->r14 = S32(SIGNED(ctx->r15) >> 2);
    // 0x80304890: andi        $t9, $t6, 0xFFF
    ctx->r25 = ctx->r14 & 0XFFF;
    // 0x80304894: sll         $t7, $t9, 12
    ctx->r15 = S32(ctx->r25 << 12);
    // 0x80304898: or          $t6, $t8, $t7
    ctx->r14 = ctx->r24 | ctx->r15;
    // 0x8030489C: lui         $t9, 0x107
    ctx->r25 = S32(0X107 << 16);
    // 0x803048A0: ori         $t9, $t9, 0xC07C
    ctx->r25 = ctx->r25 | 0XC07C;
    // 0x803048A4: sw          $t9, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r25;
    // 0x803048A8: sw          $t6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r14;
    // 0x803048AC: lui         $t8, 0x803E
    ctx->r24 = S32(0X803E << 16);
    // 0x803048B0: lh          $t8, 0x4BD8($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X4BD8);
    // 0x803048B4: addiu       $t7, $zero, 0x122
    ctx->r15 = ADD32(0, 0X122);
    // 0x803048B8: addiu       $v0, $a1, 0x8
    ctx->r2 = ADD32(ctx->r5, 0X8);
    // 0x803048BC: subu        $t6, $t7, $t8
    ctx->r14 = SUB32(ctx->r15, ctx->r24);
    // 0x803048C0: sll         $t9, $t6, 16
    ctx->r25 = S32(ctx->r14 << 16);
    // 0x803048C4: sra         $t7, $t9, 16
    ctx->r15 = S32(SIGNED(ctx->r25) >> 16);
    // 0x803048C8: lui         $t6, 0x8015
    ctx->r14 = S32(0X8015 << 16);
    // 0x803048CC: addiu       $t6, $t6, 0x2350
    ctx->r14 = ADD32(ctx->r14, 0X2350);
    // 0x803048D0: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x803048D4: addu        $a2, $t8, $t6
    ctx->r6 = ADD32(ctx->r24, ctx->r14);
    // 0x803048D8: lh          $t9, 0x384($a2)
    ctx->r25 = MEM_H(ctx->r6, 0X384);
    // 0x803048DC: lui         $t1, 0x803F
    ctx->r9 = S32(0X803F << 16);
    // 0x803048E0: sra         $t7, $t9, 2
    ctx->r15 = S32(SIGNED(ctx->r25) >> 2);
    // 0x803048E4: lh          $t9, 0x2D0($a2)
    ctx->r25 = MEM_H(ctx->r6, 0X2D0);
    // 0x803048E8: andi        $t8, $t7, 0xFFF
    ctx->r24 = ctx->r15 & 0XFFF;
    // 0x803048EC: or          $t6, $t8, $t0
    ctx->r14 = ctx->r24 | ctx->r8;
    // 0x803048F0: sra         $t7, $t9, 2
    ctx->r15 = S32(SIGNED(ctx->r25) >> 2);
    // 0x803048F4: andi        $t8, $t7, 0xFFF
    ctx->r24 = ctx->r15 & 0XFFF;
    // 0x803048F8: sll         $t9, $t8, 12
    ctx->r25 = S32(ctx->r24 << 12);
    // 0x803048FC: or          $t7, $t6, $t9
    ctx->r15 = ctx->r14 | ctx->r25;
    // 0x80304900: lui         $t8, 0x207
    ctx->r24 = S32(0X207 << 16);
    // 0x80304904: ori         $t8, $t8, 0xC07C
    ctx->r24 = ctx->r24 | 0XC07C;
    // 0x80304908: lui         $t6, 0xFA00
    ctx->r14 = S32(0XFA00 << 16);
    // 0x8030490C: sw          $t8, 0x4($a1)
    MEM_W(0X4, ctx->r5) = ctx->r24;
    // 0x80304910: sw          $t7, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r15;
    // 0x80304914: ori         $t6, $t6, 0x8080
    ctx->r14 = ctx->r14 | 0X8080;
    // 0x80304918: sw          $t6, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r14;
    // 0x8030491C: lui         $t9, 0x803E
    ctx->r25 = S32(0X803E << 16);
    // 0x80304920: lbu         $t7, 0x1BBA($t9)
    ctx->r15 = MEM_BU(ctx->r25, 0X1BBA);
    // 0x80304924: lui         $t6, 0x803E
    ctx->r14 = S32(0X803E << 16);
    // 0x80304928: lbu         $t9, 0x1BBB($t6)
    ctx->r25 = MEM_BU(ctx->r14, 0X1BBB);
    // 0x8030492C: sll         $t8, $t7, 24
    ctx->r24 = S32(ctx->r15 << 24);
    // 0x80304930: sll         $t7, $t9, 16
    ctx->r15 = S32(ctx->r25 << 16);
    // 0x80304934: or          $t6, $t8, $t7
    ctx->r14 = ctx->r24 | ctx->r15;
    // 0x80304938: lui         $t9, 0x803E
    ctx->r25 = S32(0X803E << 16);
    // 0x8030493C: lbu         $t8, 0x1BBC($t9)
    ctx->r24 = MEM_BU(ctx->r25, 0X1BBC);
    // 0x80304940: sll         $t7, $t8, 8
    ctx->r15 = S32(ctx->r24 << 8);
    // 0x80304944: or          $t9, $t6, $t7
    ctx->r25 = ctx->r14 | ctx->r15;
    // 0x80304948: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x8030494C: lbu         $t6, 0x2DA7($t8)
    ctx->r14 = MEM_BU(ctx->r24, 0X2DA7);
    // 0x80304950: or          $t7, $t9, $t6
    ctx->r15 = ctx->r25 | ctx->r14;
    // 0x80304954: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x80304958: b           L_80304E28
    // 0x8030495C: lh          $t1, 0x2CA6($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X2CA6);
        goto L_80304E28;
    // 0x8030495C: lh          $t1, 0x2CA6($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X2CA6);
L_80304960:
    // 0x80304960: lw          $t8, 0x8($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X8);
    // 0x80304964: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80304968: addiu       $a1, $v0, 0x8
    ctx->r5 = ADD32(ctx->r2, 0X8);
    // 0x8030496C: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80304970: lw          $t8, 0x4($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X4);
    // 0x80304974: andi        $t6, $t9, 0xFFF
    ctx->r14 = ctx->r25 & 0XFFF;
    // 0x80304978: or          $t7, $t6, $t0
    ctx->r15 = ctx->r14 | ctx->r8;
    // 0x8030497C: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80304980: andi        $t6, $t9, 0xFFF
    ctx->r14 = ctx->r25 & 0XFFF;
    // 0x80304984: sll         $t8, $t6, 12
    ctx->r24 = S32(ctx->r14 << 12);
    // 0x80304988: lui         $t6, 0x507
    ctx->r14 = S32(0X507 << 16);
    // 0x8030498C: ori         $t6, $t6, 0xC07C
    ctx->r14 = ctx->r14 | 0XC07C;
    // 0x80304990: or          $t9, $t7, $t8
    ctx->r25 = ctx->r15 | ctx->r24;
    // 0x80304994: sw          $t9, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r25;
    // 0x80304998: sw          $t6, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r14;
    // 0x8030499C: lw          $t7, 0x10($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X10);
    // 0x803049A0: addiu       $v0, $a1, 0x8
    ctx->r2 = ADD32(ctx->r5, 0X8);
    // 0x803049A4: lui         $t1, 0x803F
    ctx->r9 = S32(0X803F << 16);
    // 0x803049A8: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x803049AC: lw          $t7, 0xC($v1)
    ctx->r15 = MEM_W(ctx->r3, 0XC);
    // 0x803049B0: andi        $t9, $t8, 0xFFF
    ctx->r25 = ctx->r24 & 0XFFF;
    // 0x803049B4: or          $t6, $t9, $t0
    ctx->r14 = ctx->r25 | ctx->r8;
    // 0x803049B8: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x803049BC: andi        $t9, $t8, 0xFFF
    ctx->r25 = ctx->r24 & 0XFFF;
    // 0x803049C0: sll         $t7, $t9, 12
    ctx->r15 = S32(ctx->r25 << 12);
    // 0x803049C4: or          $t8, $t6, $t7
    ctx->r24 = ctx->r14 | ctx->r15;
    // 0x803049C8: lui         $t9, 0xFA00
    ctx->r25 = S32(0XFA00 << 16);
    // 0x803049CC: sw          $t8, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r24;
    // 0x803049D0: sw          $t3, 0x4($a1)
    MEM_W(0X4, ctx->r5) = ctx->r11;
    // 0x803049D4: ori         $t9, $t9, 0x8080
    ctx->r25 = ctx->r25 | 0X8080;
    // 0x803049D8: sw          $t9, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r25;
    // 0x803049DC: lui         $t6, 0x803E
    ctx->r14 = S32(0X803E << 16);
    // 0x803049E0: lbu         $t7, 0x1BBA($t6)
    ctx->r15 = MEM_BU(ctx->r14, 0X1BBA);
    // 0x803049E4: lui         $t9, 0x803E
    ctx->r25 = S32(0X803E << 16);
    // 0x803049E8: lbu         $t6, 0x1BBB($t9)
    ctx->r14 = MEM_BU(ctx->r25, 0X1BBB);
    // 0x803049EC: sll         $t8, $t7, 24
    ctx->r24 = S32(ctx->r15 << 24);
    // 0x803049F0: sll         $t7, $t6, 16
    ctx->r15 = S32(ctx->r14 << 16);
    // 0x803049F4: or          $t9, $t8, $t7
    ctx->r25 = ctx->r24 | ctx->r15;
    // 0x803049F8: lui         $t6, 0x803E
    ctx->r14 = S32(0X803E << 16);
    // 0x803049FC: lbu         $t8, 0x1BBC($t6)
    ctx->r24 = MEM_BU(ctx->r14, 0X1BBC);
    // 0x80304A00: sll         $t7, $t8, 8
    ctx->r15 = S32(ctx->r24 << 8);
    // 0x80304A04: or          $t6, $t9, $t7
    ctx->r14 = ctx->r25 | ctx->r15;
    // 0x80304A08: lui         $t8, 0x803F
    ctx->r24 = S32(0X803F << 16);
    // 0x80304A0C: lbu         $t9, 0x2DA7($t8)
    ctx->r25 = MEM_BU(ctx->r24, 0X2DA7);
    // 0x80304A10: or          $t7, $t6, $t9
    ctx->r15 = ctx->r14 | ctx->r25;
    // 0x80304A14: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x80304A18: b           L_80304E28
    // 0x80304A1C: lh          $t1, 0x2CA6($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X2CA6);
        goto L_80304E28;
    // 0x80304A1C: lh          $t1, 0x2CA6($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X2CA6);
L_80304A20:
    // 0x80304A20: lw          $t8, 0x8($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X8);
    // 0x80304A24: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80304A28: addiu       $a1, $v0, 0x8
    ctx->r5 = ADD32(ctx->r2, 0X8);
    // 0x80304A2C: sra         $t6, $t8, 16
    ctx->r14 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80304A30: lw          $t8, 0x4($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X4);
    // 0x80304A34: andi        $t9, $t6, 0xFFF
    ctx->r25 = ctx->r14 & 0XFFF;
    // 0x80304A38: or          $t7, $t9, $t0
    ctx->r15 = ctx->r25 | ctx->r8;
    // 0x80304A3C: sra         $t6, $t8, 16
    ctx->r14 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80304A40: andi        $t9, $t6, 0xFFF
    ctx->r25 = ctx->r14 & 0XFFF;
    // 0x80304A44: sll         $t8, $t9, 12
    ctx->r24 = S32(ctx->r25 << 12);
    // 0x80304A48: lui         $t9, 0x7
    ctx->r25 = S32(0X7 << 16);
    // 0x80304A4C: ori         $t9, $t9, 0xC07C
    ctx->r25 = ctx->r25 | 0XC07C;
    // 0x80304A50: or          $t6, $t7, $t8
    ctx->r14 = ctx->r15 | ctx->r24;
    // 0x80304A54: sw          $t6, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r14;
    // 0x80304A58: sw          $t9, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r25;
    // 0x80304A5C: lw          $t7, 0x8($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X8);
    // 0x80304A60: addiu       $v0, $a1, 0x8
    ctx->r2 = ADD32(ctx->r5, 0X8);
    // 0x80304A64: lui         $t1, 0x803F
    ctx->r9 = S32(0X803F << 16);
    // 0x80304A68: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80304A6C: sra         $t6, $t8, 1
    ctx->r14 = S32(SIGNED(ctx->r24) >> 1);
    // 0x80304A70: lw          $t8, 0x4($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X4);
    // 0x80304A74: andi        $t9, $t6, 0xFFF
    ctx->r25 = ctx->r14 & 0XFFF;
    // 0x80304A78: or          $t7, $t9, $t0
    ctx->r15 = ctx->r25 | ctx->r8;
    // 0x80304A7C: sra         $t6, $t8, 16
    ctx->r14 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80304A80: sra         $t9, $t6, 1
    ctx->r25 = S32(SIGNED(ctx->r14) >> 1);
    // 0x80304A84: andi        $t8, $t9, 0xFFF
    ctx->r24 = ctx->r25 & 0XFFF;
    // 0x80304A88: sll         $t6, $t8, 12
    ctx->r14 = S32(ctx->r24 << 12);
    // 0x80304A8C: lui         $t8, 0x103
    ctx->r24 = S32(0X103 << 16);
    // 0x80304A90: ori         $t8, $t8, 0xC03C
    ctx->r24 = ctx->r24 | 0XC03C;
    // 0x80304A94: or          $t9, $t7, $t6
    ctx->r25 = ctx->r15 | ctx->r14;
    // 0x80304A98: sw          $t9, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r25;
    // 0x80304A9C: sw          $t8, 0x4($a1)
    MEM_W(0X4, ctx->r5) = ctx->r24;
    // 0x80304AA0: lw          $t7, 0x8($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X8);
    // 0x80304AA4: sra         $t6, $t7, 16
    ctx->r14 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80304AA8: sra         $t9, $t6, 2
    ctx->r25 = S32(SIGNED(ctx->r14) >> 2);
    // 0x80304AAC: lw          $t6, 0x4($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X4);
    // 0x80304AB0: andi        $t8, $t9, 0xFFF
    ctx->r24 = ctx->r25 & 0XFFF;
    // 0x80304AB4: or          $t7, $t8, $t0
    ctx->r15 = ctx->r24 | ctx->r8;
    // 0x80304AB8: sra         $t9, $t6, 16
    ctx->r25 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80304ABC: sra         $t8, $t9, 2
    ctx->r24 = S32(SIGNED(ctx->r25) >> 2);
    // 0x80304AC0: andi        $t6, $t8, 0xFFF
    ctx->r14 = ctx->r24 & 0XFFF;
    // 0x80304AC4: sll         $t9, $t6, 12
    ctx->r25 = S32(ctx->r14 << 12);
    // 0x80304AC8: lui         $t6, 0x201
    ctx->r14 = S32(0X201 << 16);
    // 0x80304ACC: ori         $t6, $t6, 0xC01C
    ctx->r14 = ctx->r14 | 0XC01C;
    // 0x80304AD0: or          $t8, $t7, $t9
    ctx->r24 = ctx->r15 | ctx->r25;
    // 0x80304AD4: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x80304AD8: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x80304ADC: b           L_80304E28
    // 0x80304AE0: lh          $t1, 0x2CA6($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X2CA6);
        goto L_80304E28;
    // 0x80304AE0: lh          $t1, 0x2CA6($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X2CA6);
L_80304AE4:
    // 0x80304AE4: lw          $t7, 0x8($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X8);
    // 0x80304AE8: lui         $t1, 0x803F
    ctx->r9 = S32(0X803F << 16);
    // 0x80304AEC: sra         $t9, $t7, 16
    ctx->r25 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80304AF0: lui         $t7, 0x803E
    ctx->r15 = S32(0X803E << 16);
    // 0x80304AF4: lh          $t7, 0x4BDA($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X4BDA);
    // 0x80304AF8: andi        $t8, $t9, 0xFFF
    ctx->r24 = ctx->r25 & 0XFFF;
    // 0x80304AFC: or          $t6, $t8, $t0
    ctx->r14 = ctx->r24 | ctx->r8;
    // 0x80304B00: lui         $t8, 0x8015
    ctx->r24 = S32(0X8015 << 16);
    // 0x80304B04: sll         $t9, $t7, 1
    ctx->r25 = S32(ctx->r15 << 1);
    // 0x80304B08: addu        $t8, $t8, $t9
    ctx->r24 = ADD32(ctx->r24, ctx->r25);
    // 0x80304B0C: lh          $t8, 0x2620($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X2620);
    // 0x80304B10: sra         $t7, $t8, 7
    ctx->r15 = S32(SIGNED(ctx->r24) >> 7);
    // 0x80304B14: andi        $t9, $t7, 0xFFF
    ctx->r25 = ctx->r15 & 0XFFF;
    // 0x80304B18: sll         $t8, $t9, 12
    ctx->r24 = S32(ctx->r25 << 12);
    // 0x80304B1C: lui         $t9, 0x603
    ctx->r25 = S32(0X603 << 16);
    // 0x80304B20: ori         $t9, $t9, 0xC03C
    ctx->r25 = ctx->r25 | 0XC03C;
    // 0x80304B24: or          $t7, $t6, $t8
    ctx->r15 = ctx->r14 | ctx->r24;
    // 0x80304B28: sw          $t7, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r15;
    // 0x80304B2C: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x80304B30: b           L_80304E28
    // 0x80304B34: lh          $t1, 0x2CA6($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X2CA6);
        goto L_80304E28;
    // 0x80304B34: lh          $t1, 0x2CA6($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X2CA6);
L_80304B38:
    // 0x80304B38: lw          $t6, 0x8($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X8);
    // 0x80304B3C: lui         $t1, 0x803F
    ctx->r9 = S32(0X803F << 16);
    // 0x80304B40: sra         $t8, $t6, 16
    ctx->r24 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80304B44: lw          $t6, 0x4($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X4);
    // 0x80304B48: andi        $t7, $t8, 0xFFF
    ctx->r15 = ctx->r24 & 0XFFF;
    // 0x80304B4C: or          $t9, $t7, $t0
    ctx->r25 = ctx->r15 | ctx->r8;
    // 0x80304B50: sra         $t8, $t6, 16
    ctx->r24 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80304B54: andi        $t7, $t8, 0xFFF
    ctx->r15 = ctx->r24 & 0XFFF;
    // 0x80304B58: sll         $t6, $t7, 12
    ctx->r14 = S32(ctx->r15 << 12);
    // 0x80304B5C: lui         $t7, 0x103
    ctx->r15 = S32(0X103 << 16);
    // 0x80304B60: ori         $t7, $t7, 0xC03C
    ctx->r15 = ctx->r15 | 0XC03C;
    // 0x80304B64: or          $t8, $t9, $t6
    ctx->r24 = ctx->r25 | ctx->r14;
    // 0x80304B68: sw          $t8, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r24;
    // 0x80304B6C: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x80304B70: b           L_80304E28
    // 0x80304B74: lh          $t1, 0x2CA6($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X2CA6);
        goto L_80304E28;
    // 0x80304B74: lh          $t1, 0x2CA6($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X2CA6);
L_80304B78:
    // 0x80304B78: bne         $t4, $zero, L_80304BE0
    if (ctx->r12 != 0) {
        // 0x80304B7C: lui         $t1, 0x803F
        ctx->r9 = S32(0X803F << 16);
            goto L_80304BE0;
    }
    // 0x80304B7C: lui         $t1, 0x803F
    ctx->r9 = S32(0X803F << 16);
    // 0x80304B80: bne         $t5, $zero, L_80304BE0
    if (ctx->r13 != 0) {
        // 0x80304B84: addiu       $a0, $v0, 0x8
        ctx->r4 = ADD32(ctx->r2, 0X8);
            goto L_80304BE0;
    }
    // 0x80304B84: addiu       $a0, $v0, 0x8
    ctx->r4 = ADD32(ctx->r2, 0X8);
    // 0x80304B88: lui         $t9, 0x8103
    ctx->r25 = S32(0X8103 << 16);
    // 0x80304B8C: addiu       $t9, $t9, -0x37F0
    ctx->r25 = ADD32(ctx->r25, -0X37F0);
    // 0x80304B90: sw          $t9, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r25;
    // 0x80304B94: sw          $ra, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r31;
    // 0x80304B98: addiu       $a1, $a0, 0x8
    ctx->r5 = ADD32(ctx->r4, 0X8);
    // 0x80304B9C: sw          $s1, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r17;
    // 0x80304BA0: sw          $s0, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r16;
    // 0x80304BA4: addiu       $a2, $a1, 0x8
    ctx->r6 = ADD32(ctx->r5, 0X8);
    // 0x80304BA8: sw          $zero, 0x4($a1)
    MEM_W(0X4, ctx->r5) = 0;
    // 0x80304BAC: sw          $s2, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r18;
    // 0x80304BB0: addiu       $a3, $a2, 0x8
    ctx->r7 = ADD32(ctx->r6, 0X8);
    // 0x80304BB4: sw          $s4, 0x4($a2)
    MEM_W(0X4, ctx->r6) = ctx->r20;
    // 0x80304BB8: sw          $s3, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r19;
    // 0x80304BBC: addiu       $v1, $a3, 0x8
    ctx->r3 = ADD32(ctx->r7, 0X8);
    // 0x80304BC0: sw          $zero, 0x4($a3)
    MEM_W(0X4, ctx->r7) = 0;
    // 0x80304BC4: sw          $s5, 0x0($a3)
    MEM_W(0X0, ctx->r7) = ctx->r21;
    // 0x80304BC8: sw          $s7, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r23;
    // 0x80304BCC: sw          $s6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r22;
    // 0x80304BD0: addiu       $v0, $v1, 0x8
    ctx->r2 = ADD32(ctx->r3, 0X8);
    // 0x80304BD4: sw          $t0, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r8;
    // 0x80304BD8: b           L_80304C50
    // 0x80304BDC: sw          $t3, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r11;
        goto L_80304C50;
    // 0x80304BDC: sw          $t3, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r11;
L_80304BE0:
    // 0x80304BE0: sw          $ra, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r31;
    // 0x80304BE4: lui         $t6, 0x803E
    ctx->r14 = S32(0X803E << 16);
    // 0x80304BE8: lb          $t6, 0x4BD0($t6)
    ctx->r14 = MEM_B(ctx->r14, 0X4BD0);
    // 0x80304BEC: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80304BF0: lui         $t9, 0x103
    ctx->r25 = S32(0X103 << 16);
    // 0x80304BF4: sll         $t8, $t6, 10
    ctx->r24 = S32(ctx->r14 << 10);
    // 0x80304BF8: addu        $t7, $t8, $at
    ctx->r15 = ADD32(ctx->r24, ctx->r1);
    // 0x80304BFC: addiu       $t9, $t9, -0x37F0
    ctx->r25 = ADD32(ctx->r25, -0X37F0);
    // 0x80304C00: addu        $t6, $t7, $t9
    ctx->r14 = ADD32(ctx->r15, ctx->r25);
    // 0x80304C04: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x80304C08: addiu       $a0, $v0, 0x8
    ctx->r4 = ADD32(ctx->r2, 0X8);
    // 0x80304C0C: addiu       $a1, $a0, 0x8
    ctx->r5 = ADD32(ctx->r4, 0X8);
    // 0x80304C10: sw          $s0, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r16;
    // 0x80304C14: sw          $s1, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r17;
    // 0x80304C18: addiu       $a2, $a1, 0x8
    ctx->r6 = ADD32(ctx->r5, 0X8);
    // 0x80304C1C: sw          $zero, 0x4($a1)
    MEM_W(0X4, ctx->r5) = 0;
    // 0x80304C20: sw          $s2, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r18;
    // 0x80304C24: addiu       $a3, $a2, 0x8
    ctx->r7 = ADD32(ctx->r6, 0X8);
    // 0x80304C28: sw          $s4, 0x4($a2)
    MEM_W(0X4, ctx->r6) = ctx->r20;
    // 0x80304C2C: sw          $s3, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r19;
    // 0x80304C30: addiu       $v1, $a3, 0x8
    ctx->r3 = ADD32(ctx->r7, 0X8);
    // 0x80304C34: sw          $zero, 0x4($a3)
    MEM_W(0X4, ctx->r7) = 0;
    // 0x80304C38: sw          $s5, 0x0($a3)
    MEM_W(0X0, ctx->r7) = ctx->r21;
    // 0x80304C3C: sw          $s7, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r23;
    // 0x80304C40: sw          $s6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r22;
    // 0x80304C44: addiu       $v0, $v1, 0x8
    ctx->r2 = ADD32(ctx->r3, 0X8);
    // 0x80304C48: sw          $t0, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r8;
    // 0x80304C4C: sw          $t3, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r11;
L_80304C50:
    // 0x80304C50: b           L_80304E28
    // 0x80304C54: lh          $t1, 0x2CA6($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X2CA6);
        goto L_80304E28;
    // 0x80304C54: lh          $t1, 0x2CA6($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X2CA6);
L_80304C58:
    // 0x80304C58: bne         $t4, $zero, L_80304C68
    if (ctx->r12 != 0) {
        // 0x80304C5C: lui         $t1, 0x803F
        ctx->r9 = S32(0X803F << 16);
            goto L_80304C68;
    }
    // 0x80304C5C: lui         $t1, 0x803F
    ctx->r9 = S32(0X803F << 16);
    // 0x80304C60: beq         $t5, $zero, L_80304CE0
    if (ctx->r13 == 0) {
        // 0x80304C64: addiu       $a0, $v0, 0x8
        ctx->r4 = ADD32(ctx->r2, 0X8);
            goto L_80304CE0;
    }
    // 0x80304C64: addiu       $a0, $v0, 0x8
    ctx->r4 = ADD32(ctx->r2, 0X8);
L_80304C68:
    // 0x80304C68: sw          $ra, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r31;
    // 0x80304C6C: lui         $t8, 0x803E
    ctx->r24 = S32(0X803E << 16);
    // 0x80304C70: lb          $t8, 0x4BD1($t8)
    ctx->r24 = MEM_B(ctx->r24, 0X4BD1);
    // 0x80304C74: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80304C78: ori         $at, $at, 0x1C00
    ctx->r1 = ctx->r1 | 0X1C00;
    // 0x80304C7C: lui         $t6, 0x103
    ctx->r14 = S32(0X103 << 16);
    // 0x80304C80: sll         $t7, $t8, 10
    ctx->r15 = S32(ctx->r24 << 10);
    // 0x80304C84: addu        $t9, $t7, $at
    ctx->r25 = ADD32(ctx->r15, ctx->r1);
    // 0x80304C88: addiu       $t6, $t6, -0x37F0
    ctx->r14 = ADD32(ctx->r14, -0X37F0);
    // 0x80304C8C: addu        $t8, $t9, $t6
    ctx->r24 = ADD32(ctx->r25, ctx->r14);
    // 0x80304C90: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x80304C94: addiu       $a0, $v0, 0x8
    ctx->r4 = ADD32(ctx->r2, 0X8);
    // 0x80304C98: addiu       $a1, $a0, 0x8
    ctx->r5 = ADD32(ctx->r4, 0X8);
    // 0x80304C9C: sw          $s0, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r16;
    // 0x80304CA0: sw          $s1, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r17;
    // 0x80304CA4: addiu       $a2, $a1, 0x8
    ctx->r6 = ADD32(ctx->r5, 0X8);
    // 0x80304CA8: sw          $zero, 0x4($a1)
    MEM_W(0X4, ctx->r5) = 0;
    // 0x80304CAC: sw          $s2, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r18;
    // 0x80304CB0: addiu       $a3, $a2, 0x8
    ctx->r7 = ADD32(ctx->r6, 0X8);
    // 0x80304CB4: sw          $s4, 0x4($a2)
    MEM_W(0X4, ctx->r6) = ctx->r20;
    // 0x80304CB8: sw          $s3, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r19;
    // 0x80304CBC: addiu       $v1, $a3, 0x8
    ctx->r3 = ADD32(ctx->r7, 0X8);
    // 0x80304CC0: sw          $zero, 0x4($a3)
    MEM_W(0X4, ctx->r7) = 0;
    // 0x80304CC4: sw          $s5, 0x0($a3)
    MEM_W(0X0, ctx->r7) = ctx->r21;
    // 0x80304CC8: sw          $s7, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r23;
    // 0x80304CCC: sw          $s6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r22;
    // 0x80304CD0: addiu       $v0, $v1, 0x8
    ctx->r2 = ADD32(ctx->r3, 0X8);
    // 0x80304CD4: sw          $t0, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r8;
    // 0x80304CD8: b           L_80304D34
    // 0x80304CDC: sw          $t3, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r11;
        goto L_80304D34;
    // 0x80304CDC: sw          $t3, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r11;
L_80304CE0:
    // 0x80304CE0: lui         $t7, 0x8103
    ctx->r15 = S32(0X8103 << 16);
    // 0x80304CE4: addiu       $t7, $t7, -0x1BF0
    ctx->r15 = ADD32(ctx->r15, -0X1BF0);
    // 0x80304CE8: sw          $t7, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r15;
    // 0x80304CEC: sw          $ra, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r31;
    // 0x80304CF0: addiu       $a1, $a0, 0x8
    ctx->r5 = ADD32(ctx->r4, 0X8);
    // 0x80304CF4: sw          $s1, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r17;
    // 0x80304CF8: sw          $s0, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r16;
    // 0x80304CFC: addiu       $a2, $a1, 0x8
    ctx->r6 = ADD32(ctx->r5, 0X8);
    // 0x80304D00: sw          $zero, 0x4($a1)
    MEM_W(0X4, ctx->r5) = 0;
    // 0x80304D04: sw          $s2, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r18;
    // 0x80304D08: addiu       $a3, $a2, 0x8
    ctx->r7 = ADD32(ctx->r6, 0X8);
    // 0x80304D0C: sw          $s4, 0x4($a2)
    MEM_W(0X4, ctx->r6) = ctx->r20;
    // 0x80304D10: sw          $s3, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r19;
    // 0x80304D14: addiu       $v1, $a3, 0x8
    ctx->r3 = ADD32(ctx->r7, 0X8);
    // 0x80304D18: sw          $zero, 0x4($a3)
    MEM_W(0X4, ctx->r7) = 0;
    // 0x80304D1C: sw          $s5, 0x0($a3)
    MEM_W(0X0, ctx->r7) = ctx->r21;
    // 0x80304D20: sw          $s7, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r23;
    // 0x80304D24: sw          $s6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r22;
    // 0x80304D28: addiu       $v0, $v1, 0x8
    ctx->r2 = ADD32(ctx->r3, 0X8);
    // 0x80304D2C: sw          $t0, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r8;
    // 0x80304D30: sw          $t3, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r11;
L_80304D34:
    // 0x80304D34: b           L_80304E28
    // 0x80304D38: lh          $t1, 0x2CA6($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X2CA6);
        goto L_80304E28;
    // 0x80304D38: lh          $t1, 0x2CA6($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X2CA6);
L_80304D3C:
    // 0x80304D3C: bne         $t4, $zero, L_80304D4C
    if (ctx->r12 != 0) {
        // 0x80304D40: lui         $t1, 0x803F
        ctx->r9 = S32(0X803F << 16);
            goto L_80304D4C;
    }
    // 0x80304D40: lui         $t1, 0x803F
    ctx->r9 = S32(0X803F << 16);
    // 0x80304D44: beq         $t5, $zero, L_80304DD0
    if (ctx->r13 == 0) {
        // 0x80304D48: addiu       $a0, $v0, 0x8
        ctx->r4 = ADD32(ctx->r2, 0X8);
            goto L_80304DD0;
    }
    // 0x80304D48: addiu       $a0, $v0, 0x8
    ctx->r4 = ADD32(ctx->r2, 0X8);
L_80304D4C:
    // 0x80304D4C: sw          $ra, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r31;
    // 0x80304D50: lui         $t9, 0x803E
    ctx->r25 = S32(0X803E << 16);
    // 0x80304D54: lb          $t9, 0x4BD2($t9)
    ctx->r25 = MEM_B(ctx->r25, 0X4BD2);
    // 0x80304D58: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80304D5C: addiu       $a0, $v0, 0x8
    ctx->r4 = ADD32(ctx->r2, 0X8);
    // 0x80304D60: div         $zero, $t9, $at
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r1)));
    // 0x80304D64: mflo        $t6
    ctx->r14 = lo;
    // 0x80304D68: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80304D6C: ori         $at, $at, 0x1000
    ctx->r1 = ctx->r1 | 0X1000;
    // 0x80304D70: sll         $t8, $t6, 10
    ctx->r24 = S32(ctx->r14 << 10);
    // 0x80304D74: lui         $t9, 0x103
    ctx->r25 = S32(0X103 << 16);
    // 0x80304D78: addiu       $t9, $t9, -0x37F0
    ctx->r25 = ADD32(ctx->r25, -0X37F0);
    // 0x80304D7C: addu        $t7, $t8, $at
    ctx->r15 = ADD32(ctx->r24, ctx->r1);
    // 0x80304D80: addu        $t6, $t7, $t9
    ctx->r14 = ADD32(ctx->r15, ctx->r25);
    // 0x80304D84: sw          $t6, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r14;
    // 0x80304D88: addiu       $a1, $a0, 0x8
    ctx->r5 = ADD32(ctx->r4, 0X8);
    // 0x80304D8C: sw          $s1, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r17;
    // 0x80304D90: sw          $s0, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r16;
    // 0x80304D94: addiu       $a2, $a1, 0x8
    ctx->r6 = ADD32(ctx->r5, 0X8);
    // 0x80304D98: sw          $zero, 0x4($a1)
    MEM_W(0X4, ctx->r5) = 0;
    // 0x80304D9C: sw          $s2, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r18;
    // 0x80304DA0: addiu       $a3, $a2, 0x8
    ctx->r7 = ADD32(ctx->r6, 0X8);
    // 0x80304DA4: sw          $s4, 0x4($a2)
    MEM_W(0X4, ctx->r6) = ctx->r20;
    // 0x80304DA8: sw          $s3, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r19;
    // 0x80304DAC: addiu       $v1, $a3, 0x8
    ctx->r3 = ADD32(ctx->r7, 0X8);
    // 0x80304DB0: sw          $zero, 0x4($a3)
    MEM_W(0X4, ctx->r7) = 0;
    // 0x80304DB4: sw          $s5, 0x0($a3)
    MEM_W(0X0, ctx->r7) = ctx->r21;
    // 0x80304DB8: sw          $s7, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r23;
    // 0x80304DBC: sw          $s6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r22;
    // 0x80304DC0: addiu       $v0, $v1, 0x8
    ctx->r2 = ADD32(ctx->r3, 0X8);
    // 0x80304DC4: sw          $t0, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r8;
    // 0x80304DC8: b           L_80304E24
    // 0x80304DCC: sw          $t3, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r11;
        goto L_80304E24;
    // 0x80304DCC: sw          $t3, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r11;
L_80304DD0:
    // 0x80304DD0: lui         $t8, 0x8103
    ctx->r24 = S32(0X8103 << 16);
    // 0x80304DD4: addiu       $t8, $t8, -0x27F0
    ctx->r24 = ADD32(ctx->r24, -0X27F0);
    // 0x80304DD8: sw          $t8, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r24;
    // 0x80304DDC: sw          $ra, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r31;
    // 0x80304DE0: addiu       $a1, $a0, 0x8
    ctx->r5 = ADD32(ctx->r4, 0X8);
    // 0x80304DE4: sw          $s1, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r17;
    // 0x80304DE8: sw          $s0, 0x0($a0)
    MEM_W(0X0, ctx->r4) = ctx->r16;
    // 0x80304DEC: addiu       $a2, $a1, 0x8
    ctx->r6 = ADD32(ctx->r5, 0X8);
    // 0x80304DF0: sw          $zero, 0x4($a1)
    MEM_W(0X4, ctx->r5) = 0;
    // 0x80304DF4: sw          $s2, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r18;
    // 0x80304DF8: addiu       $a3, $a2, 0x8
    ctx->r7 = ADD32(ctx->r6, 0X8);
    // 0x80304DFC: sw          $s4, 0x4($a2)
    MEM_W(0X4, ctx->r6) = ctx->r20;
    // 0x80304E00: sw          $s3, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r19;
    // 0x80304E04: addiu       $v1, $a3, 0x8
    ctx->r3 = ADD32(ctx->r7, 0X8);
    // 0x80304E08: sw          $zero, 0x4($a3)
    MEM_W(0X4, ctx->r7) = 0;
    // 0x80304E0C: sw          $s5, 0x0($a3)
    MEM_W(0X0, ctx->r7) = ctx->r21;
    // 0x80304E10: sw          $s7, 0x4($v1)
    MEM_W(0X4, ctx->r3) = ctx->r23;
    // 0x80304E14: sw          $s6, 0x0($v1)
    MEM_W(0X0, ctx->r3) = ctx->r22;
    // 0x80304E18: addiu       $v0, $v1, 0x8
    ctx->r2 = ADD32(ctx->r3, 0X8);
    // 0x80304E1C: sw          $t0, 0x0($v0)
    MEM_W(0X0, ctx->r2) = ctx->r8;
    // 0x80304E20: sw          $t3, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r11;
L_80304E24:
    // 0x80304E24: lh          $t1, 0x2CA6($t1)
    ctx->r9 = MEM_H(ctx->r9, 0X2CA6);
L_80304E28:
    // 0x80304E28: addiu       $t2, $t2, 0x1
    ctx->r10 = ADD32(ctx->r10, 0X1);
    // 0x80304E2C: sll         $t7, $t2, 16
    ctx->r15 = S32(ctx->r10 << 16);
    // 0x80304E30: sra         $t2, $t7, 16
    ctx->r10 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80304E34: slt         $at, $t2, $t1
    ctx->r1 = SIGNED(ctx->r10) < SIGNED(ctx->r9) ? 1 : 0;
    // 0x80304E38: bnel        $at, $zero, L_80304538
    if (ctx->r1 != 0) {
        // 0x80304E3C: sll         $t8, $t2, 2
        ctx->r24 = S32(ctx->r10 << 2);
            goto L_80304538;
    }
    goto skip_2;
    // 0x80304E3C: sll         $t8, $t2, 2
    ctx->r24 = S32(ctx->r10 << 2);
    skip_2:
    // 0x80304E40: sw          $t5, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r13;
    // 0x80304E44: sw          $t4, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r12;
L_80304E48:
    // 0x80304E48: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    // 0x80304E4C: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80304E50: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x80304E54: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x80304E58: lw          $s3, 0x24($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X24);
    // 0x80304E5C: lw          $s4, 0x28($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X28);
    // 0x80304E60: lw          $s5, 0x2C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X2C);
    // 0x80304E64: lw          $s6, 0x30($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X30);
    // 0x80304E68: lw          $s7, 0x34($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X34);
    // 0x80304E6C: lw          $fp, 0x38($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X38);
    // 0x80304E70: jr          $ra
    // 0x80304E74: addiu       $sp, $sp, 0x58
    ctx->r29 = ADD32(ctx->r29, 0X58);
    return;
    // 0x80304E74: addiu       $sp, $sp, 0x58
    ctx->r29 = ADD32(ctx->r29, 0X58);
;}
RECOMP_FUNC void calculate_hypotenuse(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80304E80: lw          $v1, 0x0($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X0);
    // 0x80304E84: lw          $a1, 0x4($a0)
    ctx->r5 = MEM_W(ctx->r4, 0X4);
    // 0x80304E88: multu       $v1, $v1
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80304E8C: mflo        $t6
    ctx->r14 = lo;
    // 0x80304E90: nop

    // 0x80304E94: nop

    // 0x80304E98: multu       $a1, $a1
    result = U64(U32(ctx->r5)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80304E9C: mflo        $t7
    ctx->r15 = lo;
    // 0x80304EA0: addu        $t8, $t6, $t7
    ctx->r24 = ADD32(ctx->r14, ctx->r15);
    // 0x80304EA4: mtc1        $t8, $f4
    ctx->f4.u32l = ctx->r24;
    // 0x80304EA8: nop

    // 0x80304EAC: cvt.s.w     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    ctx->f0.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80304EB0: sqrt.s      $f0, $f0
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f0.fl = sqrtf(ctx->f0.fl);
    // 0x80304EB4: trunc.w.s   $f6, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    ctx->f6.u32l = TRUNC_W_S(ctx->f0.fl);
    // 0x80304EB8: mfc1        $v0, $f6
    ctx->r2 = (int32_t)ctx->f6.u32l;
    // 0x80304EBC: jr          $ra
    // 0x80304EC0: nop

    return;
    // 0x80304EC0: nop

;}
RECOMP_FUNC void func_80304EC4_716574(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80304EC4: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80304EC8: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80304ECC: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x80304ED0: jal         0x80304E80
    // 0x80304ED4: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    calculate_hypotenuse(rdram, ctx);
        goto after_0;
    // 0x80304ED4: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    after_0:
    // 0x80304ED8: lw          $a0, 0x18($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X18);
    // 0x80304EDC: bne         $v0, $zero, L_80304EF0
    if (ctx->r2 != 0) {
        // 0x80304EE0: lw          $a1, 0x1C($sp)
        ctx->r5 = MEM_W(ctx->r29, 0X1C);
            goto L_80304EF0;
    }
    // 0x80304EE0: lw          $a1, 0x1C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X1C);
    // 0x80304EE4: sw          $zero, 0x0($a1)
    MEM_W(0X0, ctx->r5) = 0;
    // 0x80304EE8: b           L_80304F60
    // 0x80304EEC: sw          $zero, 0x4($a1)
    MEM_W(0X4, ctx->r5) = 0;
        goto L_80304F60;
    // 0x80304EEC: sw          $zero, 0x4($a1)
    MEM_W(0X4, ctx->r5) = 0;
L_80304EF0:
    // 0x80304EF0: lw          $t6, 0x0($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X0);
    // 0x80304EF4: sll         $t7, $t6, 8
    ctx->r15 = S32(ctx->r14 << 8);
    // 0x80304EF8: div         $zero, $t7, $v0
    lo = S32(S64(S32(ctx->r15)) / S64(S32(ctx->r2))); hi = S32(S64(S32(ctx->r15)) % S64(S32(ctx->r2)));
    // 0x80304EFC: mflo        $t8
    ctx->r24 = lo;
    // 0x80304F00: sw          $t8, 0x0($a1)
    MEM_W(0X0, ctx->r5) = ctx->r24;
    // 0x80304F04: lw          $t9, 0x4($a0)
    ctx->r25 = MEM_W(ctx->r4, 0X4);
    // 0x80304F08: bne         $v0, $zero, L_80304F14
    if (ctx->r2 != 0) {
        // 0x80304F0C: nop
    
            goto L_80304F14;
    }
    // 0x80304F0C: nop

    // 0x80304F10: break       7
    do_break(2150649616);
L_80304F14:
    // 0x80304F14: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80304F18: bne         $v0, $at, L_80304F2C
    if (ctx->r2 != ctx->r1) {
        // 0x80304F1C: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80304F2C;
    }
    // 0x80304F1C: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80304F20: bne         $t7, $at, L_80304F2C
    if (ctx->r15 != ctx->r1) {
        // 0x80304F24: nop
    
            goto L_80304F2C;
    }
    // 0x80304F24: nop

    // 0x80304F28: break       6
    do_break(2150649640);
L_80304F2C:
    // 0x80304F2C: sll         $t0, $t9, 8
    ctx->r8 = S32(ctx->r25 << 8);
    // 0x80304F30: div         $zero, $t0, $v0
    lo = S32(S64(S32(ctx->r8)) / S64(S32(ctx->r2))); hi = S32(S64(S32(ctx->r8)) % S64(S32(ctx->r2)));
    // 0x80304F34: mflo        $t1
    ctx->r9 = lo;
    // 0x80304F38: sw          $t1, 0x4($a1)
    MEM_W(0X4, ctx->r5) = ctx->r9;
    // 0x80304F3C: bne         $v0, $zero, L_80304F48
    if (ctx->r2 != 0) {
        // 0x80304F40: nop
    
            goto L_80304F48;
    }
    // 0x80304F40: nop

    // 0x80304F44: break       7
    do_break(2150649668);
L_80304F48:
    // 0x80304F48: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80304F4C: bne         $v0, $at, L_80304F60
    if (ctx->r2 != ctx->r1) {
        // 0x80304F50: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80304F60;
    }
    // 0x80304F50: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80304F54: bne         $t0, $at, L_80304F60
    if (ctx->r8 != ctx->r1) {
        // 0x80304F58: nop
    
            goto L_80304F60;
    }
    // 0x80304F58: nop

    // 0x80304F5C: break       6
    do_break(2150649692);
L_80304F60:
    // 0x80304F60: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80304F64: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80304F68: jr          $ra
    // 0x80304F6C: nop

    return;
    // 0x80304F6C: nop

;}
RECOMP_FUNC void func_80304F70_716620(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80304F70: lw          $t6, 0x0($a0)
    ctx->r14 = MEM_W(ctx->r4, 0X0);
    // 0x80304F74: lw          $t7, 0x0($a1)
    ctx->r15 = MEM_W(ctx->r5, 0X0);
    // 0x80304F78: subu        $t8, $t6, $t7
    ctx->r24 = SUB32(ctx->r14, ctx->r15);
    // 0x80304F7C: sw          $t8, 0x0($a2)
    MEM_W(0X0, ctx->r6) = ctx->r24;
    // 0x80304F80: lw          $t0, 0x4($a1)
    ctx->r8 = MEM_W(ctx->r5, 0X4);
    // 0x80304F84: lw          $t9, 0x4($a0)
    ctx->r25 = MEM_W(ctx->r4, 0X4);
    // 0x80304F88: subu        $t1, $t9, $t0
    ctx->r9 = SUB32(ctx->r25, ctx->r8);
    // 0x80304F8C: jr          $ra
    // 0x80304F90: sw          $t1, 0x4($a2)
    MEM_W(0X4, ctx->r6) = ctx->r9;
    return;
    // 0x80304F90: sw          $t1, 0x4($a2)
    MEM_W(0X4, ctx->r6) = ctx->r9;
;}
RECOMP_FUNC void func_80304F94_716644(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80304F94: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80304F98: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80304F9C: lw          $v0, 0x0($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X0);
    // 0x80304FA0: lw          $v1, 0x4($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X4);
    // 0x80304FA4: lw          $a2, 0x0($a1)
    ctx->r6 = MEM_W(ctx->r5, 0X0);
    // 0x80304FA8: multu       $v0, $v0
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r2)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80304FAC: lw          $a3, 0x4($a1)
    ctx->r7 = MEM_W(ctx->r5, 0X4);
    // 0x80304FB0: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x80304FB4: mflo        $t6
    ctx->r14 = lo;
    // 0x80304FB8: nop

    // 0x80304FBC: nop

    // 0x80304FC0: multu       $v1, $v1
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80304FC4: mflo        $t7
    ctx->r15 = lo;
    // 0x80304FC8: addu        $t8, $t6, $t7
    ctx->r24 = ADD32(ctx->r14, ctx->r15);
    // 0x80304FCC: mtc1        $t8, $f4
    ctx->f4.u32l = ctx->r24;
    // 0x80304FD0: multu       $a2, $a2
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80304FD4: cvt.s.w     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    ctx->f0.fl = CVT_S_W(ctx->f4.u32l);
    // 0x80304FD8: sqrt.s      $f2, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f2.fl = sqrtf(ctx->f0.fl);
    // 0x80304FDC: mflo        $t9
    ctx->r25 = lo;
    // 0x80304FE0: nop

    // 0x80304FE4: nop

    // 0x80304FE8: multu       $a3, $a3
    result = U64(U32(ctx->r7)) * U64(U32(ctx->r7)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80304FEC: mflo        $t1
    ctx->r9 = lo;
    // 0x80304FF0: addu        $t2, $t9, $t1
    ctx->r10 = ADD32(ctx->r25, ctx->r9);
    // 0x80304FF4: mtc1        $t2, $f6
    ctx->f6.u32l = ctx->r10;
    // 0x80304FF8: multu       $v0, $a2
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80304FFC: mflo        $t3
    ctx->r11 = lo;
    // 0x80305000: nop

    // 0x80305004: nop

    // 0x80305008: multu       $v1, $a3
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r7)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8030500C: mflo        $t4
    ctx->r12 = lo;
    // 0x80305010: addu        $t0, $t3, $t4
    ctx->r8 = ADD32(ctx->r11, ctx->r12);
    // 0x80305014: sll         $t5, $t0, 8
    ctx->r13 = S32(ctx->r8 << 8);
    // 0x80305018: cvt.s.w     $f0, $f6
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    ctx->f0.fl = CVT_S_W(ctx->f6.u32l);
    // 0x8030501C: sqrt.s      $f0, $f0
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f0.fl = sqrtf(ctx->f0.fl);
    // 0x80305020: mul.s       $f2, $f2, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f2.fl = MUL_S(ctx->f2.fl, ctx->f0.fl);
    // 0x80305024: c.eq.s      $f2, $f8
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 8);
    c1cs = ctx->f2.fl == ctx->f8.fl;
    // 0x80305028: nop

    // 0x8030502C: bc1fl       L_80305040
    if (!c1cs) {
        // 0x80305030: mtc1        $t5, $f10
        ctx->f10.u32l = ctx->r13;
            goto L_80305040;
    }
    goto skip_0;
    // 0x80305030: mtc1        $t5, $f10
    ctx->f10.u32l = ctx->r13;
    skip_0:
    // 0x80305034: b           L_80305070
    // 0x80305038: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
        goto L_80305070;
    // 0x80305038: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x8030503C: mtc1        $t5, $f10
    ctx->f10.u32l = ctx->r13;
L_80305040:
    // 0x80305040: nop

    // 0x80305044: cvt.s.w     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.fl = CVT_S_W(ctx->f10.u32l);
    // 0x80305048: div.s       $f18, $f16, $f2
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f18.fl = DIV_S(ctx->f16.fl, ctx->f2.fl);
    // 0x8030504C: trunc.w.s   $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.u32l = TRUNC_W_S(ctx->f18.fl);
    // 0x80305050: mfc1        $a0, $f4
    ctx->r4 = (int32_t)ctx->f4.u32l;
    // 0x80305054: nop

    // 0x80305058: sll         $t7, $a0, 16
    ctx->r15 = S32(ctx->r4 << 16);
    // 0x8030505C: jal         0x801283AC
    // 0x80305060: sra         $a0, $t7, 16
    ctx->r4 = S32(SIGNED(ctx->r15) >> 16);
    func_801283AC(rdram, ctx);
        goto after_0;
    // 0x80305060: sra         $a0, $t7, 16
    ctx->r4 = S32(SIGNED(ctx->r15) >> 16);
    after_0:
    // 0x80305064: sll         $v1, $v0, 16
    ctx->r3 = S32(ctx->r2 << 16);
    // 0x80305068: sra         $t9, $v1, 16
    ctx->r25 = S32(SIGNED(ctx->r3) >> 16);
    // 0x8030506C: or          $v1, $t9, $zero
    ctx->r3 = ctx->r25 | 0;
L_80305070:
    // 0x80305070: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80305074: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80305078: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x8030507C: jr          $ra
    // 0x80305080: nop

    return;
    // 0x80305080: nop

;}
RECOMP_FUNC void func_80305084_716734(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80305084: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80305088: sw          $a0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r4;
    // 0x8030508C: lh          $t2, 0x1A($sp)
    ctx->r10 = MEM_H(ctx->r29, 0X1A);
    // 0x80305090: sw          $a1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r5;
    // 0x80305094: sll         $t6, $a1, 16
    ctx->r14 = S32(ctx->r5 << 16);
    // 0x80305098: multu       $t2, $t2
    result = U64(U32(ctx->r10)) * U64(U32(ctx->r10)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8030509C: sra         $a1, $t6, 16
    ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
    // 0x803050A0: sw          $a2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r6;
    // 0x803050A4: sll         $t8, $a2, 16
    ctx->r24 = S32(ctx->r6 << 16);
    // 0x803050A8: sra         $a2, $t8, 16
    ctx->r6 = S32(SIGNED(ctx->r24) >> 16);
    // 0x803050AC: sw          $a3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r7;
    // 0x803050B0: sll         $t0, $a3, 16
    ctx->r8 = S32(ctx->r7 << 16);
    // 0x803050B4: sra         $a3, $t0, 16
    ctx->r7 = S32(SIGNED(ctx->r8) >> 16);
    // 0x803050B8: mtc1        $zero, $f8
    ctx->f8.u32l = 0;
    // 0x803050BC: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x803050C0: mflo        $t3
    ctx->r11 = lo;
    // 0x803050C4: lh          $t9, 0x1A($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X1A);
    // 0x803050C8: nop

    // 0x803050CC: multu       $a1, $a1
    result = U64(U32(ctx->r5)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803050D0: mflo        $t4
    ctx->r12 = lo;
    // 0x803050D4: addu        $t5, $t3, $t4
    ctx->r13 = ADD32(ctx->r11, ctx->r12);
    // 0x803050D8: mtc1        $t5, $f4
    ctx->f4.u32l = ctx->r13;
    // 0x803050DC: multu       $a2, $a2
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803050E0: cvt.s.w     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    ctx->f0.fl = CVT_S_W(ctx->f4.u32l);
    // 0x803050E4: sqrt.s      $f2, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f2.fl = sqrtf(ctx->f0.fl);
    // 0x803050E8: mflo        $t6
    ctx->r14 = lo;
    // 0x803050EC: nop

    // 0x803050F0: nop

    // 0x803050F4: multu       $a3, $a3
    result = U64(U32(ctx->r7)) * U64(U32(ctx->r7)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803050F8: mflo        $t7
    ctx->r15 = lo;
    // 0x803050FC: addu        $t8, $t6, $t7
    ctx->r24 = ADD32(ctx->r14, ctx->r15);
    // 0x80305100: mtc1        $t8, $f6
    ctx->f6.u32l = ctx->r24;
    // 0x80305104: nop

    // 0x80305108: cvt.s.w     $f0, $f6
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 6);
    ctx->f0.fl = CVT_S_W(ctx->f6.u32l);
    // 0x8030510C: sqrt.s      $f0, $f0
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f0.fl = sqrtf(ctx->f0.fl);
    // 0x80305110: mul.s       $f2, $f2, $f0
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f2.fl); NAN_CHECK(ctx->f0.fl); 
    ctx->f2.fl = MUL_S(ctx->f2.fl, ctx->f0.fl);
    // 0x80305114: c.eq.s      $f2, $f8
    CHECK_FR(ctx, 2);
    CHECK_FR(ctx, 8);
    c1cs = ctx->f2.fl == ctx->f8.fl;
    // 0x80305118: nop

    // 0x8030511C: bc1f        L_8030512C
    if (!c1cs) {
        // 0x80305120: nop
    
            goto L_8030512C;
    }
    // 0x80305120: nop

    // 0x80305124: b           L_80305180
    // 0x80305128: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
        goto L_80305180;
    // 0x80305128: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
L_8030512C:
    // 0x8030512C: multu       $t9, $a2
    result = U64(U32(ctx->r25)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80305130: mflo        $t0
    ctx->r8 = lo;
    // 0x80305134: nop

    // 0x80305138: nop

    // 0x8030513C: multu       $a1, $a3
    result = U64(U32(ctx->r5)) * U64(U32(ctx->r7)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80305140: mflo        $t1
    ctx->r9 = lo;
    // 0x80305144: addu        $t2, $t0, $t1
    ctx->r10 = ADD32(ctx->r8, ctx->r9);
    // 0x80305148: sll         $t3, $t2, 8
    ctx->r11 = S32(ctx->r10 << 8);
    // 0x8030514C: mtc1        $t3, $f10
    ctx->f10.u32l = ctx->r11;
    // 0x80305150: nop

    // 0x80305154: cvt.s.w     $f16, $f10
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 10);
    ctx->f16.fl = CVT_S_W(ctx->f10.u32l);
    // 0x80305158: div.s       $f18, $f16, $f2
    CHECK_FR(ctx, 18);
    CHECK_FR(ctx, 16);
    CHECK_FR(ctx, 2);
    NAN_CHECK(ctx->f16.fl); NAN_CHECK(ctx->f2.fl); 
    ctx->f18.fl = DIV_S(ctx->f16.fl, ctx->f2.fl);
    // 0x8030515C: trunc.w.s   $f4, $f18
    CHECK_FR(ctx, 4);
    CHECK_FR(ctx, 18);
    ctx->f4.u32l = TRUNC_W_S(ctx->f18.fl);
    // 0x80305160: mfc1        $a0, $f4
    ctx->r4 = (int32_t)ctx->f4.u32l;
    // 0x80305164: nop

    // 0x80305168: sll         $t5, $a0, 16
    ctx->r13 = S32(ctx->r4 << 16);
    // 0x8030516C: jal         0x801283AC
    // 0x80305170: sra         $a0, $t5, 16
    ctx->r4 = S32(SIGNED(ctx->r13) >> 16);
    func_801283AC(rdram, ctx);
        goto after_0;
    // 0x80305170: sra         $a0, $t5, 16
    ctx->r4 = S32(SIGNED(ctx->r13) >> 16);
    after_0:
    // 0x80305174: sll         $v1, $v0, 16
    ctx->r3 = S32(ctx->r2 << 16);
    // 0x80305178: sra         $t7, $v1, 16
    ctx->r15 = S32(SIGNED(ctx->r3) >> 16);
    // 0x8030517C: or          $v1, $t7, $zero
    ctx->r3 = ctx->r15 | 0;
L_80305180:
    // 0x80305180: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80305184: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80305188: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x8030518C: jr          $ra
    // 0x80305190: nop

    return;
    // 0x80305190: nop

;}
RECOMP_FUNC void func_80305194_716844(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80305194: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x80305198: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x8030519C: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x803051A0: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x803051A4: subu        $v0, $t7, $t9
    ctx->r2 = SUB32(ctx->r15, ctx->r25);
    // 0x803051A8: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x803051AC: bgez        $v0, L_803051C4
    if (SIGNED(ctx->r2) >= 0) {
        // 0x803051B0: sw          $a1, 0x4($sp)
        MEM_W(0X4, ctx->r29) = ctx->r5;
            goto L_803051C4;
    }
    // 0x803051B0: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x803051B4: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
    // 0x803051B8: sll         $t0, $v1, 16
    ctx->r8 = S32(ctx->r3 << 16);
    // 0x803051BC: b           L_803051D0
    // 0x803051C0: sra         $v1, $t0, 16
    ctx->r3 = S32(SIGNED(ctx->r8) >> 16);
        goto L_803051D0;
    // 0x803051C0: sra         $v1, $t0, 16
    ctx->r3 = S32(SIGNED(ctx->r8) >> 16);
L_803051C4:
    // 0x803051C4: sll         $v1, $v0, 16
    ctx->r3 = S32(ctx->r2 << 16);
    // 0x803051C8: sra         $t2, $v1, 16
    ctx->r10 = S32(SIGNED(ctx->r3) >> 16);
    // 0x803051CC: or          $v1, $t2, $zero
    ctx->r3 = ctx->r10 | 0;
L_803051D0:
    // 0x803051D0: slti        $at, $v1, 0xB5
    ctx->r1 = SIGNED(ctx->r3) < 0XB5 ? 1 : 0;
    // 0x803051D4: bne         $at, $zero, L_803051E8
    if (ctx->r1 != 0) {
        // 0x803051D8: addiu       $t3, $zero, 0x168
        ctx->r11 = ADD32(0, 0X168);
            goto L_803051E8;
    }
    // 0x803051D8: addiu       $t3, $zero, 0x168
    ctx->r11 = ADD32(0, 0X168);
    // 0x803051DC: subu        $v1, $t3, $v1
    ctx->r3 = SUB32(ctx->r11, ctx->r3);
    // 0x803051E0: sll         $t4, $v1, 16
    ctx->r12 = S32(ctx->r3 << 16);
    // 0x803051E4: sra         $v1, $t4, 16
    ctx->r3 = S32(SIGNED(ctx->r12) >> 16);
L_803051E8:
    // 0x803051E8: jr          $ra
    // 0x803051EC: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    return;
    // 0x803051EC: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
;}
RECOMP_FUNC void func_803051F0_7168A0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803051F0: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x803051F4: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x803051F8: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x803051FC: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80305200: subu        $v0, $t7, $t9
    ctx->r2 = SUB32(ctx->r15, ctx->r25);
    // 0x80305204: sw          $a0, 0x0($sp)
    MEM_W(0X0, ctx->r29) = ctx->r4;
    // 0x80305208: bgez        $v0, L_80305220
    if (SIGNED(ctx->r2) >= 0) {
        // 0x8030520C: sw          $a1, 0x4($sp)
        MEM_W(0X4, ctx->r29) = ctx->r5;
            goto L_80305220;
    }
    // 0x8030520C: sw          $a1, 0x4($sp)
    MEM_W(0X4, ctx->r29) = ctx->r5;
    // 0x80305210: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
    // 0x80305214: sll         $t0, $v1, 16
    ctx->r8 = S32(ctx->r3 << 16);
    // 0x80305218: b           L_8030522C
    // 0x8030521C: sra         $v1, $t0, 16
    ctx->r3 = S32(SIGNED(ctx->r8) >> 16);
        goto L_8030522C;
    // 0x8030521C: sra         $v1, $t0, 16
    ctx->r3 = S32(SIGNED(ctx->r8) >> 16);
L_80305220:
    // 0x80305220: sll         $v1, $v0, 16
    ctx->r3 = S32(ctx->r2 << 16);
    // 0x80305224: sra         $t2, $v1, 16
    ctx->r10 = S32(SIGNED(ctx->r3) >> 16);
    // 0x80305228: or          $v1, $t2, $zero
    ctx->r3 = ctx->r10 | 0;
L_8030522C:
    // 0x8030522C: slti        $at, $v1, 0x81
    ctx->r1 = SIGNED(ctx->r3) < 0X81 ? 1 : 0;
    // 0x80305230: bne         $at, $zero, L_80305244
    if (ctx->r1 != 0) {
        // 0x80305234: addiu       $t3, $zero, 0x100
        ctx->r11 = ADD32(0, 0X100);
            goto L_80305244;
    }
    // 0x80305234: addiu       $t3, $zero, 0x100
    ctx->r11 = ADD32(0, 0X100);
    // 0x80305238: subu        $v1, $t3, $v1
    ctx->r3 = SUB32(ctx->r11, ctx->r3);
    // 0x8030523C: sll         $t4, $v1, 16
    ctx->r12 = S32(ctx->r3 << 16);
    // 0x80305240: sra         $v1, $t4, 16
    ctx->r3 = S32(SIGNED(ctx->r12) >> 16);
L_80305244:
    // 0x80305244: jr          $ra
    // 0x80305248: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    return;
    // 0x80305248: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
;}
RECOMP_FUNC void func_80305250_716900(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80305250: sw          $a2, 0x8($sp)
    MEM_W(0X8, ctx->r29) = ctx->r6;
    // 0x80305254: sll         $t6, $a2, 16
    ctx->r14 = S32(ctx->r6 << 16);
    // 0x80305258: sra         $a2, $t6, 16
    ctx->r6 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8030525C: bgez        $a2, L_80305268
    if (SIGNED(ctx->r6) >= 0) {
        // 0x80305260: sw          $a3, 0xC($sp)
        MEM_W(0XC, ctx->r29) = ctx->r7;
            goto L_80305268;
    }
    // 0x80305260: sw          $a3, 0xC($sp)
    MEM_W(0XC, ctx->r29) = ctx->r7;
    // 0x80305264: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
L_80305268:
    // 0x80305268: lhu         $v0, 0x0($a0)
    ctx->r2 = MEM_HU(ctx->r4, 0X0);
    // 0x8030526C: bne         $v0, $zero, L_80305288
    if (ctx->r2 != 0) {
        // 0x80305270: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_80305288;
    }
    // 0x80305270: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x80305274: addiu       $t8, $v0, 0x1
    ctx->r24 = ADD32(ctx->r2, 0X1);
    // 0x80305278: sw          $a2, 0x4($a0)
    MEM_W(0X4, ctx->r4) = ctx->r6;
    // 0x8030527C: sw          $a1, 0x10($a0)
    MEM_W(0X10, ctx->r4) = ctx->r5;
    // 0x80305280: sh          $t8, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r24;
    // 0x80305284: andi        $v1, $t8, 0xFFFF
    ctx->r3 = ctx->r24 & 0XFFFF;
L_80305288:
    // 0x80305288: blez        $v1, L_803052CC
    if (SIGNED(ctx->r3) <= 0) {
        // 0x8030528C: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_803052CC;
    }
    // 0x8030528C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x80305290: sll         $t9, $v0, 2
    ctx->r25 = S32(ctx->r2 << 2);
L_80305294:
    // 0x80305294: addu        $a3, $a0, $t9
    ctx->r7 = ADD32(ctx->r4, ctx->r25);
    // 0x80305298: lw          $t2, 0x10($a3)
    ctx->r10 = MEM_W(ctx->r7, 0X10);
    // 0x8030529C: beq         $a1, $t2, L_80305360
    if (ctx->r5 == ctx->r10) {
        // 0x803052A0: nop
    
            goto L_80305360;
    }
    // 0x803052A0: nop

    // 0x803052A4: lw          $t3, 0x4($a3)
    ctx->r11 = MEM_W(ctx->r7, 0X4);
    // 0x803052A8: slt         $at, $a2, $t3
    ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r11) ? 1 : 0;
    // 0x803052AC: bnel        $at, $zero, L_803052D0
    if (ctx->r1 != 0) {
        // 0x803052B0: lbu         $t0, 0xF($sp)
        ctx->r8 = MEM_BU(ctx->r29, 0XF);
            goto L_803052D0;
    }
    goto skip_0;
    // 0x803052B0: lbu         $t0, 0xF($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0XF);
    skip_0:
    // 0x803052B4: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x803052B8: sll         $t4, $v0, 16
    ctx->r12 = S32(ctx->r2 << 16);
    // 0x803052BC: sra         $v0, $t4, 16
    ctx->r2 = S32(SIGNED(ctx->r12) >> 16);
    // 0x803052C0: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x803052C4: bnel        $at, $zero, L_80305294
    if (ctx->r1 != 0) {
        // 0x803052C8: sll         $t9, $v0, 2
        ctx->r25 = S32(ctx->r2 << 2);
            goto L_80305294;
    }
    goto skip_1;
    // 0x803052C8: sll         $t9, $v0, 2
    ctx->r25 = S32(ctx->r2 << 2);
    skip_1:
L_803052CC:
    // 0x803052CC: lbu         $t0, 0xF($sp)
    ctx->r8 = MEM_BU(ctx->r29, 0XF);
L_803052D0:
    // 0x803052D0: slt         $at, $v0, $t0
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r8) ? 1 : 0;
    // 0x803052D4: beq         $at, $zero, L_80305360
    if (ctx->r1 == 0) {
        // 0x803052D8: nop
    
            goto L_80305360;
    }
    // 0x803052D8: nop

    // 0x803052DC: bne         $v0, $v1, L_80305304
    if (ctx->r2 != ctx->r3) {
        // 0x803052E0: addiu       $t1, $t0, -0x1
        ctx->r9 = ADD32(ctx->r8, -0X1);
            goto L_80305304;
    }
    // 0x803052E0: addiu       $t1, $t0, -0x1
    ctx->r9 = ADD32(ctx->r8, -0X1);
    // 0x803052E4: sll         $t6, $v0, 2
    ctx->r14 = S32(ctx->r2 << 2);
    // 0x803052E8: addu        $a3, $a0, $t6
    ctx->r7 = ADD32(ctx->r4, ctx->r14);
    // 0x803052EC: sw          $a2, 0x4($a3)
    MEM_W(0X4, ctx->r7) = ctx->r6;
    // 0x803052F0: sw          $a1, 0x10($a3)
    MEM_W(0X10, ctx->r7) = ctx->r5;
    // 0x803052F4: lhu         $t7, 0x0($a0)
    ctx->r15 = MEM_HU(ctx->r4, 0X0);
    // 0x803052F8: addiu       $t8, $t7, 0x1
    ctx->r24 = ADD32(ctx->r15, 0X1);
    // 0x803052FC: jr          $ra
    // 0x80305300: sh          $t8, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r24;
    return;
    // 0x80305300: sh          $t8, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r24;
L_80305304:
    // 0x80305304: slt         $at, $v0, $t1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r9) ? 1 : 0;
    // 0x80305308: beq         $at, $zero, L_8030533C
    if (ctx->r1 == 0) {
        // 0x8030530C: andi        $v1, $v0, 0xFF
        ctx->r3 = ctx->r2 & 0XFF;
            goto L_8030533C;
    }
    // 0x8030530C: andi        $v1, $v0, 0xFF
    ctx->r3 = ctx->r2 & 0XFF;
L_80305310:
    // 0x80305310: sll         $t9, $v0, 2
    ctx->r25 = S32(ctx->r2 << 2);
    // 0x80305314: addu        $a3, $a0, $t9
    ctx->r7 = ADD32(ctx->r4, ctx->r25);
    // 0x80305318: addiu       $v0, $v0, 0x1
    ctx->r2 = ADD32(ctx->r2, 0X1);
    // 0x8030531C: sll         $t4, $v0, 16
    ctx->r12 = S32(ctx->r2 << 16);
    // 0x80305320: lw          $t2, 0x10($a3)
    ctx->r10 = MEM_W(ctx->r7, 0X10);
    // 0x80305324: lw          $t3, 0x4($a3)
    ctx->r11 = MEM_W(ctx->r7, 0X4);
    // 0x80305328: sra         $v0, $t4, 16
    ctx->r2 = S32(SIGNED(ctx->r12) >> 16);
    // 0x8030532C: slt         $at, $v0, $t1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r9) ? 1 : 0;
    // 0x80305330: sw          $t2, 0x14($a3)
    MEM_W(0X14, ctx->r7) = ctx->r10;
    // 0x80305334: bne         $at, $zero, L_80305310
    if (ctx->r1 != 0) {
        // 0x80305338: sw          $t3, 0x8($a3)
        MEM_W(0X8, ctx->r7) = ctx->r11;
            goto L_80305310;
    }
    // 0x80305338: sw          $t3, 0x8($a3)
    MEM_W(0X8, ctx->r7) = ctx->r11;
L_8030533C:
    // 0x8030533C: sll         $t6, $v1, 2
    ctx->r14 = S32(ctx->r3 << 2);
    // 0x80305340: addu        $a3, $a0, $t6
    ctx->r7 = ADD32(ctx->r4, ctx->r14);
    // 0x80305344: sw          $a1, 0x10($a3)
    MEM_W(0X10, ctx->r7) = ctx->r5;
    // 0x80305348: sw          $a2, 0x4($a3)
    MEM_W(0X4, ctx->r7) = ctx->r6;
    // 0x8030534C: lhu         $v0, 0x0($a0)
    ctx->r2 = MEM_HU(ctx->r4, 0X0);
    // 0x80305350: slt         $at, $v0, $t0
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r8) ? 1 : 0;
    // 0x80305354: beq         $at, $zero, L_80305360
    if (ctx->r1 == 0) {
        // 0x80305358: addiu       $t7, $v0, 0x1
        ctx->r15 = ADD32(ctx->r2, 0X1);
            goto L_80305360;
    }
    // 0x80305358: addiu       $t7, $v0, 0x1
    ctx->r15 = ADD32(ctx->r2, 0X1);
    // 0x8030535C: sh          $t7, 0x0($a0)
    MEM_H(0X0, ctx->r4) = ctx->r15;
L_80305360:
    // 0x80305360: jr          $ra
    // 0x80305364: nop

    return;
    // 0x80305364: nop

;}
RECOMP_FUNC void func_80305368_716A18(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80305368: addiu       $sp, $sp, -0x88
    ctx->r29 = ADD32(ctx->r29, -0X88);
    // 0x8030536C: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x80305370: lw          $a2, 0x5524($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X5524);
    // 0x80305374: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x80305378: sw          $fp, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r30;
    // 0x8030537C: sw          $s7, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r23;
    // 0x80305380: sw          $s6, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r22;
    // 0x80305384: sw          $s5, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r21;
    // 0x80305388: sw          $s4, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r20;
    // 0x8030538C: sw          $s3, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r19;
    // 0x80305390: sw          $s2, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r18;
    // 0x80305394: sw          $s1, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r17;
    // 0x80305398: sw          $s0, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r16;
    // 0x8030539C: lhu         $t6, 0x9E($a2)
    ctx->r14 = MEM_HU(ctx->r6, 0X9E);
    // 0x803053A0: addiu       $at, $zero, 0x40
    ctx->r1 = ADD32(0, 0X40);
    // 0x803053A4: or          $s3, $a0, $zero
    ctx->r19 = ctx->r4 | 0;
    // 0x803053A8: beq         $t6, $at, L_803053BC
    if (ctx->r14 == ctx->r1) {
        // 0x803053AC: lui         $s7, 0x803D
        ctx->r23 = S32(0X803D << 16);
            goto L_803053BC;
    }
    // 0x803053AC: lui         $s7, 0x803D
    ctx->r23 = S32(0X803D << 16);
    // 0x803053B0: lhu         $t7, 0xA0($a2)
    ctx->r15 = MEM_HU(ctx->r6, 0XA0);
    // 0x803053B4: andi        $t8, $t7, 0x4
    ctx->r24 = ctx->r15 & 0X4;
    // 0x803053B8: beq         $t8, $zero, L_803053DC
    if (ctx->r24 == 0) {
        // 0x803053BC: addiu       $s7, $s7, 0x5530
        ctx->r23 = ADD32(ctx->r23, 0X5530);
            goto L_803053DC;
    }
L_803053BC:
    // 0x803053BC: addiu       $s7, $s7, 0x5530
    ctx->r23 = ADD32(ctx->r23, 0X5530);
    // 0x803053C0: lw          $v0, 0x0($s7)
    ctx->r2 = MEM_W(ctx->r23, 0X0);
    // 0x803053C4: lh          $v1, 0xC($v0)
    ctx->r3 = MEM_H(ctx->r2, 0XC);
    // 0x803053C8: addiu       $t9, $v1, 0x190
    ctx->r25 = ADD32(ctx->r3, 0X190);
    // 0x803053CC: addiu       $t5, $v1, -0x1F4
    ctx->r13 = ADD32(ctx->r3, -0X1F4);
    // 0x803053D0: sh          $t9, 0x58($sp)
    MEM_H(0X58, ctx->r29) = ctx->r25;
    // 0x803053D4: b           L_803053FC
    // 0x803053D8: sh          $t5, 0x56($sp)
    MEM_H(0X56, ctx->r29) = ctx->r13;
        goto L_803053FC;
    // 0x803053D8: sh          $t5, 0x56($sp)
    MEM_H(0X56, ctx->r29) = ctx->r13;
L_803053DC:
    // 0x803053DC: lui         $s7, 0x803D
    ctx->r23 = S32(0X803D << 16);
    // 0x803053E0: addiu       $s7, $s7, 0x5530
    ctx->r23 = ADD32(ctx->r23, 0X5530);
    // 0x803053E4: lw          $v0, 0x0($s7)
    ctx->r2 = MEM_W(ctx->r23, 0X0);
    // 0x803053E8: lh          $v1, 0xC($v0)
    ctx->r3 = MEM_H(ctx->r2, 0XC);
    // 0x803053EC: addiu       $t6, $v1, 0xC8
    ctx->r14 = ADD32(ctx->r3, 0XC8);
    // 0x803053F0: addiu       $t7, $v1, -0xC8
    ctx->r15 = ADD32(ctx->r3, -0XC8);
    // 0x803053F4: sh          $t6, 0x58($sp)
    MEM_H(0X58, ctx->r29) = ctx->r14;
    // 0x803053F8: sh          $t7, 0x56($sp)
    MEM_H(0X56, ctx->r29) = ctx->r15;
L_803053FC:
    // 0x803053FC: lh          $fp, 0x4($v0)
    ctx->r30 = MEM_H(ctx->r2, 0X4);
    // 0x80305400: lh          $t4, 0x8($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X8);
    // 0x80305404: addiu       $s6, $zero, 0x2
    ctx->r22 = ADD32(0, 0X2);
    // 0x80305408: sra         $v1, $fp, 6
    ctx->r3 = S32(SIGNED(ctx->r30) >> 6);
    // 0x8030540C: sll         $t8, $v1, 16
    ctx->r24 = S32(ctx->r3 << 16);
    // 0x80305410: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80305414: sra         $a1, $t4, 6
    ctx->r5 = S32(SIGNED(ctx->r12) >> 6);
    // 0x80305418: addiu       $a0, $t9, -0x1
    ctx->r4 = ADD32(ctx->r25, -0X1);
    // 0x8030541C: sll         $t6, $a1, 16
    ctx->r14 = S32(ctx->r5 << 16);
    // 0x80305420: sll         $t2, $a0, 16
    ctx->r10 = S32(ctx->r4 << 16);
    // 0x80305424: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80305428: sra         $t5, $t2, 16
    ctx->r13 = S32(SIGNED(ctx->r10) >> 16);
    // 0x8030542C: or          $t2, $t5, $zero
    ctx->r10 = ctx->r13 | 0;
    // 0x80305430: addiu       $t0, $t7, -0x1
    ctx->r8 = ADD32(ctx->r15, -0X1);
    // 0x80305434: addiu       $t1, $t7, 0x1
    ctx->r9 = ADD32(ctx->r15, 0X1);
    // 0x80305438: addiu       $a2, $t9, 0x1
    ctx->r6 = ADD32(ctx->r25, 0X1);
    // 0x8030543C: sll         $a3, $t0, 16
    ctx->r7 = S32(ctx->r8 << 16);
    // 0x80305440: sll         $t3, $t1, 16
    ctx->r11 = S32(ctx->r9 << 16);
    // 0x80305444: sll         $t5, $a0, 16
    ctx->r13 = S32(ctx->r4 << 16);
    // 0x80305448: sra         $t8, $a3, 16
    ctx->r24 = S32(SIGNED(ctx->r7) >> 16);
    // 0x8030544C: sra         $t9, $t3, 16
    ctx->r25 = S32(SIGNED(ctx->r11) >> 16);
    // 0x80305450: sra         $t6, $t5, 16
    ctx->r14 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80305454: sh          $a2, 0x84($sp)
    MEM_H(0X84, ctx->r29) = ctx->r6;
    // 0x80305458: or          $a3, $t8, $zero
    ctx->r7 = ctx->r24 | 0;
    // 0x8030545C: bgez        $t6, L_8030546C
    if (SIGNED(ctx->r14) >= 0) {
        // 0x80305460: or          $t3, $t9, $zero
        ctx->r11 = ctx->r25 | 0;
            goto L_8030546C;
    }
    // 0x80305460: or          $t3, $t9, $zero
    ctx->r11 = ctx->r25 | 0;
    // 0x80305464: b           L_80305484
    // 0x80305468: or          $t2, $zero, $zero
    ctx->r10 = 0 | 0;
        goto L_80305484;
    // 0x80305468: or          $t2, $zero, $zero
    ctx->r10 = 0 | 0;
L_8030546C:
    // 0x8030546C: sll         $t7, $a2, 16
    ctx->r15 = S32(ctx->r6 << 16);
    // 0x80305470: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80305474: slti        $at, $t8, 0x49
    ctx->r1 = SIGNED(ctx->r24) < 0X49 ? 1 : 0;
    // 0x80305478: bne         $at, $zero, L_80305484
    if (ctx->r1 != 0) {
        // 0x8030547C: addiu       $t9, $zero, 0x48
        ctx->r25 = ADD32(0, 0X48);
            goto L_80305484;
    }
    // 0x8030547C: addiu       $t9, $zero, 0x48
    ctx->r25 = ADD32(0, 0X48);
    // 0x80305480: sh          $t9, 0x84($sp)
    MEM_H(0X84, ctx->r29) = ctx->r25;
L_80305484:
    // 0x80305484: sll         $t5, $t0, 16
    ctx->r13 = S32(ctx->r8 << 16);
    // 0x80305488: sra         $t6, $t5, 16
    ctx->r14 = S32(SIGNED(ctx->r13) >> 16);
    // 0x8030548C: bgez        $t6, L_8030549C
    if (SIGNED(ctx->r14) >= 0) {
        // 0x80305490: sra         $t9, $t2, 4
        ctx->r25 = S32(SIGNED(ctx->r10) >> 4);
            goto L_8030549C;
    }
    // 0x80305490: sra         $t9, $t2, 4
    ctx->r25 = S32(SIGNED(ctx->r10) >> 4);
    // 0x80305494: b           L_803054B4
    // 0x80305498: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
        goto L_803054B4;
    // 0x80305498: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
L_8030549C:
    // 0x8030549C: sll         $t7, $t1, 16
    ctx->r15 = S32(ctx->r9 << 16);
    // 0x803054A0: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x803054A4: slti        $at, $t8, 0x81
    ctx->r1 = SIGNED(ctx->r24) < 0X81 ? 1 : 0;
    // 0x803054A8: bnel        $at, $zero, L_803054B8
    if (ctx->r1 != 0) {
        // 0x803054AC: lh          $t7, 0x84($sp)
        ctx->r15 = MEM_H(ctx->r29, 0X84);
            goto L_803054B8;
    }
    goto skip_0;
    // 0x803054AC: lh          $t7, 0x84($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X84);
    skip_0:
    // 0x803054B0: addiu       $t3, $zero, 0x80
    ctx->r11 = ADD32(0, 0X80);
L_803054B4:
    // 0x803054B4: lh          $t7, 0x84($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X84);
L_803054B8:
    // 0x803054B8: sll         $t5, $t9, 16
    ctx->r13 = S32(ctx->r25 << 16);
    // 0x803054BC: sra         $t2, $t5, 16
    ctx->r10 = S32(SIGNED(ctx->r13) >> 16);
    // 0x803054C0: sra         $t8, $t7, 4
    ctx->r24 = S32(SIGNED(ctx->r15) >> 4);
    // 0x803054C4: sh          $t8, 0x84($sp)
    MEM_H(0X84, ctx->r29) = ctx->r24;
    // 0x803054C8: sra         $t9, $a3, 4
    ctx->r25 = S32(SIGNED(ctx->r7) >> 4);
    // 0x803054CC: sra         $t7, $t3, 4
    ctx->r15 = S32(SIGNED(ctx->r11) >> 4);
    // 0x803054D0: sll         $t5, $t9, 16
    ctx->r13 = S32(ctx->r25 << 16);
    // 0x803054D4: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x803054D8: lui         $a0, 0x7FFF
    ctx->r4 = S32(0X7FFF << 16);
    // 0x803054DC: sra         $a3, $t5, 16
    ctx->r7 = S32(SIGNED(ctx->r13) >> 16);
    // 0x803054E0: sra         $t3, $t8, 16
    ctx->r11 = S32(SIGNED(ctx->r24) >> 16);
    // 0x803054E4: ori         $a0, $a0, 0xFFFF
    ctx->r4 = ctx->r4 | 0XFFFF;
    // 0x803054E8: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
L_803054EC:
    // 0x803054EC: sll         $t5, $v1, 2
    ctx->r13 = S32(ctx->r3 << 2);
    // 0x803054F0: addiu       $v1, $v1, 0x1
    ctx->r3 = ADD32(ctx->r3, 0X1);
    // 0x803054F4: sll         $t6, $v1, 16
    ctx->r14 = S32(ctx->r3 << 16);
    // 0x803054F8: sra         $v1, $t6, 16
    ctx->r3 = S32(SIGNED(ctx->r14) >> 16);
    // 0x803054FC: addu        $v0, $s3, $t5
    ctx->r2 = ADD32(ctx->r19, ctx->r13);
    // 0x80305500: slti        $at, $v1, 0x3
    ctx->r1 = SIGNED(ctx->r3) < 0X3 ? 1 : 0;
    // 0x80305504: sw          $a0, 0x3C($v0)
    MEM_W(0X3C, ctx->r2) = ctx->r4;
    // 0x80305508: sw          $a0, 0x20($v0)
    MEM_W(0X20, ctx->r2) = ctx->r4;
    // 0x8030550C: bne         $at, $zero, L_803054EC
    if (ctx->r1 != 0) {
        // 0x80305510: sw          $a0, 0x4($v0)
        MEM_W(0X4, ctx->r2) = ctx->r4;
            goto L_803054EC;
    }
    // 0x80305510: sw          $a0, 0x4($v0)
    MEM_W(0X4, ctx->r2) = ctx->r4;
    // 0x80305514: sh          $zero, 0x38($s3)
    MEM_H(0X38, ctx->r19) = 0;
    // 0x80305518: sh          $zero, 0x1C($s3)
    MEM_H(0X1C, ctx->r19) = 0;
    // 0x8030551C: sh          $zero, 0x0($s3)
    MEM_H(0X0, ctx->r19) = 0;
    // 0x80305520: sw          $a0, 0x5C($s3)
    MEM_W(0X5C, ctx->r19) = ctx->r4;
    // 0x80305524: sw          $a0, 0x54($s3)
    MEM_W(0X54, ctx->r19) = ctx->r4;
    // 0x80305528: sw          $zero, 0x58($s3)
    MEM_W(0X58, ctx->r19) = 0;
    // 0x8030552C: sw          $zero, 0x60($s3)
    MEM_W(0X60, ctx->r19) = 0;
    // 0x80305530: slt         $at, $t3, $a3
    ctx->r1 = SIGNED(ctx->r11) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x80305534: bne         $at, $zero, L_80305A40
    if (ctx->r1 != 0) {
        // 0x80305538: sh          $a3, 0x78($sp)
        MEM_H(0X78, ctx->r29) = ctx->r7;
            goto L_80305A40;
    }
    // 0x80305538: sh          $a3, 0x78($sp)
    MEM_H(0X78, ctx->r29) = ctx->r7;
    // 0x8030553C: lui         $s4, 0x803D
    ctx->r20 = S32(0X803D << 16);
    // 0x80305540: addiu       $s4, $s4, 0x552C
    ctx->r20 = ADD32(ctx->r20, 0X552C);
    // 0x80305544: sh          $t2, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r10;
    // 0x80305548: sh          $t3, 0x80($sp)
    MEM_H(0X80, ctx->r29) = ctx->r11;
    // 0x8030554C: sh          $t4, 0x60($sp)
    MEM_H(0X60, ctx->r29) = ctx->r12;
L_80305550:
    // 0x80305550: lh          $t8, 0x86($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X86);
    // 0x80305554: lh          $t9, 0x84($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X84);
    // 0x80305558: lh          $t5, 0x78($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X78);
    // 0x8030555C: sh          $t8, 0x7A($sp)
    MEM_H(0X7A, ctx->r29) = ctx->r24;
    // 0x80305560: slt         $at, $t9, $t8
    ctx->r1 = SIGNED(ctx->r25) < SIGNED(ctx->r24) ? 1 : 0;
    // 0x80305564: bne         $at, $zero, L_80305A20
    if (ctx->r1 != 0) {
        // 0x80305568: sll         $t6, $t5, 2
        ctx->r14 = S32(ctx->r13 << 2);
            goto L_80305A20;
    }
    // 0x80305568: sll         $t6, $t5, 2
    ctx->r14 = S32(ctx->r13 << 2);
    // 0x8030556C: addu        $t6, $t6, $t5
    ctx->r14 = ADD32(ctx->r14, ctx->r13);
    // 0x80305570: sw          $t6, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r14;
L_80305574:
    // 0x80305574: lh          $t7, 0x7A($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X7A);
    // 0x80305578: lw          $t9, 0x40($sp)
    ctx->r25 = MEM_W(ctx->r29, 0X40);
    // 0x8030557C: lui         $s5, 0x803E
    ctx->r21 = S32(0X803E << 16);
    // 0x80305580: addu        $t8, $t7, $t9
    ctx->r24 = ADD32(ctx->r15, ctx->r25);
    // 0x80305584: andi        $t5, $t8, 0xFFFF
    ctx->r13 = ctx->r24 & 0XFFFF;
    // 0x80305588: sll         $t6, $t5, 2
    ctx->r14 = S32(ctx->r13 << 2);
    // 0x8030558C: subu        $t6, $t6, $t5
    ctx->r14 = SUB32(ctx->r14, ctx->r13);
    // 0x80305590: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x80305594: addu        $s5, $s5, $t6
    ctx->r21 = ADD32(ctx->r21, ctx->r14);
    // 0x80305598: lw          $s5, -0x5EF0($s5)
    ctx->r21 = MEM_W(ctx->r21, -0X5EF0);
    // 0x8030559C: beql        $s5, $zero, L_80305A04
    if (ctx->r21 == 0) {
        // 0x803055A0: lh          $t9, 0x7A($sp)
        ctx->r25 = MEM_H(ctx->r29, 0X7A);
            goto L_80305A04;
    }
    goto skip_1;
    // 0x803055A0: lh          $t9, 0x7A($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X7A);
    skip_1:
    // 0x803055A4: lw          $s1, 0x8($s5)
    ctx->r17 = MEM_W(ctx->r21, 0X8);
L_803055A8:
    // 0x803055A8: lw          $v1, 0x16C($s1)
    ctx->r3 = MEM_W(ctx->r17, 0X16C);
    // 0x803055AC: lhu         $v0, 0x0($v1)
    ctx->r2 = MEM_HU(ctx->r3, 0X0);
    // 0x803055B0: slti        $at, $v0, 0x100
    ctx->r1 = SIGNED(ctx->r2) < 0X100 ? 1 : 0;
    // 0x803055B4: beql        $at, $zero, L_80305738
    if (ctx->r1 == 0) {
        // 0x803055B8: lw          $t9, 0x0($s7)
        ctx->r25 = MEM_W(ctx->r23, 0X0);
            goto L_80305738;
    }
    goto skip_2;
    // 0x803055B8: lw          $t9, 0x0($s7)
    ctx->r25 = MEM_W(ctx->r23, 0X0);
    skip_2:
    // 0x803055BC: lw          $t7, 0x80($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X80);
    // 0x803055C0: addiu       $at, $zero, 0x36
    ctx->r1 = ADD32(0, 0X36);
    // 0x803055C4: sll         $t8, $t7, 17
    ctx->r24 = S32(ctx->r15 << 17);
    // 0x803055C8: bltzl       $t8, L_803059F8
    if (SIGNED(ctx->r24) < 0) {
        // 0x803055CC: lw          $s5, 0x0($s5)
        ctx->r21 = MEM_W(ctx->r21, 0X0);
            goto L_803059F8;
    }
    goto skip_3;
    // 0x803055CC: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
    skip_3:
    // 0x803055D0: beq         $v0, $at, L_803059F4
    if (ctx->r2 == ctx->r1) {
        // 0x803055D4: addiu       $at, $zero, 0x37
        ctx->r1 = ADD32(0, 0X37);
            goto L_803059F4;
    }
    // 0x803055D4: addiu       $at, $zero, 0x37
    ctx->r1 = ADD32(0, 0X37);
    // 0x803055D8: beq         $v0, $at, L_803059F4
    if (ctx->r2 == ctx->r1) {
        // 0x803055DC: addiu       $at, $zero, 0x38
        ctx->r1 = ADD32(0, 0X38);
            goto L_803059F4;
    }
    // 0x803055DC: addiu       $at, $zero, 0x38
    ctx->r1 = ADD32(0, 0X38);
    // 0x803055E0: beql        $v0, $at, L_803059F8
    if (ctx->r2 == ctx->r1) {
        // 0x803055E4: lw          $s5, 0x0($s5)
        ctx->r21 = MEM_W(ctx->r21, 0X0);
            goto L_803059F8;
    }
    goto skip_4;
    // 0x803055E4: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
    skip_4:
    // 0x803055E8: lbu         $a1, 0x2($v1)
    ctx->r5 = MEM_BU(ctx->r3, 0X2);
    // 0x803055EC: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x803055F0: beq         $a1, $at, L_803059F4
    if (ctx->r5 == ctx->r1) {
        // 0x803055F4: addiu       $at, $zero, 0x9
        ctx->r1 = ADD32(0, 0X9);
            goto L_803059F4;
    }
    // 0x803055F4: addiu       $at, $zero, 0x9
    ctx->r1 = ADD32(0, 0X9);
    // 0x803055F8: beql        $a1, $at, L_803059F8
    if (ctx->r5 == ctx->r1) {
        // 0x803055FC: lw          $s5, 0x0($s5)
        ctx->r21 = MEM_W(ctx->r21, 0X0);
            goto L_803059F8;
    }
    goto skip_5;
    // 0x803055FC: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
    skip_5:
    // 0x80305600: lbu         $t5, 0x15($v1)
    ctx->r13 = MEM_BU(ctx->r3, 0X15);
    // 0x80305604: beql        $s6, $t5, L_803059F8
    if (ctx->r22 == ctx->r13) {
        // 0x80305608: lw          $s5, 0x0($s5)
        ctx->r21 = MEM_W(ctx->r21, 0X0);
            goto L_803059F8;
    }
    goto skip_6;
    // 0x80305608: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
    skip_6:
    // 0x8030560C: lw          $v0, 0x0($s4)
    ctx->r2 = MEM_W(ctx->r20, 0X0);
    // 0x80305610: lw          $t6, 0x2AC($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X2AC);
    // 0x80305614: beql        $s1, $t6, L_803059F8
    if (ctx->r17 == ctx->r14) {
        // 0x80305618: lw          $s5, 0x0($s5)
        ctx->r21 = MEM_W(ctx->r21, 0X0);
            goto L_803059F8;
    }
    goto skip_7;
    // 0x80305618: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
    skip_7:
    // 0x8030561C: lw          $t7, 0x320($v0)
    ctx->r15 = MEM_W(ctx->r2, 0X320);
    // 0x80305620: lh          $t5, 0x60($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X60);
    // 0x80305624: beql        $s1, $t7, L_803059F8
    if (ctx->r17 == ctx->r15) {
        // 0x80305628: lw          $s5, 0x0($s5)
        ctx->r21 = MEM_W(ctx->r21, 0X0);
            goto L_803059F8;
    }
    goto skip_8;
    // 0x80305628: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
    skip_8:
    // 0x8030562C: lh          $t9, 0x4($s1)
    ctx->r25 = MEM_H(ctx->r17, 0X4);
    // 0x80305630: lui         $a2, 0x803D
    ctx->r6 = S32(0X803D << 16);
    // 0x80305634: lw          $a2, 0x5524($a2)
    ctx->r6 = MEM_W(ctx->r6, 0X5524);
    // 0x80305638: subu        $v0, $t9, $fp
    ctx->r2 = SUB32(ctx->r25, ctx->r30);
    // 0x8030563C: bgez        $v0, L_8030564C
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80305640: lhu         $a3, 0xBE($a2)
        ctx->r7 = MEM_HU(ctx->r6, 0XBE);
            goto L_8030564C;
    }
    // 0x80305640: lhu         $a3, 0xBE($a2)
    ctx->r7 = MEM_HU(ctx->r6, 0XBE);
    // 0x80305644: b           L_80305650
    // 0x80305648: negu        $a0, $v0
    ctx->r4 = SUB32(0, ctx->r2);
        goto L_80305650;
    // 0x80305648: negu        $a0, $v0
    ctx->r4 = SUB32(0, ctx->r2);
L_8030564C:
    // 0x8030564C: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
L_80305650:
    // 0x80305650: lh          $t8, 0x8($s1)
    ctx->r24 = MEM_H(ctx->r17, 0X8);
    // 0x80305654: subu        $v0, $t8, $t5
    ctx->r2 = SUB32(ctx->r24, ctx->r13);
    // 0x80305658: bgez        $v0, L_80305668
    if (SIGNED(ctx->r2) >= 0) {
        // 0x8030565C: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_80305668;
    }
    // 0x8030565C: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x80305660: b           L_80305668
    // 0x80305664: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_80305668;
    // 0x80305664: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
L_80305668:
    // 0x80305668: addu        $t6, $v1, $a0
    ctx->r14 = ADD32(ctx->r3, ctx->r4);
    // 0x8030566C: bne         $s6, $a1, L_80305710
    if (ctx->r22 != ctx->r5) {
        // 0x80305670: subu        $s0, $t6, $a3
        ctx->r16 = SUB32(ctx->r14, ctx->r7);
            goto L_80305710;
    }
    // 0x80305670: subu        $s0, $t6, $a3
    ctx->r16 = SUB32(ctx->r14, ctx->r7);
    // 0x80305674: lhu         $v0, 0x9C($a2)
    ctx->r2 = MEM_HU(ctx->r6, 0X9C);
    // 0x80305678: addiu       $at, $zero, 0x20
    ctx->r1 = ADD32(0, 0X20);
    // 0x8030567C: beq         $v0, $at, L_803056A4
    if (ctx->r2 == ctx->r1) {
        // 0x80305680: addiu       $at, $zero, 0x26
        ctx->r1 = ADD32(0, 0X26);
            goto L_803056A4;
    }
    // 0x80305680: addiu       $at, $zero, 0x26
    ctx->r1 = ADD32(0, 0X26);
    // 0x80305684: beql        $v0, $at, L_803056A8
    if (ctx->r2 == ctx->r1) {
        // 0x80305688: lbu         $t7, 0x15C($s1)
        ctx->r15 = MEM_BU(ctx->r17, 0X15C);
            goto L_803056A8;
    }
    goto skip_9;
    // 0x80305688: lbu         $t7, 0x15C($s1)
    ctx->r15 = MEM_BU(ctx->r17, 0X15C);
    skip_9:
    // 0x8030568C: beq         $s6, $v0, L_803056A4
    if (ctx->r22 == ctx->r2) {
        // 0x80305690: addiu       $at, $zero, 0xD
        ctx->r1 = ADD32(0, 0XD);
            goto L_803056A4;
    }
    // 0x80305690: addiu       $at, $zero, 0xD
    ctx->r1 = ADD32(0, 0XD);
    // 0x80305694: beq         $v0, $at, L_803056A4
    if (ctx->r2 == ctx->r1) {
        // 0x80305698: addiu       $at, $zero, 0x27
        ctx->r1 = ADD32(0, 0X27);
            goto L_803056A4;
    }
    // 0x80305698: addiu       $at, $zero, 0x27
    ctx->r1 = ADD32(0, 0X27);
    // 0x8030569C: bne         $v0, $at, L_803056E4
    if (ctx->r2 != ctx->r1) {
        // 0x803056A0: addiu       $a0, $s3, 0x1C
        ctx->r4 = ADD32(ctx->r19, 0X1C);
            goto L_803056E4;
    }
    // 0x803056A0: addiu       $a0, $s3, 0x1C
    ctx->r4 = ADD32(ctx->r19, 0X1C);
L_803056A4:
    // 0x803056A4: lbu         $t7, 0x15C($s1)
    ctx->r15 = MEM_BU(ctx->r17, 0X15C);
L_803056A8:
    // 0x803056A8: addiu       $a0, $s3, 0x38
    ctx->r4 = ADD32(ctx->r19, 0X38);
    // 0x803056AC: slti        $at, $t7, 0x19
    ctx->r1 = SIGNED(ctx->r15) < 0X19 ? 1 : 0;
    // 0x803056B0: beql        $at, $zero, L_803059F8
    if (ctx->r1 == 0) {
        // 0x803056B4: lw          $s5, 0x0($s5)
        ctx->r21 = MEM_W(ctx->r21, 0X0);
            goto L_803059F8;
    }
    goto skip_10;
    // 0x803056B4: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
    skip_10:
    // 0x803056B8: lh          $t9, 0x30($s1)
    ctx->r25 = MEM_H(ctx->r17, 0X30);
    // 0x803056BC: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x803056C0: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
    // 0x803056C4: subu        $s0, $s0, $t9
    ctx->r16 = SUB32(ctx->r16, ctx->r25);
    // 0x803056C8: addiu       $s0, $s0, -0x64
    ctx->r16 = ADD32(ctx->r16, -0X64);
    // 0x803056CC: sll         $a2, $s0, 16
    ctx->r6 = S32(ctx->r16 << 16);
    // 0x803056D0: sra         $t8, $a2, 16
    ctx->r24 = S32(SIGNED(ctx->r6) >> 16);
    // 0x803056D4: jal         0x80305250
    // 0x803056D8: or          $a2, $t8, $zero
    ctx->r6 = ctx->r24 | 0;
    func_80305250_716900(rdram, ctx);
        goto after_0;
    // 0x803056D8: or          $a2, $t8, $zero
    ctx->r6 = ctx->r24 | 0;
    after_0:
    // 0x803056DC: b           L_803059F8
    // 0x803056E0: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
        goto L_803059F8;
    // 0x803056E0: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
L_803056E4:
    // 0x803056E4: lh          $t5, 0x30($s1)
    ctx->r13 = MEM_H(ctx->r17, 0X30);
    // 0x803056E8: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x803056EC: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
    // 0x803056F0: subu        $s0, $s0, $t5
    ctx->r16 = SUB32(ctx->r16, ctx->r13);
    // 0x803056F4: addiu       $s0, $s0, -0x64
    ctx->r16 = ADD32(ctx->r16, -0X64);
    // 0x803056F8: sll         $a2, $s0, 16
    ctx->r6 = S32(ctx->r16 << 16);
    // 0x803056FC: sra         $t6, $a2, 16
    ctx->r14 = S32(SIGNED(ctx->r6) >> 16);
    // 0x80305700: jal         0x80305250
    // 0x80305704: or          $a2, $t6, $zero
    ctx->r6 = ctx->r14 | 0;
    func_80305250_716900(rdram, ctx);
        goto after_1;
    // 0x80305704: or          $a2, $t6, $zero
    ctx->r6 = ctx->r14 | 0;
    after_1:
    // 0x80305708: b           L_803059F8
    // 0x8030570C: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
        goto L_803059F8;
    // 0x8030570C: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
L_80305710:
    // 0x80305710: sll         $a2, $s0, 16
    ctx->r6 = S32(ctx->r16 << 16);
    // 0x80305714: sra         $t7, $a2, 16
    ctx->r15 = S32(SIGNED(ctx->r6) >> 16);
    // 0x80305718: or          $a2, $t7, $zero
    ctx->r6 = ctx->r15 | 0;
    // 0x8030571C: addiu       $a0, $s3, 0x38
    ctx->r4 = ADD32(ctx->r19, 0X38);
    // 0x80305720: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x80305724: jal         0x80305250
    // 0x80305728: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
    func_80305250_716900(rdram, ctx);
        goto after_2;
    // 0x80305728: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
    after_2:
    // 0x8030572C: b           L_803059F8
    // 0x80305730: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
        goto L_803059F8;
    // 0x80305730: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
    // 0x80305734: lw          $t9, 0x0($s7)
    ctx->r25 = MEM_W(ctx->r23, 0X0);
L_80305738:
    // 0x80305738: addiu       $at, $zero, 0x13E
    ctx->r1 = ADD32(0, 0X13E);
    // 0x8030573C: beql        $s1, $t9, L_803059F8
    if (ctx->r17 == ctx->r25) {
        // 0x80305740: lw          $s5, 0x0($s5)
        ctx->r21 = MEM_W(ctx->r21, 0X0);
            goto L_803059F8;
    }
    goto skip_11;
    // 0x80305740: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
    skip_11:
    // 0x80305744: beq         $v0, $at, L_803059F4
    if (ctx->r2 == ctx->r1) {
        // 0x80305748: lh          $t8, 0x58($sp)
        ctx->r24 = MEM_H(ctx->r29, 0X58);
            goto L_803059F4;
    }
    // 0x80305748: lh          $t8, 0x58($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X58);
    // 0x8030574C: lh          $v0, 0xC($s1)
    ctx->r2 = MEM_H(ctx->r17, 0XC);
    // 0x80305750: lh          $t5, 0x56($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X56);
    // 0x80305754: slt         $at, $v0, $t8
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r24) ? 1 : 0;
    // 0x80305758: beq         $at, $zero, L_803059F4
    if (ctx->r1 == 0) {
        // 0x8030575C: slt         $at, $t5, $v0
        ctx->r1 = SIGNED(ctx->r13) < SIGNED(ctx->r2) ? 1 : 0;
            goto L_803059F4;
    }
    // 0x8030575C: slt         $at, $t5, $v0
    ctx->r1 = SIGNED(ctx->r13) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x80305760: beql        $at, $zero, L_803059F8
    if (ctx->r1 == 0) {
        // 0x80305764: lw          $s5, 0x0($s5)
        ctx->r21 = MEM_W(ctx->r21, 0X0);
            goto L_803059F8;
    }
    goto skip_12;
    // 0x80305764: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
    skip_12:
    // 0x80305768: jal         0x80362B00
    // 0x8030576C: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    func_80362B00_7741B0(rdram, ctx);
        goto after_3;
    // 0x8030576C: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    after_3:
    // 0x80305770: bne         $v0, $zero, L_80305798
    if (ctx->r2 != 0) {
        // 0x80305774: nop
    
            goto L_80305798;
    }
    // 0x80305774: nop

    // 0x80305778: jal         0x80362B38
    // 0x8030577C: lw          $a0, 0x0($s7)
    ctx->r4 = MEM_W(ctx->r23, 0X0);
    can_swim(rdram, ctx);
        goto after_4;
    // 0x8030577C: lw          $a0, 0x0($s7)
    ctx->r4 = MEM_W(ctx->r23, 0X0);
    after_4:
    // 0x80305780: beql        $v0, $zero, L_803057A4
    if (ctx->r2 == 0) {
        // 0x80305784: lw          $t6, 0x0($s7)
        ctx->r14 = MEM_W(ctx->r23, 0X0);
            goto L_803057A4;
    }
    goto skip_13;
    // 0x80305784: lw          $t6, 0x0($s7)
    ctx->r14 = MEM_W(ctx->r23, 0X0);
    skip_13:
    // 0x80305788: jal         0x80362B60
    // 0x8030578C: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    func_80362B60_774210(rdram, ctx);
        goto after_5;
    // 0x8030578C: or          $a0, $s1, $zero
    ctx->r4 = ctx->r17 | 0;
    after_5:
    // 0x80305790: bnel        $v0, $zero, L_803057A4
    if (ctx->r2 != 0) {
        // 0x80305794: lw          $t6, 0x0($s7)
        ctx->r14 = MEM_W(ctx->r23, 0X0);
            goto L_803057A4;
    }
    goto skip_14;
    // 0x80305794: lw          $t6, 0x0($s7)
    ctx->r14 = MEM_W(ctx->r23, 0X0);
    skip_14:
L_80305798:
    // 0x80305798: b           L_803057BC
    // 0x8030579C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
        goto L_803057BC;
    // 0x8030579C: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x803057A0: lw          $t6, 0x0($s7)
    ctx->r14 = MEM_W(ctx->r23, 0X0);
L_803057A4:
    // 0x803057A4: lw          $t9, 0x16C($s1)
    ctx->r25 = MEM_W(ctx->r17, 0X16C);
    // 0x803057A8: lw          $t7, 0x16C($t6)
    ctx->r15 = MEM_W(ctx->r14, 0X16C);
    // 0x803057AC: lhu         $a1, 0x0($t9)
    ctx->r5 = MEM_HU(ctx->r25, 0X0);
    // 0x803057B0: jal         0x802EA3E0
    // 0x803057B4: lhu         $a0, 0x0($t7)
    ctx->r4 = MEM_HU(ctx->r15, 0X0);
    get_ai_behaviour(rdram, ctx);
        goto after_6;
    // 0x803057B4: lhu         $a0, 0x0($t7)
    ctx->r4 = MEM_HU(ctx->r15, 0X0);
    after_6:
    // 0x803057B8: andi        $a1, $v0, 0xFF
    ctx->r5 = ctx->r2 & 0XFF;
L_803057BC:
    // 0x803057BC: lh          $t8, 0x4($s1)
    ctx->r24 = MEM_H(ctx->r17, 0X4);
    // 0x803057C0: lh          $t6, 0x60($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X60);
    // 0x803057C4: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x803057C8: subu        $v0, $t8, $fp
    ctx->r2 = SUB32(ctx->r24, ctx->r30);
    // 0x803057CC: bgez        $v0, L_803057DC
    if (SIGNED(ctx->r2) >= 0) {
        // 0x803057D0: sltiu       $at, $a1, 0x9
        ctx->r1 = ctx->r5 < 0X9 ? 1 : 0;
            goto L_803057DC;
    }
    // 0x803057D0: sltiu       $at, $a1, 0x9
    ctx->r1 = ctx->r5 < 0X9 ? 1 : 0;
    // 0x803057D4: b           L_803057E0
    // 0x803057D8: negu        $a0, $v0
    ctx->r4 = SUB32(0, ctx->r2);
        goto L_803057E0;
    // 0x803057D8: negu        $a0, $v0
    ctx->r4 = SUB32(0, ctx->r2);
L_803057DC:
    // 0x803057DC: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
L_803057E0:
    // 0x803057E0: lh          $t5, 0x8($s1)
    ctx->r13 = MEM_H(ctx->r17, 0X8);
    // 0x803057E4: subu        $v0, $t5, $t6
    ctx->r2 = SUB32(ctx->r13, ctx->r14);
    // 0x803057E8: bgez        $v0, L_803057F8
    if (SIGNED(ctx->r2) >= 0) {
        // 0x803057EC: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_803057F8;
    }
    // 0x803057EC: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x803057F0: b           L_803057F8
    // 0x803057F4: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_803057F8;
    // 0x803057F4: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
L_803057F8:
    // 0x803057F8: lw          $t9, 0x5524($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5524);
    // 0x803057FC: lw          $t5, 0x16C($s1)
    ctx->r13 = MEM_W(ctx->r17, 0X16C);
    // 0x80305800: addu        $t7, $v1, $a0
    ctx->r15 = ADD32(ctx->r3, ctx->r4);
    // 0x80305804: lhu         $t8, 0xBE($t9)
    ctx->r24 = MEM_HU(ctx->r25, 0XBE);
    // 0x80305808: lhu         $t6, 0xBE($t5)
    ctx->r14 = MEM_HU(ctx->r13, 0XBE);
    // 0x8030580C: sll         $t9, $a1, 2
    ctx->r25 = S32(ctx->r5 << 2);
    // 0x80305810: subu        $s0, $t7, $t8
    ctx->r16 = SUB32(ctx->r15, ctx->r24);
    // 0x80305814: subu        $s0, $s0, $t6
    ctx->r16 = SUB32(ctx->r16, ctx->r14);
    // 0x80305818: bgez        $s0, L_80305824
    if (SIGNED(ctx->r16) >= 0) {
        // 0x8030581C: nop
    
            goto L_80305824;
    }
    // 0x8030581C: nop

    // 0x80305820: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
L_80305824:
    // 0x80305824: beq         $at, $zero, L_803059F4
    if (ctx->r1 == 0) {
        // 0x80305828: lui         $at, 0x803C
        ctx->r1 = S32(0X803C << 16);
            goto L_803059F4;
    }
    // 0x80305828: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8030582C: addu        $at, $at, $t9
    gpr jr_addend_80305834 = ctx->r25;
    ctx->r1 = ADD32(ctx->r1, ctx->r25);
    // 0x80305830: lw          $t9, -0x2FF0($at)
    ctx->r25 = ADD32(ctx->r1, -0X2FF0);
    // 0x80305834: jr          $t9
    // 0x80305838: nop

    switch (jr_addend_80305834 >> 2) {
        case 0: goto L_8030583C; break;
        case 1: goto L_80305860; break;
        case 2: goto L_803058B4; break;
        case 3: goto L_80305904; break;
        case 4: goto L_80305928; break;
        case 5: goto L_80305980; break;
        case 6: goto L_803059D4; break;
        case 7: goto L_803059F4; break;
        case 8: goto L_803059F4; break;
        default: switch_error(__func__, 0x80305834, 0x803BD010);
    }
    // 0x80305838: nop

L_8030583C:
    // 0x8030583C: sll         $a2, $s0, 16
    ctx->r6 = S32(ctx->r16 << 16);
    // 0x80305840: sra         $t7, $a2, 16
    ctx->r15 = S32(SIGNED(ctx->r6) >> 16);
    // 0x80305844: or          $a2, $t7, $zero
    ctx->r6 = ctx->r15 | 0;
    // 0x80305848: addiu       $a0, $s3, 0x38
    ctx->r4 = ADD32(ctx->r19, 0X38);
    // 0x8030584C: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x80305850: jal         0x80305250
    // 0x80305854: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
    func_80305250_716900(rdram, ctx);
        goto after_7;
    // 0x80305854: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
    after_7:
    // 0x80305858: b           L_803059F8
    // 0x8030585C: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
        goto L_803059F8;
    // 0x8030585C: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
L_80305860:
    // 0x80305860: lw          $t8, 0x0($s4)
    ctx->r24 = MEM_W(ctx->r20, 0X0);
    // 0x80305864: sll         $a2, $s0, 16
    ctx->r6 = S32(ctx->r16 << 16);
    // 0x80305868: addiu       $s2, $s3, 0x38
    ctx->r18 = ADD32(ctx->r19, 0X38);
    // 0x8030586C: lhu         $t5, 0x272($t8)
    ctx->r13 = MEM_HU(ctx->r24, 0X272);
    // 0x80305870: sra         $t9, $a2, 16
    ctx->r25 = S32(SIGNED(ctx->r6) >> 16);
    // 0x80305874: addiu       $a0, $s3, 0x1C
    ctx->r4 = ADD32(ctx->r19, 0X1C);
    // 0x80305878: andi        $t6, $t5, 0x4
    ctx->r14 = ctx->r13 & 0X4;
    // 0x8030587C: beq         $t6, $zero, L_80305890
    if (ctx->r14 == 0) {
        // 0x80305880: or          $a1, $s1, $zero
        ctx->r5 = ctx->r17 | 0;
            goto L_80305890;
    }
    // 0x80305880: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x80305884: or          $a2, $t9, $zero
    ctx->r6 = ctx->r25 | 0;
    // 0x80305888: jal         0x80305250
    // 0x8030588C: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
    func_80305250_716900(rdram, ctx);
        goto after_8;
    // 0x8030588C: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
    after_8:
L_80305890:
    // 0x80305890: sll         $a2, $s0, 16
    ctx->r6 = S32(ctx->r16 << 16);
    // 0x80305894: sra         $t7, $a2, 16
    ctx->r15 = S32(SIGNED(ctx->r6) >> 16);
    // 0x80305898: or          $a2, $t7, $zero
    ctx->r6 = ctx->r15 | 0;
    // 0x8030589C: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    // 0x803058A0: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x803058A4: jal         0x80305250
    // 0x803058A8: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
    func_80305250_716900(rdram, ctx);
        goto after_9;
    // 0x803058A8: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
    after_9:
    // 0x803058AC: b           L_803059F8
    // 0x803058B0: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
        goto L_803059F8;
    // 0x803058B0: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
L_803058B4:
    // 0x803058B4: lw          $t8, 0x0($s4)
    ctx->r24 = MEM_W(ctx->r20, 0X0);
    // 0x803058B8: sll         $a2, $s0, 16
    ctx->r6 = S32(ctx->r16 << 16);
    // 0x803058BC: sra         $t7, $a2, 16
    ctx->r15 = S32(SIGNED(ctx->r6) >> 16);
    // 0x803058C0: lhu         $t5, 0x272($t8)
    ctx->r13 = MEM_HU(ctx->r24, 0X272);
    // 0x803058C4: or          $a2, $t7, $zero
    ctx->r6 = ctx->r15 | 0;
    // 0x803058C8: addiu       $a0, $s3, 0x38
    ctx->r4 = ADD32(ctx->r19, 0X38);
    // 0x803058CC: andi        $t6, $t5, 0x1
    ctx->r14 = ctx->r13 & 0X1;
    // 0x803058D0: beq         $t6, $zero, L_803058F4
    if (ctx->r14 == 0) {
        // 0x803058D4: or          $a1, $s1, $zero
        ctx->r5 = ctx->r17 | 0;
            goto L_803058F4;
    }
    // 0x803058D4: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x803058D8: lw          $t9, 0x54($s3)
    ctx->r25 = MEM_W(ctx->r19, 0X54);
    // 0x803058DC: slt         $at, $s0, $t9
    ctx->r1 = SIGNED(ctx->r16) < SIGNED(ctx->r25) ? 1 : 0;
    // 0x803058E0: beql        $at, $zero, L_803059F8
    if (ctx->r1 == 0) {
        // 0x803058E4: lw          $s5, 0x0($s5)
        ctx->r21 = MEM_W(ctx->r21, 0X0);
            goto L_803059F8;
    }
    goto skip_15;
    // 0x803058E4: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
    skip_15:
    // 0x803058E8: sw          $s0, 0x54($s3)
    MEM_W(0X54, ctx->r19) = ctx->r16;
    // 0x803058EC: b           L_803059F4
    // 0x803058F0: sw          $s1, 0x58($s3)
    MEM_W(0X58, ctx->r19) = ctx->r17;
        goto L_803059F4;
    // 0x803058F0: sw          $s1, 0x58($s3)
    MEM_W(0X58, ctx->r19) = ctx->r17;
L_803058F4:
    // 0x803058F4: jal         0x80305250
    // 0x803058F8: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
    func_80305250_716900(rdram, ctx);
        goto after_10;
    // 0x803058F8: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
    after_10:
    // 0x803058FC: b           L_803059F8
    // 0x80305900: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
        goto L_803059F8;
    // 0x80305900: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
L_80305904:
    // 0x80305904: sll         $a2, $s0, 16
    ctx->r6 = S32(ctx->r16 << 16);
    // 0x80305908: sra         $t8, $a2, 16
    ctx->r24 = S32(SIGNED(ctx->r6) >> 16);
    // 0x8030590C: or          $a2, $t8, $zero
    ctx->r6 = ctx->r24 | 0;
    // 0x80305910: addiu       $a0, $s3, 0x38
    ctx->r4 = ADD32(ctx->r19, 0X38);
    // 0x80305914: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x80305918: jal         0x80305250
    // 0x8030591C: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
    func_80305250_716900(rdram, ctx);
        goto after_11;
    // 0x8030591C: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
    after_11:
    // 0x80305920: b           L_803059F8
    // 0x80305924: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
        goto L_803059F8;
    // 0x80305924: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
L_80305928:
    // 0x80305928: lw          $t5, 0x0($s4)
    ctx->r13 = MEM_W(ctx->r20, 0X0);
    // 0x8030592C: sll         $a2, $s0, 16
    ctx->r6 = S32(ctx->r16 << 16);
    // 0x80305930: sra         $t8, $a2, 16
    ctx->r24 = S32(SIGNED(ctx->r6) >> 16);
    // 0x80305934: lhu         $t6, 0x272($t5)
    ctx->r14 = MEM_HU(ctx->r13, 0X272);
    // 0x80305938: or          $a2, $t8, $zero
    ctx->r6 = ctx->r24 | 0;
    // 0x8030593C: addiu       $a0, $s3, 0x38
    ctx->r4 = ADD32(ctx->r19, 0X38);
    // 0x80305940: andi        $t9, $t6, 0x8
    ctx->r25 = ctx->r14 & 0X8;
    // 0x80305944: beq         $t9, $zero, L_80305970
    if (ctx->r25 == 0) {
        // 0x80305948: or          $a1, $s1, $zero
        ctx->r5 = ctx->r17 | 0;
            goto L_80305970;
    }
    // 0x80305948: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x8030594C: sll         $a2, $s0, 16
    ctx->r6 = S32(ctx->r16 << 16);
    // 0x80305950: sra         $t7, $a2, 16
    ctx->r15 = S32(SIGNED(ctx->r6) >> 16);
    // 0x80305954: or          $a2, $t7, $zero
    ctx->r6 = ctx->r15 | 0;
    // 0x80305958: or          $a0, $s3, $zero
    ctx->r4 = ctx->r19 | 0;
    // 0x8030595C: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x80305960: jal         0x80305250
    // 0x80305964: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
    func_80305250_716900(rdram, ctx);
        goto after_12;
    // 0x80305964: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
    after_12:
    // 0x80305968: b           L_803059F8
    // 0x8030596C: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
        goto L_803059F8;
    // 0x8030596C: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
L_80305970:
    // 0x80305970: jal         0x80305250
    // 0x80305974: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
    func_80305250_716900(rdram, ctx);
        goto after_13;
    // 0x80305974: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
    after_13:
    // 0x80305978: b           L_803059F8
    // 0x8030597C: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
        goto L_803059F8;
    // 0x8030597C: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
L_80305980:
    // 0x80305980: lw          $t5, 0x0($s4)
    ctx->r13 = MEM_W(ctx->r20, 0X0);
    // 0x80305984: sll         $a2, $s0, 16
    ctx->r6 = S32(ctx->r16 << 16);
    // 0x80305988: sra         $t8, $a2, 16
    ctx->r24 = S32(SIGNED(ctx->r6) >> 16);
    // 0x8030598C: lhu         $t6, 0x272($t5)
    ctx->r14 = MEM_HU(ctx->r13, 0X272);
    // 0x80305990: or          $a2, $t8, $zero
    ctx->r6 = ctx->r24 | 0;
    // 0x80305994: addiu       $a0, $s3, 0x38
    ctx->r4 = ADD32(ctx->r19, 0X38);
    // 0x80305998: andi        $t9, $t6, 0x8
    ctx->r25 = ctx->r14 & 0X8;
    // 0x8030599C: beq         $t9, $zero, L_803059C4
    if (ctx->r25 == 0) {
        // 0x803059A0: or          $a1, $s1, $zero
        ctx->r5 = ctx->r17 | 0;
            goto L_803059C4;
    }
    // 0x803059A0: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x803059A4: lw          $t7, 0x5C($s3)
    ctx->r15 = MEM_W(ctx->r19, 0X5C);
    // 0x803059A8: slt         $at, $s0, $t7
    ctx->r1 = SIGNED(ctx->r16) < SIGNED(ctx->r15) ? 1 : 0;
    // 0x803059AC: beql        $at, $zero, L_803059F8
    if (ctx->r1 == 0) {
        // 0x803059B0: lw          $s5, 0x0($s5)
        ctx->r21 = MEM_W(ctx->r21, 0X0);
            goto L_803059F8;
    }
    goto skip_16;
    // 0x803059B0: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
    skip_16:
    // 0x803059B4: sw          $s0, 0x5C($s3)
    MEM_W(0X5C, ctx->r19) = ctx->r16;
    // 0x803059B8: sw          $s1, 0x60($s3)
    MEM_W(0X60, ctx->r19) = ctx->r17;
    // 0x803059BC: b           L_803059F4
    // 0x803059C0: sb          $zero, 0x64($s3)
    MEM_B(0X64, ctx->r19) = 0;
        goto L_803059F4;
    // 0x803059C0: sb          $zero, 0x64($s3)
    MEM_B(0X64, ctx->r19) = 0;
L_803059C4:
    // 0x803059C4: jal         0x80305250
    // 0x803059C8: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
    func_80305250_716900(rdram, ctx);
        goto after_14;
    // 0x803059C8: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
    after_14:
    // 0x803059CC: b           L_803059F8
    // 0x803059D0: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
        goto L_803059F8;
    // 0x803059D0: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
L_803059D4:
    // 0x803059D4: lw          $t5, 0x5C($s3)
    ctx->r13 = MEM_W(ctx->r19, 0X5C);
    // 0x803059D8: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x803059DC: slt         $at, $s0, $t5
    ctx->r1 = SIGNED(ctx->r16) < SIGNED(ctx->r13) ? 1 : 0;
    // 0x803059E0: beql        $at, $zero, L_803059F8
    if (ctx->r1 == 0) {
        // 0x803059E4: lw          $s5, 0x0($s5)
        ctx->r21 = MEM_W(ctx->r21, 0X0);
            goto L_803059F8;
    }
    goto skip_17;
    // 0x803059E4: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
    skip_17:
    // 0x803059E8: sw          $s0, 0x5C($s3)
    MEM_W(0X5C, ctx->r19) = ctx->r16;
    // 0x803059EC: sw          $s1, 0x60($s3)
    MEM_W(0X60, ctx->r19) = ctx->r17;
    // 0x803059F0: sb          $t6, 0x64($s3)
    MEM_B(0X64, ctx->r19) = ctx->r14;
L_803059F4:
    // 0x803059F4: lw          $s5, 0x0($s5)
    ctx->r21 = MEM_W(ctx->r21, 0X0);
L_803059F8:
    // 0x803059F8: bnel        $s5, $zero, L_803055A8
    if (ctx->r21 != 0) {
        // 0x803059FC: lw          $s1, 0x8($s5)
        ctx->r17 = MEM_W(ctx->r21, 0X8);
            goto L_803055A8;
    }
    goto skip_18;
    // 0x803059FC: lw          $s1, 0x8($s5)
    ctx->r17 = MEM_W(ctx->r21, 0X8);
    skip_18:
    // 0x80305A00: lh          $t9, 0x7A($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X7A);
L_80305A04:
    // 0x80305A04: lh          $t8, 0x84($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X84);
    // 0x80305A08: addiu       $t7, $t9, 0x1
    ctx->r15 = ADD32(ctx->r25, 0X1);
    // 0x80305A0C: sll         $t5, $t7, 16
    ctx->r13 = S32(ctx->r15 << 16);
    // 0x80305A10: sra         $t6, $t5, 16
    ctx->r14 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80305A14: slt         $at, $t8, $t6
    ctx->r1 = SIGNED(ctx->r24) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x80305A18: beq         $at, $zero, L_80305574
    if (ctx->r1 == 0) {
        // 0x80305A1C: sh          $t7, 0x7A($sp)
        MEM_H(0X7A, ctx->r29) = ctx->r15;
            goto L_80305574;
    }
    // 0x80305A1C: sh          $t7, 0x7A($sp)
    MEM_H(0X7A, ctx->r29) = ctx->r15;
L_80305A20:
    // 0x80305A20: lh          $t9, 0x78($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X78);
    // 0x80305A24: lh          $t5, 0x80($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X80);
    // 0x80305A28: addiu       $t7, $t9, 0x1
    ctx->r15 = ADD32(ctx->r25, 0X1);
    // 0x80305A2C: sll         $t8, $t7, 16
    ctx->r24 = S32(ctx->r15 << 16);
    // 0x80305A30: sra         $t6, $t8, 16
    ctx->r14 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80305A34: slt         $at, $t5, $t6
    ctx->r1 = SIGNED(ctx->r13) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x80305A38: beq         $at, $zero, L_80305550
    if (ctx->r1 == 0) {
        // 0x80305A3C: sh          $t7, 0x78($sp)
        MEM_H(0X78, ctx->r29) = ctx->r15;
            goto L_80305550;
    }
    // 0x80305A3C: sh          $t7, 0x78($sp)
    MEM_H(0X78, ctx->r29) = ctx->r15;
L_80305A40:
    // 0x80305A40: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    // 0x80305A44: lw          $s0, 0x18($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X18);
    // 0x80305A48: lw          $s1, 0x1C($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X1C);
    // 0x80305A4C: lw          $s2, 0x20($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X20);
    // 0x80305A50: lw          $s3, 0x24($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X24);
    // 0x80305A54: lw          $s4, 0x28($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X28);
    // 0x80305A58: lw          $s5, 0x2C($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X2C);
    // 0x80305A5C: lw          $s6, 0x30($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X30);
    // 0x80305A60: lw          $s7, 0x34($sp)
    ctx->r23 = MEM_W(ctx->r29, 0X34);
    // 0x80305A64: lw          $fp, 0x38($sp)
    ctx->r30 = MEM_W(ctx->r29, 0X38);
    // 0x80305A68: jr          $ra
    // 0x80305A6C: addiu       $sp, $sp, 0x88
    ctx->r29 = ADD32(ctx->r29, 0X88);
    return;
    // 0x80305A6C: addiu       $sp, $sp, 0x88
    ctx->r29 = ADD32(ctx->r29, 0X88);
;}
RECOMP_FUNC void func_80305A70_717120(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80305A70: addiu       $sp, $sp, -0x50
    ctx->r29 = ADD32(ctx->r29, -0X50);
    // 0x80305A74: lbu         $v0, 0x63($sp)
    ctx->r2 = MEM_BU(ctx->r29, 0X63);
    // 0x80305A78: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80305A7C: sw          $a0, 0x50($sp)
    MEM_W(0X50, ctx->r29) = ctx->r4;
    // 0x80305A80: sw          $a1, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r5;
    // 0x80305A84: sw          $a2, 0x58($sp)
    MEM_W(0X58, ctx->r29) = ctx->r6;
    // 0x80305A88: beq         $v0, $zero, L_80305ABC
    if (ctx->r2 == 0) {
        // 0x80305A8C: sw          $a3, 0x5C($sp)
        MEM_W(0X5C, ctx->r29) = ctx->r7;
            goto L_80305ABC;
    }
    // 0x80305A8C: sw          $a3, 0x5C($sp)
    MEM_W(0X5C, ctx->r29) = ctx->r7;
    // 0x80305A90: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80305A94: beq         $v0, $at, L_80305AD0
    if (ctx->r2 == ctx->r1) {
        // 0x80305A98: addiu       $a3, $zero, 0x2
        ctx->r7 = ADD32(0, 0X2);
            goto L_80305AD0;
    }
    // 0x80305A98: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
    // 0x80305A9C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80305AA0: beq         $v0, $at, L_80305AE0
    if (ctx->r2 == ctx->r1) {
        // 0x80305AA4: addiu       $a3, $zero, 0x2
        ctx->r7 = ADD32(0, 0X2);
            goto L_80305AE0;
    }
    // 0x80305AA4: addiu       $a3, $zero, 0x2
    ctx->r7 = ADD32(0, 0X2);
    // 0x80305AA8: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80305AAC: beq         $v0, $at, L_80305AEC
    if (ctx->r2 == ctx->r1) {
        // 0x80305AB0: addiu       $t6, $zero, 0x3
        ctx->r14 = ADD32(0, 0X3);
            goto L_80305AEC;
    }
    // 0x80305AB0: addiu       $t6, $zero, 0x3
    ctx->r14 = ADD32(0, 0X3);
    // 0x80305AB4: b           L_80305AF8
    // 0x80305AB8: lbu         $v0, 0x63($sp)
    ctx->r2 = MEM_BU(ctx->r29, 0X63);
        goto L_80305AF8;
    // 0x80305AB8: lbu         $v0, 0x63($sp)
    ctx->r2 = MEM_BU(ctx->r29, 0X63);
L_80305ABC:
    // 0x80305ABC: addiu       $a3, $zero, 0x3
    ctx->r7 = ADD32(0, 0X3);
    // 0x80305AC0: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
    // 0x80305AC4: sb          $t1, 0x4E($sp)
    MEM_B(0X4E, ctx->r29) = ctx->r9;
    // 0x80305AC8: b           L_80305AF4
    // 0x80305ACC: sb          $a3, 0x4F($sp)
    MEM_B(0X4F, ctx->r29) = ctx->r7;
        goto L_80305AF4;
    // 0x80305ACC: sb          $a3, 0x4F($sp)
    MEM_B(0X4F, ctx->r29) = ctx->r7;
L_80305AD0:
    // 0x80305AD0: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
    // 0x80305AD4: sb          $t1, 0x4E($sp)
    MEM_B(0X4E, ctx->r29) = ctx->r9;
    // 0x80305AD8: b           L_80305AF4
    // 0x80305ADC: sb          $a3, 0x4F($sp)
    MEM_B(0X4F, ctx->r29) = ctx->r7;
        goto L_80305AF4;
    // 0x80305ADC: sb          $a3, 0x4F($sp)
    MEM_B(0X4F, ctx->r29) = ctx->r7;
L_80305AE0:
    // 0x80305AE0: sb          $a3, 0x4F($sp)
    MEM_B(0X4F, ctx->r29) = ctx->r7;
    // 0x80305AE4: b           L_80305AF4
    // 0x80305AE8: sb          $zero, 0x4E($sp)
    MEM_B(0X4E, ctx->r29) = 0;
        goto L_80305AF4;
    // 0x80305AE8: sb          $zero, 0x4E($sp)
    MEM_B(0X4E, ctx->r29) = 0;
L_80305AEC:
    // 0x80305AEC: sb          $t6, 0x4F($sp)
    MEM_B(0X4F, ctx->r29) = ctx->r14;
    // 0x80305AF0: sb          $zero, 0x4E($sp)
    MEM_B(0X4E, ctx->r29) = 0;
L_80305AF4:
    // 0x80305AF4: lbu         $v0, 0x63($sp)
    ctx->r2 = MEM_BU(ctx->r29, 0X63);
L_80305AF8:
    // 0x80305AF8: lui         $t8, 0x803A
    ctx->r24 = S32(0X803A << 16);
    // 0x80305AFC: lh          $t9, 0x5E($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X5E);
    // 0x80305B00: sll         $t7, $v0, 1
    ctx->r15 = S32(ctx->r2 << 1);
    // 0x80305B04: addu        $t8, $t8, $t7
    ctx->r24 = ADD32(ctx->r24, ctx->r15);
    // 0x80305B08: lh          $t8, 0x5560($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X5560);
    // 0x80305B0C: lui         $t4, 0x803A
    ctx->r12 = S32(0X803A << 16);
    // 0x80305B10: addu        $t4, $t4, $t7
    ctx->r12 = ADD32(ctx->r12, ctx->r15);
    // 0x80305B14: multu       $t8, $t9
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80305B18: lh          $t4, 0x5568($t4)
    ctx->r12 = MEM_H(ctx->r12, 0X5568);
    // 0x80305B1C: lh          $t7, 0x52($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X52);
    // 0x80305B20: lh          $t8, 0x56($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X56);
    // 0x80305B24: mflo        $v1
    ctx->r3 = lo;
    // 0x80305B28: sll         $t2, $v1, 16
    ctx->r10 = S32(ctx->r3 << 16);
    // 0x80305B2C: sra         $t3, $t2, 16
    ctx->r11 = S32(SIGNED(ctx->r10) >> 16);
    // 0x80305B30: multu       $t4, $t9
    result = U64(U32(ctx->r12)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80305B34: addu        $a2, $t7, $t3
    ctx->r6 = ADD32(ctx->r15, ctx->r11);
    // 0x80305B38: sra         $t2, $a2, 6
    ctx->r10 = S32(SIGNED(ctx->r6) >> 6);
    // 0x80305B3C: sll         $t3, $t2, 7
    ctx->r11 = S32(ctx->r10 << 7);
    // 0x80305B40: addu        $t3, $t3, $t2
    ctx->r11 = ADD32(ctx->r11, ctx->r10);
    // 0x80305B44: sll         $t3, $t3, 3
    ctx->r11 = S32(ctx->r11 << 3);
    // 0x80305B48: mflo        $a0
    ctx->r4 = lo;
    // 0x80305B4C: sll         $t5, $a0, 16
    ctx->r13 = S32(ctx->r4 << 16);
    // 0x80305B50: sra         $t6, $t5, 16
    ctx->r14 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80305B54: addu        $a3, $t8, $t6
    ctx->r7 = ADD32(ctx->r24, ctx->r14);
    // 0x80305B58: sra         $t4, $a3, 6
    ctx->r12 = S32(SIGNED(ctx->r7) >> 6);
    // 0x80305B5C: sll         $t9, $t4, 3
    ctx->r25 = S32(ctx->r12 << 3);
    // 0x80305B60: lui         $t6, 0x803C
    ctx->r14 = S32(0X803C << 16);
    // 0x80305B64: addiu       $t6, $t6, 0x740
    ctx->r14 = ADD32(ctx->r14, 0X740);
    // 0x80305B68: addu        $t5, $t3, $t9
    ctx->r13 = ADD32(ctx->r11, ctx->r25);
    // 0x80305B6C: addu        $t0, $t5, $t6
    ctx->r8 = ADD32(ctx->r13, ctx->r14);
    // 0x80305B70: lbu         $t7, 0x3($t0)
    ctx->r15 = MEM_BU(ctx->r8, 0X3);
    // 0x80305B74: sll         $a0, $a2, 16
    ctx->r4 = S32(ctx->r6 << 16);
    // 0x80305B78: sra         $t9, $a0, 16
    ctx->r25 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80305B7C: beq         $t7, $zero, L_80305D4C
    if (ctx->r15 == 0) {
        // 0x80305B80: or          $a0, $t9, $zero
        ctx->r4 = ctx->r25 | 0;
            goto L_80305D4C;
    }
    // 0x80305B80: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    // 0x80305B84: sll         $a0, $a2, 16
    ctx->r4 = S32(ctx->r6 << 16);
    // 0x80305B88: sll         $a1, $a3, 16
    ctx->r5 = S32(ctx->r7 << 16);
    // 0x80305B8C: sra         $t2, $a1, 16
    ctx->r10 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80305B90: sra         $t8, $a0, 16
    ctx->r24 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80305B94: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    // 0x80305B98: sw          $t8, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r24;
    // 0x80305B9C: or          $a1, $t2, $zero
    ctx->r5 = ctx->r10 | 0;
    // 0x80305BA0: sw          $t2, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r10;
    // 0x80305BA4: jal         0x80310F58
    // 0x80305BA8: sw          $t0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r8;
    func_80310F58_722608(rdram, ctx);
        goto after_0;
    // 0x80305BA8: sw          $t0, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r8;
    after_0:
    // 0x80305BAC: lw          $t4, 0x58($sp)
    ctx->r12 = MEM_W(ctx->r29, 0X58);
    // 0x80305BB0: lw          $a0, 0x20($sp)
    ctx->r4 = MEM_W(ctx->r29, 0X20);
    // 0x80305BB4: lw          $a1, 0x1C($sp)
    ctx->r5 = MEM_W(ctx->r29, 0X1C);
    // 0x80305BB8: subu        $v1, $t4, $v0
    ctx->r3 = SUB32(ctx->r12, ctx->r2);
    // 0x80305BBC: sra         $t3, $v1, 16
    ctx->r11 = S32(SIGNED(ctx->r3) >> 16);
    // 0x80305BC0: lbu         $a3, 0x4F($sp)
    ctx->r7 = MEM_BU(ctx->r29, 0X4F);
    // 0x80305BC4: lw          $t0, 0x24($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X24);
    // 0x80305BC8: lbu         $t1, 0x4E($sp)
    ctx->r9 = MEM_BU(ctx->r29, 0X4E);
    // 0x80305BCC: bgez        $t3, L_80305BDC
    if (SIGNED(ctx->r11) >= 0) {
        // 0x80305BD0: or          $v1, $t3, $zero
        ctx->r3 = ctx->r11 | 0;
            goto L_80305BDC;
    }
    // 0x80305BD0: or          $v1, $t3, $zero
    ctx->r3 = ctx->r11 | 0;
    // 0x80305BD4: b           L_80305BE0
    // 0x80305BD8: negu        $a2, $t3
    ctx->r6 = SUB32(0, ctx->r11);
        goto L_80305BE0;
    // 0x80305BD8: negu        $a2, $t3
    ctx->r6 = SUB32(0, ctx->r11);
L_80305BDC:
    // 0x80305BDC: or          $a2, $v1, $zero
    ctx->r6 = ctx->r3 | 0;
L_80305BE0:
    // 0x80305BE0: slti        $at, $a2, 0x31
    ctx->r1 = SIGNED(ctx->r6) < 0X31 ? 1 : 0;
    // 0x80305BE4: beq         $at, $zero, L_80305C48
    if (ctx->r1 == 0) {
        // 0x80305BE8: lui         $t8, 0x803D
        ctx->r24 = S32(0X803D << 16);
            goto L_80305C48;
    }
    // 0x80305BE8: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x80305BEC: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80305BF0: lw          $t9, 0x552C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X552C);
    // 0x80305BF4: xori        $t7, $a3, 0x1
    ctx->r15 = ctx->r7 ^ 0X1;
    // 0x80305BF8: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x80305BFC: lhu         $t5, 0x272($t9)
    ctx->r13 = MEM_HU(ctx->r25, 0X272);
    // 0x80305C00: andi        $t6, $t5, 0x20
    ctx->r14 = ctx->r13 & 0X20;
    // 0x80305C04: beq         $t6, $zero, L_80305C40
    if (ctx->r14 == 0) {
        // 0x80305C08: nop
    
            goto L_80305C40;
    }
    // 0x80305C08: nop

    // 0x80305C0C: lbu         $v0, 0x5($t0)
    ctx->r2 = MEM_BU(ctx->r8, 0X5);
    // 0x80305C10: addiu       $t8, $zero, 0x10
    ctx->r24 = ADD32(0, 0X10);
    // 0x80305C14: sllv        $t2, $t8, $t7
    ctx->r10 = S32(ctx->r24 << (ctx->r15 & 31));
    // 0x80305C18: and         $t4, $v0, $t2
    ctx->r12 = ctx->r2 & ctx->r10;
    // 0x80305C1C: beq         $t4, $zero, L_80305C40
    if (ctx->r12 == 0) {
        // 0x80305C20: xori        $t3, $t1, 0x1
        ctx->r11 = ctx->r9 ^ 0X1;
            goto L_80305C40;
    }
    // 0x80305C20: xori        $t3, $t1, 0x1
    ctx->r11 = ctx->r9 ^ 0X1;
    // 0x80305C24: addiu       $t9, $zero, 0x10
    ctx->r25 = ADD32(0, 0X10);
    // 0x80305C28: sllv        $t5, $t9, $t3
    ctx->r13 = S32(ctx->r25 << (ctx->r11 & 31));
    // 0x80305C2C: and         $t6, $v0, $t5
    ctx->r14 = ctx->r2 & ctx->r13;
    // 0x80305C30: beq         $t6, $zero, L_80305C40
    if (ctx->r14 == 0) {
        // 0x80305C34: nop
    
            goto L_80305C40;
    }
    // 0x80305C34: nop

    // 0x80305C38: b           L_80305C40
    // 0x80305C3C: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
        goto L_80305C40;
    // 0x80305C3C: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
L_80305C40:
    // 0x80305C40: b           L_80305D44
    // 0x80305C44: sb          $v1, 0x43($sp)
    MEM_B(0X43, ctx->r29) = ctx->r3;
        goto L_80305D44;
    // 0x80305C44: sb          $v1, 0x43($sp)
    MEM_B(0X43, ctx->r29) = ctx->r3;
L_80305C48:
    // 0x80305C48: lw          $t8, 0x552C($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X552C);
    // 0x80305C4C: xori        $t4, $a3, 0x1
    ctx->r12 = ctx->r7 ^ 0X1;
    // 0x80305C50: lhu         $t7, 0x272($t8)
    ctx->r15 = MEM_HU(ctx->r24, 0X272);
    // 0x80305C54: andi        $t2, $t7, 0x20
    ctx->r10 = ctx->r15 & 0X20;
    // 0x80305C58: beq         $t2, $zero, L_80305CD4
    if (ctx->r10 == 0) {
        // 0x80305C5C: nop
    
            goto L_80305CD4;
    }
    // 0x80305C5C: nop

    // 0x80305C60: lbu         $v0, 0x5($t0)
    ctx->r2 = MEM_BU(ctx->r8, 0X5);
    // 0x80305C64: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x80305C68: sllv        $t3, $t9, $t4
    ctx->r11 = S32(ctx->r25 << (ctx->r12 & 31));
    // 0x80305C6C: and         $t5, $v0, $t3
    ctx->r13 = ctx->r2 & ctx->r11;
    // 0x80305C70: beq         $t5, $zero, L_80305CD4
    if (ctx->r13 == 0) {
        // 0x80305C74: xori        $t6, $t1, 0x1
        ctx->r14 = ctx->r9 ^ 0X1;
            goto L_80305CD4;
    }
    // 0x80305C74: xori        $t6, $t1, 0x1
    ctx->r14 = ctx->r9 ^ 0X1;
    // 0x80305C78: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x80305C7C: sllv        $t7, $t8, $t6
    ctx->r15 = S32(ctx->r24 << (ctx->r14 & 31));
    // 0x80305C80: and         $t2, $v0, $t7
    ctx->r10 = ctx->r2 & ctx->r15;
    // 0x80305C84: beq         $t2, $zero, L_80305CD4
    if (ctx->r10 == 0) {
        // 0x80305C88: nop
    
            goto L_80305CD4;
    }
    // 0x80305C88: nop

    // 0x80305C8C: bgez        $v1, L_80305C9C
    if (SIGNED(ctx->r3) >= 0) {
        // 0x80305C90: or          $a2, $v1, $zero
        ctx->r6 = ctx->r3 | 0;
            goto L_80305C9C;
    }
    // 0x80305C90: or          $a2, $v1, $zero
    ctx->r6 = ctx->r3 | 0;
    // 0x80305C94: b           L_80305C9C
    // 0x80305C98: negu        $a2, $v1
    ctx->r6 = SUB32(0, ctx->r3);
        goto L_80305C9C;
    // 0x80305C98: negu        $a2, $v1
    ctx->r6 = SUB32(0, ctx->r3);
L_80305C9C:
    // 0x80305C9C: lbu         $t9, 0x3($t0)
    ctx->r25 = MEM_BU(ctx->r8, 0X3);
    // 0x80305CA0: lui         $t3, 0x803E
    ctx->r11 = S32(0X803E << 16);
    // 0x80305CA4: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x80305CA8: sll         $t4, $t9, 2
    ctx->r12 = S32(ctx->r25 << 2);
    // 0x80305CAC: subu        $t4, $t4, $t9
    ctx->r12 = SUB32(ctx->r12, ctx->r25);
    // 0x80305CB0: sll         $t4, $t4, 2
    ctx->r12 = S32(ctx->r12 << 2);
    // 0x80305CB4: addu        $t3, $t3, $t4
    ctx->r11 = ADD32(ctx->r11, ctx->r12);
    // 0x80305CB8: lbu         $t3, 0x1D32($t3)
    ctx->r11 = MEM_BU(ctx->r11, 0X1D32);
    // 0x80305CBC: sll         $t5, $t3, 3
    ctx->r13 = S32(ctx->r11 << 3);
    // 0x80305CC0: slt         $at, $t5, $a2
    ctx->r1 = SIGNED(ctx->r13) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x80305CC4: bne         $at, $zero, L_80305CD4
    if (ctx->r1 != 0) {
        // 0x80305CC8: nop
    
            goto L_80305CD4;
    }
    // 0x80305CC8: nop

    // 0x80305CCC: b           L_80305D44
    // 0x80305CD0: sb          $v1, 0x43($sp)
    MEM_B(0X43, ctx->r29) = ctx->r3;
        goto L_80305D44;
    // 0x80305CD0: sb          $v1, 0x43($sp)
    MEM_B(0X43, ctx->r29) = ctx->r3;
L_80305CD4:
    // 0x80305CD4: jal         0x8031124C
    // 0x80305CD8: nop

    sample_ground_height_at_xz(rdram, ctx);
        goto after_1;
    // 0x80305CD8: nop

    after_1:
    // 0x80305CDC: lh          $a0, 0x52($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X52);
    // 0x80305CE0: lh          $a1, 0x56($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X56);
    // 0x80305CE4: jal         0x8031124C
    // 0x80305CE8: sw          $v0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r2;
    sample_ground_height_at_xz(rdram, ctx);
        goto after_2;
    // 0x80305CE8: sw          $v0, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r2;
    after_2:
    // 0x80305CEC: lw          $a2, 0x30($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X30);
    // 0x80305CF0: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80305CF4: subu        $v1, $a2, $v0
    ctx->r3 = SUB32(ctx->r6, ctx->r2);
    // 0x80305CF8: sra         $t8, $v1, 16
    ctx->r24 = S32(SIGNED(ctx->r3) >> 16);
    // 0x80305CFC: bgez        $t8, L_80305D0C
    if (SIGNED(ctx->r24) >= 0) {
        // 0x80305D00: or          $a0, $t8, $zero
        ctx->r4 = ctx->r24 | 0;
            goto L_80305D0C;
    }
    // 0x80305D00: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    // 0x80305D04: b           L_80305D10
    // 0x80305D08: negu        $a2, $t8
    ctx->r6 = SUB32(0, ctx->r24);
        goto L_80305D10;
    // 0x80305D08: negu        $a2, $t8
    ctx->r6 = SUB32(0, ctx->r24);
L_80305D0C:
    // 0x80305D0C: or          $a2, $a0, $zero
    ctx->r6 = ctx->r4 | 0;
L_80305D10:
    // 0x80305D10: slti        $at, $a2, 0x61
    ctx->r1 = SIGNED(ctx->r6) < 0X61 ? 1 : 0;
    // 0x80305D14: beq         $at, $zero, L_80305D24
    if (ctx->r1 == 0) {
        // 0x80305D18: nop
    
            goto L_80305D24;
    }
    // 0x80305D18: nop

    // 0x80305D1C: b           L_80305D44
    // 0x80305D20: sb          $zero, 0x43($sp)
    MEM_B(0X43, ctx->r29) = 0;
        goto L_80305D44;
    // 0x80305D20: sb          $zero, 0x43($sp)
    MEM_B(0X43, ctx->r29) = 0;
L_80305D24:
    // 0x80305D24: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x80305D28: lhu         $t7, 0x272($t6)
    ctx->r15 = MEM_HU(ctx->r14, 0X272);
    // 0x80305D2C: andi        $t2, $t7, 0x20
    ctx->r10 = ctx->r15 & 0X20;
    // 0x80305D30: beq         $t2, $zero, L_80305D44
    if (ctx->r10 == 0) {
        // 0x80305D34: nop
    
            goto L_80305D44;
    }
    // 0x80305D34: nop

    // 0x80305D38: bgez        $a0, L_80305D44
    if (SIGNED(ctx->r4) >= 0) {
        // 0x80305D3C: addiu       $v1, $zero, 0x1
        ctx->r3 = ADD32(0, 0X1);
            goto L_80305D44;
    }
    // 0x80305D3C: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x80305D40: sb          $v1, 0x43($sp)
    MEM_B(0X43, ctx->r29) = ctx->r3;
L_80305D44:
    // 0x80305D44: b           L_80305D90
    // 0x80305D48: lbu         $v1, 0x43($sp)
    ctx->r3 = MEM_BU(ctx->r29, 0X43);
        goto L_80305D90;
    // 0x80305D48: lbu         $v1, 0x43($sp)
    ctx->r3 = MEM_BU(ctx->r29, 0X43);
L_80305D4C:
    // 0x80305D4C: sll         $a1, $a3, 16
    ctx->r5 = S32(ctx->r7 << 16);
    // 0x80305D50: sra         $t4, $a1, 16
    ctx->r12 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80305D54: jal         0x8031124C
    // 0x80305D58: or          $a1, $t4, $zero
    ctx->r5 = ctx->r12 | 0;
    sample_ground_height_at_xz(rdram, ctx);
        goto after_3;
    // 0x80305D58: or          $a1, $t4, $zero
    ctx->r5 = ctx->r12 | 0;
    after_3:
    // 0x80305D5C: lw          $t3, 0x58($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X58);
    // 0x80305D60: subu        $v1, $t3, $v0
    ctx->r3 = SUB32(ctx->r11, ctx->r2);
    // 0x80305D64: sra         $t5, $v1, 16
    ctx->r13 = S32(SIGNED(ctx->r3) >> 16);
    // 0x80305D68: bgez        $t5, L_80305D78
    if (SIGNED(ctx->r13) >= 0) {
        // 0x80305D6C: or          $v1, $t5, $zero
        ctx->r3 = ctx->r13 | 0;
            goto L_80305D78;
    }
    // 0x80305D6C: or          $v1, $t5, $zero
    ctx->r3 = ctx->r13 | 0;
    // 0x80305D70: b           L_80305D7C
    // 0x80305D74: negu        $a2, $t5
    ctx->r6 = SUB32(0, ctx->r13);
        goto L_80305D7C;
    // 0x80305D74: negu        $a2, $t5
    ctx->r6 = SUB32(0, ctx->r13);
L_80305D78:
    // 0x80305D78: or          $a2, $v1, $zero
    ctx->r6 = ctx->r3 | 0;
L_80305D7C:
    // 0x80305D7C: slti        $at, $a2, 0x61
    ctx->r1 = SIGNED(ctx->r6) < 0X61 ? 1 : 0;
    // 0x80305D80: beq         $at, $zero, L_80305D90
    if (ctx->r1 == 0) {
        // 0x80305D84: addiu       $v1, $zero, 0x1
        ctx->r3 = ADD32(0, 0X1);
            goto L_80305D90;
    }
    // 0x80305D84: addiu       $v1, $zero, 0x1
    ctx->r3 = ADD32(0, 0X1);
    // 0x80305D88: b           L_80305D90
    // 0x80305D8C: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
        goto L_80305D90;
    // 0x80305D8C: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
L_80305D90:
    // 0x80305D90: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80305D94: addiu       $sp, $sp, 0x50
    ctx->r29 = ADD32(ctx->r29, 0X50);
    // 0x80305D98: or          $v0, $v1, $zero
    ctx->r2 = ctx->r3 | 0;
    // 0x80305D9C: jr          $ra
    // 0x80305DA0: nop

    return;
    // 0x80305DA0: nop

;}
RECOMP_FUNC void func_80305DA4_717454(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80305DA4: addiu       $sp, $sp, -0x78
    ctx->r29 = ADD32(ctx->r29, -0X78);
    // 0x80305DA8: sw          $s1, 0x18($sp)
    MEM_W(0X18, ctx->r29) = ctx->r17;
    // 0x80305DAC: sw          $s0, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r16;
    // 0x80305DB0: lbu         $v0, 0x8B($sp)
    ctx->r2 = MEM_BU(ctx->r29, 0X8B);
    // 0x80305DB4: sll         $s0, $a0, 16
    ctx->r16 = S32(ctx->r4 << 16);
    // 0x80305DB8: sll         $s1, $a1, 16
    ctx->r17 = S32(ctx->r5 << 16);
    // 0x80305DBC: sra         $t7, $s1, 16
    ctx->r15 = S32(SIGNED(ctx->r17) >> 16);
    // 0x80305DC0: sra         $t6, $s0, 16
    ctx->r14 = S32(SIGNED(ctx->r16) >> 16);
    // 0x80305DC4: or          $s0, $t6, $zero
    ctx->r16 = ctx->r14 | 0;
    // 0x80305DC8: or          $s1, $t7, $zero
    ctx->r17 = ctx->r15 | 0;
    // 0x80305DCC: lui         $t7, 0x803A
    ctx->r15 = S32(0X803A << 16);
    // 0x80305DD0: sll         $t6, $v0, 1
    ctx->r14 = S32(ctx->r2 << 1);
    // 0x80305DD4: addu        $t7, $t7, $t6
    ctx->r15 = ADD32(ctx->r15, ctx->r14);
    // 0x80305DD8: lh          $t7, 0x5570($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X5570);
    // 0x80305DDC: sw          $a3, 0x84($sp)
    MEM_W(0X84, ctx->r29) = ctx->r7;
    // 0x80305DE0: sll         $t8, $a3, 16
    ctx->r24 = S32(ctx->r7 << 16);
    // 0x80305DE4: sra         $a3, $t8, 16
    ctx->r7 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80305DE8: multu       $t7, $a3
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r7)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80305DEC: or          $v0, $t6, $zero
    ctx->r2 = ctx->r14 | 0;
    // 0x80305DF0: lui         $t6, 0x803A
    ctx->r14 = S32(0X803A << 16);
    // 0x80305DF4: addu        $t6, $t6, $v0
    ctx->r14 = ADD32(ctx->r14, ctx->r2);
    // 0x80305DF8: lh          $t6, 0x5578($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X5578);
    // 0x80305DFC: sw          $a1, 0x7C($sp)
    MEM_W(0X7C, ctx->r29) = ctx->r5;
    // 0x80305E00: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80305E04: sw          $a0, 0x78($sp)
    MEM_W(0X78, ctx->r29) = ctx->r4;
    // 0x80305E08: sw          $a2, 0x80($sp)
    MEM_W(0X80, ctx->r29) = ctx->r6;
    // 0x80305E0C: mflo        $v1
    ctx->r3 = lo;
    // 0x80305E10: sll         $t8, $v1, 16
    ctx->r24 = S32(ctx->r3 << 16);
    // 0x80305E14: sra         $t9, $t8, 16
    ctx->r25 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80305E18: multu       $t6, $a3
    result = U64(U32(ctx->r14)) * U64(U32(ctx->r7)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80305E1C: addu        $t4, $s0, $t9
    ctx->r12 = ADD32(ctx->r16, ctx->r25);
    // 0x80305E20: sra         $t9, $t4, 6
    ctx->r25 = S32(SIGNED(ctx->r12) >> 6);
    // 0x80305E24: sll         $t6, $t9, 7
    ctx->r14 = S32(ctx->r25 << 7);
    // 0x80305E28: addu        $t6, $t6, $t9
    ctx->r14 = ADD32(ctx->r14, ctx->r25);
    // 0x80305E2C: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x80305E30: mflo        $t0
    ctx->r8 = lo;
    // 0x80305E34: sll         $t7, $t0, 16
    ctx->r15 = S32(ctx->r8 << 16);
    // 0x80305E38: sra         $t8, $t7, 16
    ctx->r24 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80305E3C: addu        $t5, $s1, $t8
    ctx->r13 = ADD32(ctx->r17, ctx->r24);
    // 0x80305E40: sra         $t7, $t5, 6
    ctx->r15 = S32(SIGNED(ctx->r13) >> 6);
    // 0x80305E44: sll         $t8, $t7, 3
    ctx->r24 = S32(ctx->r15 << 3);
    // 0x80305E48: lui         $t7, 0x803C
    ctx->r15 = S32(0X803C << 16);
    // 0x80305E4C: addiu       $t7, $t7, 0x740
    ctx->r15 = ADD32(ctx->r15, 0X740);
    // 0x80305E50: addu        $t9, $t6, $t8
    ctx->r25 = ADD32(ctx->r14, ctx->r24);
    // 0x80305E54: addu        $t3, $t9, $t7
    ctx->r11 = ADD32(ctx->r25, ctx->r15);
    // 0x80305E58: lbu         $t1, 0x40E($t3)
    ctx->r9 = MEM_BU(ctx->r11, 0X40E);
    // 0x80305E5C: lbu         $t2, 0x6($t3)
    ctx->r10 = MEM_BU(ctx->r11, 0X6);
    // 0x80305E60: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80305E64: or          $a1, $t1, $zero
    ctx->r5 = ctx->r9 | 0;
    // 0x80305E68: slt         $at, $t1, $t2
    ctx->r1 = SIGNED(ctx->r9) < SIGNED(ctx->r10) ? 1 : 0;
    // 0x80305E6C: beq         $at, $zero, L_80305E7C
    if (ctx->r1 == 0) {
        // 0x80305E70: nop
    
            goto L_80305E7C;
    }
    // 0x80305E70: nop

    // 0x80305E74: b           L_80305E7C
    // 0x80305E78: or          $a1, $t2, $zero
    ctx->r5 = ctx->r10 | 0;
        goto L_80305E7C;
    // 0x80305E78: or          $a1, $t2, $zero
    ctx->r5 = ctx->r10 | 0;
L_80305E7C:
    // 0x80305E7C: lbu         $v0, 0x416($t3)
    ctx->r2 = MEM_BU(ctx->r11, 0X416);
    // 0x80305E80: lbu         $v1, 0xE($t3)
    ctx->r3 = MEM_BU(ctx->r11, 0XE);
    // 0x80305E84: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80305E88: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x80305E8C: beq         $at, $zero, L_80305E9C
    if (ctx->r1 == 0) {
        // 0x80305E90: nop
    
            goto L_80305E9C;
    }
    // 0x80305E90: nop

    // 0x80305E94: b           L_80305E9C
    // 0x80305E98: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
        goto L_80305E9C;
    // 0x80305E98: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
L_80305E9C:
    // 0x80305E9C: slt         $at, $a0, $a1
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x80305EA0: beq         $at, $zero, L_80305EC0
    if (ctx->r1 == 0) {
        // 0x80305EA4: slt         $at, $t1, $t2
        ctx->r1 = SIGNED(ctx->r9) < SIGNED(ctx->r10) ? 1 : 0;
            goto L_80305EC0;
    }
    // 0x80305EA4: slt         $at, $t1, $t2
    ctx->r1 = SIGNED(ctx->r9) < SIGNED(ctx->r10) ? 1 : 0;
    // 0x80305EA8: beq         $at, $zero, L_80305EB8
    if (ctx->r1 == 0) {
        // 0x80305EAC: or          $v0, $t1, $zero
        ctx->r2 = ctx->r9 | 0;
            goto L_80305EB8;
    }
    // 0x80305EAC: or          $v0, $t1, $zero
    ctx->r2 = ctx->r9 | 0;
    // 0x80305EB0: b           L_80305EB8
    // 0x80305EB4: or          $v0, $t2, $zero
    ctx->r2 = ctx->r10 | 0;
        goto L_80305EB8;
    // 0x80305EB4: or          $v0, $t2, $zero
    ctx->r2 = ctx->r10 | 0;
L_80305EB8:
    // 0x80305EB8: b           L_80305ED8
    // 0x80305EBC: or          $a2, $v0, $zero
    ctx->r6 = ctx->r2 | 0;
        goto L_80305ED8;
    // 0x80305EBC: or          $a2, $v0, $zero
    ctx->r6 = ctx->r2 | 0;
L_80305EC0:
    // 0x80305EC0: slt         $at, $v0, $v1
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x80305EC4: beq         $at, $zero, L_80305ED4
    if (ctx->r1 == 0) {
        // 0x80305EC8: or          $a0, $v0, $zero
        ctx->r4 = ctx->r2 | 0;
            goto L_80305ED4;
    }
    // 0x80305EC8: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80305ECC: b           L_80305ED4
    // 0x80305ED0: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
        goto L_80305ED4;
    // 0x80305ED0: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
L_80305ED4:
    // 0x80305ED4: or          $a2, $a0, $zero
    ctx->r6 = ctx->r4 | 0;
L_80305ED8:
    // 0x80305ED8: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x80305EDC: sll         $t0, $a2, 2
    ctx->r8 = S32(ctx->r6 << 2);
    // 0x80305EE0: sh          $t0, 0x60($sp)
    MEM_H(0X60, ctx->r29) = ctx->r8;
    // 0x80305EE4: lhu         $t8, 0xA0($t6)
    ctx->r24 = MEM_HU(ctx->r14, 0XA0);
    // 0x80305EE8: sll         $t7, $t0, 16
    ctx->r15 = S32(ctx->r8 << 16);
    // 0x80305EEC: sra         $t6, $t7, 16
    ctx->r14 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80305EF0: andi        $t9, $t8, 0x4
    ctx->r25 = ctx->r24 & 0X4;
    // 0x80305EF4: beql        $t9, $zero, L_80305F10
    if (ctx->r25 == 0) {
        // 0x80305EF8: lbu         $t8, 0x3($t3)
        ctx->r24 = MEM_BU(ctx->r11, 0X3);
            goto L_80305F10;
    }
    goto skip_0;
    // 0x80305EF8: lbu         $t8, 0x3($t3)
    ctx->r24 = MEM_BU(ctx->r11, 0X3);
    skip_0:
    // 0x80305EFC: bgtzl       $t6, L_80305F10
    if (SIGNED(ctx->r14) > 0) {
        // 0x80305F00: lbu         $t8, 0x3($t3)
        ctx->r24 = MEM_BU(ctx->r11, 0X3);
            goto L_80305F10;
    }
    goto skip_1;
    // 0x80305F00: lbu         $t8, 0x3($t3)
    ctx->r24 = MEM_BU(ctx->r11, 0X3);
    skip_1:
    // 0x80305F04: b           L_803064A8
    // 0x80305F08: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_803064A8;
    // 0x80305F08: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x80305F0C: lbu         $t8, 0x3($t3)
    ctx->r24 = MEM_BU(ctx->r11, 0X3);
L_80305F10:
    // 0x80305F10: sll         $a0, $t4, 16
    ctx->r4 = S32(ctx->r12 << 16);
    // 0x80305F14: sra         $t9, $a0, 16
    ctx->r25 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80305F18: beq         $t8, $zero, L_80306154
    if (ctx->r24 == 0) {
        // 0x80305F1C: or          $a0, $t9, $zero
        ctx->r4 = ctx->r25 | 0;
            goto L_80306154;
    }
    // 0x80305F1C: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    // 0x80305F20: sll         $a0, $t4, 16
    ctx->r4 = S32(ctx->r12 << 16);
    // 0x80305F24: sll         $a1, $t5, 16
    ctx->r5 = S32(ctx->r13 << 16);
    // 0x80305F28: sra         $t7, $a1, 16
    ctx->r15 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80305F2C: sra         $t9, $a0, 16
    ctx->r25 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80305F30: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    // 0x80305F34: sw          $t9, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r25;
    // 0x80305F38: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    // 0x80305F3C: sw          $t7, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r15;
    // 0x80305F40: sh          $a3, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r7;
    // 0x80305F44: sw          $t0, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r8;
    // 0x80305F48: jal         0x80310F58
    // 0x80305F4C: sw          $t3, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r11;
    func_80310F58_722608(rdram, ctx);
        goto after_0;
    // 0x80305F4C: sw          $t3, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r11;
    after_0:
    // 0x80305F50: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80305F54: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x80305F58: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    // 0x80305F5C: lw          $t0, 0x2C($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X2C);
    // 0x80305F60: lhu         $a0, 0xA0($t6)
    ctx->r4 = MEM_HU(ctx->r14, 0XA0);
    // 0x80305F64: lw          $t3, 0x30($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X30);
    // 0x80305F68: lw          $ra, 0x80($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X80);
    // 0x80305F6C: andi        $t8, $a0, 0x6
    ctx->r24 = ctx->r4 & 0X6;
    // 0x80305F70: beq         $t8, $zero, L_80305F98
    if (ctx->r24 == 0) {
        // 0x80305F74: or          $a1, $v0, $zero
        ctx->r5 = ctx->r2 | 0;
            goto L_80305F98;
    }
    // 0x80305F74: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x80305F78: sll         $t7, $t0, 16
    ctx->r15 = S32(ctx->r8 << 16);
    // 0x80305F7C: slt         $at, $v0, $t7
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r15) ? 1 : 0;
    // 0x80305F80: beq         $at, $zero, L_80305F98
    if (ctx->r1 == 0) {
        // 0x80305F84: andi        $t6, $a0, 0xC00
        ctx->r14 = ctx->r4 & 0XC00;
            goto L_80305F98;
    }
    // 0x80305F84: andi        $t6, $a0, 0xC00
    ctx->r14 = ctx->r4 & 0XC00;
    // 0x80305F88: beq         $t6, $zero, L_80305F98
    if (ctx->r14 == 0) {
        // 0x80305F8C: or          $a1, $t7, $zero
        ctx->r5 = ctx->r15 | 0;
            goto L_80305F98;
    }
    // 0x80305F8C: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    // 0x80305F90: b           L_803064A8
    // 0x80305F94: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_803064A8;
    // 0x80305F94: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_80305F98:
    // 0x80305F98: subu        $v0, $ra, $a1
    ctx->r2 = SUB32(ctx->r31, ctx->r5);
    // 0x80305F9C: sra         $t8, $v0, 16
    ctx->r24 = S32(SIGNED(ctx->r2) >> 16);
    // 0x80305FA0: bgez        $t8, L_80305FB0
    if (SIGNED(ctx->r24) >= 0) {
        // 0x80305FA4: or          $v0, $t8, $zero
        ctx->r2 = ctx->r24 | 0;
            goto L_80305FB0;
    }
    // 0x80305FA4: or          $v0, $t8, $zero
    ctx->r2 = ctx->r24 | 0;
    // 0x80305FA8: b           L_80305FB4
    // 0x80305FAC: negu        $a2, $t8
    ctx->r6 = SUB32(0, ctx->r24);
        goto L_80305FB4;
    // 0x80305FAC: negu        $a2, $t8
    ctx->r6 = SUB32(0, ctx->r24);
L_80305FB0:
    // 0x80305FB0: or          $a2, $v0, $zero
    ctx->r6 = ctx->r2 | 0;
L_80305FB4:
    // 0x80305FB4: slti        $at, $a2, 0x31
    ctx->r1 = SIGNED(ctx->r6) < 0X31 ? 1 : 0;
    // 0x80305FB8: beq         $at, $zero, L_80306004
    if (ctx->r1 == 0) {
        // 0x80305FBC: lui         $t7, 0x803D
        ctx->r15 = S32(0X803D << 16);
            goto L_80306004;
    }
    // 0x80305FBC: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80305FC0: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80305FC4: lw          $t9, 0x552C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X552C);
    // 0x80305FC8: lhu         $t7, 0x272($t9)
    ctx->r15 = MEM_HU(ctx->r25, 0X272);
    // 0x80305FCC: lbu         $t9, 0x8B($sp)
    ctx->r25 = MEM_BU(ctx->r29, 0X8B);
    // 0x80305FD0: andi        $t6, $t7, 0x20
    ctx->r14 = ctx->r15 & 0X20;
    // 0x80305FD4: beq         $t6, $zero, L_80305FFC
    if (ctx->r14 == 0) {
        // 0x80305FD8: xori        $t7, $t9, 0x1
        ctx->r15 = ctx->r25 ^ 0X1;
            goto L_80305FFC;
    }
    // 0x80305FD8: xori        $t7, $t9, 0x1
    ctx->r15 = ctx->r25 ^ 0X1;
    // 0x80305FDC: lbu         $t8, 0x5($t3)
    ctx->r24 = MEM_BU(ctx->r11, 0X5);
    // 0x80305FE0: addiu       $t6, $zero, 0x10
    ctx->r14 = ADD32(0, 0X10);
    // 0x80305FE4: sllv        $t9, $t6, $t7
    ctx->r25 = S32(ctx->r14 << (ctx->r15 & 31));
    // 0x80305FE8: and         $t6, $t8, $t9
    ctx->r14 = ctx->r24 & ctx->r25;
    // 0x80305FEC: beq         $t6, $zero, L_80305FFC
    if (ctx->r14 == 0) {
        // 0x80305FF0: nop
    
            goto L_80305FFC;
    }
    // 0x80305FF0: nop

    // 0x80305FF4: b           L_803064A8
    // 0x80305FF8: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_803064A8;
    // 0x80305FF8: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_80305FFC:
    // 0x80305FFC: b           L_803064A8
    // 0x80306000: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_803064A8;
    // 0x80306000: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80306004:
    // 0x80306004: lw          $t7, 0x552C($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X552C);
    // 0x80306008: lh          $a0, 0x2A($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X2A);
    // 0x8030600C: lh          $a1, 0x26($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X26);
    // 0x80306010: lhu         $t8, 0x272($t7)
    ctx->r24 = MEM_HU(ctx->r15, 0X272);
    // 0x80306014: lbu         $t7, 0x8B($sp)
    ctx->r15 = MEM_BU(ctx->r29, 0X8B);
    // 0x80306018: andi        $t9, $t8, 0x20
    ctx->r25 = ctx->r24 & 0X20;
    // 0x8030601C: beq         $t9, $zero, L_80306080
    if (ctx->r25 == 0) {
        // 0x80306020: xori        $t8, $t7, 0x1
        ctx->r24 = ctx->r15 ^ 0X1;
            goto L_80306080;
    }
    // 0x80306020: xori        $t8, $t7, 0x1
    ctx->r24 = ctx->r15 ^ 0X1;
    // 0x80306024: lbu         $t6, 0x5($t3)
    ctx->r14 = MEM_BU(ctx->r11, 0X5);
    // 0x80306028: addiu       $t9, $zero, 0x1
    ctx->r25 = ADD32(0, 0X1);
    // 0x8030602C: sllv        $t7, $t9, $t8
    ctx->r15 = S32(ctx->r25 << (ctx->r24 & 31));
    // 0x80306030: and         $t9, $t6, $t7
    ctx->r25 = ctx->r14 & ctx->r15;
    // 0x80306034: beq         $t9, $zero, L_80306080
    if (ctx->r25 == 0) {
        // 0x80306038: nop
    
            goto L_80306080;
    }
    // 0x80306038: nop

    // 0x8030603C: bgez        $v0, L_8030604C
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80306040: or          $a2, $v0, $zero
        ctx->r6 = ctx->r2 | 0;
            goto L_8030604C;
    }
    // 0x80306040: or          $a2, $v0, $zero
    ctx->r6 = ctx->r2 | 0;
    // 0x80306044: b           L_8030604C
    // 0x80306048: negu        $a2, $v0
    ctx->r6 = SUB32(0, ctx->r2);
        goto L_8030604C;
    // 0x80306048: negu        $a2, $v0
    ctx->r6 = SUB32(0, ctx->r2);
L_8030604C:
    // 0x8030604C: lbu         $t8, 0x3($t3)
    ctx->r24 = MEM_BU(ctx->r11, 0X3);
    // 0x80306050: lui         $t7, 0x803E
    ctx->r15 = S32(0X803E << 16);
    // 0x80306054: sll         $t6, $t8, 2
    ctx->r14 = S32(ctx->r24 << 2);
    // 0x80306058: subu        $t6, $t6, $t8
    ctx->r14 = SUB32(ctx->r14, ctx->r24);
    // 0x8030605C: sll         $t6, $t6, 2
    ctx->r14 = S32(ctx->r14 << 2);
    // 0x80306060: addu        $t7, $t7, $t6
    ctx->r15 = ADD32(ctx->r15, ctx->r14);
    // 0x80306064: lbu         $t7, 0x1D32($t7)
    ctx->r15 = MEM_BU(ctx->r15, 0X1D32);
    // 0x80306068: sll         $t9, $t7, 3
    ctx->r25 = S32(ctx->r15 << 3);
    // 0x8030606C: slt         $at, $t9, $a2
    ctx->r1 = SIGNED(ctx->r25) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x80306070: bne         $at, $zero, L_80306080
    if (ctx->r1 != 0) {
        // 0x80306074: nop
    
            goto L_80306080;
    }
    // 0x80306074: nop

    // 0x80306078: b           L_803064A8
    // 0x8030607C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_803064A8;
    // 0x8030607C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_80306080:
    // 0x80306080: jal         0x8031124C
    // 0x80306084: sh          $a3, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r7;
    sample_ground_height_at_xz(rdram, ctx);
        goto after_1;
    // 0x80306084: sh          $a3, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r7;
    after_1:
    // 0x80306088: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x8030608C: lw          $t8, 0x5524($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5524);
    // 0x80306090: lh          $t7, 0x60($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X60);
    // 0x80306094: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    // 0x80306098: lhu         $a0, 0xA0($t8)
    ctx->r4 = MEM_HU(ctx->r24, 0XA0);
    // 0x8030609C: sll         $t9, $t7, 16
    ctx->r25 = S32(ctx->r15 << 16);
    // 0x803060A0: slt         $at, $v0, $t9
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r25) ? 1 : 0;
    // 0x803060A4: andi        $t6, $a0, 0x6
    ctx->r14 = ctx->r4 & 0X6;
    // 0x803060A8: beq         $t6, $zero, L_803060C8
    if (ctx->r14 == 0) {
        // 0x803060AC: lh          $a1, 0x26($sp)
        ctx->r5 = MEM_H(ctx->r29, 0X26);
            goto L_803060C8;
    }
    // 0x803060AC: lh          $a1, 0x26($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X26);
    // 0x803060B0: beq         $at, $zero, L_803060C8
    if (ctx->r1 == 0) {
        // 0x803060B4: andi        $t8, $a0, 0xC00
        ctx->r24 = ctx->r4 & 0XC00;
            goto L_803060C8;
    }
    // 0x803060B4: andi        $t8, $a0, 0xC00
    ctx->r24 = ctx->r4 & 0XC00;
    // 0x803060B8: beql        $t8, $zero, L_803060CC
    if (ctx->r24 == 0) {
        // 0x803060BC: lh          $a0, 0x2A($sp)
        ctx->r4 = MEM_H(ctx->r29, 0X2A);
            goto L_803060CC;
    }
    goto skip_2;
    // 0x803060BC: lh          $a0, 0x2A($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X2A);
    skip_2:
    // 0x803060C0: b           L_803064A8
    // 0x803060C4: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_803064A8;
    // 0x803060C4: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_803060C8:
    // 0x803060C8: lh          $a0, 0x2A($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X2A);
L_803060CC:
    // 0x803060CC: jal         0x8031124C
    // 0x803060D0: sh          $a3, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r7;
    sample_ground_height_at_xz(rdram, ctx);
        goto after_2;
    // 0x803060D0: sh          $a3, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r7;
    after_2:
    // 0x803060D4: sll         $a0, $s0, 16
    ctx->r4 = S32(ctx->r16 << 16);
    // 0x803060D8: sll         $a1, $s1, 16
    ctx->r5 = S32(ctx->r17 << 16);
    // 0x803060DC: sra         $t7, $a1, 16
    ctx->r15 = S32(SIGNED(ctx->r5) >> 16);
    // 0x803060E0: sra         $t6, $a0, 16
    ctx->r14 = S32(SIGNED(ctx->r4) >> 16);
    // 0x803060E4: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    // 0x803060E8: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    // 0x803060EC: jal         0x8031124C
    // 0x803060F0: sw          $v0, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r2;
    sample_ground_height_at_xz(rdram, ctx);
        goto after_3;
    // 0x803060F0: sw          $v0, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r2;
    after_3:
    // 0x803060F4: lw          $a2, 0x4C($sp)
    ctx->r6 = MEM_W(ctx->r29, 0X4C);
    // 0x803060F8: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    // 0x803060FC: lw          $ra, 0x80($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X80);
    // 0x80306100: subu        $v1, $a2, $v0
    ctx->r3 = SUB32(ctx->r6, ctx->r2);
    // 0x80306104: sra         $t9, $v1, 16
    ctx->r25 = S32(SIGNED(ctx->r3) >> 16);
    // 0x80306108: bgez        $t9, L_80306118
    if (SIGNED(ctx->r25) >= 0) {
        // 0x8030610C: or          $a0, $t9, $zero
        ctx->r4 = ctx->r25 | 0;
            goto L_80306118;
    }
    // 0x8030610C: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    // 0x80306110: b           L_8030611C
    // 0x80306114: negu        $a2, $t9
    ctx->r6 = SUB32(0, ctx->r25);
        goto L_8030611C;
    // 0x80306114: negu        $a2, $t9
    ctx->r6 = SUB32(0, ctx->r25);
L_80306118:
    // 0x80306118: or          $a2, $a0, $zero
    ctx->r6 = ctx->r4 | 0;
L_8030611C:
    // 0x8030611C: slti        $at, $a2, 0x61
    ctx->r1 = SIGNED(ctx->r6) < 0X61 ? 1 : 0;
    // 0x80306120: beq         $at, $zero, L_80306130
    if (ctx->r1 == 0) {
        // 0x80306124: lui         $t8, 0x803D
        ctx->r24 = S32(0X803D << 16);
            goto L_80306130;
    }
    // 0x80306124: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x80306128: b           L_803064A8
    // 0x8030612C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_803064A8;
    // 0x8030612C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80306130:
    // 0x80306130: lw          $t8, 0x552C($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X552C);
    // 0x80306134: lhu         $t6, 0x272($t8)
    ctx->r14 = MEM_HU(ctx->r24, 0X272);
    // 0x80306138: andi        $t7, $t6, 0x20
    ctx->r15 = ctx->r14 & 0X20;
    // 0x8030613C: beq         $t7, $zero, L_80306214
    if (ctx->r15 == 0) {
        // 0x80306140: nop
    
            goto L_80306214;
    }
    // 0x80306140: nop

    // 0x80306144: bgez        $a0, L_80306214
    if (SIGNED(ctx->r4) >= 0) {
        // 0x80306148: nop
    
            goto L_80306214;
    }
    // 0x80306148: nop

    // 0x8030614C: b           L_803064A8
    // 0x80306150: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_803064A8;
    // 0x80306150: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_80306154:
    // 0x80306154: sll         $a1, $t5, 16
    ctx->r5 = S32(ctx->r13 << 16);
    // 0x80306158: sra         $t8, $a1, 16
    ctx->r24 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8030615C: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    // 0x80306160: sh          $a3, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r7;
    // 0x80306164: jal         0x8031124C
    // 0x80306168: sw          $t0, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r8;
    sample_ground_height_at_xz(rdram, ctx);
        goto after_4;
    // 0x80306168: sw          $t0, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r8;
    after_4:
    // 0x8030616C: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80306170: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x80306174: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    // 0x80306178: lw          $t0, 0x2C($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X2C);
    // 0x8030617C: lhu         $a0, 0xA0($t6)
    ctx->r4 = MEM_HU(ctx->r14, 0XA0);
    // 0x80306180: lw          $ra, 0x80($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X80);
    // 0x80306184: or          $a1, $v0, $zero
    ctx->r5 = ctx->r2 | 0;
    // 0x80306188: andi        $t7, $a0, 0x4
    ctx->r15 = ctx->r4 & 0X4;
    // 0x8030618C: beq         $t7, $zero, L_803061B0
    if (ctx->r15 == 0) {
        // 0x80306190: andi        $t9, $a0, 0x6
        ctx->r25 = ctx->r4 & 0X6;
            goto L_803061B0;
    }
    // 0x80306190: andi        $t9, $a0, 0x6
    ctx->r25 = ctx->r4 & 0X6;
    // 0x80306194: slt         $at, $v0, $ra
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r31) ? 1 : 0;
    // 0x80306198: bne         $at, $zero, L_803061A8
    if (ctx->r1 != 0) {
        // 0x8030619C: nop
    
            goto L_803061A8;
    }
    // 0x8030619C: nop

    // 0x803061A0: b           L_803064A8
    // 0x803061A4: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_803064A8;
    // 0x803061A4: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_803061A8:
    // 0x803061A8: b           L_803064A8
    // 0x803061AC: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_803064A8;
    // 0x803061AC: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_803061B0:
    // 0x803061B0: beq         $t9, $zero, L_803061D4
    if (ctx->r25 == 0) {
        // 0x803061B4: sll         $t6, $t0, 16
        ctx->r14 = S32(ctx->r8 << 16);
            goto L_803061D4;
    }
    // 0x803061B4: sll         $t6, $t0, 16
    ctx->r14 = S32(ctx->r8 << 16);
    // 0x803061B8: slt         $at, $v0, $t6
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x803061BC: beq         $at, $zero, L_803061D4
    if (ctx->r1 == 0) {
        // 0x803061C0: andi        $t7, $a0, 0xC00
        ctx->r15 = ctx->r4 & 0XC00;
            goto L_803061D4;
    }
    // 0x803061C0: andi        $t7, $a0, 0xC00
    ctx->r15 = ctx->r4 & 0XC00;
    // 0x803061C4: beq         $t7, $zero, L_803061D4
    if (ctx->r15 == 0) {
        // 0x803061C8: or          $a1, $t6, $zero
        ctx->r5 = ctx->r14 | 0;
            goto L_803061D4;
    }
    // 0x803061C8: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x803061CC: b           L_803064A8
    // 0x803061D0: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_803064A8;
    // 0x803061D0: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_803061D4:
    // 0x803061D4: subu        $v0, $ra, $a1
    ctx->r2 = SUB32(ctx->r31, ctx->r5);
    // 0x803061D8: sra         $t9, $v0, 16
    ctx->r25 = S32(SIGNED(ctx->r2) >> 16);
    // 0x803061DC: bgez        $t9, L_803061EC
    if (SIGNED(ctx->r25) >= 0) {
        // 0x803061E0: or          $v0, $t9, $zero
        ctx->r2 = ctx->r25 | 0;
            goto L_803061EC;
    }
    // 0x803061E0: or          $v0, $t9, $zero
    ctx->r2 = ctx->r25 | 0;
    // 0x803061E4: b           L_803061F0
    // 0x803061E8: negu        $a2, $t9
    ctx->r6 = SUB32(0, ctx->r25);
        goto L_803061F0;
    // 0x803061E8: negu        $a2, $t9
    ctx->r6 = SUB32(0, ctx->r25);
L_803061EC:
    // 0x803061EC: or          $a2, $v0, $zero
    ctx->r6 = ctx->r2 | 0;
L_803061F0:
    // 0x803061F0: slti        $at, $a2, 0x61
    ctx->r1 = SIGNED(ctx->r6) < 0X61 ? 1 : 0;
    // 0x803061F4: beq         $at, $zero, L_80306204
    if (ctx->r1 == 0) {
        // 0x803061F8: nop
    
            goto L_80306204;
    }
    // 0x803061F8: nop

    // 0x803061FC: b           L_803064A8
    // 0x80306200: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_803064A8;
    // 0x80306200: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80306204:
    // 0x80306204: bgez        $v0, L_80306214
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80306208: nop
    
            goto L_80306214;
    }
    // 0x80306208: nop

    // 0x8030620C: b           L_803064A8
    // 0x80306210: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_803064A8;
    // 0x80306210: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_80306214:
    // 0x80306214: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x80306218: lw          $t8, 0x552C($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X552C);
    // 0x8030621C: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80306220: lui         $a1, 0x803E
    ctx->r5 = S32(0X803E << 16);
    // 0x80306224: lhu         $t6, 0x272($t8)
    ctx->r14 = MEM_HU(ctx->r24, 0X272);
    // 0x80306228: andi        $t7, $t6, 0x10
    ctx->r15 = ctx->r14 & 0X10;
    // 0x8030622C: bnel        $t7, $zero, L_80306254
    if (ctx->r15 != 0) {
        // 0x80306230: sra         $t9, $s1, 10
        ctx->r25 = S32(SIGNED(ctx->r17) >> 10);
            goto L_80306254;
    }
    goto skip_3;
    // 0x80306230: sra         $t9, $s1, 10
    ctx->r25 = S32(SIGNED(ctx->r17) >> 10);
    skip_3:
    // 0x80306234: lw          $t9, 0x5524($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5524);
    // 0x80306238: lhu         $t8, 0xA0($t9)
    ctx->r24 = MEM_HU(ctx->r25, 0XA0);
    // 0x8030623C: andi        $t6, $t8, 0x4
    ctx->r14 = ctx->r24 & 0X4;
    // 0x80306240: bnel        $t6, $zero, L_80306254
    if (ctx->r14 != 0) {
        // 0x80306244: sra         $t9, $s1, 10
        ctx->r25 = S32(SIGNED(ctx->r17) >> 10);
            goto L_80306254;
    }
    goto skip_4;
    // 0x80306244: sra         $t9, $s1, 10
    ctx->r25 = S32(SIGNED(ctx->r17) >> 10);
    skip_4:
    // 0x80306248: b           L_803064A8
    // 0x8030624C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_803064A8;
    // 0x8030624C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x80306250: sra         $t9, $s1, 10
    ctx->r25 = S32(SIGNED(ctx->r17) >> 10);
L_80306254:
    // 0x80306254: sll         $t8, $t9, 2
    ctx->r24 = S32(ctx->r25 << 2);
    // 0x80306258: addu        $t8, $t8, $t9
    ctx->r24 = ADD32(ctx->r24, ctx->r25);
    // 0x8030625C: sra         $t7, $s0, 10
    ctx->r15 = S32(SIGNED(ctx->r16) >> 10);
    // 0x80306260: addu        $t6, $t7, $t8
    ctx->r14 = ADD32(ctx->r15, ctx->r24);
    // 0x80306264: sll         $t9, $t6, 16
    ctx->r25 = S32(ctx->r14 << 16);
    // 0x80306268: sra         $t7, $t9, 16
    ctx->r15 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8030626C: sll         $t8, $t7, 2
    ctx->r24 = S32(ctx->r15 << 2);
    // 0x80306270: subu        $t8, $t8, $t7
    ctx->r24 = SUB32(ctx->r24, ctx->r15);
    // 0x80306274: sll         $t8, $t8, 2
    ctx->r24 = S32(ctx->r24 << 2);
    // 0x80306278: addu        $a1, $a1, $t8
    ctx->r5 = ADD32(ctx->r5, ctx->r24);
    // 0x8030627C: lw          $a1, -0x5EF0($a1)
    ctx->r5 = MEM_W(ctx->r5, -0X5EF0);
    // 0x80306280: addiu       $t4, $zero, 0x3
    ctx->r12 = ADD32(0, 0X3);
    // 0x80306284: addiu       $t3, $zero, 0x2
    ctx->r11 = ADD32(0, 0X2);
    // 0x80306288: beq         $a1, $zero, L_803064A4
    if (ctx->r5 == 0) {
        // 0x8030628C: addiu       $t2, $zero, 0x1
        ctx->r10 = ADD32(0, 0X1);
            goto L_803064A4;
    }
    // 0x8030628C: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x80306290: lui         $t1, 0x10
    ctx->r9 = S32(0X10 << 16);
    // 0x80306294: ori         $t1, $t1, 0x1
    ctx->r9 = ctx->r9 | 0X1;
    // 0x80306298: lw          $t0, 0x50($sp)
    ctx->r8 = MEM_W(ctx->r29, 0X50);
    // 0x8030629C: lw          $v0, 0x8($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X8);
L_803062A0:
    // 0x803062A0: lw          $t6, 0x16C($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X16C);
    // 0x803062A4: lw          $t9, 0x80($t6)
    ctx->r25 = MEM_W(ctx->r14, 0X80);
    // 0x803062A8: sll         $t8, $t9, 17
    ctx->r24 = S32(ctx->r25 << 17);
    // 0x803062AC: bgezl       $t8, L_8030649C
    if (SIGNED(ctx->r24) >= 0) {
        // 0x803062B0: lw          $a1, 0x0($a1)
        ctx->r5 = MEM_W(ctx->r5, 0X0);
            goto L_8030649C;
    }
    goto skip_5;
    // 0x803062B0: lw          $a1, 0x0($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X0);
    skip_5:
    // 0x803062B4: beql        $v0, $t0, L_8030649C
    if (ctx->r2 == ctx->r8) {
        // 0x803062B8: lw          $a1, 0x0($a1)
        ctx->r5 = MEM_W(ctx->r5, 0X0);
            goto L_8030649C;
    }
    goto skip_6;
    // 0x803062B8: lw          $a1, 0x0($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X0);
    skip_6:
    // 0x803062BC: lh          $t6, 0x1C($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X1C);
    // 0x803062C0: bnel        $t6, $zero, L_8030649C
    if (ctx->r14 != 0) {
        // 0x803062C4: lw          $a1, 0x0($a1)
        ctx->r5 = MEM_W(ctx->r5, 0X0);
            goto L_8030649C;
    }
    goto skip_7;
    // 0x803062C4: lw          $a1, 0x0($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X0);
    skip_7:
    // 0x803062C8: lh          $t9, 0x20($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X20);
    // 0x803062CC: bnel        $t9, $zero, L_8030649C
    if (ctx->r25 != 0) {
        // 0x803062D0: lw          $a1, 0x0($a1)
        ctx->r5 = MEM_W(ctx->r5, 0X0);
            goto L_8030649C;
    }
    goto skip_8;
    // 0x803062D0: lw          $a1, 0x0($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X0);
    skip_8:
    // 0x803062D4: lh          $t7, 0x24($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X24);
    // 0x803062D8: bnel        $t7, $zero, L_8030649C
    if (ctx->r15 != 0) {
        // 0x803062DC: lw          $a1, 0x0($a1)
        ctx->r5 = MEM_W(ctx->r5, 0X0);
            goto L_8030649C;
    }
    goto skip_9;
    // 0x803062DC: lw          $a1, 0x0($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X0);
    skip_9:
    // 0x803062E0: lhu         $t6, 0x42($v0)
    ctx->r14 = MEM_HU(ctx->r2, 0X42);
    // 0x803062E4: lw          $t8, 0xC($v0)
    ctx->r24 = MEM_W(ctx->r2, 0XC);
    // 0x803062E8: sll         $t9, $t6, 16
    ctx->r25 = S32(ctx->r14 << 16);
    // 0x803062EC: addu        $t7, $t8, $t9
    ctx->r15 = ADD32(ctx->r24, ctx->r25);
    // 0x803062F0: subu        $v1, $t7, $ra
    ctx->r3 = SUB32(ctx->r15, ctx->r31);
    // 0x803062F4: bgez        $v1, L_80306304
    if (SIGNED(ctx->r3) >= 0) {
        // 0x803062F8: or          $a2, $v1, $zero
        ctx->r6 = ctx->r3 | 0;
            goto L_80306304;
    }
    // 0x803062F8: or          $a2, $v1, $zero
    ctx->r6 = ctx->r3 | 0;
    // 0x803062FC: b           L_80306304
    // 0x80306300: negu        $a2, $v1
    ctx->r6 = SUB32(0, ctx->r3);
        goto L_80306304;
    // 0x80306300: negu        $a2, $v1
    ctx->r6 = SUB32(0, ctx->r3);
L_80306304:
    // 0x80306304: slt         $at, $a2, $t1
    ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r9) ? 1 : 0;
    // 0x80306308: beq         $at, $zero, L_80306498
    if (ctx->r1 == 0) {
        // 0x8030630C: lbu         $v1, 0x8B($sp)
        ctx->r3 = MEM_BU(ctx->r29, 0X8B);
            goto L_80306498;
    }
    // 0x8030630C: lbu         $v1, 0x8B($sp)
    ctx->r3 = MEM_BU(ctx->r29, 0X8B);
    // 0x80306310: beql        $v1, $zero, L_8030633C
    if (ctx->r3 == 0) {
        // 0x80306314: lh          $t6, 0x8($v0)
        ctx->r14 = MEM_H(ctx->r2, 0X8);
            goto L_8030633C;
    }
    goto skip_10;
    // 0x80306314: lh          $t6, 0x8($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X8);
    skip_10:
    // 0x80306318: beql        $v1, $t2, L_80306394
    if (ctx->r3 == ctx->r10) {
        // 0x8030631C: lh          $t9, 0x8($v0)
        ctx->r25 = MEM_H(ctx->r2, 0X8);
            goto L_80306394;
    }
    goto skip_11;
    // 0x8030631C: lh          $t9, 0x8($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X8);
    skip_11:
    // 0x80306320: beql        $v1, $t3, L_803063EC
    if (ctx->r3 == ctx->r11) {
        // 0x80306324: lh          $t6, 0x4($v0)
        ctx->r14 = MEM_H(ctx->r2, 0X4);
            goto L_803063EC;
    }
    goto skip_12;
    // 0x80306324: lh          $t6, 0x4($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X4);
    skip_12:
    // 0x80306328: beql        $v1, $t4, L_80306444
    if (ctx->r3 == ctx->r12) {
        // 0x8030632C: lh          $t9, 0x4($v0)
        ctx->r25 = MEM_H(ctx->r2, 0X4);
            goto L_80306444;
    }
    goto skip_13;
    // 0x8030632C: lh          $t9, 0x4($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X4);
    skip_13:
    // 0x80306330: b           L_8030649C
    // 0x80306334: lw          $a1, 0x0($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X0);
        goto L_8030649C;
    // 0x80306334: lw          $a1, 0x0($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X0);
    // 0x80306338: lh          $t6, 0x8($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X8);
L_8030633C:
    // 0x8030633C: subu        $v1, $t6, $s1
    ctx->r3 = SUB32(ctx->r14, ctx->r17);
    // 0x80306340: bgez        $v1, L_80306350
    if (SIGNED(ctx->r3) >= 0) {
        // 0x80306344: or          $a0, $v1, $zero
        ctx->r4 = ctx->r3 | 0;
            goto L_80306350;
    }
    // 0x80306344: or          $a0, $v1, $zero
    ctx->r4 = ctx->r3 | 0;
    // 0x80306348: b           L_80306350
    // 0x8030634C: negu        $a0, $v1
    ctx->r4 = SUB32(0, ctx->r3);
        goto L_80306350;
    // 0x8030634C: negu        $a0, $v1
    ctx->r4 = SUB32(0, ctx->r3);
L_80306350:
    // 0x80306350: lh          $t8, 0x32($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X32);
    // 0x80306354: sra         $t9, $t8, 1
    ctx->r25 = S32(SIGNED(ctx->r24) >> 1);
    // 0x80306358: slt         $at, $a0, $t9
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r25) ? 1 : 0;
    // 0x8030635C: beql        $at, $zero, L_8030649C
    if (ctx->r1 == 0) {
        // 0x80306360: lw          $a1, 0x0($a1)
        ctx->r5 = MEM_W(ctx->r5, 0X0);
            goto L_8030649C;
    }
    goto skip_14;
    // 0x80306360: lw          $a1, 0x0($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X0);
    skip_14:
    // 0x80306364: lh          $t8, 0x4($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X4);
    // 0x80306368: lh          $t9, 0x30($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X30);
    // 0x8030636C: sra         $t7, $a3, 1
    ctx->r15 = S32(SIGNED(ctx->r7) >> 1);
    // 0x80306370: subu        $t6, $s0, $t7
    ctx->r14 = SUB32(ctx->r16, ctx->r15);
    // 0x80306374: addu        $t7, $t8, $t9
    ctx->r15 = ADD32(ctx->r24, ctx->r25);
    // 0x80306378: addiu       $t8, $t7, 0x2
    ctx->r24 = ADD32(ctx->r15, 0X2);
    // 0x8030637C: slt         $at, $t6, $t8
    ctx->r1 = SIGNED(ctx->r14) < SIGNED(ctx->r24) ? 1 : 0;
    // 0x80306380: beql        $at, $zero, L_8030649C
    if (ctx->r1 == 0) {
        // 0x80306384: lw          $a1, 0x0($a1)
        ctx->r5 = MEM_W(ctx->r5, 0X0);
            goto L_8030649C;
    }
    goto skip_15;
    // 0x80306384: lw          $a1, 0x0($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X0);
    skip_15:
    // 0x80306388: b           L_803064A8
    // 0x8030638C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_803064A8;
    // 0x8030638C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x80306390: lh          $t9, 0x8($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X8);
L_80306394:
    // 0x80306394: subu        $v1, $t9, $s1
    ctx->r3 = SUB32(ctx->r25, ctx->r17);
    // 0x80306398: bgez        $v1, L_803063A8
    if (SIGNED(ctx->r3) >= 0) {
        // 0x8030639C: or          $a2, $v1, $zero
        ctx->r6 = ctx->r3 | 0;
            goto L_803063A8;
    }
    // 0x8030639C: or          $a2, $v1, $zero
    ctx->r6 = ctx->r3 | 0;
    // 0x803063A0: b           L_803063A8
    // 0x803063A4: negu        $a2, $v1
    ctx->r6 = SUB32(0, ctx->r3);
        goto L_803063A8;
    // 0x803063A4: negu        $a2, $v1
    ctx->r6 = SUB32(0, ctx->r3);
L_803063A8:
    // 0x803063A8: lh          $t7, 0x32($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X32);
    // 0x803063AC: sra         $t6, $t7, 1
    ctx->r14 = S32(SIGNED(ctx->r15) >> 1);
    // 0x803063B0: slt         $at, $a2, $t6
    ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x803063B4: beql        $at, $zero, L_8030649C
    if (ctx->r1 == 0) {
        // 0x803063B8: lw          $a1, 0x0($a1)
        ctx->r5 = MEM_W(ctx->r5, 0X0);
            goto L_8030649C;
    }
    goto skip_16;
    // 0x803063B8: lw          $a1, 0x0($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X0);
    skip_16:
    // 0x803063BC: lh          $t7, 0x4($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X4);
    // 0x803063C0: lh          $t6, 0x30($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X30);
    // 0x803063C4: sra         $t8, $a3, 1
    ctx->r24 = S32(SIGNED(ctx->r7) >> 1);
    // 0x803063C8: addu        $t9, $s0, $t8
    ctx->r25 = ADD32(ctx->r16, ctx->r24);
    // 0x803063CC: subu        $t8, $t7, $t6
    ctx->r24 = SUB32(ctx->r15, ctx->r14);
    // 0x803063D0: addiu       $t7, $t8, -0x2
    ctx->r15 = ADD32(ctx->r24, -0X2);
    // 0x803063D4: slt         $at, $t7, $t9
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r25) ? 1 : 0;
    // 0x803063D8: beql        $at, $zero, L_8030649C
    if (ctx->r1 == 0) {
        // 0x803063DC: lw          $a1, 0x0($a1)
        ctx->r5 = MEM_W(ctx->r5, 0X0);
            goto L_8030649C;
    }
    goto skip_17;
    // 0x803063DC: lw          $a1, 0x0($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X0);
    skip_17:
    // 0x803063E0: b           L_803064A8
    // 0x803063E4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_803064A8;
    // 0x803063E4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x803063E8: lh          $t6, 0x4($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X4);
L_803063EC:
    // 0x803063EC: subu        $v1, $t6, $s0
    ctx->r3 = SUB32(ctx->r14, ctx->r16);
    // 0x803063F0: bgez        $v1, L_80306400
    if (SIGNED(ctx->r3) >= 0) {
        // 0x803063F4: or          $a2, $v1, $zero
        ctx->r6 = ctx->r3 | 0;
            goto L_80306400;
    }
    // 0x803063F4: or          $a2, $v1, $zero
    ctx->r6 = ctx->r3 | 0;
    // 0x803063F8: b           L_80306400
    // 0x803063FC: negu        $a2, $v1
    ctx->r6 = SUB32(0, ctx->r3);
        goto L_80306400;
    // 0x803063FC: negu        $a2, $v1
    ctx->r6 = SUB32(0, ctx->r3);
L_80306400:
    // 0x80306400: lh          $t8, 0x30($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X30);
    // 0x80306404: sra         $t9, $t8, 1
    ctx->r25 = S32(SIGNED(ctx->r24) >> 1);
    // 0x80306408: slt         $at, $a2, $t9
    ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r25) ? 1 : 0;
    // 0x8030640C: beql        $at, $zero, L_8030649C
    if (ctx->r1 == 0) {
        // 0x80306410: lw          $a1, 0x0($a1)
        ctx->r5 = MEM_W(ctx->r5, 0X0);
            goto L_8030649C;
    }
    goto skip_18;
    // 0x80306410: lw          $a1, 0x0($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X0);
    skip_18:
    // 0x80306414: lh          $t8, 0x8($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X8);
    // 0x80306418: lh          $t9, 0x32($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X32);
    // 0x8030641C: sra         $t7, $a3, 1
    ctx->r15 = S32(SIGNED(ctx->r7) >> 1);
    // 0x80306420: subu        $t6, $s1, $t7
    ctx->r14 = SUB32(ctx->r17, ctx->r15);
    // 0x80306424: addu        $t7, $t8, $t9
    ctx->r15 = ADD32(ctx->r24, ctx->r25);
    // 0x80306428: addiu       $t8, $t7, 0x2
    ctx->r24 = ADD32(ctx->r15, 0X2);
    // 0x8030642C: slt         $at, $t6, $t8
    ctx->r1 = SIGNED(ctx->r14) < SIGNED(ctx->r24) ? 1 : 0;
    // 0x80306430: beql        $at, $zero, L_8030649C
    if (ctx->r1 == 0) {
        // 0x80306434: lw          $a1, 0x0($a1)
        ctx->r5 = MEM_W(ctx->r5, 0X0);
            goto L_8030649C;
    }
    goto skip_19;
    // 0x80306434: lw          $a1, 0x0($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X0);
    skip_19:
    // 0x80306438: b           L_803064A8
    // 0x8030643C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_803064A8;
    // 0x8030643C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x80306440: lh          $t9, 0x4($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X4);
L_80306444:
    // 0x80306444: subu        $v1, $t9, $s0
    ctx->r3 = SUB32(ctx->r25, ctx->r16);
    // 0x80306448: bgez        $v1, L_80306458
    if (SIGNED(ctx->r3) >= 0) {
        // 0x8030644C: or          $a2, $v1, $zero
        ctx->r6 = ctx->r3 | 0;
            goto L_80306458;
    }
    // 0x8030644C: or          $a2, $v1, $zero
    ctx->r6 = ctx->r3 | 0;
    // 0x80306450: b           L_80306458
    // 0x80306454: negu        $a2, $v1
    ctx->r6 = SUB32(0, ctx->r3);
        goto L_80306458;
    // 0x80306454: negu        $a2, $v1
    ctx->r6 = SUB32(0, ctx->r3);
L_80306458:
    // 0x80306458: lh          $t7, 0x30($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X30);
    // 0x8030645C: sra         $t6, $t7, 1
    ctx->r14 = S32(SIGNED(ctx->r15) >> 1);
    // 0x80306460: slt         $at, $a2, $t6
    ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x80306464: beql        $at, $zero, L_8030649C
    if (ctx->r1 == 0) {
        // 0x80306468: lw          $a1, 0x0($a1)
        ctx->r5 = MEM_W(ctx->r5, 0X0);
            goto L_8030649C;
    }
    goto skip_20;
    // 0x80306468: lw          $a1, 0x0($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X0);
    skip_20:
    // 0x8030646C: lh          $t7, 0x8($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X8);
    // 0x80306470: lh          $t6, 0x32($v0)
    ctx->r14 = MEM_H(ctx->r2, 0X32);
    // 0x80306474: sra         $t8, $a3, 1
    ctx->r24 = S32(SIGNED(ctx->r7) >> 1);
    // 0x80306478: addu        $t9, $s1, $t8
    ctx->r25 = ADD32(ctx->r17, ctx->r24);
    // 0x8030647C: subu        $t8, $t7, $t6
    ctx->r24 = SUB32(ctx->r15, ctx->r14);
    // 0x80306480: addiu       $t7, $t8, -0x2
    ctx->r15 = ADD32(ctx->r24, -0X2);
    // 0x80306484: slt         $at, $t7, $t9
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r25) ? 1 : 0;
    // 0x80306488: beql        $at, $zero, L_8030649C
    if (ctx->r1 == 0) {
        // 0x8030648C: lw          $a1, 0x0($a1)
        ctx->r5 = MEM_W(ctx->r5, 0X0);
            goto L_8030649C;
    }
    goto skip_21;
    // 0x8030648C: lw          $a1, 0x0($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X0);
    skip_21:
    // 0x80306490: b           L_803064A8
    // 0x80306494: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_803064A8;
    // 0x80306494: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80306498:
    // 0x80306498: lw          $a1, 0x0($a1)
    ctx->r5 = MEM_W(ctx->r5, 0X0);
L_8030649C:
    // 0x8030649C: bnel        $a1, $zero, L_803062A0
    if (ctx->r5 != 0) {
        // 0x803064A0: lw          $v0, 0x8($a1)
        ctx->r2 = MEM_W(ctx->r5, 0X8);
            goto L_803062A0;
    }
    goto skip_22;
    // 0x803064A0: lw          $v0, 0x8($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X8);
    skip_22:
L_803064A4:
    // 0x803064A4: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_803064A8:
    // 0x803064A8: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x803064AC: lw          $s0, 0x14($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X14);
    // 0x803064B0: lw          $s1, 0x18($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X18);
    // 0x803064B4: jr          $ra
    // 0x803064B8: addiu       $sp, $sp, 0x78
    ctx->r29 = ADD32(ctx->r29, 0X78);
    return;
    // 0x803064B8: addiu       $sp, $sp, 0x78
    ctx->r29 = ADD32(ctx->r29, 0X78);
;}
RECOMP_FUNC void func_803064BC_717B6C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803064BC: addiu       $sp, $sp, -0x40
    ctx->r29 = ADD32(ctx->r29, -0X40);
    // 0x803064C0: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x803064C4: lw          $t8, 0x5530($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5530);
    // 0x803064C8: sw          $ra, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r31;
    // 0x803064CC: sw          $s6, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r22;
    // 0x803064D0: sw          $s5, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r21;
    // 0x803064D4: sw          $s4, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r20;
    // 0x803064D8: sw          $s3, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r19;
    // 0x803064DC: sw          $s2, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r18;
    // 0x803064E0: sw          $s1, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r17;
    // 0x803064E4: sw          $s0, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r16;
    // 0x803064E8: sw          $a0, 0x40($sp)
    MEM_W(0X40, ctx->r29) = ctx->r4;
    // 0x803064EC: sw          $a1, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r5;
    // 0x803064F0: sw          $a3, 0x4C($sp)
    MEM_W(0X4C, ctx->r29) = ctx->r7;
    // 0x803064F4: lw          $v0, 0x6C($t8)
    ctx->r2 = MEM_W(ctx->r24, 0X6C);
    // 0x803064F8: sll         $s4, $a0, 16
    ctx->r20 = S32(ctx->r4 << 16);
    // 0x803064FC: sll         $s5, $a1, 16
    ctx->r21 = S32(ctx->r5 << 16);
    // 0x80306500: sra         $t7, $s5, 16
    ctx->r15 = S32(SIGNED(ctx->r21) >> 16);
    // 0x80306504: sra         $t6, $s4, 16
    ctx->r14 = S32(SIGNED(ctx->r20) >> 16);
    // 0x80306508: or          $s4, $t6, $zero
    ctx->r20 = ctx->r14 | 0;
    // 0x8030650C: or          $s5, $t7, $zero
    ctx->r21 = ctx->r15 | 0;
    // 0x80306510: beq         $v0, $zero, L_80306554
    if (ctx->r2 == 0) {
        // 0x80306514: or          $s6, $a2, $zero
        ctx->r22 = ctx->r6 | 0;
            goto L_80306554;
    }
    // 0x80306514: or          $s6, $a2, $zero
    ctx->r22 = ctx->r6 | 0;
    // 0x80306518: lw          $t9, 0x16C($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X16C);
    // 0x8030651C: lw          $t0, 0x80($t9)
    ctx->r8 = MEM_W(ctx->r25, 0X80);
    // 0x80306520: sll         $t2, $t0, 17
    ctx->r10 = S32(ctx->r8 << 17);
    // 0x80306524: bgezl       $t2, L_80306558
    if (SIGNED(ctx->r10) >= 0) {
        // 0x80306528: or          $s2, $zero, $zero
        ctx->r18 = 0 | 0;
            goto L_80306558;
    }
    goto skip_0;
    // 0x80306528: or          $s2, $zero, $zero
    ctx->r18 = 0 | 0;
    skip_0:
    // 0x8030652C: lw          $t3, 0x1C($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X1C);
    // 0x80306530: lw          $t4, 0x20($v0)
    ctx->r12 = MEM_W(ctx->r2, 0X20);
    // 0x80306534: lw          $t6, 0x24($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X24);
    // 0x80306538: or          $t5, $t3, $t4
    ctx->r13 = ctx->r11 | ctx->r12;
    // 0x8030653C: sltu        $t7, $zero, $t6
    ctx->r15 = 0 < ctx->r14 ? 1 : 0;
    // 0x80306540: or          $t8, $t5, $t7
    ctx->r24 = ctx->r13 | ctx->r15;
    // 0x80306544: beql        $t8, $zero, L_80306558
    if (ctx->r24 == 0) {
        // 0x80306548: or          $s2, $zero, $zero
        ctx->r18 = 0 | 0;
            goto L_80306558;
    }
    goto skip_1;
    // 0x80306548: or          $s2, $zero, $zero
    ctx->r18 = 0 | 0;
    skip_1:
    // 0x8030654C: b           L_803065C8
    // 0x80306550: addiu       $v0, $zero, 0xF
    ctx->r2 = ADD32(0, 0XF);
        goto L_803065C8;
    // 0x80306550: addiu       $v0, $zero, 0xF
    ctx->r2 = ADD32(0, 0XF);
L_80306554:
    // 0x80306554: or          $s2, $zero, $zero
    ctx->r18 = 0 | 0;
L_80306558:
    // 0x80306558: or          $s0, $zero, $zero
    ctx->r16 = 0 | 0;
    // 0x8030655C: addiu       $s1, $zero, 0x1
    ctx->r17 = ADD32(0, 0X1);
    // 0x80306560: lh          $s3, 0x52($sp)
    ctx->r19 = MEM_H(ctx->r29, 0X52);
L_80306564:
    // 0x80306564: sll         $a0, $s4, 16
    ctx->r4 = S32(ctx->r20 << 16);
    // 0x80306568: sll         $a1, $s5, 16
    ctx->r5 = S32(ctx->r21 << 16);
    // 0x8030656C: sll         $a3, $s3, 16
    ctx->r7 = S32(ctx->r19 << 16);
    // 0x80306570: sra         $t1, $a3, 16
    ctx->r9 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306574: sra         $t0, $a1, 16
    ctx->r8 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80306578: sra         $t9, $a0, 16
    ctx->r25 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8030657C: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    // 0x80306580: or          $a1, $t0, $zero
    ctx->r5 = ctx->r8 | 0;
    // 0x80306584: or          $a3, $t1, $zero
    ctx->r7 = ctx->r9 | 0;
    // 0x80306588: or          $a2, $s6, $zero
    ctx->r6 = ctx->r22 | 0;
    // 0x8030658C: jal         0x80305DA4
    // 0x80306590: sw          $s0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r16;
    func_80305DA4_717454(rdram, ctx);
        goto after_0;
    // 0x80306590: sw          $s0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r16;
    after_0:
    // 0x80306594: beq         $v0, $zero, L_803065A8
    if (ctx->r2 == 0) {
        // 0x80306598: addiu       $s0, $s0, 0x1
        ctx->r16 = ADD32(ctx->r16, 0X1);
            goto L_803065A8;
    }
    // 0x80306598: addiu       $s0, $s0, 0x1
    ctx->r16 = ADD32(ctx->r16, 0X1);
    // 0x8030659C: or          $s2, $s2, $s1
    ctx->r18 = ctx->r18 | ctx->r17;
    // 0x803065A0: sll         $t2, $s2, 16
    ctx->r10 = S32(ctx->r18 << 16);
    // 0x803065A4: sra         $s2, $t2, 16
    ctx->r18 = S32(SIGNED(ctx->r10) >> 16);
L_803065A8:
    // 0x803065A8: andi        $t4, $s0, 0xFF
    ctx->r12 = ctx->r16 & 0XFF;
    // 0x803065AC: or          $t6, $s1, $zero
    ctx->r14 = ctx->r17 | 0;
    // 0x803065B0: sll         $t5, $t6, 17
    ctx->r13 = S32(ctx->r14 << 17);
    // 0x803065B4: slti        $at, $t4, 0x4
    ctx->r1 = SIGNED(ctx->r12) < 0X4 ? 1 : 0;
    // 0x803065B8: sra         $s1, $t5, 16
    ctx->r17 = S32(SIGNED(ctx->r13) >> 16);
    // 0x803065BC: bne         $at, $zero, L_80306564
    if (ctx->r1 != 0) {
        // 0x803065C0: or          $s0, $t4, $zero
        ctx->r16 = ctx->r12 | 0;
            goto L_80306564;
    }
    // 0x803065C0: or          $s0, $t4, $zero
    ctx->r16 = ctx->r12 | 0;
    // 0x803065C4: or          $v0, $s2, $zero
    ctx->r2 = ctx->r18 | 0;
L_803065C8:
    // 0x803065C8: lw          $ra, 0x3C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X3C);
    // 0x803065CC: lw          $s0, 0x20($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X20);
    // 0x803065D0: lw          $s1, 0x24($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X24);
    // 0x803065D4: lw          $s2, 0x28($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X28);
    // 0x803065D8: lw          $s3, 0x2C($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X2C);
    // 0x803065DC: lw          $s4, 0x30($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X30);
    // 0x803065E0: lw          $s5, 0x34($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X34);
    // 0x803065E4: lw          $s6, 0x38($sp)
    ctx->r22 = MEM_W(ctx->r29, 0X38);
    // 0x803065E8: jr          $ra
    // 0x803065EC: addiu       $sp, $sp, 0x40
    ctx->r29 = ADD32(ctx->r29, 0X40);
    return;
    // 0x803065EC: addiu       $sp, $sp, 0x40
    ctx->r29 = ADD32(ctx->r29, 0X40);
;}
RECOMP_FUNC void func_803065F0_717CA0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803065F0: addiu       $sp, $sp, -0x38
    ctx->r29 = ADD32(ctx->r29, -0X38);
    // 0x803065F4: sw          $s3, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r19;
    // 0x803065F8: sw          $s2, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r18;
    // 0x803065FC: sw          $s0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r16;
    // 0x80306600: sll         $s0, $a3, 16
    ctx->r16 = S32(ctx->r7 << 16);
    // 0x80306604: sll         $s2, $a0, 16
    ctx->r18 = S32(ctx->r4 << 16);
    // 0x80306608: sll         $s3, $a1, 16
    ctx->r19 = S32(ctx->r5 << 16);
    // 0x8030660C: sra         $t7, $s3, 16
    ctx->r15 = S32(SIGNED(ctx->r19) >> 16);
    // 0x80306610: sra         $t6, $s2, 16
    ctx->r14 = S32(SIGNED(ctx->r18) >> 16);
    // 0x80306614: sra         $t8, $s0, 16
    ctx->r24 = S32(SIGNED(ctx->r16) >> 16);
    // 0x80306618: sw          $s1, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r17;
    // 0x8030661C: addiu       $at, $zero, 0x40
    ctx->r1 = ADD32(0, 0X40);
    // 0x80306620: or          $s1, $a2, $zero
    ctx->r17 = ctx->r6 | 0;
    // 0x80306624: or          $s0, $t8, $zero
    ctx->r16 = ctx->r24 | 0;
    // 0x80306628: or          $s2, $t6, $zero
    ctx->r18 = ctx->r14 | 0;
    // 0x8030662C: or          $s3, $t7, $zero
    ctx->r19 = ctx->r15 | 0;
    // 0x80306630: sw          $ra, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r31;
    // 0x80306634: sw          $a0, 0x38($sp)
    MEM_W(0X38, ctx->r29) = ctx->r4;
    // 0x80306638: sw          $a1, 0x3C($sp)
    MEM_W(0X3C, ctx->r29) = ctx->r5;
    // 0x8030663C: bne         $t8, $at, L_80306674
    if (ctx->r24 != ctx->r1) {
        // 0x80306640: sw          $a3, 0x44($sp)
        MEM_W(0X44, ctx->r29) = ctx->r7;
            goto L_80306674;
    }
    // 0x80306640: sw          $a3, 0x44($sp)
    MEM_W(0X44, ctx->r29) = ctx->r7;
    // 0x80306644: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80306648: lw          $t9, 0x5530($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5530);
    // 0x8030664C: lhu         $t4, 0x4A($sp)
    ctx->r12 = MEM_HU(ctx->r29, 0X4A);
    // 0x80306650: lw          $v0, 0x6C($t9)
    ctx->r2 = MEM_W(ctx->r25, 0X6C);
    // 0x80306654: sltiu       $at, $t4, 0x10
    ctx->r1 = ctx->r12 < 0X10 ? 1 : 0;
    // 0x80306658: beq         $v0, $zero, L_8030667C
    if (ctx->r2 == 0) {
        // 0x8030665C: nop
    
            goto L_8030667C;
    }
    // 0x8030665C: nop

    // 0x80306660: lw          $t0, 0x16C($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X16C);
    // 0x80306664: lw          $t1, 0x80($t0)
    ctx->r9 = MEM_W(ctx->r8, 0X80);
    // 0x80306668: sll         $t3, $t1, 17
    ctx->r11 = S32(ctx->r9 << 17);
    // 0x8030666C: bgez        $t3, L_8030667C
    if (SIGNED(ctx->r11) >= 0) {
        // 0x80306670: nop
    
            goto L_8030667C;
    }
    // 0x80306670: nop

L_80306674:
    // 0x80306674: b           L_803071A0
    // 0x80306678: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_803071A0;
    // 0x80306678: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_8030667C:
    // 0x8030667C: beq         $at, $zero, L_8030719C
    if (ctx->r1 == 0) {
        // 0x80306680: sll         $t4, $t4, 2
        ctx->r12 = S32(ctx->r12 << 2);
            goto L_8030719C;
    }
    // 0x80306680: sll         $t4, $t4, 2
    ctx->r12 = S32(ctx->r12 << 2);
    // 0x80306684: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80306688: addu        $at, $at, $t4
    gpr jr_addend_80306690 = ctx->r12;
    ctx->r1 = ADD32(ctx->r1, ctx->r12);
    // 0x8030668C: lw          $t4, -0x2FCC($at)
    ctx->r12 = ADD32(ctx->r1, -0X2FCC);
    // 0x80306690: jr          $t4
    // 0x80306694: nop

    switch (jr_addend_80306690 >> 2) {
        case 0: goto L_80306698; break;
        case 1: goto L_80306A40; break;
        case 2: goto L_80306B68; break;
        case 3: goto L_80306C90; break;
        case 4: goto L_80306C98; break;
        case 5: goto L_80306DBC; break;
        case 6: goto L_80306E64; break;
        case 7: goto L_80306F04; break;
        case 8: goto L_80306F0C; break;
        case 9: goto L_80307034; break;
        case 10: goto L_803070D4; break;
        case 11: goto L_80307174; break;
        case 12: goto L_8030717C; break;
        case 13: goto L_80307184; break;
        case 14: goto L_8030718C; break;
        case 15: goto L_80307194; break;
        default: switch_error(__func__, 0x80306690, 0x803BD034);
    }
    // 0x80306694: nop

L_80306698:
    // 0x80306698: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
    // 0x8030669C: sll         $a1, $s3, 16
    ctx->r5 = S32(ctx->r19 << 16);
    // 0x803066A0: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x803066A4: sra         $t7, $a3, 16
    ctx->r15 = S32(SIGNED(ctx->r7) >> 16);
    // 0x803066A8: sra         $t6, $a1, 16
    ctx->r14 = S32(SIGNED(ctx->r5) >> 16);
    // 0x803066AC: sra         $t5, $a0, 16
    ctx->r13 = S32(SIGNED(ctx->r4) >> 16);
    // 0x803066B0: addiu       $t8, $zero, 0x3
    ctx->r24 = ADD32(0, 0X3);
    // 0x803066B4: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x803066B8: or          $a0, $t5, $zero
    ctx->r4 = ctx->r13 | 0;
    // 0x803066BC: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x803066C0: or          $a3, $t7, $zero
    ctx->r7 = ctx->r15 | 0;
    // 0x803066C4: jal         0x80305A70
    // 0x803066C8: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305A70_717120(rdram, ctx);
        goto after_0;
    // 0x803066C8: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_0:
    // 0x803066CC: bne         $v0, $zero, L_80306780
    if (ctx->r2 != 0) {
        // 0x803066D0: sll         $a0, $s2, 16
        ctx->r4 = S32(ctx->r18 << 16);
            goto L_80306780;
    }
    // 0x803066D0: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
    // 0x803066D4: sll         $a1, $s3, 16
    ctx->r5 = S32(ctx->r19 << 16);
    // 0x803066D8: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x803066DC: sra         $t1, $a3, 16
    ctx->r9 = S32(SIGNED(ctx->r7) >> 16);
    // 0x803066E0: sra         $t0, $a1, 16
    ctx->r8 = S32(SIGNED(ctx->r5) >> 16);
    // 0x803066E4: sra         $t9, $a0, 16
    ctx->r25 = S32(SIGNED(ctx->r4) >> 16);
    // 0x803066E8: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x803066EC: sw          $t2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r10;
    // 0x803066F0: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    // 0x803066F4: or          $a1, $t0, $zero
    ctx->r5 = ctx->r8 | 0;
    // 0x803066F8: or          $a3, $t1, $zero
    ctx->r7 = ctx->r9 | 0;
    // 0x803066FC: jal         0x80305A70
    // 0x80306700: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305A70_717120(rdram, ctx);
        goto after_1;
    // 0x80306700: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_1:
    // 0x80306704: beq         $v0, $zero, L_80306780
    if (ctx->r2 == 0) {
        // 0x80306708: subu        $a0, $s2, $s0
        ctx->r4 = SUB32(ctx->r18, ctx->r16);
            goto L_80306780;
    }
    // 0x80306708: subu        $a0, $s2, $s0
    ctx->r4 = SUB32(ctx->r18, ctx->r16);
    // 0x8030670C: sll         $a1, $s3, 16
    ctx->r5 = S32(ctx->r19 << 16);
    // 0x80306710: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306714: sra         $t6, $a3, 16
    ctx->r14 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306718: sra         $t5, $a1, 16
    ctx->r13 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8030671C: sll         $t3, $a0, 16
    ctx->r11 = S32(ctx->r4 << 16);
    // 0x80306720: sra         $a0, $t3, 16
    ctx->r4 = S32(SIGNED(ctx->r11) >> 16);
    // 0x80306724: or          $a1, $t5, $zero
    ctx->r5 = ctx->r13 | 0;
    // 0x80306728: or          $a3, $t6, $zero
    ctx->r7 = ctx->r14 | 0;
    // 0x8030672C: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    // 0x80306730: jal         0x80305DA4
    // 0x80306734: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_2;
    // 0x80306734: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_2:
    // 0x80306738: beq         $v0, $zero, L_80306780
    if (ctx->r2 == 0) {
        // 0x8030673C: sll         $a0, $s2, 16
        ctx->r4 = S32(ctx->r18 << 16);
            goto L_80306780;
    }
    // 0x8030673C: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
    // 0x80306740: addu        $a1, $s3, $s0
    ctx->r5 = ADD32(ctx->r19, ctx->r16);
    // 0x80306744: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306748: sra         $t0, $a3, 16
    ctx->r8 = S32(SIGNED(ctx->r7) >> 16);
    // 0x8030674C: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x80306750: sra         $t7, $a0, 16
    ctx->r15 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80306754: addiu       $t1, $zero, 0x3
    ctx->r9 = ADD32(0, 0X3);
    // 0x80306758: sw          $t1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r9;
    // 0x8030675C: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x80306760: sra         $a1, $t8, 16
    ctx->r5 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80306764: or          $a3, $t0, $zero
    ctx->r7 = ctx->r8 | 0;
    // 0x80306768: jal         0x80305DA4
    // 0x8030676C: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_3;
    // 0x8030676C: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_3:
    // 0x80306770: beql        $v0, $zero, L_80306784
    if (ctx->r2 == 0) {
        // 0x80306774: sll         $a0, $s2, 16
        ctx->r4 = S32(ctx->r18 << 16);
            goto L_80306784;
    }
    goto skip_0;
    // 0x80306774: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
    skip_0:
    // 0x80306778: b           L_803071A0
    // 0x8030677C: addiu       $v0, $zero, 0x6
    ctx->r2 = ADD32(0, 0X6);
        goto L_803071A0;
    // 0x8030677C: addiu       $v0, $zero, 0x6
    ctx->r2 = ADD32(0, 0X6);
L_80306780:
    // 0x80306780: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
L_80306784:
    // 0x80306784: sll         $a1, $s3, 16
    ctx->r5 = S32(ctx->r19 << 16);
    // 0x80306788: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x8030678C: sra         $t4, $a3, 16
    ctx->r12 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306790: sra         $t3, $a1, 16
    ctx->r11 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80306794: sra         $t2, $a0, 16
    ctx->r10 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80306798: or          $a0, $t2, $zero
    ctx->r4 = ctx->r10 | 0;
    // 0x8030679C: or          $a1, $t3, $zero
    ctx->r5 = ctx->r11 | 0;
    // 0x803067A0: or          $a3, $t4, $zero
    ctx->r7 = ctx->r12 | 0;
    // 0x803067A4: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    // 0x803067A8: jal         0x80305A70
    // 0x803067AC: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    func_80305A70_717120(rdram, ctx);
        goto after_4;
    // 0x803067AC: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_4:
    // 0x803067B0: bne         $v0, $zero, L_80306868
    if (ctx->r2 != 0) {
        // 0x803067B4: sll         $a0, $s2, 16
        ctx->r4 = S32(ctx->r18 << 16);
            goto L_80306868;
    }
    // 0x803067B4: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
    // 0x803067B8: sll         $a1, $s3, 16
    ctx->r5 = S32(ctx->r19 << 16);
    // 0x803067BC: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x803067C0: sra         $t7, $a3, 16
    ctx->r15 = S32(SIGNED(ctx->r7) >> 16);
    // 0x803067C4: sra         $t6, $a1, 16
    ctx->r14 = S32(SIGNED(ctx->r5) >> 16);
    // 0x803067C8: sra         $t5, $a0, 16
    ctx->r13 = S32(SIGNED(ctx->r4) >> 16);
    // 0x803067CC: addiu       $t8, $zero, 0x2
    ctx->r24 = ADD32(0, 0X2);
    // 0x803067D0: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x803067D4: or          $a0, $t5, $zero
    ctx->r4 = ctx->r13 | 0;
    // 0x803067D8: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x803067DC: or          $a3, $t7, $zero
    ctx->r7 = ctx->r15 | 0;
    // 0x803067E0: jal         0x80305A70
    // 0x803067E4: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305A70_717120(rdram, ctx);
        goto after_5;
    // 0x803067E4: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_5:
    // 0x803067E8: beq         $v0, $zero, L_80306868
    if (ctx->r2 == 0) {
        // 0x803067EC: addu        $a0, $s2, $s0
        ctx->r4 = ADD32(ctx->r18, ctx->r16);
            goto L_80306868;
    }
    // 0x803067EC: addu        $a0, $s2, $s0
    ctx->r4 = ADD32(ctx->r18, ctx->r16);
    // 0x803067F0: sll         $a1, $s3, 16
    ctx->r5 = S32(ctx->r19 << 16);
    // 0x803067F4: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x803067F8: sra         $t2, $a3, 16
    ctx->r10 = S32(SIGNED(ctx->r7) >> 16);
    // 0x803067FC: sra         $t1, $a1, 16
    ctx->r9 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80306800: sll         $t9, $a0, 16
    ctx->r25 = S32(ctx->r4 << 16);
    // 0x80306804: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x80306808: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    // 0x8030680C: sra         $a0, $t9, 16
    ctx->r4 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80306810: or          $a1, $t1, $zero
    ctx->r5 = ctx->r9 | 0;
    // 0x80306814: or          $a3, $t2, $zero
    ctx->r7 = ctx->r10 | 0;
    // 0x80306818: jal         0x80305DA4
    // 0x8030681C: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_6;
    // 0x8030681C: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_6:
    // 0x80306820: beq         $v0, $zero, L_80306868
    if (ctx->r2 == 0) {
        // 0x80306824: sll         $a0, $s2, 16
        ctx->r4 = S32(ctx->r18 << 16);
            goto L_80306868;
    }
    // 0x80306824: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
    // 0x80306828: addu        $a1, $s3, $s0
    ctx->r5 = ADD32(ctx->r19, ctx->r16);
    // 0x8030682C: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306830: sra         $t7, $a3, 16
    ctx->r15 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306834: sll         $t5, $a1, 16
    ctx->r13 = S32(ctx->r5 << 16);
    // 0x80306838: sra         $t4, $a0, 16
    ctx->r12 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8030683C: addiu       $t8, $zero, 0x3
    ctx->r24 = ADD32(0, 0X3);
    // 0x80306840: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80306844: or          $a0, $t4, $zero
    ctx->r4 = ctx->r12 | 0;
    // 0x80306848: sra         $a1, $t5, 16
    ctx->r5 = S32(SIGNED(ctx->r13) >> 16);
    // 0x8030684C: or          $a3, $t7, $zero
    ctx->r7 = ctx->r15 | 0;
    // 0x80306850: jal         0x80305DA4
    // 0x80306854: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_7;
    // 0x80306854: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_7:
    // 0x80306858: beql        $v0, $zero, L_8030686C
    if (ctx->r2 == 0) {
        // 0x8030685C: sll         $a0, $s2, 16
        ctx->r4 = S32(ctx->r18 << 16);
            goto L_8030686C;
    }
    goto skip_1;
    // 0x8030685C: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
    skip_1:
    // 0x80306860: b           L_803071A0
    // 0x80306864: addiu       $v0, $zero, 0x5
    ctx->r2 = ADD32(0, 0X5);
        goto L_803071A0;
    // 0x80306864: addiu       $v0, $zero, 0x5
    ctx->r2 = ADD32(0, 0X5);
L_80306868:
    // 0x80306868: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
L_8030686C:
    // 0x8030686C: sll         $a1, $s3, 16
    ctx->r5 = S32(ctx->r19 << 16);
    // 0x80306870: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306874: sra         $t1, $a3, 16
    ctx->r9 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306878: sra         $t0, $a1, 16
    ctx->r8 = S32(SIGNED(ctx->r5) >> 16);
    // 0x8030687C: sra         $t9, $a0, 16
    ctx->r25 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80306880: addiu       $t2, $zero, 0x1
    ctx->r10 = ADD32(0, 0X1);
    // 0x80306884: sw          $t2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r10;
    // 0x80306888: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    // 0x8030688C: or          $a1, $t0, $zero
    ctx->r5 = ctx->r8 | 0;
    // 0x80306890: or          $a3, $t1, $zero
    ctx->r7 = ctx->r9 | 0;
    // 0x80306894: jal         0x80305A70
    // 0x80306898: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305A70_717120(rdram, ctx);
        goto after_8;
    // 0x80306898: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_8:
    // 0x8030689C: bne         $v0, $zero, L_80306954
    if (ctx->r2 != 0) {
        // 0x803068A0: sll         $a0, $s2, 16
        ctx->r4 = S32(ctx->r18 << 16);
            goto L_80306954;
    }
    // 0x803068A0: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
    // 0x803068A4: sll         $a1, $s3, 16
    ctx->r5 = S32(ctx->r19 << 16);
    // 0x803068A8: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x803068AC: sra         $t5, $a3, 16
    ctx->r13 = S32(SIGNED(ctx->r7) >> 16);
    // 0x803068B0: sra         $t4, $a1, 16
    ctx->r12 = S32(SIGNED(ctx->r5) >> 16);
    // 0x803068B4: sra         $t3, $a0, 16
    ctx->r11 = S32(SIGNED(ctx->r4) >> 16);
    // 0x803068B8: addiu       $t6, $zero, 0x3
    ctx->r14 = ADD32(0, 0X3);
    // 0x803068BC: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x803068C0: or          $a0, $t3, $zero
    ctx->r4 = ctx->r11 | 0;
    // 0x803068C4: or          $a1, $t4, $zero
    ctx->r5 = ctx->r12 | 0;
    // 0x803068C8: or          $a3, $t5, $zero
    ctx->r7 = ctx->r13 | 0;
    // 0x803068CC: jal         0x80305A70
    // 0x803068D0: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305A70_717120(rdram, ctx);
        goto after_9;
    // 0x803068D0: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_9:
    // 0x803068D4: beq         $v0, $zero, L_80306954
    if (ctx->r2 == 0) {
        // 0x803068D8: addu        $a0, $s2, $s0
        ctx->r4 = ADD32(ctx->r18, ctx->r16);
            goto L_80306954;
    }
    // 0x803068D8: addu        $a0, $s2, $s0
    ctx->r4 = ADD32(ctx->r18, ctx->r16);
    // 0x803068DC: sll         $a1, $s3, 16
    ctx->r5 = S32(ctx->r19 << 16);
    // 0x803068E0: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x803068E4: sra         $t0, $a3, 16
    ctx->r8 = S32(SIGNED(ctx->r7) >> 16);
    // 0x803068E8: sra         $t9, $a1, 16
    ctx->r25 = S32(SIGNED(ctx->r5) >> 16);
    // 0x803068EC: sll         $t7, $a0, 16
    ctx->r15 = S32(ctx->r4 << 16);
    // 0x803068F0: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
    // 0x803068F4: sw          $t1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r9;
    // 0x803068F8: sra         $a0, $t7, 16
    ctx->r4 = S32(SIGNED(ctx->r15) >> 16);
    // 0x803068FC: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
    // 0x80306900: or          $a3, $t0, $zero
    ctx->r7 = ctx->r8 | 0;
    // 0x80306904: jal         0x80305DA4
    // 0x80306908: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_10;
    // 0x80306908: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_10:
    // 0x8030690C: beq         $v0, $zero, L_80306954
    if (ctx->r2 == 0) {
        // 0x80306910: sll         $a0, $s2, 16
        ctx->r4 = S32(ctx->r18 << 16);
            goto L_80306954;
    }
    // 0x80306910: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
    // 0x80306914: subu        $a1, $s3, $s0
    ctx->r5 = SUB32(ctx->r19, ctx->r16);
    // 0x80306918: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x8030691C: sra         $t5, $a3, 16
    ctx->r13 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306920: sll         $t3, $a1, 16
    ctx->r11 = S32(ctx->r5 << 16);
    // 0x80306924: sra         $t2, $a0, 16
    ctx->r10 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80306928: addiu       $t6, $zero, 0x2
    ctx->r14 = ADD32(0, 0X2);
    // 0x8030692C: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80306930: or          $a0, $t2, $zero
    ctx->r4 = ctx->r10 | 0;
    // 0x80306934: sra         $a1, $t3, 16
    ctx->r5 = S32(SIGNED(ctx->r11) >> 16);
    // 0x80306938: or          $a3, $t5, $zero
    ctx->r7 = ctx->r13 | 0;
    // 0x8030693C: jal         0x80305DA4
    // 0x80306940: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_11;
    // 0x80306940: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_11:
    // 0x80306944: beql        $v0, $zero, L_80306958
    if (ctx->r2 == 0) {
        // 0x80306948: sll         $a0, $s2, 16
        ctx->r4 = S32(ctx->r18 << 16);
            goto L_80306958;
    }
    goto skip_2;
    // 0x80306948: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
    skip_2:
    // 0x8030694C: b           L_803071A0
    // 0x80306950: addiu       $v0, $zero, 0x9
    ctx->r2 = ADD32(0, 0X9);
        goto L_803071A0;
    // 0x80306950: addiu       $v0, $zero, 0x9
    ctx->r2 = ADD32(0, 0X9);
L_80306954:
    // 0x80306954: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
L_80306958:
    // 0x80306958: sll         $a1, $s3, 16
    ctx->r5 = S32(ctx->r19 << 16);
    // 0x8030695C: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306960: sra         $t9, $a3, 16
    ctx->r25 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306964: sra         $t8, $a1, 16
    ctx->r24 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80306968: sra         $t7, $a0, 16
    ctx->r15 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8030696C: addiu       $t0, $zero, 0x2
    ctx->r8 = ADD32(0, 0X2);
    // 0x80306970: sw          $t0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r8;
    // 0x80306974: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x80306978: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    // 0x8030697C: or          $a3, $t9, $zero
    ctx->r7 = ctx->r25 | 0;
    // 0x80306980: jal         0x80305A70
    // 0x80306984: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305A70_717120(rdram, ctx);
        goto after_12;
    // 0x80306984: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_12:
    // 0x80306988: bne         $v0, $zero, L_80306A38
    if (ctx->r2 != 0) {
        // 0x8030698C: sll         $a0, $s2, 16
        ctx->r4 = S32(ctx->r18 << 16);
            goto L_80306A38;
    }
    // 0x8030698C: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
    // 0x80306990: sll         $a1, $s3, 16
    ctx->r5 = S32(ctx->r19 << 16);
    // 0x80306994: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306998: sra         $t3, $a3, 16
    ctx->r11 = S32(SIGNED(ctx->r7) >> 16);
    // 0x8030699C: sra         $t2, $a1, 16
    ctx->r10 = S32(SIGNED(ctx->r5) >> 16);
    // 0x803069A0: sra         $t1, $a0, 16
    ctx->r9 = S32(SIGNED(ctx->r4) >> 16);
    // 0x803069A4: or          $a0, $t1, $zero
    ctx->r4 = ctx->r9 | 0;
    // 0x803069A8: or          $a1, $t2, $zero
    ctx->r5 = ctx->r10 | 0;
    // 0x803069AC: or          $a3, $t3, $zero
    ctx->r7 = ctx->r11 | 0;
    // 0x803069B0: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    // 0x803069B4: jal         0x80305A70
    // 0x803069B8: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    func_80305A70_717120(rdram, ctx);
        goto after_13;
    // 0x803069B8: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_13:
    // 0x803069BC: beq         $v0, $zero, L_80306A38
    if (ctx->r2 == 0) {
        // 0x803069C0: subu        $a0, $s2, $s0
        ctx->r4 = SUB32(ctx->r18, ctx->r16);
            goto L_80306A38;
    }
    // 0x803069C0: subu        $a0, $s2, $s0
    ctx->r4 = SUB32(ctx->r18, ctx->r16);
    // 0x803069C4: sll         $a1, $s3, 16
    ctx->r5 = S32(ctx->r19 << 16);
    // 0x803069C8: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x803069CC: sra         $t7, $a3, 16
    ctx->r15 = S32(SIGNED(ctx->r7) >> 16);
    // 0x803069D0: sra         $t6, $a1, 16
    ctx->r14 = S32(SIGNED(ctx->r5) >> 16);
    // 0x803069D4: sll         $t4, $a0, 16
    ctx->r12 = S32(ctx->r4 << 16);
    // 0x803069D8: sra         $a0, $t4, 16
    ctx->r4 = S32(SIGNED(ctx->r12) >> 16);
    // 0x803069DC: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x803069E0: or          $a3, $t7, $zero
    ctx->r7 = ctx->r15 | 0;
    // 0x803069E4: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    // 0x803069E8: jal         0x80305DA4
    // 0x803069EC: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_14;
    // 0x803069EC: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_14:
    // 0x803069F0: beq         $v0, $zero, L_80306A38
    if (ctx->r2 == 0) {
        // 0x803069F4: sll         $a0, $s2, 16
        ctx->r4 = S32(ctx->r18 << 16);
            goto L_80306A38;
    }
    // 0x803069F4: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
    // 0x803069F8: subu        $a1, $s3, $s0
    ctx->r5 = SUB32(ctx->r19, ctx->r16);
    // 0x803069FC: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306A00: sra         $t1, $a3, 16
    ctx->r9 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306A04: sll         $t9, $a1, 16
    ctx->r25 = S32(ctx->r5 << 16);
    // 0x80306A08: sra         $t8, $a0, 16
    ctx->r24 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80306A0C: addiu       $t2, $zero, 0x2
    ctx->r10 = ADD32(0, 0X2);
    // 0x80306A10: sw          $t2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r10;
    // 0x80306A14: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    // 0x80306A18: sra         $a1, $t9, 16
    ctx->r5 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80306A1C: or          $a3, $t1, $zero
    ctx->r7 = ctx->r9 | 0;
    // 0x80306A20: jal         0x80305DA4
    // 0x80306A24: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_15;
    // 0x80306A24: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_15:
    // 0x80306A28: beq         $v0, $zero, L_80306A38
    if (ctx->r2 == 0) {
        // 0x80306A2C: nop
    
            goto L_80306A38;
    }
    // 0x80306A2C: nop

    // 0x80306A30: b           L_803071A0
    // 0x80306A34: addiu       $v0, $zero, 0xA
    ctx->r2 = ADD32(0, 0XA);
        goto L_803071A0;
    // 0x80306A34: addiu       $v0, $zero, 0xA
    ctx->r2 = ADD32(0, 0XA);
L_80306A38:
    // 0x80306A38: b           L_803071A0
    // 0x80306A3C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_803071A0;
    // 0x80306A3C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80306A40:
    // 0x80306A40: addu        $a0, $s2, $s0
    ctx->r4 = ADD32(ctx->r18, ctx->r16);
    // 0x80306A44: sll         $t3, $a0, 16
    ctx->r11 = S32(ctx->r4 << 16);
    // 0x80306A48: sll         $a1, $s3, 16
    ctx->r5 = S32(ctx->r19 << 16);
    // 0x80306A4C: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306A50: sra         $t6, $a3, 16
    ctx->r14 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306A54: sra         $t5, $a1, 16
    ctx->r13 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80306A58: sra         $a0, $t3, 16
    ctx->r4 = S32(SIGNED(ctx->r11) >> 16);
    // 0x80306A5C: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x80306A60: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80306A64: sw          $a0, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r4;
    // 0x80306A68: or          $a1, $t5, $zero
    ctx->r5 = ctx->r13 | 0;
    // 0x80306A6C: or          $a3, $t6, $zero
    ctx->r7 = ctx->r14 | 0;
    // 0x80306A70: jal         0x80305DA4
    // 0x80306A74: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_16;
    // 0x80306A74: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_16:
    // 0x80306A78: beq         $v0, $zero, L_80306A88
    if (ctx->r2 == 0) {
        // 0x80306A7C: sll         $a0, $s2, 16
        ctx->r4 = S32(ctx->r18 << 16);
            goto L_80306A88;
    }
    // 0x80306A7C: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
    // 0x80306A80: b           L_803071A0
    // 0x80306A84: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_803071A0;
    // 0x80306A84: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_80306A88:
    // 0x80306A88: addu        $a1, $s3, $s0
    ctx->r5 = ADD32(ctx->r19, ctx->r16);
    // 0x80306A8C: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306A90: sra         $t1, $a3, 16
    ctx->r9 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306A94: sll         $t9, $a1, 16
    ctx->r25 = S32(ctx->r5 << 16);
    // 0x80306A98: sra         $t8, $a0, 16
    ctx->r24 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80306A9C: addiu       $t2, $zero, 0x3
    ctx->r10 = ADD32(0, 0X3);
    // 0x80306AA0: sw          $t2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r10;
    // 0x80306AA4: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    // 0x80306AA8: sra         $a1, $t9, 16
    ctx->r5 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80306AAC: or          $a3, $t1, $zero
    ctx->r7 = ctx->r9 | 0;
    // 0x80306AB0: jal         0x80305DA4
    // 0x80306AB4: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_17;
    // 0x80306AB4: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_17:
    // 0x80306AB8: beq         $v0, $zero, L_80306AF8
    if (ctx->r2 == 0) {
        // 0x80306ABC: lh          $a0, 0x36($sp)
        ctx->r4 = MEM_H(ctx->r29, 0X36);
            goto L_80306AF8;
    }
    // 0x80306ABC: lh          $a0, 0x36($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X36);
    // 0x80306AC0: sll         $a1, $s3, 16
    ctx->r5 = S32(ctx->r19 << 16);
    // 0x80306AC4: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306AC8: sra         $t4, $a3, 16
    ctx->r12 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306ACC: sra         $t3, $a1, 16
    ctx->r11 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80306AD0: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
    // 0x80306AD4: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x80306AD8: or          $a1, $t3, $zero
    ctx->r5 = ctx->r11 | 0;
    // 0x80306ADC: or          $a3, $t4, $zero
    ctx->r7 = ctx->r12 | 0;
    // 0x80306AE0: jal         0x80305A70
    // 0x80306AE4: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305A70_717120(rdram, ctx);
        goto after_18;
    // 0x80306AE4: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_18:
    // 0x80306AE8: beql        $v0, $zero, L_80306AFC
    if (ctx->r2 == 0) {
        // 0x80306AEC: sll         $a0, $s2, 16
        ctx->r4 = S32(ctx->r18 << 16);
            goto L_80306AFC;
    }
    goto skip_3;
    // 0x80306AEC: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
    skip_3:
    // 0x80306AF0: b           L_803071A0
    // 0x80306AF4: addiu       $v0, $zero, 0x5
    ctx->r2 = ADD32(0, 0X5);
        goto L_803071A0;
    // 0x80306AF4: addiu       $v0, $zero, 0x5
    ctx->r2 = ADD32(0, 0X5);
L_80306AF8:
    // 0x80306AF8: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
L_80306AFC:
    // 0x80306AFC: subu        $a1, $s3, $s0
    ctx->r5 = SUB32(ctx->r19, ctx->r16);
    // 0x80306B00: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306B04: sra         $t9, $a3, 16
    ctx->r25 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306B08: sll         $t7, $a1, 16
    ctx->r15 = S32(ctx->r5 << 16);
    // 0x80306B0C: sra         $t6, $a0, 16
    ctx->r14 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80306B10: addiu       $t0, $zero, 0x2
    ctx->r8 = ADD32(0, 0X2);
    // 0x80306B14: sw          $t0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r8;
    // 0x80306B18: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    // 0x80306B1C: sra         $a1, $t7, 16
    ctx->r5 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80306B20: or          $a3, $t9, $zero
    ctx->r7 = ctx->r25 | 0;
    // 0x80306B24: jal         0x80305DA4
    // 0x80306B28: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_19;
    // 0x80306B28: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_19:
    // 0x80306B2C: beq         $v0, $zero, L_8030719C
    if (ctx->r2 == 0) {
        // 0x80306B30: lh          $a0, 0x36($sp)
        ctx->r4 = MEM_H(ctx->r29, 0X36);
            goto L_8030719C;
    }
    // 0x80306B30: lh          $a0, 0x36($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X36);
    // 0x80306B34: sll         $a1, $s3, 16
    ctx->r5 = S32(ctx->r19 << 16);
    // 0x80306B38: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306B3C: sra         $t2, $a3, 16
    ctx->r10 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306B40: sra         $t1, $a1, 16
    ctx->r9 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80306B44: or          $a1, $t1, $zero
    ctx->r5 = ctx->r9 | 0;
    // 0x80306B48: or          $a3, $t2, $zero
    ctx->r7 = ctx->r10 | 0;
    // 0x80306B4C: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    // 0x80306B50: jal         0x80305A70
    // 0x80306B54: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    func_80305A70_717120(rdram, ctx);
        goto after_20;
    // 0x80306B54: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_20:
    // 0x80306B58: beql        $v0, $zero, L_803071A0
    if (ctx->r2 == 0) {
        // 0x80306B5C: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_803071A0;
    }
    goto skip_4;
    // 0x80306B5C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_4:
    // 0x80306B60: b           L_803071A0
    // 0x80306B64: addiu       $v0, $zero, 0x9
    ctx->r2 = ADD32(0, 0X9);
        goto L_803071A0;
    // 0x80306B64: addiu       $v0, $zero, 0x9
    ctx->r2 = ADD32(0, 0X9);
L_80306B68:
    // 0x80306B68: subu        $a0, $s2, $s0
    ctx->r4 = SUB32(ctx->r18, ctx->r16);
    // 0x80306B6C: sll         $t3, $a0, 16
    ctx->r11 = S32(ctx->r4 << 16);
    // 0x80306B70: sll         $a1, $s3, 16
    ctx->r5 = S32(ctx->r19 << 16);
    // 0x80306B74: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306B78: sra         $t6, $a3, 16
    ctx->r14 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306B7C: sra         $t5, $a1, 16
    ctx->r13 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80306B80: sra         $a0, $t3, 16
    ctx->r4 = S32(SIGNED(ctx->r11) >> 16);
    // 0x80306B84: sw          $a0, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r4;
    // 0x80306B88: or          $a1, $t5, $zero
    ctx->r5 = ctx->r13 | 0;
    // 0x80306B8C: or          $a3, $t6, $zero
    ctx->r7 = ctx->r14 | 0;
    // 0x80306B90: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    // 0x80306B94: jal         0x80305DA4
    // 0x80306B98: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_21;
    // 0x80306B98: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_21:
    // 0x80306B9C: beq         $v0, $zero, L_80306BAC
    if (ctx->r2 == 0) {
        // 0x80306BA0: sll         $a0, $s2, 16
        ctx->r4 = S32(ctx->r18 << 16);
            goto L_80306BAC;
    }
    // 0x80306BA0: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
    // 0x80306BA4: b           L_803071A0
    // 0x80306BA8: addiu       $v0, $zero, 0x2
    ctx->r2 = ADD32(0, 0X2);
        goto L_803071A0;
    // 0x80306BA8: addiu       $v0, $zero, 0x2
    ctx->r2 = ADD32(0, 0X2);
L_80306BAC:
    // 0x80306BAC: addu        $a1, $s3, $s0
    ctx->r5 = ADD32(ctx->r19, ctx->r16);
    // 0x80306BB0: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306BB4: sra         $t0, $a3, 16
    ctx->r8 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306BB8: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x80306BBC: sra         $t7, $a0, 16
    ctx->r15 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80306BC0: addiu       $t1, $zero, 0x3
    ctx->r9 = ADD32(0, 0X3);
    // 0x80306BC4: sw          $t1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r9;
    // 0x80306BC8: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x80306BCC: sra         $a1, $t8, 16
    ctx->r5 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80306BD0: or          $a3, $t0, $zero
    ctx->r7 = ctx->r8 | 0;
    // 0x80306BD4: jal         0x80305DA4
    // 0x80306BD8: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_22;
    // 0x80306BD8: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_22:
    // 0x80306BDC: beq         $v0, $zero, L_80306C1C
    if (ctx->r2 == 0) {
        // 0x80306BE0: lh          $a0, 0x36($sp)
        ctx->r4 = MEM_H(ctx->r29, 0X36);
            goto L_80306C1C;
    }
    // 0x80306BE0: lh          $a0, 0x36($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X36);
    // 0x80306BE4: sll         $a1, $s3, 16
    ctx->r5 = S32(ctx->r19 << 16);
    // 0x80306BE8: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306BEC: sra         $t3, $a3, 16
    ctx->r11 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306BF0: sra         $t2, $a1, 16
    ctx->r10 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80306BF4: addiu       $t4, $zero, 0x2
    ctx->r12 = ADD32(0, 0X2);
    // 0x80306BF8: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x80306BFC: or          $a1, $t2, $zero
    ctx->r5 = ctx->r10 | 0;
    // 0x80306C00: or          $a3, $t3, $zero
    ctx->r7 = ctx->r11 | 0;
    // 0x80306C04: jal         0x80305A70
    // 0x80306C08: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305A70_717120(rdram, ctx);
        goto after_23;
    // 0x80306C08: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_23:
    // 0x80306C0C: beql        $v0, $zero, L_80306C20
    if (ctx->r2 == 0) {
        // 0x80306C10: sll         $a0, $s2, 16
        ctx->r4 = S32(ctx->r18 << 16);
            goto L_80306C20;
    }
    goto skip_5;
    // 0x80306C10: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
    skip_5:
    // 0x80306C14: b           L_803071A0
    // 0x80306C18: addiu       $v0, $zero, 0x6
    ctx->r2 = ADD32(0, 0X6);
        goto L_803071A0;
    // 0x80306C18: addiu       $v0, $zero, 0x6
    ctx->r2 = ADD32(0, 0X6);
L_80306C1C:
    // 0x80306C1C: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
L_80306C20:
    // 0x80306C20: subu        $a1, $s3, $s0
    ctx->r5 = SUB32(ctx->r19, ctx->r16);
    // 0x80306C24: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306C28: sra         $t8, $a3, 16
    ctx->r24 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306C2C: sll         $t6, $a1, 16
    ctx->r14 = S32(ctx->r5 << 16);
    // 0x80306C30: sra         $t5, $a0, 16
    ctx->r13 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80306C34: addiu       $t9, $zero, 0x2
    ctx->r25 = ADD32(0, 0X2);
    // 0x80306C38: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x80306C3C: or          $a0, $t5, $zero
    ctx->r4 = ctx->r13 | 0;
    // 0x80306C40: sra         $a1, $t6, 16
    ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80306C44: or          $a3, $t8, $zero
    ctx->r7 = ctx->r24 | 0;
    // 0x80306C48: jal         0x80305DA4
    // 0x80306C4C: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_24;
    // 0x80306C4C: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_24:
    // 0x80306C50: beq         $v0, $zero, L_8030719C
    if (ctx->r2 == 0) {
        // 0x80306C54: lh          $a0, 0x36($sp)
        ctx->r4 = MEM_H(ctx->r29, 0X36);
            goto L_8030719C;
    }
    // 0x80306C54: lh          $a0, 0x36($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X36);
    // 0x80306C58: sll         $a1, $s3, 16
    ctx->r5 = S32(ctx->r19 << 16);
    // 0x80306C5C: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306C60: sra         $t1, $a3, 16
    ctx->r9 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306C64: sra         $t0, $a1, 16
    ctx->r8 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80306C68: addiu       $t2, $zero, 0x3
    ctx->r10 = ADD32(0, 0X3);
    // 0x80306C6C: sw          $t2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r10;
    // 0x80306C70: or          $a1, $t0, $zero
    ctx->r5 = ctx->r8 | 0;
    // 0x80306C74: or          $a3, $t1, $zero
    ctx->r7 = ctx->r9 | 0;
    // 0x80306C78: jal         0x80305A70
    // 0x80306C7C: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305A70_717120(rdram, ctx);
        goto after_25;
    // 0x80306C7C: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_25:
    // 0x80306C80: beql        $v0, $zero, L_803071A0
    if (ctx->r2 == 0) {
        // 0x80306C84: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_803071A0;
    }
    goto skip_6;
    // 0x80306C84: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_6:
    // 0x80306C88: b           L_803071A0
    // 0x80306C8C: addiu       $v0, $zero, 0xA
    ctx->r2 = ADD32(0, 0XA);
        goto L_803071A0;
    // 0x80306C8C: addiu       $v0, $zero, 0xA
    ctx->r2 = ADD32(0, 0XA);
L_80306C90:
    // 0x80306C90: b           L_803071A0
    // 0x80306C94: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_803071A0;
    // 0x80306C94: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80306C98:
    // 0x80306C98: addu        $a1, $s3, $s0
    ctx->r5 = ADD32(ctx->r19, ctx->r16);
    // 0x80306C9C: sll         $t4, $a1, 16
    ctx->r12 = S32(ctx->r5 << 16);
    // 0x80306CA0: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
    // 0x80306CA4: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306CA8: sra         $t6, $a3, 16
    ctx->r14 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306CAC: sra         $t3, $a0, 16
    ctx->r11 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80306CB0: sra         $a1, $t4, 16
    ctx->r5 = S32(SIGNED(ctx->r12) >> 16);
    // 0x80306CB4: addiu       $t7, $zero, 0x3
    ctx->r15 = ADD32(0, 0X3);
    // 0x80306CB8: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80306CBC: sw          $a1, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r5;
    // 0x80306CC0: or          $a0, $t3, $zero
    ctx->r4 = ctx->r11 | 0;
    // 0x80306CC4: or          $a3, $t6, $zero
    ctx->r7 = ctx->r14 | 0;
    // 0x80306CC8: jal         0x80305DA4
    // 0x80306CCC: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_26;
    // 0x80306CCC: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_26:
    // 0x80306CD0: beq         $v0, $zero, L_80306CE0
    if (ctx->r2 == 0) {
        // 0x80306CD4: subu        $a0, $s2, $s0
        ctx->r4 = SUB32(ctx->r18, ctx->r16);
            goto L_80306CE0;
    }
    // 0x80306CD4: subu        $a0, $s2, $s0
    ctx->r4 = SUB32(ctx->r18, ctx->r16);
    // 0x80306CD8: b           L_803071A0
    // 0x80306CDC: addiu       $v0, $zero, 0x4
    ctx->r2 = ADD32(0, 0X4);
        goto L_803071A0;
    // 0x80306CDC: addiu       $v0, $zero, 0x4
    ctx->r2 = ADD32(0, 0X4);
L_80306CE0:
    // 0x80306CE0: sll         $a1, $s3, 16
    ctx->r5 = S32(ctx->r19 << 16);
    // 0x80306CE4: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306CE8: sra         $t1, $a3, 16
    ctx->r9 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306CEC: sra         $t0, $a1, 16
    ctx->r8 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80306CF0: sll         $t8, $a0, 16
    ctx->r24 = S32(ctx->r4 << 16);
    // 0x80306CF4: sra         $a0, $t8, 16
    ctx->r4 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80306CF8: or          $a1, $t0, $zero
    ctx->r5 = ctx->r8 | 0;
    // 0x80306CFC: or          $a3, $t1, $zero
    ctx->r7 = ctx->r9 | 0;
    // 0x80306D00: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    // 0x80306D04: jal         0x80305DA4
    // 0x80306D08: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_27;
    // 0x80306D08: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_27:
    // 0x80306D0C: beq         $v0, $zero, L_80306D48
    if (ctx->r2 == 0) {
        // 0x80306D10: sll         $a0, $s2, 16
        ctx->r4 = S32(ctx->r18 << 16);
            goto L_80306D48;
    }
    // 0x80306D10: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
    // 0x80306D14: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306D18: sra         $t3, $a3, 16
    ctx->r11 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306D1C: sra         $t2, $a0, 16
    ctx->r10 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80306D20: or          $a0, $t2, $zero
    ctx->r4 = ctx->r10 | 0;
    // 0x80306D24: or          $a3, $t3, $zero
    ctx->r7 = ctx->r11 | 0;
    // 0x80306D28: lh          $a1, 0x32($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X32);
    // 0x80306D2C: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    // 0x80306D30: jal         0x80305A70
    // 0x80306D34: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    func_80305A70_717120(rdram, ctx);
        goto after_28;
    // 0x80306D34: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_28:
    // 0x80306D38: beql        $v0, $zero, L_80306D4C
    if (ctx->r2 == 0) {
        // 0x80306D3C: addu        $a0, $s2, $s0
        ctx->r4 = ADD32(ctx->r18, ctx->r16);
            goto L_80306D4C;
    }
    goto skip_7;
    // 0x80306D3C: addu        $a0, $s2, $s0
    ctx->r4 = ADD32(ctx->r18, ctx->r16);
    skip_7:
    // 0x80306D40: b           L_803071A0
    // 0x80306D44: addiu       $v0, $zero, 0x6
    ctx->r2 = ADD32(0, 0X6);
        goto L_803071A0;
    // 0x80306D44: addiu       $v0, $zero, 0x6
    ctx->r2 = ADD32(0, 0X6);
L_80306D48:
    // 0x80306D48: addu        $a0, $s2, $s0
    ctx->r4 = ADD32(ctx->r18, ctx->r16);
L_80306D4C:
    // 0x80306D4C: sll         $a1, $s3, 16
    ctx->r5 = S32(ctx->r19 << 16);
    // 0x80306D50: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306D54: sra         $t7, $a3, 16
    ctx->r15 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306D58: sra         $t6, $a1, 16
    ctx->r14 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80306D5C: sll         $t4, $a0, 16
    ctx->r12 = S32(ctx->r4 << 16);
    // 0x80306D60: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x80306D64: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80306D68: sra         $a0, $t4, 16
    ctx->r4 = S32(SIGNED(ctx->r12) >> 16);
    // 0x80306D6C: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x80306D70: or          $a3, $t7, $zero
    ctx->r7 = ctx->r15 | 0;
    // 0x80306D74: jal         0x80305DA4
    // 0x80306D78: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_29;
    // 0x80306D78: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_29:
    // 0x80306D7C: beq         $v0, $zero, L_8030719C
    if (ctx->r2 == 0) {
        // 0x80306D80: sll         $a0, $s2, 16
        ctx->r4 = S32(ctx->r18 << 16);
            goto L_8030719C;
    }
    // 0x80306D80: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
    // 0x80306D84: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306D88: sra         $t0, $a3, 16
    ctx->r8 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306D8C: sra         $t9, $a0, 16
    ctx->r25 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80306D90: addiu       $t1, $zero, 0x3
    ctx->r9 = ADD32(0, 0X3);
    // 0x80306D94: sw          $t1, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r9;
    // 0x80306D98: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    // 0x80306D9C: or          $a3, $t0, $zero
    ctx->r7 = ctx->r8 | 0;
    // 0x80306DA0: lh          $a1, 0x32($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X32);
    // 0x80306DA4: jal         0x80305A70
    // 0x80306DA8: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305A70_717120(rdram, ctx);
        goto after_30;
    // 0x80306DA8: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_30:
    // 0x80306DAC: beql        $v0, $zero, L_803071A0
    if (ctx->r2 == 0) {
        // 0x80306DB0: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_803071A0;
    }
    goto skip_8;
    // 0x80306DB0: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_8:
    // 0x80306DB4: b           L_803071A0
    // 0x80306DB8: addiu       $v0, $zero, 0x5
    ctx->r2 = ADD32(0, 0X5);
        goto L_803071A0;
    // 0x80306DB8: addiu       $v0, $zero, 0x5
    ctx->r2 = ADD32(0, 0X5);
L_80306DBC:
    // 0x80306DBC: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
    // 0x80306DC0: sll         $a1, $s3, 16
    ctx->r5 = S32(ctx->r19 << 16);
    // 0x80306DC4: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306DC8: sra         $t4, $a3, 16
    ctx->r12 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306DCC: sra         $t3, $a1, 16
    ctx->r11 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80306DD0: sra         $t2, $a0, 16
    ctx->r10 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80306DD4: or          $a0, $t2, $zero
    ctx->r4 = ctx->r10 | 0;
    // 0x80306DD8: or          $a1, $t3, $zero
    ctx->r5 = ctx->r11 | 0;
    // 0x80306DDC: or          $a3, $t4, $zero
    ctx->r7 = ctx->r12 | 0;
    // 0x80306DE0: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    // 0x80306DE4: jal         0x80305A70
    // 0x80306DE8: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    func_80305A70_717120(rdram, ctx);
        goto after_31;
    // 0x80306DE8: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_31:
    // 0x80306DEC: bne         $v0, $zero, L_8030719C
    if (ctx->r2 != 0) {
        // 0x80306DF0: addu        $a0, $s2, $s0
        ctx->r4 = ADD32(ctx->r18, ctx->r16);
            goto L_8030719C;
    }
    // 0x80306DF0: addu        $a0, $s2, $s0
    ctx->r4 = ADD32(ctx->r18, ctx->r16);
    // 0x80306DF4: addu        $a1, $s3, $s0
    ctx->r5 = ADD32(ctx->r19, ctx->r16);
    // 0x80306DF8: sll         $t7, $a1, 16
    ctx->r15 = S32(ctx->r5 << 16);
    // 0x80306DFC: sll         $t5, $a0, 16
    ctx->r13 = S32(ctx->r4 << 16);
    // 0x80306E00: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306E04: sra         $t9, $a3, 16
    ctx->r25 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306E08: sra         $a0, $t5, 16
    ctx->r4 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80306E0C: sra         $a1, $t7, 16
    ctx->r5 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80306E10: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x80306E14: sw          $t0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r8;
    // 0x80306E18: sw          $a1, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r5;
    // 0x80306E1C: sw          $a0, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r4;
    // 0x80306E20: or          $a3, $t9, $zero
    ctx->r7 = ctx->r25 | 0;
    // 0x80306E24: jal         0x80305DA4
    // 0x80306E28: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_32;
    // 0x80306E28: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_32:
    // 0x80306E2C: bne         $v0, $zero, L_80306E5C
    if (ctx->r2 != 0) {
        // 0x80306E30: lh          $a0, 0x36($sp)
        ctx->r4 = MEM_H(ctx->r29, 0X36);
            goto L_80306E5C;
    }
    // 0x80306E30: lh          $a0, 0x36($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X36);
    // 0x80306E34: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306E38: sra         $t1, $a3, 16
    ctx->r9 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306E3C: addiu       $t2, $zero, 0x3
    ctx->r10 = ADD32(0, 0X3);
    // 0x80306E40: sw          $t2, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r10;
    // 0x80306E44: or          $a3, $t1, $zero
    ctx->r7 = ctx->r9 | 0;
    // 0x80306E48: lh          $a1, 0x32($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X32);
    // 0x80306E4C: jal         0x80305DA4
    // 0x80306E50: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_33;
    // 0x80306E50: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_33:
    // 0x80306E54: beql        $v0, $zero, L_803071A0
    if (ctx->r2 == 0) {
        // 0x80306E58: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_803071A0;
    }
    goto skip_9;
    // 0x80306E58: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_9:
L_80306E5C:
    // 0x80306E5C: b           L_803071A0
    // 0x80306E60: addiu       $v0, $zero, 0x5
    ctx->r2 = ADD32(0, 0X5);
        goto L_803071A0;
    // 0x80306E60: addiu       $v0, $zero, 0x5
    ctx->r2 = ADD32(0, 0X5);
L_80306E64:
    // 0x80306E64: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
    // 0x80306E68: sll         $a1, $s3, 16
    ctx->r5 = S32(ctx->r19 << 16);
    // 0x80306E6C: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306E70: sra         $t5, $a3, 16
    ctx->r13 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306E74: sra         $t4, $a1, 16
    ctx->r12 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80306E78: sra         $t3, $a0, 16
    ctx->r11 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80306E7C: addiu       $t6, $zero, 0x3
    ctx->r14 = ADD32(0, 0X3);
    // 0x80306E80: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80306E84: or          $a0, $t3, $zero
    ctx->r4 = ctx->r11 | 0;
    // 0x80306E88: or          $a1, $t4, $zero
    ctx->r5 = ctx->r12 | 0;
    // 0x80306E8C: or          $a3, $t5, $zero
    ctx->r7 = ctx->r13 | 0;
    // 0x80306E90: jal         0x80305A70
    // 0x80306E94: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305A70_717120(rdram, ctx);
        goto after_34;
    // 0x80306E94: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_34:
    // 0x80306E98: bne         $v0, $zero, L_80306F04
    if (ctx->r2 != 0) {
        // 0x80306E9C: subu        $a0, $s2, $s0
        ctx->r4 = SUB32(ctx->r18, ctx->r16);
            goto L_80306F04;
    }
    // 0x80306E9C: subu        $a0, $s2, $s0
    ctx->r4 = SUB32(ctx->r18, ctx->r16);
    // 0x80306EA0: addu        $a1, $s3, $s0
    ctx->r5 = ADD32(ctx->r19, ctx->r16);
    // 0x80306EA4: sll         $t9, $a1, 16
    ctx->r25 = S32(ctx->r5 << 16);
    // 0x80306EA8: sll         $t7, $a0, 16
    ctx->r15 = S32(ctx->r4 << 16);
    // 0x80306EAC: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306EB0: sra         $t1, $a3, 16
    ctx->r9 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306EB4: sra         $a0, $t7, 16
    ctx->r4 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80306EB8: sra         $a1, $t9, 16
    ctx->r5 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80306EBC: sw          $a1, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r5;
    // 0x80306EC0: sw          $a0, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r4;
    // 0x80306EC4: or          $a3, $t1, $zero
    ctx->r7 = ctx->r9 | 0;
    // 0x80306EC8: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    // 0x80306ECC: jal         0x80305DA4
    // 0x80306ED0: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_35;
    // 0x80306ED0: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_35:
    // 0x80306ED4: bne         $v0, $zero, L_8030719C
    if (ctx->r2 != 0) {
        // 0x80306ED8: lh          $a0, 0x36($sp)
        ctx->r4 = MEM_H(ctx->r29, 0X36);
            goto L_8030719C;
    }
    // 0x80306ED8: lh          $a0, 0x36($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X36);
    // 0x80306EDC: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306EE0: sra         $t2, $a3, 16
    ctx->r10 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306EE4: addiu       $t3, $zero, 0x3
    ctx->r11 = ADD32(0, 0X3);
    // 0x80306EE8: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    // 0x80306EEC: or          $a3, $t2, $zero
    ctx->r7 = ctx->r10 | 0;
    // 0x80306EF0: lh          $a1, 0x32($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X32);
    // 0x80306EF4: jal         0x80305DA4
    // 0x80306EF8: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_36;
    // 0x80306EF8: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_36:
    // 0x80306EFC: bnel        $v0, $zero, L_803071A0
    if (ctx->r2 != 0) {
        // 0x80306F00: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_803071A0;
    }
    goto skip_10;
    // 0x80306F00: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_10:
L_80306F04:
    // 0x80306F04: b           L_803071A0
    // 0x80306F08: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_803071A0;
    // 0x80306F08: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80306F0C:
    // 0x80306F0C: subu        $a1, $s3, $s0
    ctx->r5 = SUB32(ctx->r19, ctx->r16);
    // 0x80306F10: sll         $t5, $a1, 16
    ctx->r13 = S32(ctx->r5 << 16);
    // 0x80306F14: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
    // 0x80306F18: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306F1C: sra         $t7, $a3, 16
    ctx->r15 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306F20: sra         $t4, $a0, 16
    ctx->r12 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80306F24: sra         $a1, $t5, 16
    ctx->r5 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80306F28: addiu       $t8, $zero, 0x2
    ctx->r24 = ADD32(0, 0X2);
    // 0x80306F2C: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80306F30: sw          $a1, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r5;
    // 0x80306F34: or          $a0, $t4, $zero
    ctx->r4 = ctx->r12 | 0;
    // 0x80306F38: or          $a3, $t7, $zero
    ctx->r7 = ctx->r15 | 0;
    // 0x80306F3C: jal         0x80305DA4
    // 0x80306F40: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_37;
    // 0x80306F40: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_37:
    // 0x80306F44: beq         $v0, $zero, L_80306F54
    if (ctx->r2 == 0) {
        // 0x80306F48: subu        $a0, $s2, $s0
        ctx->r4 = SUB32(ctx->r18, ctx->r16);
            goto L_80306F54;
    }
    // 0x80306F48: subu        $a0, $s2, $s0
    ctx->r4 = SUB32(ctx->r18, ctx->r16);
    // 0x80306F4C: b           L_803071A0
    // 0x80306F50: addiu       $v0, $zero, 0x8
    ctx->r2 = ADD32(0, 0X8);
        goto L_803071A0;
    // 0x80306F50: addiu       $v0, $zero, 0x8
    ctx->r2 = ADD32(0, 0X8);
L_80306F54:
    // 0x80306F54: sll         $a1, $s3, 16
    ctx->r5 = S32(ctx->r19 << 16);
    // 0x80306F58: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306F5C: sra         $t2, $a3, 16
    ctx->r10 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306F60: sra         $t1, $a1, 16
    ctx->r9 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80306F64: sll         $t9, $a0, 16
    ctx->r25 = S32(ctx->r4 << 16);
    // 0x80306F68: sra         $a0, $t9, 16
    ctx->r4 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80306F6C: or          $a1, $t1, $zero
    ctx->r5 = ctx->r9 | 0;
    // 0x80306F70: or          $a3, $t2, $zero
    ctx->r7 = ctx->r10 | 0;
    // 0x80306F74: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    // 0x80306F78: jal         0x80305DA4
    // 0x80306F7C: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_38;
    // 0x80306F7C: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_38:
    // 0x80306F80: beq         $v0, $zero, L_80306FC0
    if (ctx->r2 == 0) {
        // 0x80306F84: sll         $a0, $s2, 16
        ctx->r4 = S32(ctx->r18 << 16);
            goto L_80306FC0;
    }
    // 0x80306F84: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
    // 0x80306F88: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306F8C: sra         $t4, $a3, 16
    ctx->r12 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306F90: sra         $t3, $a0, 16
    ctx->r11 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80306F94: addiu       $t5, $zero, 0x1
    ctx->r13 = ADD32(0, 0X1);
    // 0x80306F98: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x80306F9C: or          $a0, $t3, $zero
    ctx->r4 = ctx->r11 | 0;
    // 0x80306FA0: or          $a3, $t4, $zero
    ctx->r7 = ctx->r12 | 0;
    // 0x80306FA4: lh          $a1, 0x32($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X32);
    // 0x80306FA8: jal         0x80305A70
    // 0x80306FAC: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305A70_717120(rdram, ctx);
        goto after_39;
    // 0x80306FAC: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_39:
    // 0x80306FB0: beql        $v0, $zero, L_80306FC4
    if (ctx->r2 == 0) {
        // 0x80306FB4: addu        $a0, $s2, $s0
        ctx->r4 = ADD32(ctx->r18, ctx->r16);
            goto L_80306FC4;
    }
    goto skip_11;
    // 0x80306FB4: addu        $a0, $s2, $s0
    ctx->r4 = ADD32(ctx->r18, ctx->r16);
    skip_11:
    // 0x80306FB8: b           L_803071A0
    // 0x80306FBC: addiu       $v0, $zero, 0xA
    ctx->r2 = ADD32(0, 0XA);
        goto L_803071A0;
    // 0x80306FBC: addiu       $v0, $zero, 0xA
    ctx->r2 = ADD32(0, 0XA);
L_80306FC0:
    // 0x80306FC0: addu        $a0, $s2, $s0
    ctx->r4 = ADD32(ctx->r18, ctx->r16);
L_80306FC4:
    // 0x80306FC4: sll         $a1, $s3, 16
    ctx->r5 = S32(ctx->r19 << 16);
    // 0x80306FC8: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80306FCC: sra         $t9, $a3, 16
    ctx->r25 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80306FD0: sra         $t8, $a1, 16
    ctx->r24 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80306FD4: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x80306FD8: addiu       $t0, $zero, 0x1
    ctx->r8 = ADD32(0, 0X1);
    // 0x80306FDC: sw          $t0, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r8;
    // 0x80306FE0: sra         $a0, $t6, 16
    ctx->r4 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80306FE4: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    // 0x80306FE8: or          $a3, $t9, $zero
    ctx->r7 = ctx->r25 | 0;
    // 0x80306FEC: jal         0x80305DA4
    // 0x80306FF0: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_40;
    // 0x80306FF0: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_40:
    // 0x80306FF4: beq         $v0, $zero, L_8030719C
    if (ctx->r2 == 0) {
        // 0x80306FF8: sll         $a0, $s2, 16
        ctx->r4 = S32(ctx->r18 << 16);
            goto L_8030719C;
    }
    // 0x80306FF8: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
    // 0x80306FFC: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80307000: sra         $t2, $a3, 16
    ctx->r10 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80307004: sra         $t1, $a0, 16
    ctx->r9 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80307008: addiu       $t3, $zero, 0x2
    ctx->r11 = ADD32(0, 0X2);
    // 0x8030700C: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    // 0x80307010: or          $a0, $t1, $zero
    ctx->r4 = ctx->r9 | 0;
    // 0x80307014: or          $a3, $t2, $zero
    ctx->r7 = ctx->r10 | 0;
    // 0x80307018: lh          $a1, 0x32($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X32);
    // 0x8030701C: jal         0x80305A70
    // 0x80307020: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305A70_717120(rdram, ctx);
        goto after_41;
    // 0x80307020: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_41:
    // 0x80307024: beql        $v0, $zero, L_803071A0
    if (ctx->r2 == 0) {
        // 0x80307028: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_803071A0;
    }
    goto skip_12;
    // 0x80307028: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_12:
    // 0x8030702C: b           L_803071A0
    // 0x80307030: addiu       $v0, $zero, 0x9
    ctx->r2 = ADD32(0, 0X9);
        goto L_803071A0;
    // 0x80307030: addiu       $v0, $zero, 0x9
    ctx->r2 = ADD32(0, 0X9);
L_80307034:
    // 0x80307034: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
    // 0x80307038: sll         $a1, $s3, 16
    ctx->r5 = S32(ctx->r19 << 16);
    // 0x8030703C: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80307040: sra         $t6, $a3, 16
    ctx->r14 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80307044: sra         $t5, $a1, 16
    ctx->r13 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80307048: sra         $t4, $a0, 16
    ctx->r12 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8030704C: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x80307050: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80307054: or          $a0, $t4, $zero
    ctx->r4 = ctx->r12 | 0;
    // 0x80307058: or          $a1, $t5, $zero
    ctx->r5 = ctx->r13 | 0;
    // 0x8030705C: or          $a3, $t6, $zero
    ctx->r7 = ctx->r14 | 0;
    // 0x80307060: jal         0x80305A70
    // 0x80307064: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305A70_717120(rdram, ctx);
        goto after_42;
    // 0x80307064: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_42:
    // 0x80307068: bne         $v0, $zero, L_803070D4
    if (ctx->r2 != 0) {
        // 0x8030706C: addu        $a0, $s2, $s0
        ctx->r4 = ADD32(ctx->r18, ctx->r16);
            goto L_803070D4;
    }
    // 0x8030706C: addu        $a0, $s2, $s0
    ctx->r4 = ADD32(ctx->r18, ctx->r16);
    // 0x80307070: subu        $a1, $s3, $s0
    ctx->r5 = SUB32(ctx->r19, ctx->r16);
    // 0x80307074: sll         $t0, $a1, 16
    ctx->r8 = S32(ctx->r5 << 16);
    // 0x80307078: sll         $t8, $a0, 16
    ctx->r24 = S32(ctx->r4 << 16);
    // 0x8030707C: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80307080: sra         $t2, $a3, 16
    ctx->r10 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80307084: sra         $a0, $t8, 16
    ctx->r4 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80307088: sra         $a1, $t0, 16
    ctx->r5 = S32(SIGNED(ctx->r8) >> 16);
    // 0x8030708C: addiu       $t3, $zero, 0x1
    ctx->r11 = ADD32(0, 0X1);
    // 0x80307090: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    // 0x80307094: sw          $a1, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r5;
    // 0x80307098: sw          $a0, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r4;
    // 0x8030709C: or          $a3, $t2, $zero
    ctx->r7 = ctx->r10 | 0;
    // 0x803070A0: jal         0x80305DA4
    // 0x803070A4: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_43;
    // 0x803070A4: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_43:
    // 0x803070A8: bne         $v0, $zero, L_8030719C
    if (ctx->r2 != 0) {
        // 0x803070AC: lh          $a0, 0x36($sp)
        ctx->r4 = MEM_H(ctx->r29, 0X36);
            goto L_8030719C;
    }
    // 0x803070AC: lh          $a0, 0x36($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X36);
    // 0x803070B0: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x803070B4: sra         $t4, $a3, 16
    ctx->r12 = S32(SIGNED(ctx->r7) >> 16);
    // 0x803070B8: addiu       $t5, $zero, 0x2
    ctx->r13 = ADD32(0, 0X2);
    // 0x803070BC: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x803070C0: or          $a3, $t4, $zero
    ctx->r7 = ctx->r12 | 0;
    // 0x803070C4: lh          $a1, 0x32($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X32);
    // 0x803070C8: jal         0x80305DA4
    // 0x803070CC: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_44;
    // 0x803070CC: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_44:
    // 0x803070D0: bne         $v0, $zero, L_8030719C
    if (ctx->r2 != 0) {
        // 0x803070D4: sll         $a0, $s2, 16
        ctx->r4 = S32(ctx->r18 << 16);
            goto L_8030719C;
    }
L_803070D4:
    // 0x803070D4: sll         $a0, $s2, 16
    ctx->r4 = S32(ctx->r18 << 16);
    // 0x803070D8: sll         $a1, $s3, 16
    ctx->r5 = S32(ctx->r19 << 16);
    // 0x803070DC: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x803070E0: sra         $t8, $a3, 16
    ctx->r24 = S32(SIGNED(ctx->r7) >> 16);
    // 0x803070E4: sra         $t7, $a1, 16
    ctx->r15 = S32(SIGNED(ctx->r5) >> 16);
    // 0x803070E8: sra         $t6, $a0, 16
    ctx->r14 = S32(SIGNED(ctx->r4) >> 16);
    // 0x803070EC: addiu       $t9, $zero, 0x2
    ctx->r25 = ADD32(0, 0X2);
    // 0x803070F0: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x803070F4: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    // 0x803070F8: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    // 0x803070FC: or          $a3, $t8, $zero
    ctx->r7 = ctx->r24 | 0;
    // 0x80307100: jal         0x80305A70
    // 0x80307104: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305A70_717120(rdram, ctx);
        goto after_45;
    // 0x80307104: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_45:
    // 0x80307108: bne         $v0, $zero, L_80307174
    if (ctx->r2 != 0) {
        // 0x8030710C: subu        $a0, $s2, $s0
        ctx->r4 = SUB32(ctx->r18, ctx->r16);
            goto L_80307174;
    }
    // 0x8030710C: subu        $a0, $s2, $s0
    ctx->r4 = SUB32(ctx->r18, ctx->r16);
    // 0x80307110: subu        $a1, $s3, $s0
    ctx->r5 = SUB32(ctx->r19, ctx->r16);
    // 0x80307114: sll         $t2, $a1, 16
    ctx->r10 = S32(ctx->r5 << 16);
    // 0x80307118: sll         $t0, $a0, 16
    ctx->r8 = S32(ctx->r4 << 16);
    // 0x8030711C: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80307120: sra         $t4, $a3, 16
    ctx->r12 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80307124: sra         $a0, $t0, 16
    ctx->r4 = S32(SIGNED(ctx->r8) >> 16);
    // 0x80307128: sra         $a1, $t2, 16
    ctx->r5 = S32(SIGNED(ctx->r10) >> 16);
    // 0x8030712C: sw          $a1, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r5;
    // 0x80307130: sw          $a0, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r4;
    // 0x80307134: or          $a3, $t4, $zero
    ctx->r7 = ctx->r12 | 0;
    // 0x80307138: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    // 0x8030713C: jal         0x80305DA4
    // 0x80307140: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_46;
    // 0x80307140: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    after_46:
    // 0x80307144: bne         $v0, $zero, L_8030719C
    if (ctx->r2 != 0) {
        // 0x80307148: lh          $a0, 0x36($sp)
        ctx->r4 = MEM_H(ctx->r29, 0X36);
            goto L_8030719C;
    }
    // 0x80307148: lh          $a0, 0x36($sp)
    ctx->r4 = MEM_H(ctx->r29, 0X36);
    // 0x8030714C: sll         $a3, $s0, 16
    ctx->r7 = S32(ctx->r16 << 16);
    // 0x80307150: sra         $t5, $a3, 16
    ctx->r13 = S32(SIGNED(ctx->r7) >> 16);
    // 0x80307154: addiu       $t6, $zero, 0x2
    ctx->r14 = ADD32(0, 0X2);
    // 0x80307158: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x8030715C: or          $a3, $t5, $zero
    ctx->r7 = ctx->r13 | 0;
    // 0x80307160: lh          $a1, 0x32($sp)
    ctx->r5 = MEM_H(ctx->r29, 0X32);
    // 0x80307164: jal         0x80305DA4
    // 0x80307168: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    func_80305DA4_717454(rdram, ctx);
        goto after_47;
    // 0x80307168: or          $a2, $s1, $zero
    ctx->r6 = ctx->r17 | 0;
    after_47:
    // 0x8030716C: bnel        $v0, $zero, L_803071A0
    if (ctx->r2 != 0) {
        // 0x80307170: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_803071A0;
    }
    goto skip_13;
    // 0x80307170: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_13:
L_80307174:
    // 0x80307174: b           L_803071A0
    // 0x80307178: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_803071A0;
    // 0x80307178: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_8030717C:
    // 0x8030717C: b           L_803071A0
    // 0x80307180: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_803071A0;
    // 0x80307180: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80307184:
    // 0x80307184: b           L_803071A0
    // 0x80307188: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_803071A0;
    // 0x80307188: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_8030718C:
    // 0x8030718C: b           L_803071A0
    // 0x80307190: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_803071A0;
    // 0x80307190: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80307194:
    // 0x80307194: b           L_803071A0
    // 0x80307198: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_803071A0;
    // 0x80307198: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_8030719C:
    // 0x8030719C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_803071A0:
    // 0x803071A0: lw          $ra, 0x2C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X2C);
    // 0x803071A4: lw          $s0, 0x1C($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X1C);
    // 0x803071A8: lw          $s1, 0x20($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X20);
    // 0x803071AC: lw          $s2, 0x24($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X24);
    // 0x803071B0: lw          $s3, 0x28($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X28);
    // 0x803071B4: jr          $ra
    // 0x803071B8: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
    return;
    // 0x803071B8: addiu       $sp, $sp, 0x38
    ctx->r29 = ADD32(ctx->r29, 0X38);
;}
RECOMP_FUNC void func_803071BC_71886C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803071BC: addiu       $sp, $sp, -0xD8
    ctx->r29 = ADD32(ctx->r29, -0XD8);
    // 0x803071C0: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803071C4: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x803071C8: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x803071CC: lw          $v1, 0x5524($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5524);
    // 0x803071D0: sw          $ra, 0x34($sp)
    MEM_W(0X34, ctx->r29) = ctx->r31;
    // 0x803071D4: sw          $s5, 0x30($sp)
    MEM_W(0X30, ctx->r29) = ctx->r21;
    // 0x803071D8: sw          $s4, 0x2C($sp)
    MEM_W(0X2C, ctx->r29) = ctx->r20;
    // 0x803071DC: sw          $s3, 0x28($sp)
    MEM_W(0X28, ctx->r29) = ctx->r19;
    // 0x803071E0: sw          $s2, 0x24($sp)
    MEM_W(0X24, ctx->r29) = ctx->r18;
    // 0x803071E4: sw          $s1, 0x20($sp)
    MEM_W(0X20, ctx->r29) = ctx->r17;
    // 0x803071E8: sw          $s0, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r16;
    // 0x803071EC: lh          $s1, 0x4($t0)
    ctx->r17 = MEM_H(ctx->r8, 0X4);
    // 0x803071F0: lh          $s2, 0x8($t0)
    ctx->r18 = MEM_H(ctx->r8, 0X8);
    // 0x803071F4: lhu         $t8, 0xA0($v1)
    ctx->r24 = MEM_HU(ctx->r3, 0XA0);
    // 0x803071F8: lui         $s0, 0x803E
    ctx->r16 = S32(0X803E << 16);
    // 0x803071FC: sll         $s4, $s1, 16
    ctx->r20 = S32(ctx->r17 << 16);
    // 0x80307200: sll         $s3, $s2, 16
    ctx->r19 = S32(ctx->r18 << 16);
    // 0x80307204: addiu       $s0, $s0, 0x4BE0
    ctx->r16 = ADD32(ctx->r16, 0X4BE0);
    // 0x80307208: sra         $t6, $s4, 16
    ctx->r14 = S32(SIGNED(ctx->r20) >> 16);
    // 0x8030720C: sra         $t7, $s3, 16
    ctx->r15 = S32(SIGNED(ctx->r19) >> 16);
    // 0x80307210: andi        $t9, $t8, 0x4
    ctx->r25 = ctx->r24 & 0X4;
    // 0x80307214: or          $t3, $s0, $zero
    ctx->r11 = ctx->r16 | 0;
    // 0x80307218: or          $s4, $t6, $zero
    ctx->r20 = ctx->r14 | 0;
    // 0x8030721C: or          $s3, $t7, $zero
    ctx->r19 = ctx->r15 | 0;
    // 0x80307220: or          $t1, $zero, $zero
    ctx->r9 = 0 | 0;
    // 0x80307224: beq         $t9, $zero, L_80307334
    if (ctx->r25 == 0) {
        // 0x80307228: or          $t2, $zero, $zero
        ctx->r10 = 0 | 0;
            goto L_80307334;
    }
    // 0x80307228: or          $t2, $zero, $zero
    ctx->r10 = 0 | 0;
    // 0x8030722C: sra         $t5, $s1, 6
    ctx->r13 = S32(SIGNED(ctx->r17) >> 6);
    // 0x80307230: sll         $t6, $t5, 7
    ctx->r14 = S32(ctx->r13 << 7);
    // 0x80307234: addu        $t6, $t6, $t5
    ctx->r14 = ADD32(ctx->r14, ctx->r13);
    // 0x80307238: sra         $t7, $s2, 6
    ctx->r15 = S32(SIGNED(ctx->r18) >> 6);
    // 0x8030723C: sll         $t8, $t7, 3
    ctx->r24 = S32(ctx->r15 << 3);
    // 0x80307240: sll         $t6, $t6, 3
    ctx->r14 = S32(ctx->r14 << 3);
    // 0x80307244: lui         $t5, 0x803C
    ctx->r13 = S32(0X803C << 16);
    // 0x80307248: addiu       $t5, $t5, 0x740
    ctx->r13 = ADD32(ctx->r13, 0X740);
    // 0x8030724C: addu        $t9, $t6, $t8
    ctx->r25 = ADD32(ctx->r14, ctx->r24);
    // 0x80307250: addu        $v0, $t9, $t5
    ctx->r2 = ADD32(ctx->r25, ctx->r13);
    // 0x80307254: lbu         $a0, 0x40E($v0)
    ctx->r4 = MEM_BU(ctx->r2, 0X40E);
    // 0x80307258: lbu         $a1, 0x6($v0)
    ctx->r5 = MEM_BU(ctx->r2, 0X6);
    // 0x8030725C: addiu       $s5, $zero, 0xA
    ctx->r21 = ADD32(0, 0XA);
    // 0x80307260: slt         $at, $a0, $a1
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x80307264: beql        $at, $zero, L_80307278
    if (ctx->r1 == 0) {
        // 0x80307268: or          $t4, $a0, $zero
        ctx->r12 = ctx->r4 | 0;
            goto L_80307278;
    }
    goto skip_0;
    // 0x80307268: or          $t4, $a0, $zero
    ctx->r12 = ctx->r4 | 0;
    skip_0:
    // 0x8030726C: b           L_80307278
    // 0x80307270: or          $t4, $a1, $zero
    ctx->r12 = ctx->r5 | 0;
        goto L_80307278;
    // 0x80307270: or          $t4, $a1, $zero
    ctx->r12 = ctx->r5 | 0;
    // 0x80307274: or          $t4, $a0, $zero
    ctx->r12 = ctx->r4 | 0;
L_80307278:
    // 0x80307278: lbu         $a2, 0x416($v0)
    ctx->r6 = MEM_BU(ctx->r2, 0X416);
    // 0x8030727C: lbu         $a3, 0xE($v0)
    ctx->r7 = MEM_BU(ctx->r2, 0XE);
    // 0x80307280: slt         $at, $a2, $a3
    ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x80307284: beql        $at, $zero, L_80307298
    if (ctx->r1 == 0) {
        // 0x80307288: or          $v1, $a2, $zero
        ctx->r3 = ctx->r6 | 0;
            goto L_80307298;
    }
    goto skip_1;
    // 0x80307288: or          $v1, $a2, $zero
    ctx->r3 = ctx->r6 | 0;
    skip_1:
    // 0x8030728C: b           L_80307298
    // 0x80307290: or          $v1, $a3, $zero
    ctx->r3 = ctx->r7 | 0;
        goto L_80307298;
    // 0x80307290: or          $v1, $a3, $zero
    ctx->r3 = ctx->r7 | 0;
    // 0x80307294: or          $v1, $a2, $zero
    ctx->r3 = ctx->r6 | 0;
L_80307298:
    // 0x80307298: slt         $at, $v1, $t4
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x8030729C: beq         $at, $zero, L_803072C0
    if (ctx->r1 == 0) {
        // 0x803072A0: slt         $at, $a0, $a1
        ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r5) ? 1 : 0;
            goto L_803072C0;
    }
    // 0x803072A0: slt         $at, $a0, $a1
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x803072A4: beql        $at, $zero, L_803072B8
    if (ctx->r1 == 0) {
        // 0x803072A8: or          $v0, $a0, $zero
        ctx->r2 = ctx->r4 | 0;
            goto L_803072B8;
    }
    goto skip_2;
    // 0x803072A8: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
    skip_2:
    // 0x803072AC: b           L_803072DC
    // 0x803072B0: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
        goto L_803072DC;
    // 0x803072B0: or          $v1, $a1, $zero
    ctx->r3 = ctx->r5 | 0;
    // 0x803072B4: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
L_803072B8:
    // 0x803072B8: b           L_803072DC
    // 0x803072BC: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
        goto L_803072DC;
    // 0x803072BC: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_803072C0:
    // 0x803072C0: slt         $at, $a2, $a3
    ctx->r1 = SIGNED(ctx->r6) < SIGNED(ctx->r7) ? 1 : 0;
    // 0x803072C4: beql        $at, $zero, L_803072D8
    if (ctx->r1 == 0) {
        // 0x803072C8: or          $v0, $a2, $zero
        ctx->r2 = ctx->r6 | 0;
            goto L_803072D8;
    }
    goto skip_3;
    // 0x803072C8: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
    skip_3:
    // 0x803072CC: b           L_803072D8
    // 0x803072D0: or          $v0, $a3, $zero
    ctx->r2 = ctx->r7 | 0;
        goto L_803072D8;
    // 0x803072D0: or          $v0, $a3, $zero
    ctx->r2 = ctx->r7 | 0;
    // 0x803072D4: or          $v0, $a2, $zero
    ctx->r2 = ctx->r6 | 0;
L_803072D8:
    // 0x803072D8: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_803072DC:
    // 0x803072DC: lbu         $a2, 0x160($t0)
    ctx->r6 = MEM_BU(ctx->r8, 0X160);
    // 0x803072E0: sll         $a0, $s1, 16
    ctx->r4 = S32(ctx->r17 << 16);
    // 0x803072E4: sll         $a1, $s2, 16
    ctx->r5 = S32(ctx->r18 << 16);
    // 0x803072E8: sra         $t6, $a1, 16
    ctx->r14 = S32(SIGNED(ctx->r5) >> 16);
    // 0x803072EC: sra         $t7, $a0, 16
    ctx->r15 = S32(SIGNED(ctx->r4) >> 16);
    // 0x803072F0: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x803072F4: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x803072F8: sw          $t3, 0x9C($sp)
    MEM_W(0X9C, ctx->r29) = ctx->r11;
    // 0x803072FC: sw          $t2, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->r10;
    // 0x80307300: sw          $t1, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->r9;
    // 0x80307304: jal         0x80310EE4
    // 0x80307308: sw          $v1, 0x68($sp)
    MEM_W(0X68, ctx->r29) = ctx->r3;
    func_80310EE4_722594(rdram, ctx);
        goto after_0;
    // 0x80307308: sw          $v1, 0x68($sp)
    MEM_W(0X68, ctx->r29) = ctx->r3;
    after_0:
    // 0x8030730C: lw          $v1, 0x68($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X68);
    // 0x80307310: sra         $t8, $v0, 16
    ctx->r24 = S32(SIGNED(ctx->r2) >> 16);
    // 0x80307314: lw          $t1, 0xB0($sp)
    ctx->r9 = MEM_W(ctx->r29, 0XB0);
    // 0x80307318: sll         $t9, $v1, 2
    ctx->r25 = S32(ctx->r3 << 2);
    // 0x8030731C: addu        $t5, $t8, $t9
    ctx->r13 = ADD32(ctx->r24, ctx->r25);
    // 0x80307320: sra         $t7, $t5, 1
    ctx->r15 = S32(SIGNED(ctx->r13) >> 1);
    // 0x80307324: sh          $t7, 0x9A($sp)
    MEM_H(0X9A, ctx->r29) = ctx->r15;
    // 0x80307328: lw          $t2, 0xAC($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XAC);
    // 0x8030732C: b           L_80307358
    // 0x80307330: lw          $t3, 0x9C($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X9C);
        goto L_80307358;
    // 0x80307330: lw          $t3, 0x9C($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X9C);
L_80307334:
    // 0x80307334: lhu         $t6, 0x9E($v1)
    ctx->r14 = MEM_HU(ctx->r3, 0X9E);
    // 0x80307338: andi        $t8, $t6, 0x40
    ctx->r24 = ctx->r14 & 0X40;
    // 0x8030733C: beq         $t8, $zero, L_80307350
    if (ctx->r24 == 0) {
        // 0x80307340: addiu       $t9, $zero, -0xC8
        ctx->r25 = ADD32(0, -0XC8);
            goto L_80307350;
    }
    // 0x80307340: addiu       $t9, $zero, -0xC8
    ctx->r25 = ADD32(0, -0XC8);
    // 0x80307344: addiu       $s5, $zero, 0xA
    ctx->r21 = ADD32(0, 0XA);
    // 0x80307348: b           L_80307358
    // 0x8030734C: sh          $t9, 0x9A($sp)
    MEM_H(0X9A, ctx->r29) = ctx->r25;
        goto L_80307358;
    // 0x8030734C: sh          $t9, 0x9A($sp)
    MEM_H(0X9A, ctx->r29) = ctx->r25;
L_80307350:
    // 0x80307350: addiu       $s5, $zero, -0x1
    ctx->r21 = ADD32(0, -0X1);
    // 0x80307354: sh          $zero, 0x9A($sp)
    MEM_H(0X9A, ctx->r29) = 0;
L_80307358:
    // 0x80307358: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030735C: lw          $t0, 0x552C($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X552C);
    // 0x80307360: lbu         $v0, 0x274($t0)
    ctx->r2 = MEM_BU(ctx->r8, 0X274);
    // 0x80307364: beql        $v0, $zero, L_80307548
    if (ctx->r2 == 0) {
        // 0x80307368: lbu         $v0, 0x2A0($t0)
        ctx->r2 = MEM_BU(ctx->r8, 0X2A0);
            goto L_80307548;
    }
    goto skip_4;
    // 0x80307368: lbu         $v0, 0x2A0($t0)
    ctx->r2 = MEM_BU(ctx->r8, 0X2A0);
    skip_4:
    // 0x8030736C: beq         $v0, $zero, L_80307544
    if (ctx->r2 == 0) {
        // 0x80307370: addiu       $at, $zero, 0x1
        ctx->r1 = ADD32(0, 0X1);
            goto L_80307544;
    }
    // 0x80307370: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80307374: beq         $v0, $at, L_80307394
    if (ctx->r2 == ctx->r1) {
        // 0x80307378: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80307394;
    }
    // 0x80307378: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x8030737C: beq         $v0, $at, L_80307420
    if (ctx->r2 == ctx->r1) {
        // 0x80307380: addiu       $at, $zero, 0x3
        ctx->r1 = ADD32(0, 0X3);
            goto L_80307420;
    }
    // 0x80307380: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80307384: beql        $v0, $at, L_803074D0
    if (ctx->r2 == ctx->r1) {
        // 0x80307388: lh          $t5, 0x27C($t0)
        ctx->r13 = MEM_H(ctx->r8, 0X27C);
            goto L_803074D0;
    }
    goto skip_5;
    // 0x80307388: lh          $t5, 0x27C($t0)
    ctx->r13 = MEM_H(ctx->r8, 0X27C);
    skip_5:
    // 0x8030738C: b           L_80307548
    // 0x80307390: lbu         $v0, 0x2A0($t0)
    ctx->r2 = MEM_BU(ctx->r8, 0X2A0);
        goto L_80307548;
    // 0x80307390: lbu         $v0, 0x2A0($t0)
    ctx->r2 = MEM_BU(ctx->r8, 0X2A0);
L_80307394:
    // 0x80307394: lh          $t5, 0x276($t0)
    ctx->r13 = MEM_H(ctx->r8, 0X276);
    // 0x80307398: lui         $v1, 0x8015
    ctx->r3 = S32(0X8015 << 16);
    // 0x8030739C: addiu       $v1, $v1, 0x2350
    ctx->r3 = ADD32(ctx->r3, 0X2350);
    // 0x803073A0: sll         $t7, $t5, 1
    ctx->r15 = S32(ctx->r13 << 1);
    // 0x803073A4: addu        $t6, $v1, $t7
    ctx->r14 = ADD32(ctx->r3, ctx->r15);
    // 0x803073A8: lh          $t8, 0x2D0($t6)
    ctx->r24 = MEM_H(ctx->r14, 0X2D0);
    // 0x803073AC: sw          $t8, 0xBC($sp)
    MEM_W(0XBC, ctx->r29) = ctx->r24;
    // 0x803073B0: lh          $t9, 0x276($t0)
    ctx->r25 = MEM_H(ctx->r8, 0X276);
    // 0x803073B4: sll         $t5, $t9, 1
    ctx->r13 = S32(ctx->r25 << 1);
    // 0x803073B8: addu        $t7, $v1, $t5
    ctx->r15 = ADD32(ctx->r3, ctx->r13);
    // 0x803073BC: lh          $t6, 0x384($t7)
    ctx->r14 = MEM_H(ctx->r15, 0X384);
    // 0x803073C0: sw          $t6, 0xC0($sp)
    MEM_W(0XC0, ctx->r29) = ctx->r14;
    // 0x803073C4: lh          $t8, 0x27C($t0)
    ctx->r24 = MEM_H(ctx->r8, 0X27C);
    // 0x803073C8: sh          $t8, 0x9A($sp)
    MEM_H(0X9A, ctx->r29) = ctx->r24;
    // 0x803073CC: lb          $v0, 0x275($t0)
    ctx->r2 = MEM_B(ctx->r8, 0X275);
    // 0x803073D0: slt         $at, $s5, $v0
    ctx->r1 = SIGNED(ctx->r21) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x803073D4: beql        $at, $zero, L_803073EC
    if (ctx->r1 == 0) {
        // 0x803073D8: addiu       $a1, $sp, 0xB4
        ctx->r5 = ADD32(ctx->r29, 0XB4);
            goto L_803073EC;
    }
    goto skip_6;
    // 0x803073D8: addiu       $a1, $sp, 0xB4
    ctx->r5 = ADD32(ctx->r29, 0XB4);
    skip_6:
    // 0x803073DC: sll         $s5, $v0, 16
    ctx->r21 = S32(ctx->r2 << 16);
    // 0x803073E0: sra         $t9, $s5, 16
    ctx->r25 = S32(SIGNED(ctx->r21) >> 16);
    // 0x803073E4: or          $s5, $t9, $zero
    ctx->r21 = ctx->r25 | 0;
    // 0x803073E8: addiu       $a1, $sp, 0xB4
    ctx->r5 = ADD32(ctx->r29, 0XB4);
L_803073EC:
    // 0x803073EC: addiu       $a0, $sp, 0xBC
    ctx->r4 = ADD32(ctx->r29, 0XBC);
    // 0x803073F0: jal         0x80304EC4
    // 0x803073F4: sw          $t3, 0x9C($sp)
    MEM_W(0X9C, ctx->r29) = ctx->r11;
    func_80304EC4_716574(rdram, ctx);
        goto after_1;
    // 0x803073F4: sw          $t3, 0x9C($sp)
    MEM_W(0X9C, ctx->r29) = ctx->r11;
    after_1:
    // 0x803073F8: lw          $t2, 0xB4($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XB4);
    // 0x803073FC: lw          $t1, 0xB8($sp)
    ctx->r9 = MEM_W(ctx->r29, 0XB8);
    // 0x80307400: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80307404: sll         $t5, $t2, 7
    ctx->r13 = S32(ctx->r10 << 7);
    // 0x80307408: sll         $t6, $t1, 7
    ctx->r14 = S32(ctx->r9 << 7);
    // 0x8030740C: lw          $t3, 0x9C($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X9C);
    // 0x80307410: sra         $t2, $t5, 8
    ctx->r10 = S32(SIGNED(ctx->r13) >> 8);
    // 0x80307414: sra         $t1, $t6, 8
    ctx->r9 = S32(SIGNED(ctx->r14) >> 8);
    // 0x80307418: b           L_80307544
    // 0x8030741C: lw          $t0, 0x552C($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X552C);
        goto L_80307544;
    // 0x8030741C: lw          $t0, 0x552C($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X552C);
L_80307420:
    // 0x80307420: lh          $t9, 0x27C($t0)
    ctx->r25 = MEM_H(ctx->r8, 0X27C);
    // 0x80307424: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80307428: lw          $v1, 0x5524($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5524);
    // 0x8030742C: sh          $t9, 0x9A($sp)
    MEM_H(0X9A, ctx->r29) = ctx->r25;
    // 0x80307430: lh          $t5, 0x278($t0)
    ctx->r13 = MEM_H(ctx->r8, 0X278);
    // 0x80307434: subu        $t7, $t5, $s4
    ctx->r15 = SUB32(ctx->r13, ctx->r20);
    // 0x80307438: sw          $t7, 0xBC($sp)
    MEM_W(0XBC, ctx->r29) = ctx->r15;
    // 0x8030743C: lh          $t6, 0x27A($t0)
    ctx->r14 = MEM_H(ctx->r8, 0X27A);
    // 0x80307440: subu        $t8, $t6, $s3
    ctx->r24 = SUB32(ctx->r14, ctx->r19);
    // 0x80307444: sw          $t8, 0xC0($sp)
    MEM_W(0XC0, ctx->r29) = ctx->r24;
    // 0x80307448: lb          $v0, 0x275($t0)
    ctx->r2 = MEM_B(ctx->r8, 0X275);
    // 0x8030744C: slt         $at, $s5, $v0
    ctx->r1 = SIGNED(ctx->r21) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x80307450: beql        $at, $zero, L_80307468
    if (ctx->r1 == 0) {
        // 0x80307454: lhu         $t5, 0x9E($v1)
        ctx->r13 = MEM_HU(ctx->r3, 0X9E);
            goto L_80307468;
    }
    goto skip_7;
    // 0x80307454: lhu         $t5, 0x9E($v1)
    ctx->r13 = MEM_HU(ctx->r3, 0X9E);
    skip_7:
    // 0x80307458: sll         $s5, $v0, 16
    ctx->r21 = S32(ctx->r2 << 16);
    // 0x8030745C: sra         $t9, $s5, 16
    ctx->r25 = S32(SIGNED(ctx->r21) >> 16);
    // 0x80307460: or          $s5, $t9, $zero
    ctx->r21 = ctx->r25 | 0;
    // 0x80307464: lhu         $t5, 0x9E($v1)
    ctx->r13 = MEM_HU(ctx->r3, 0X9E);
L_80307468:
    // 0x80307468: addiu       $at, $zero, 0x8
    ctx->r1 = ADD32(0, 0X8);
    // 0x8030746C: bne         $t5, $at, L_80307494
    if (ctx->r13 != ctx->r1) {
        // 0x80307470: slti        $at, $s5, 0x9
        ctx->r1 = SIGNED(ctx->r21) < 0X9 ? 1 : 0;
            goto L_80307494;
    }
    // 0x80307470: slti        $at, $s5, 0x9
    ctx->r1 = SIGNED(ctx->r21) < 0X9 ? 1 : 0;
    // 0x80307474: bne         $at, $zero, L_80307494
    if (ctx->r1 != 0) {
        // 0x80307478: addiu       $a0, $sp, 0xBC
        ctx->r4 = ADD32(ctx->r29, 0XBC);
            goto L_80307494;
    }
    // 0x80307478: addiu       $a0, $sp, 0xBC
    ctx->r4 = ADD32(ctx->r29, 0XBC);
    // 0x8030747C: jal         0x80304E80
    // 0x80307480: sw          $t3, 0x9C($sp)
    MEM_W(0X9C, ctx->r29) = ctx->r11;
    calculate_hypotenuse(rdram, ctx);
        goto after_2;
    // 0x80307480: sw          $t3, 0x9C($sp)
    MEM_W(0X9C, ctx->r29) = ctx->r11;
    after_2:
    // 0x80307484: slti        $at, $v0, 0x100
    ctx->r1 = SIGNED(ctx->r2) < 0X100 ? 1 : 0;
    // 0x80307488: beq         $at, $zero, L_80307494
    if (ctx->r1 == 0) {
        // 0x8030748C: lw          $t3, 0x9C($sp)
        ctx->r11 = MEM_W(ctx->r29, 0X9C);
            goto L_80307494;
    }
    // 0x8030748C: lw          $t3, 0x9C($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X9C);
    // 0x80307490: addiu       $s5, $zero, 0x8
    ctx->r21 = ADD32(0, 0X8);
L_80307494:
    // 0x80307494: addiu       $a1, $sp, 0xB4
    ctx->r5 = ADD32(ctx->r29, 0XB4);
    // 0x80307498: addiu       $a0, $sp, 0xBC
    ctx->r4 = ADD32(ctx->r29, 0XBC);
    // 0x8030749C: jal         0x80304EC4
    // 0x803074A0: sw          $t3, 0x9C($sp)
    MEM_W(0X9C, ctx->r29) = ctx->r11;
    func_80304EC4_716574(rdram, ctx);
        goto after_3;
    // 0x803074A0: sw          $t3, 0x9C($sp)
    MEM_W(0X9C, ctx->r29) = ctx->r11;
    after_3:
    // 0x803074A4: lw          $t2, 0xB4($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XB4);
    // 0x803074A8: lw          $t1, 0xB8($sp)
    ctx->r9 = MEM_W(ctx->r29, 0XB8);
    // 0x803074AC: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803074B0: sll         $t7, $t2, 7
    ctx->r15 = S32(ctx->r10 << 7);
    // 0x803074B4: sll         $t8, $t1, 7
    ctx->r24 = S32(ctx->r9 << 7);
    // 0x803074B8: lw          $t3, 0x9C($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X9C);
    // 0x803074BC: sra         $t2, $t7, 8
    ctx->r10 = S32(SIGNED(ctx->r15) >> 8);
    // 0x803074C0: sra         $t1, $t8, 8
    ctx->r9 = S32(SIGNED(ctx->r24) >> 8);
    // 0x803074C4: b           L_80307544
    // 0x803074C8: lw          $t0, 0x552C($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X552C);
        goto L_80307544;
    // 0x803074C8: lw          $t0, 0x552C($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X552C);
    // 0x803074CC: lh          $t5, 0x27C($t0)
    ctx->r13 = MEM_H(ctx->r8, 0X27C);
L_803074D0:
    // 0x803074D0: sh          $t5, 0x9A($sp)
    MEM_H(0X9A, ctx->r29) = ctx->r13;
    // 0x803074D4: lh          $t7, 0x278($t0)
    ctx->r15 = MEM_H(ctx->r8, 0X278);
    // 0x803074D8: subu        $t6, $t7, $s4
    ctx->r14 = SUB32(ctx->r15, ctx->r20);
    // 0x803074DC: negu        $t8, $t6
    ctx->r24 = SUB32(0, ctx->r14);
    // 0x803074E0: sw          $t8, 0xBC($sp)
    MEM_W(0XBC, ctx->r29) = ctx->r24;
    // 0x803074E4: lh          $t9, 0x27A($t0)
    ctx->r25 = MEM_H(ctx->r8, 0X27A);
    // 0x803074E8: subu        $t5, $t9, $s3
    ctx->r13 = SUB32(ctx->r25, ctx->r19);
    // 0x803074EC: negu        $t7, $t5
    ctx->r15 = SUB32(0, ctx->r13);
    // 0x803074F0: sw          $t7, 0xC0($sp)
    MEM_W(0XC0, ctx->r29) = ctx->r15;
    // 0x803074F4: lb          $v0, 0x275($t0)
    ctx->r2 = MEM_B(ctx->r8, 0X275);
    // 0x803074F8: slt         $at, $s5, $v0
    ctx->r1 = SIGNED(ctx->r21) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x803074FC: beql        $at, $zero, L_80307514
    if (ctx->r1 == 0) {
        // 0x80307500: addiu       $a1, $sp, 0xB4
        ctx->r5 = ADD32(ctx->r29, 0XB4);
            goto L_80307514;
    }
    goto skip_8;
    // 0x80307500: addiu       $a1, $sp, 0xB4
    ctx->r5 = ADD32(ctx->r29, 0XB4);
    skip_8:
    // 0x80307504: sll         $s5, $v0, 16
    ctx->r21 = S32(ctx->r2 << 16);
    // 0x80307508: sra         $t6, $s5, 16
    ctx->r14 = S32(SIGNED(ctx->r21) >> 16);
    // 0x8030750C: or          $s5, $t6, $zero
    ctx->r21 = ctx->r14 | 0;
    // 0x80307510: addiu       $a1, $sp, 0xB4
    ctx->r5 = ADD32(ctx->r29, 0XB4);
L_80307514:
    // 0x80307514: addiu       $a0, $sp, 0xBC
    ctx->r4 = ADD32(ctx->r29, 0XBC);
    // 0x80307518: jal         0x80304EC4
    // 0x8030751C: sw          $t3, 0x9C($sp)
    MEM_W(0X9C, ctx->r29) = ctx->r11;
    func_80304EC4_716574(rdram, ctx);
        goto after_4;
    // 0x8030751C: sw          $t3, 0x9C($sp)
    MEM_W(0X9C, ctx->r29) = ctx->r11;
    after_4:
    // 0x80307520: lw          $t2, 0xB4($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XB4);
    // 0x80307524: lw          $t1, 0xB8($sp)
    ctx->r9 = MEM_W(ctx->r29, 0XB8);
    // 0x80307528: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030752C: sll         $t8, $t2, 7
    ctx->r24 = S32(ctx->r10 << 7);
    // 0x80307530: sll         $t5, $t1, 7
    ctx->r13 = S32(ctx->r9 << 7);
    // 0x80307534: lw          $t3, 0x9C($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X9C);
    // 0x80307538: sra         $t2, $t8, 8
    ctx->r10 = S32(SIGNED(ctx->r24) >> 8);
    // 0x8030753C: sra         $t1, $t5, 8
    ctx->r9 = S32(SIGNED(ctx->r13) >> 8);
    // 0x80307540: lw          $t0, 0x552C($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X552C);
L_80307544:
    // 0x80307544: lbu         $v0, 0x2A0($t0)
    ctx->r2 = MEM_BU(ctx->r8, 0X2A0);
L_80307548:
    // 0x80307548: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8030754C: addiu       $s1, $sp, 0xB4
    ctx->r17 = ADD32(ctx->r29, 0XB4);
    // 0x80307550: beq         $v0, $at, L_8030774C
    if (ctx->r2 == ctx->r1) {
        // 0x80307554: addiu       $s2, $sp, 0xBC
        ctx->r18 = ADD32(ctx->r29, 0XBC);
            goto L_8030774C;
    }
    // 0x80307554: addiu       $s2, $sp, 0xBC
    ctx->r18 = ADD32(ctx->r29, 0XBC);
    // 0x80307558: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x8030755C: bne         $v0, $at, L_80307570
    if (ctx->r2 != ctx->r1) {
        // 0x80307560: nop
    
            goto L_80307570;
    }
    // 0x80307560: nop

    // 0x80307564: lb          $t6, 0x2A1($t0)
    ctx->r14 = MEM_B(ctx->r8, 0X2A1);
    // 0x80307568: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x8030756C: beq         $t6, $at, L_8030774C
    if (ctx->r14 == ctx->r1) {
        // 0x80307570: lui         $t8, 0x803E
        ctx->r24 = S32(0X803E << 16);
            goto L_8030774C;
    }
L_80307570:
    // 0x80307570: lui         $t8, 0x803E
    ctx->r24 = S32(0X803E << 16);
    // 0x80307574: lw          $t8, 0x4C3C($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X4C3C);
    // 0x80307578: slti        $at, $t8, 0x280
    ctx->r1 = SIGNED(ctx->r24) < 0X280 ? 1 : 0;
    // 0x8030757C: beq         $at, $zero, L_8030774C
    if (ctx->r1 == 0) {
        // 0x80307580: nop
    
            goto L_8030774C;
    }
    // 0x80307580: nop

    // 0x80307584: lhu         $t9, 0x272($t0)
    ctx->r25 = MEM_HU(ctx->r8, 0X272);
    // 0x80307588: andi        $t5, $t9, 0x8
    ctx->r13 = ctx->r25 & 0X8;
    // 0x8030758C: beq         $t5, $zero, L_8030774C
    if (ctx->r13 == 0) {
        // 0x80307590: lui         $t6, 0x803E
        ctx->r14 = S32(0X803E << 16);
            goto L_8030774C;
    }
    // 0x80307590: lui         $t6, 0x803E
    ctx->r14 = S32(0X803E << 16);
    // 0x80307594: lw          $t6, 0x4C40($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X4C40);
    // 0x80307598: lw          $t7, 0x2CC($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X2CC);
    // 0x8030759C: beq         $t7, $t6, L_8030774C
    if (ctx->r15 == ctx->r14) {
        // 0x803075A0: nop
    
            goto L_8030774C;
    }
    // 0x803075A0: nop

    // 0x803075A4: lh          $t9, 0x4($t6)
    ctx->r25 = MEM_H(ctx->r14, 0X4);
    // 0x803075A8: slti        $at, $t8, 0xC
    ctx->r1 = SIGNED(ctx->r24) < 0XC ? 1 : 0;
    // 0x803075AC: subu        $t5, $t9, $s4
    ctx->r13 = SUB32(ctx->r25, ctx->r20);
    // 0x803075B0: sw          $t5, 0xBC($sp)
    MEM_W(0XBC, ctx->r29) = ctx->r13;
    // 0x803075B4: lh          $t7, 0x8($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X8);
    // 0x803075B8: subu        $t9, $t7, $s3
    ctx->r25 = SUB32(ctx->r15, ctx->r19);
    // 0x803075BC: beq         $at, $zero, L_80307684
    if (ctx->r1 == 0) {
        // 0x803075C0: sw          $t9, 0xC0($sp)
        MEM_W(0XC0, ctx->r29) = ctx->r25;
            goto L_80307684;
    }
    // 0x803075C0: sw          $t9, 0xC0($sp)
    MEM_W(0XC0, ctx->r29) = ctx->r25;
    // 0x803075C4: addiu       $a0, $sp, 0xBC
    ctx->r4 = ADD32(ctx->r29, 0XBC);
    // 0x803075C8: addiu       $a1, $sp, 0xB4
    ctx->r5 = ADD32(ctx->r29, 0XB4);
    // 0x803075CC: sw          $t1, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->r9;
    // 0x803075D0: sw          $t2, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->r10;
    // 0x803075D4: jal         0x80304EC4
    // 0x803075D8: sw          $t3, 0x9C($sp)
    MEM_W(0X9C, ctx->r29) = ctx->r11;
    func_80304EC4_716574(rdram, ctx);
        goto after_5;
    // 0x803075D8: sw          $t3, 0x9C($sp)
    MEM_W(0X9C, ctx->r29) = ctx->r11;
    after_5:
    // 0x803075DC: lw          $t5, 0xB4($sp)
    ctx->r13 = MEM_W(ctx->r29, 0XB4);
    // 0x803075E0: lw          $t2, 0xAC($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XAC);
    // 0x803075E4: lw          $t9, 0xB8($sp)
    ctx->r25 = MEM_W(ctx->r29, 0XB8);
    // 0x803075E8: sll         $t6, $t5, 2
    ctx->r14 = S32(ctx->r13 << 2);
    // 0x803075EC: subu        $t6, $t6, $t5
    ctx->r14 = SUB32(ctx->r14, ctx->r13);
    // 0x803075F0: sll         $t6, $t6, 6
    ctx->r14 = S32(ctx->r14 << 6);
    // 0x803075F4: sra         $t7, $t6, 8
    ctx->r15 = S32(SIGNED(ctx->r14) >> 8);
    // 0x803075F8: lui         $t6, 0x803E
    ctx->r14 = S32(0X803E << 16);
    // 0x803075FC: lw          $t6, 0x4C3C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X4C3C);
    // 0x80307600: addiu       $v0, $zero, 0xC
    ctx->r2 = ADD32(0, 0XC);
    // 0x80307604: subu        $t2, $t2, $t7
    ctx->r10 = SUB32(ctx->r10, ctx->r15);
    // 0x80307608: sll         $t8, $t9, 2
    ctx->r24 = S32(ctx->r25 << 2);
    // 0x8030760C: subu        $t8, $t8, $t9
    ctx->r24 = SUB32(ctx->r24, ctx->r25);
    // 0x80307610: subu        $t7, $v0, $t6
    ctx->r15 = SUB32(ctx->r2, ctx->r14);
    // 0x80307614: sll         $t9, $t7, 4
    ctx->r25 = S32(ctx->r15 << 4);
    // 0x80307618: div         $zero, $t9, $v0
    lo = S32(S64(S32(ctx->r25)) / S64(S32(ctx->r2))); hi = S32(S64(S32(ctx->r25)) % S64(S32(ctx->r2)));
    // 0x8030761C: lw          $t1, 0xB0($sp)
    ctx->r9 = MEM_W(ctx->r29, 0XB0);
    // 0x80307620: sll         $t8, $t8, 6
    ctx->r24 = S32(ctx->r24 << 6);
    // 0x80307624: sra         $t5, $t8, 8
    ctx->r13 = S32(SIGNED(ctx->r24) >> 8);
    // 0x80307628: mflo        $a0
    ctx->r4 = lo;
    // 0x8030762C: sll         $t8, $a0, 16
    ctx->r24 = S32(ctx->r4 << 16);
    // 0x80307630: subu        $t1, $t1, $t5
    ctx->r9 = SUB32(ctx->r9, ctx->r13);
    // 0x80307634: sra         $t5, $t8, 16
    ctx->r13 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80307638: lw          $t3, 0x9C($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X9C);
    // 0x8030763C: addiu       $s1, $sp, 0xB4
    ctx->r17 = ADD32(ctx->r29, 0XB4);
    // 0x80307640: addiu       $s2, $sp, 0xBC
    ctx->r18 = ADD32(ctx->r29, 0XBC);
    // 0x80307644: bne         $v0, $zero, L_80307650
    if (ctx->r2 != 0) {
        // 0x80307648: nop
    
            goto L_80307650;
    }
    // 0x80307648: nop

    // 0x8030764C: break       7
    do_break(2150659660);
L_80307650:
    // 0x80307650: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80307654: bne         $v0, $at, L_80307668
    if (ctx->r2 != ctx->r1) {
        // 0x80307658: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80307668;
    }
    // 0x80307658: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x8030765C: bne         $t9, $at, L_80307668
    if (ctx->r25 != ctx->r1) {
        // 0x80307660: nop
    
            goto L_80307668;
    }
    // 0x80307660: nop

    // 0x80307664: break       6
    do_break(2150659684);
L_80307668:
    // 0x80307668: slt         $at, $s5, $t5
    ctx->r1 = SIGNED(ctx->r21) < SIGNED(ctx->r13) ? 1 : 0;
    // 0x8030766C: beq         $at, $zero, L_8030774C
    if (ctx->r1 == 0) {
        // 0x80307670: or          $a0, $t5, $zero
        ctx->r4 = ctx->r13 | 0;
            goto L_8030774C;
    }
    // 0x80307670: or          $a0, $t5, $zero
    ctx->r4 = ctx->r13 | 0;
    // 0x80307674: sll         $s5, $t5, 16
    ctx->r21 = S32(ctx->r13 << 16);
    // 0x80307678: sra         $t6, $s5, 16
    ctx->r14 = S32(SIGNED(ctx->r21) >> 16);
    // 0x8030767C: b           L_8030774C
    // 0x80307680: or          $s5, $t6, $zero
    ctx->r21 = ctx->r14 | 0;
        goto L_8030774C;
    // 0x80307680: or          $s5, $t6, $zero
    ctx->r21 = ctx->r14 | 0;
L_80307684:
    // 0x80307684: lbu         $t7, 0x274($t0)
    ctx->r15 = MEM_BU(ctx->r8, 0X274);
    // 0x80307688: bne         $t7, $zero, L_8030774C
    if (ctx->r15 != 0) {
        // 0x8030768C: lui         $t9, 0x803E
        ctx->r25 = S32(0X803E << 16);
            goto L_8030774C;
    }
    // 0x8030768C: lui         $t9, 0x803E
    ctx->r25 = S32(0X803E << 16);
    // 0x80307690: lw          $t9, 0x4C3C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X4C3C);
    // 0x80307694: slti        $at, $t9, 0x4D
    ctx->r1 = SIGNED(ctx->r25) < 0X4D ? 1 : 0;
    // 0x80307698: bne         $at, $zero, L_8030774C
    if (ctx->r1 != 0) {
        // 0x8030769C: or          $a0, $s2, $zero
        ctx->r4 = ctx->r18 | 0;
            goto L_8030774C;
    }
    // 0x8030769C: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    // 0x803076A0: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x803076A4: sw          $t1, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->r9;
    // 0x803076A8: sw          $t2, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->r10;
    // 0x803076AC: jal         0x80304EC4
    // 0x803076B0: sw          $t3, 0x9C($sp)
    MEM_W(0X9C, ctx->r29) = ctx->r11;
    func_80304EC4_716574(rdram, ctx);
        goto after_6;
    // 0x803076B0: sw          $t3, 0x9C($sp)
    MEM_W(0X9C, ctx->r29) = ctx->r11;
    after_6:
    // 0x803076B4: lw          $t8, 0xB4($sp)
    ctx->r24 = MEM_W(ctx->r29, 0XB4);
    // 0x803076B8: addiu       $a1, $zero, 0xA0
    ctx->r5 = ADD32(0, 0XA0);
    // 0x803076BC: lw          $t7, 0xB8($sp)
    ctx->r15 = MEM_W(ctx->r29, 0XB8);
    // 0x803076C0: multu       $t8, $a1
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803076C4: lui         $v1, 0x803E
    ctx->r3 = S32(0X803E << 16);
    // 0x803076C8: lw          $v1, 0x4C3C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X4C3C);
    // 0x803076CC: addiu       $at, $zero, 0x8D
    ctx->r1 = ADD32(0, 0X8D);
    // 0x803076D0: lw          $t2, 0xAC($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XAC);
    // 0x803076D4: addiu       $v1, $v1, -0x4C
    ctx->r3 = ADD32(ctx->r3, -0X4C);
    // 0x803076D8: sll         $v0, $v1, 2
    ctx->r2 = S32(ctx->r3 << 2);
    // 0x803076DC: subu        $v0, $v0, $v1
    ctx->r2 = SUB32(ctx->r2, ctx->r3);
    // 0x803076E0: sll         $v0, $v0, 1
    ctx->r2 = S32(ctx->r2 << 1);
    // 0x803076E4: lw          $t1, 0xB0($sp)
    ctx->r9 = MEM_W(ctx->r29, 0XB0);
    // 0x803076E8: mflo        $t5
    ctx->r13 = lo;
    // 0x803076EC: sra         $t6, $t5, 8
    ctx->r14 = S32(SIGNED(ctx->r13) >> 8);
    // 0x803076F0: addu        $t2, $t2, $t6
    ctx->r10 = ADD32(ctx->r10, ctx->r14);
    // 0x803076F4: multu       $t7, $a1
    result = U64(U32(ctx->r15)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x803076F8: lw          $t3, 0x9C($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X9C);
    // 0x803076FC: mflo        $t9
    ctx->r25 = lo;
    // 0x80307700: sra         $t8, $t9, 8
    ctx->r24 = S32(SIGNED(ctx->r25) >> 8);
    // 0x80307704: addu        $t1, $t1, $t8
    ctx->r9 = ADD32(ctx->r9, ctx->r24);
    // 0x80307708: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x8030770C: mflo        $t5
    ctx->r13 = lo;
    // 0x80307710: addiu       $v0, $t5, 0xE
    ctx->r2 = ADD32(ctx->r13, 0XE);
    // 0x80307714: sll         $t7, $v0, 16
    ctx->r15 = S32(ctx->r2 << 16);
    // 0x80307718: sll         $a0, $v0, 16
    ctx->r4 = S32(ctx->r2 << 16);
    // 0x8030771C: sra         $t9, $t7, 16
    ctx->r25 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80307720: sra         $t6, $a0, 16
    ctx->r14 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80307724: slti        $at, $t9, 0x15
    ctx->r1 = SIGNED(ctx->r25) < 0X15 ? 1 : 0;
    // 0x80307728: bne         $at, $zero, L_80307734
    if (ctx->r1 != 0) {
        // 0x8030772C: or          $a0, $t6, $zero
        ctx->r4 = ctx->r14 | 0;
            goto L_80307734;
    }
    // 0x8030772C: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    // 0x80307730: addiu       $a0, $zero, 0x14
    ctx->r4 = ADD32(0, 0X14);
L_80307734:
    // 0x80307734: slt         $at, $s5, $a0
    ctx->r1 = SIGNED(ctx->r21) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x80307738: beq         $at, $zero, L_8030774C
    if (ctx->r1 == 0) {
        // 0x8030773C: nop
    
            goto L_8030774C;
    }
    // 0x8030773C: nop

    // 0x80307740: sll         $s5, $a0, 16
    ctx->r21 = S32(ctx->r4 << 16);
    // 0x80307744: sra         $t8, $s5, 16
    ctx->r24 = S32(SIGNED(ctx->r21) >> 16);
    // 0x80307748: or          $s5, $t8, $zero
    ctx->r21 = ctx->r24 | 0;
L_8030774C:
    // 0x8030774C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80307750: lw          $t0, 0x552C($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X552C);
    // 0x80307754: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80307758: lbu         $v0, 0x2A0($t0)
    ctx->r2 = MEM_BU(ctx->r8, 0X2A0);
    // 0x8030775C: beq         $v0, $at, L_803079C8
    if (ctx->r2 == ctx->r1) {
        // 0x80307760: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_803079C8;
    }
    // 0x80307760: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80307764: bne         $v0, $at, L_80307778
    if (ctx->r2 != ctx->r1) {
        // 0x80307768: nop
    
            goto L_80307778;
    }
    // 0x80307768: nop

    // 0x8030776C: lb          $t5, 0x2A1($t0)
    ctx->r13 = MEM_B(ctx->r8, 0X2A1);
    // 0x80307770: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80307774: beq         $t5, $at, L_803079C8
    if (ctx->r13 == ctx->r1) {
        // 0x80307778: lui         $v0, 0x803E
        ctx->r2 = S32(0X803E << 16);
            goto L_803079C8;
    }
L_80307778:
    // 0x80307778: lui         $v0, 0x803E
    ctx->r2 = S32(0X803E << 16);
    // 0x8030777C: lhu         $v0, 0x4BE0($v0)
    ctx->r2 = MEM_HU(ctx->r2, 0X4BE0);
    // 0x80307780: beql        $v0, $zero, L_803079CC
    if (ctx->r2 == 0) {
        // 0x80307784: sb          $zero, 0x28A($t0)
        MEM_B(0X28A, ctx->r8) = 0;
            goto L_803079CC;
    }
    goto skip_9;
    // 0x80307784: sb          $zero, 0x28A($t0)
    MEM_B(0X28A, ctx->r8) = 0;
    skip_9:
    // 0x80307788: lhu         $t6, 0x272($t0)
    ctx->r14 = MEM_HU(ctx->r8, 0X272);
    // 0x8030778C: andi        $t7, $t6, 0x8
    ctx->r15 = ctx->r14 & 0X8;
    // 0x80307790: beql        $t7, $zero, L_803079CC
    if (ctx->r15 == 0) {
        // 0x80307794: sb          $zero, 0x28A($t0)
        MEM_B(0X28A, ctx->r8) = 0;
            goto L_803079CC;
    }
    goto skip_10;
    // 0x80307794: sb          $zero, 0x28A($t0)
    MEM_B(0X28A, ctx->r8) = 0;
    skip_10:
    // 0x80307798: blez        $v0, L_803079C8
    if (SIGNED(ctx->r2) <= 0) {
        // 0x8030779C: or          $a3, $zero, $zero
        ctx->r7 = 0 | 0;
            goto L_803079C8;
    }
    // 0x8030779C: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x803077A0: sll         $t9, $a3, 2
    ctx->r25 = S32(ctx->r7 << 2);
L_803077A4:
    // 0x803077A4: addu        $a0, $s0, $t9
    ctx->r4 = ADD32(ctx->r16, ctx->r25);
    // 0x803077A8: lw          $v0, 0x10($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X10);
    // 0x803077AC: lw          $t8, 0x2CC($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X2CC);
    // 0x803077B0: bnel        $v0, $t8, L_803077C4
    if (ctx->r2 != ctx->r24) {
        // 0x803077B4: lh          $t5, 0x4($v0)
        ctx->r13 = MEM_H(ctx->r2, 0X4);
            goto L_803077C4;
    }
    goto skip_11;
    // 0x803077B4: lh          $t5, 0x4($v0)
    ctx->r13 = MEM_H(ctx->r2, 0X4);
    skip_11:
    // 0x803077B8: b           L_803079B0
    // 0x803077BC: lhu         $v0, 0x0($t3)
    ctx->r2 = MEM_HU(ctx->r11, 0X0);
        goto L_803079B0;
    // 0x803077BC: lhu         $v0, 0x0($t3)
    ctx->r2 = MEM_HU(ctx->r11, 0X0);
    // 0x803077C0: lh          $t5, 0x4($v0)
    ctx->r13 = MEM_H(ctx->r2, 0X4);
L_803077C4:
    // 0x803077C4: lw          $v1, 0x4($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X4);
    // 0x803077C8: subu        $t6, $t5, $s4
    ctx->r14 = SUB32(ctx->r13, ctx->r20);
    // 0x803077CC: sw          $t6, 0xBC($sp)
    MEM_W(0XBC, ctx->r29) = ctx->r14;
    // 0x803077D0: lh          $t7, 0x8($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X8);
    // 0x803077D4: slti        $at, $v1, 0x140
    ctx->r1 = SIGNED(ctx->r3) < 0X140 ? 1 : 0;
    // 0x803077D8: subu        $t9, $t7, $s3
    ctx->r25 = SUB32(ctx->r15, ctx->r19);
    // 0x803077DC: beq         $at, $zero, L_803079A4
    if (ctx->r1 == 0) {
        // 0x803077E0: sw          $t9, 0xC0($sp)
        MEM_W(0XC0, ctx->r29) = ctx->r25;
            goto L_803079A4;
    }
    // 0x803077E0: sw          $t9, 0xC0($sp)
    MEM_W(0XC0, ctx->r29) = ctx->r25;
    // 0x803077E4: slti        $at, $v1, 0x40
    ctx->r1 = SIGNED(ctx->r3) < 0X40 ? 1 : 0;
    // 0x803077E8: beq         $at, $zero, L_803078B4
    if (ctx->r1 == 0) {
        // 0x803077EC: or          $a0, $s2, $zero
        ctx->r4 = ctx->r18 | 0;
            goto L_803078B4;
    }
    // 0x803077EC: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    // 0x803077F0: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x803077F4: sw          $v1, 0xCC($sp)
    MEM_W(0XCC, ctx->r29) = ctx->r3;
    // 0x803077F8: sh          $a3, 0xD6($sp)
    MEM_H(0XD6, ctx->r29) = ctx->r7;
    // 0x803077FC: sw          $t1, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->r9;
    // 0x80307800: sw          $t2, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->r10;
    // 0x80307804: jal         0x80304EC4
    // 0x80307808: sw          $t3, 0x9C($sp)
    MEM_W(0X9C, ctx->r29) = ctx->r11;
    func_80304EC4_716574(rdram, ctx);
        goto after_7;
    // 0x80307808: sw          $t3, 0x9C($sp)
    MEM_W(0X9C, ctx->r29) = ctx->r11;
    after_7:
    // 0x8030780C: lw          $v1, 0xCC($sp)
    ctx->r3 = MEM_W(ctx->r29, 0XCC);
    // 0x80307810: lw          $t7, 0xB4($sp)
    ctx->r15 = MEM_W(ctx->r29, 0XB4);
    // 0x80307814: addiu       $t6, $zero, 0xC0
    ctx->r14 = ADD32(0, 0XC0);
    // 0x80307818: sll         $t8, $v1, 2
    ctx->r24 = S32(ctx->r3 << 2);
    // 0x8030781C: subu        $t8, $t8, $v1
    ctx->r24 = SUB32(ctx->r24, ctx->r3);
    // 0x80307820: sll         $t8, $t8, 6
    ctx->r24 = S32(ctx->r24 << 6);
    // 0x80307824: negu        $a0, $v1
    ctx->r4 = SUB32(0, ctx->r3);
    // 0x80307828: lw          $t2, 0xAC($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XAC);
    // 0x8030782C: lw          $t1, 0xB0($sp)
    ctx->r9 = MEM_W(ctx->r29, 0XB0);
    // 0x80307830: lh          $a3, 0xD6($sp)
    ctx->r7 = MEM_H(ctx->r29, 0XD6);
    // 0x80307834: lw          $t3, 0x9C($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X9C);
    // 0x80307838: bgez        $t8, L_80307848
    if (SIGNED(ctx->r24) >= 0) {
        // 0x8030783C: sra         $t5, $t8, 6
        ctx->r13 = S32(SIGNED(ctx->r24) >> 6);
            goto L_80307848;
    }
    // 0x8030783C: sra         $t5, $t8, 6
    ctx->r13 = S32(SIGNED(ctx->r24) >> 6);
    // 0x80307840: addiu       $at, $t8, 0x3F
    ctx->r1 = ADD32(ctx->r24, 0X3F);
    // 0x80307844: sra         $t5, $at, 6
    ctx->r13 = S32(SIGNED(ctx->r1) >> 6);
L_80307848:
    // 0x80307848: subu        $v0, $t6, $t5
    ctx->r2 = SUB32(ctx->r14, ctx->r13);
    // 0x8030784C: multu       $v0, $t7
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80307850: lw          $t6, 0xB8($sp)
    ctx->r14 = MEM_W(ctx->r29, 0XB8);
    // 0x80307854: mflo        $t9
    ctx->r25 = lo;
    // 0x80307858: sra         $t8, $t9, 8
    ctx->r24 = S32(SIGNED(ctx->r25) >> 8);
    // 0x8030785C: sll         $t9, $a0, 2
    ctx->r25 = S32(ctx->r4 << 2);
    // 0x80307860: multu       $v0, $t6
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r14)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80307864: addu        $t9, $t9, $a0
    ctx->r25 = ADD32(ctx->r25, ctx->r4);
    // 0x80307868: sll         $t9, $t9, 1
    ctx->r25 = S32(ctx->r25 << 1);
    // 0x8030786C: addiu       $a0, $t9, 0x280
    ctx->r4 = ADD32(ctx->r25, 0X280);
    // 0x80307870: subu        $t2, $t2, $t8
    ctx->r10 = SUB32(ctx->r10, ctx->r24);
    // 0x80307874: mflo        $t5
    ctx->r13 = lo;
    // 0x80307878: sra         $t7, $t5, 8
    ctx->r15 = S32(SIGNED(ctx->r13) >> 8);
    // 0x8030787C: subu        $t1, $t1, $t7
    ctx->r9 = SUB32(ctx->r9, ctx->r15);
    // 0x80307880: bgez        $a0, L_80307890
    if (SIGNED(ctx->r4) >= 0) {
        // 0x80307884: sra         $t8, $a0, 6
        ctx->r24 = S32(SIGNED(ctx->r4) >> 6);
            goto L_80307890;
    }
    // 0x80307884: sra         $t8, $a0, 6
    ctx->r24 = S32(SIGNED(ctx->r4) >> 6);
    // 0x80307888: addiu       $at, $a0, 0x3F
    ctx->r1 = ADD32(ctx->r4, 0X3F);
    // 0x8030788C: sra         $t8, $at, 6
    ctx->r24 = S32(SIGNED(ctx->r1) >> 6);
L_80307890:
    // 0x80307890: sll         $t6, $t8, 16
    ctx->r14 = S32(ctx->r24 << 16);
    // 0x80307894: sra         $t5, $t6, 16
    ctx->r13 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80307898: slt         $at, $s5, $t5
    ctx->r1 = SIGNED(ctx->r21) < SIGNED(ctx->r13) ? 1 : 0;
    // 0x8030789C: beq         $at, $zero, L_803079A4
    if (ctx->r1 == 0) {
        // 0x803078A0: nop
    
            goto L_803079A4;
    }
    // 0x803078A0: nop

    // 0x803078A4: sll         $s5, $t5, 16
    ctx->r21 = S32(ctx->r13 << 16);
    // 0x803078A8: sra         $t7, $s5, 16
    ctx->r15 = S32(SIGNED(ctx->r21) >> 16);
    // 0x803078AC: b           L_803079A4
    // 0x803078B0: or          $s5, $t7, $zero
    ctx->r21 = ctx->r15 | 0;
        goto L_803079A4;
    // 0x803078B0: or          $s5, $t7, $zero
    ctx->r21 = ctx->r15 | 0;
L_803078B4:
    // 0x803078B4: lbu         $t9, 0x274($t0)
    ctx->r25 = MEM_BU(ctx->r8, 0X274);
    // 0x803078B8: bne         $t9, $zero, L_803079A4
    if (ctx->r25 != 0) {
        // 0x803078BC: slti        $at, $v1, 0x81
        ctx->r1 = SIGNED(ctx->r3) < 0X81 ? 1 : 0;
            goto L_803079A4;
    }
    // 0x803078BC: slti        $at, $v1, 0x81
    ctx->r1 = SIGNED(ctx->r3) < 0X81 ? 1 : 0;
    // 0x803078C0: bne         $at, $zero, L_803079A4
    if (ctx->r1 != 0) {
        // 0x803078C4: slti        $at, $v1, 0x101
        ctx->r1 = SIGNED(ctx->r3) < 0X101 ? 1 : 0;
            goto L_803079A4;
    }
    // 0x803078C4: slti        $at, $v1, 0x101
    ctx->r1 = SIGNED(ctx->r3) < 0X101 ? 1 : 0;
    // 0x803078C8: bne         $at, $zero, L_803078F0
    if (ctx->r1 != 0) {
        // 0x803078CC: sll         $t8, $v1, 6
        ctx->r24 = S32(ctx->r3 << 6);
            goto L_803078F0;
    }
    // 0x803078CC: sll         $t8, $v1, 6
    ctx->r24 = S32(ctx->r3 << 6);
    // 0x803078D0: addiu       $t6, $zero, 0x5000
    ctx->r14 = ADD32(0, 0X5000);
    // 0x803078D4: subu        $a2, $t6, $t8
    ctx->r6 = SUB32(ctx->r14, ctx->r24);
    // 0x803078D8: bgez        $a2, L_803078E8
    if (SIGNED(ctx->r6) >= 0) {
        // 0x803078DC: sra         $t5, $a2, 6
        ctx->r13 = S32(SIGNED(ctx->r6) >> 6);
            goto L_803078E8;
    }
    // 0x803078DC: sra         $t5, $a2, 6
    ctx->r13 = S32(SIGNED(ctx->r6) >> 6);
    // 0x803078E0: addiu       $at, $a2, 0x3F
    ctx->r1 = ADD32(ctx->r6, 0X3F);
    // 0x803078E4: sra         $t5, $at, 6
    ctx->r13 = S32(SIGNED(ctx->r1) >> 6);
L_803078E8:
    // 0x803078E8: b           L_803078F4
    // 0x803078EC: or          $a2, $t5, $zero
    ctx->r6 = ctx->r13 | 0;
        goto L_803078F4;
    // 0x803078EC: or          $a2, $t5, $zero
    ctx->r6 = ctx->r13 | 0;
L_803078F0:
    // 0x803078F0: addiu       $a2, $zero, 0x40
    ctx->r6 = ADD32(0, 0X40);
L_803078F4:
    // 0x803078F4: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    // 0x803078F8: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x803078FC: sw          $v1, 0xCC($sp)
    MEM_W(0XCC, ctx->r29) = ctx->r3;
    // 0x80307900: sw          $a2, 0xA4($sp)
    MEM_W(0XA4, ctx->r29) = ctx->r6;
    // 0x80307904: sh          $a3, 0xD6($sp)
    MEM_H(0XD6, ctx->r29) = ctx->r7;
    // 0x80307908: sw          $t1, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->r9;
    // 0x8030790C: sw          $t2, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->r10;
    // 0x80307910: jal         0x80304EC4
    // 0x80307914: sw          $t3, 0x9C($sp)
    MEM_W(0X9C, ctx->r29) = ctx->r11;
    func_80304EC4_716574(rdram, ctx);
        goto after_8;
    // 0x80307914: sw          $t3, 0x9C($sp)
    MEM_W(0X9C, ctx->r29) = ctx->r11;
    after_8:
    // 0x80307918: lw          $a2, 0xA4($sp)
    ctx->r6 = MEM_W(ctx->r29, 0XA4);
    // 0x8030791C: lw          $t7, 0xB4($sp)
    ctx->r15 = MEM_W(ctx->r29, 0XB4);
    // 0x80307920: lw          $t8, 0xB8($sp)
    ctx->r24 = MEM_W(ctx->r29, 0XB8);
    // 0x80307924: lw          $v1, 0xCC($sp)
    ctx->r3 = MEM_W(ctx->r29, 0XCC);
    // 0x80307928: multu       $a2, $t7
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8030792C: addiu       $at, $zero, 0x60
    ctx->r1 = ADD32(0, 0X60);
    // 0x80307930: sll         $v0, $v1, 4
    ctx->r2 = S32(ctx->r3 << 4);
    // 0x80307934: addiu       $v0, $v0, -0x800
    ctx->r2 = ADD32(ctx->r2, -0X800);
    // 0x80307938: lw          $t2, 0xAC($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XAC);
    // 0x8030793C: lw          $t1, 0xB0($sp)
    ctx->r9 = MEM_W(ctx->r29, 0XB0);
    // 0x80307940: lh          $a3, 0xD6($sp)
    ctx->r7 = MEM_H(ctx->r29, 0XD6);
    // 0x80307944: lw          $t3, 0x9C($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X9C);
    // 0x80307948: mflo        $t9
    ctx->r25 = lo;
    // 0x8030794C: sra         $t6, $t9, 8
    ctx->r14 = S32(SIGNED(ctx->r25) >> 8);
    // 0x80307950: addu        $t2, $t2, $t6
    ctx->r10 = ADD32(ctx->r10, ctx->r14);
    // 0x80307954: multu       $a2, $t8
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80307958: mflo        $t5
    ctx->r13 = lo;
    // 0x8030795C: sra         $t7, $t5, 8
    ctx->r15 = S32(SIGNED(ctx->r13) >> 8);
    // 0x80307960: addu        $t1, $t1, $t7
    ctx->r9 = ADD32(ctx->r9, ctx->r15);
    // 0x80307964: div         $zero, $v0, $at
    lo = S32(S64(S32(ctx->r2)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r2)) % S64(S32(ctx->r1)));
    // 0x80307968: mflo        $t9
    ctx->r25 = lo;
    // 0x8030796C: sll         $t8, $t9, 16
    ctx->r24 = S32(ctx->r25 << 16);
    // 0x80307970: sll         $a0, $t9, 16
    ctx->r4 = S32(ctx->r25 << 16);
    // 0x80307974: sra         $t5, $t8, 16
    ctx->r13 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80307978: sra         $t6, $a0, 16
    ctx->r14 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8030797C: slti        $at, $t5, 0x11
    ctx->r1 = SIGNED(ctx->r13) < 0X11 ? 1 : 0;
    // 0x80307980: bne         $at, $zero, L_8030798C
    if (ctx->r1 != 0) {
        // 0x80307984: or          $a0, $t6, $zero
        ctx->r4 = ctx->r14 | 0;
            goto L_8030798C;
    }
    // 0x80307984: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    // 0x80307988: addiu       $a0, $zero, 0x10
    ctx->r4 = ADD32(0, 0X10);
L_8030798C:
    // 0x8030798C: slt         $at, $s5, $a0
    ctx->r1 = SIGNED(ctx->r21) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x80307990: beq         $at, $zero, L_803079A4
    if (ctx->r1 == 0) {
        // 0x80307994: nop
    
            goto L_803079A4;
    }
    // 0x80307994: nop

    // 0x80307998: sll         $s5, $a0, 16
    ctx->r21 = S32(ctx->r4 << 16);
    // 0x8030799C: sra         $t7, $s5, 16
    ctx->r15 = S32(SIGNED(ctx->r21) >> 16);
    // 0x803079A0: or          $s5, $t7, $zero
    ctx->r21 = ctx->r15 | 0;
L_803079A4:
    // 0x803079A4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803079A8: lw          $t0, 0x552C($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X552C);
    // 0x803079AC: lhu         $v0, 0x0($t3)
    ctx->r2 = MEM_HU(ctx->r11, 0X0);
L_803079B0:
    // 0x803079B0: addiu       $a3, $a3, 0x1
    ctx->r7 = ADD32(ctx->r7, 0X1);
    // 0x803079B4: sll         $t9, $a3, 16
    ctx->r25 = S32(ctx->r7 << 16);
    // 0x803079B8: sra         $a3, $t9, 16
    ctx->r7 = S32(SIGNED(ctx->r25) >> 16);
    // 0x803079BC: slt         $at, $a3, $v0
    ctx->r1 = SIGNED(ctx->r7) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x803079C0: bnel        $at, $zero, L_803077A4
    if (ctx->r1 != 0) {
        // 0x803079C4: sll         $t9, $a3, 2
        ctx->r25 = S32(ctx->r7 << 2);
            goto L_803077A4;
    }
    goto skip_12;
    // 0x803079C4: sll         $t9, $a3, 2
    ctx->r25 = S32(ctx->r7 << 2);
    skip_12:
L_803079C8:
    // 0x803079C8: sb          $zero, 0x28A($t0)
    MEM_B(0X28A, ctx->r8) = 0;
L_803079CC:
    // 0x803079CC: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803079D0: lw          $t0, 0x552C($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X552C);
    // 0x803079D4: lhu         $t8, 0x272($t0)
    ctx->r24 = MEM_HU(ctx->r8, 0X272);
    // 0x803079D8: andi        $t5, $t8, 0x4
    ctx->r13 = ctx->r24 & 0X4;
    // 0x803079DC: beq         $t5, $zero, L_80307B08
    if (ctx->r13 == 0) {
        // 0x803079E0: lui         $t7, 0x803E
        ctx->r15 = S32(0X803E << 16);
            goto L_80307B08;
    }
    // 0x803079E0: lui         $t7, 0x803E
    ctx->r15 = S32(0X803E << 16);
    // 0x803079E4: lhu         $t7, 0x4BFC($t7)
    ctx->r15 = MEM_HU(ctx->r15, 0X4BFC);
    // 0x803079E8: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x803079EC: blez        $t7, L_80307B08
    if (SIGNED(ctx->r15) <= 0) {
        // 0x803079F0: sll         $t9, $a3, 2
        ctx->r25 = S32(ctx->r7 << 2);
            goto L_80307B08;
    }
L_803079F0:
    // 0x803079F0: sll         $t9, $a3, 2
    ctx->r25 = S32(ctx->r7 << 2);
    // 0x803079F4: addu        $a0, $s0, $t9
    ctx->r4 = ADD32(ctx->r16, ctx->r25);
    // 0x803079F8: lw          $v0, 0x2C($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X2C);
    // 0x803079FC: lw          $t6, 0x2CC($t0)
    ctx->r14 = MEM_W(ctx->r8, 0X2CC);
    // 0x80307A00: beql        $v0, $t6, L_80307AEC
    if (ctx->r2 == ctx->r14) {
        // 0x80307A04: lhu         $t8, 0x1C($t3)
        ctx->r24 = MEM_HU(ctx->r11, 0X1C);
            goto L_80307AEC;
    }
    goto skip_13;
    // 0x80307A04: lhu         $t8, 0x1C($t3)
    ctx->r24 = MEM_HU(ctx->r11, 0X1C);
    skip_13:
    // 0x80307A08: lh          $t8, 0x4($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X4);
    // 0x80307A0C: lw          $v1, 0x20($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X20);
    // 0x80307A10: subu        $t5, $t8, $s4
    ctx->r13 = SUB32(ctx->r24, ctx->r20);
    // 0x80307A14: sw          $t5, 0xBC($sp)
    MEM_W(0XBC, ctx->r29) = ctx->r13;
    // 0x80307A18: lh          $t7, 0x8($v0)
    ctx->r15 = MEM_H(ctx->r2, 0X8);
    // 0x80307A1C: slti        $at, $v1, 0x180
    ctx->r1 = SIGNED(ctx->r3) < 0X180 ? 1 : 0;
    // 0x80307A20: subu        $t9, $t7, $s3
    ctx->r25 = SUB32(ctx->r15, ctx->r19);
    // 0x80307A24: beq         $at, $zero, L_80307AE8
    if (ctx->r1 == 0) {
        // 0x80307A28: sw          $t9, 0xC0($sp)
        MEM_W(0XC0, ctx->r29) = ctx->r25;
            goto L_80307AE8;
    }
    // 0x80307A28: sw          $t9, 0xC0($sp)
    MEM_W(0XC0, ctx->r29) = ctx->r25;
    // 0x80307A2C: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x80307A30: sb          $t6, 0x28A($t0)
    MEM_B(0X28A, ctx->r8) = ctx->r14;
    // 0x80307A34: sw          $t3, 0x9C($sp)
    MEM_W(0X9C, ctx->r29) = ctx->r11;
    // 0x80307A38: sw          $t2, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->r10;
    // 0x80307A3C: sw          $t1, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->r9;
    // 0x80307A40: sh          $a3, 0xD6($sp)
    MEM_H(0XD6, ctx->r29) = ctx->r7;
    // 0x80307A44: sw          $v1, 0xCC($sp)
    MEM_W(0XCC, ctx->r29) = ctx->r3;
    // 0x80307A48: addiu       $a0, $sp, 0xBC
    ctx->r4 = ADD32(ctx->r29, 0XBC);
    // 0x80307A4C: jal         0x80304EC4
    // 0x80307A50: addiu       $a1, $sp, 0xB4
    ctx->r5 = ADD32(ctx->r29, 0XB4);
    func_80304EC4_716574(rdram, ctx);
        goto after_9;
    // 0x80307A50: addiu       $a1, $sp, 0xB4
    ctx->r5 = ADD32(ctx->r29, 0XB4);
    after_9:
    // 0x80307A54: lw          $v1, 0xCC($sp)
    ctx->r3 = MEM_W(ctx->r29, 0XCC);
    // 0x80307A58: addiu       $a2, $zero, 0x180
    ctx->r6 = ADD32(0, 0X180);
    // 0x80307A5C: lw          $t7, 0xB4($sp)
    ctx->r15 = MEM_W(ctx->r29, 0XB4);
    // 0x80307A60: subu        $t8, $a2, $v1
    ctx->r24 = SUB32(ctx->r6, ctx->r3);
    // 0x80307A64: multu       $t8, $a2
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80307A68: lw          $t8, 0xB8($sp)
    ctx->r24 = MEM_W(ctx->r29, 0XB8);
    // 0x80307A6C: lw          $t1, 0xB0($sp)
    ctx->r9 = MEM_W(ctx->r29, 0XB0);
    // 0x80307A70: lw          $t2, 0xAC($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XAC);
    // 0x80307A74: lh          $a3, 0xD6($sp)
    ctx->r7 = MEM_H(ctx->r29, 0XD6);
    // 0x80307A78: lw          $t3, 0x9C($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X9C);
    // 0x80307A7C: addiu       $s1, $sp, 0xB4
    ctx->r17 = ADD32(ctx->r29, 0XB4);
    // 0x80307A80: addiu       $s2, $sp, 0xBC
    ctx->r18 = ADD32(ctx->r29, 0XBC);
    // 0x80307A84: mflo        $t5
    ctx->r13 = lo;
    // 0x80307A88: nop

    // 0x80307A8C: nop

    // 0x80307A90: div         $zero, $t5, $a2
    lo = S32(S64(S32(ctx->r13)) / S64(S32(ctx->r6))); hi = S32(S64(S32(ctx->r13)) % S64(S32(ctx->r6)));
    // 0x80307A94: mflo        $v0
    ctx->r2 = lo;
    // 0x80307A98: bne         $a2, $zero, L_80307AA4
    if (ctx->r6 != 0) {
        // 0x80307A9C: nop
    
            goto L_80307AA4;
    }
    // 0x80307A9C: nop

    // 0x80307AA0: break       7
    do_break(2150660768);
L_80307AA4:
    // 0x80307AA4: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80307AA8: bne         $a2, $at, L_80307ABC
    if (ctx->r6 != ctx->r1) {
        // 0x80307AAC: lui         $at, 0x8000
        ctx->r1 = S32(0X8000 << 16);
            goto L_80307ABC;
    }
    // 0x80307AAC: lui         $at, 0x8000
    ctx->r1 = S32(0X8000 << 16);
    // 0x80307AB0: bne         $t5, $at, L_80307ABC
    if (ctx->r13 != ctx->r1) {
        // 0x80307AB4: nop
    
            goto L_80307ABC;
    }
    // 0x80307AB4: nop

    // 0x80307AB8: break       6
    do_break(2150660792);
L_80307ABC:
    // 0x80307ABC: multu       $v0, $t7
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r15)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80307AC0: slti        $at, $s5, 0x10
    ctx->r1 = SIGNED(ctx->r21) < 0X10 ? 1 : 0;
    // 0x80307AC4: mflo        $t9
    ctx->r25 = lo;
    // 0x80307AC8: sra         $t6, $t9, 8
    ctx->r14 = S32(SIGNED(ctx->r25) >> 8);
    // 0x80307ACC: subu        $t2, $t2, $t6
    ctx->r10 = SUB32(ctx->r10, ctx->r14);
    // 0x80307AD0: multu       $v0, $t8
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80307AD4: mflo        $t5
    ctx->r13 = lo;
    // 0x80307AD8: sra         $t7, $t5, 8
    ctx->r15 = S32(SIGNED(ctx->r13) >> 8);
    // 0x80307ADC: beq         $at, $zero, L_80307AE8
    if (ctx->r1 == 0) {
        // 0x80307AE0: subu        $t1, $t1, $t7
        ctx->r9 = SUB32(ctx->r9, ctx->r15);
            goto L_80307AE8;
    }
    // 0x80307AE0: subu        $t1, $t1, $t7
    ctx->r9 = SUB32(ctx->r9, ctx->r15);
    // 0x80307AE4: addiu       $s5, $zero, 0x10
    ctx->r21 = ADD32(0, 0X10);
L_80307AE8:
    // 0x80307AE8: lhu         $t8, 0x1C($t3)
    ctx->r24 = MEM_HU(ctx->r11, 0X1C);
L_80307AEC:
    // 0x80307AEC: addiu       $a3, $a3, 0x1
    ctx->r7 = ADD32(ctx->r7, 0X1);
    // 0x80307AF0: sll         $t9, $a3, 16
    ctx->r25 = S32(ctx->r7 << 16);
    // 0x80307AF4: sra         $a3, $t9, 16
    ctx->r7 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80307AF8: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80307AFC: slt         $at, $a3, $t8
    ctx->r1 = SIGNED(ctx->r7) < SIGNED(ctx->r24) ? 1 : 0;
    // 0x80307B00: bne         $at, $zero, L_803079F0
    if (ctx->r1 != 0) {
        // 0x80307B04: lw          $t0, 0x552C($t0)
        ctx->r8 = MEM_W(ctx->r8, 0X552C);
            goto L_803079F0;
    }
    // 0x80307B04: lw          $t0, 0x552C($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X552C);
L_80307B08:
    // 0x80307B08: lbu         $v0, 0x2A0($t0)
    ctx->r2 = MEM_BU(ctx->r8, 0X2A0);
    // 0x80307B0C: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x80307B10: beq         $v0, $at, L_80307C84
    if (ctx->r2 == ctx->r1) {
        // 0x80307B14: addiu       $at, $zero, 0x5
        ctx->r1 = ADD32(0, 0X5);
            goto L_80307C84;
    }
    // 0x80307B14: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80307B18: bnel        $v0, $at, L_80307B34
    if (ctx->r2 != ctx->r1) {
        // 0x80307B1C: lhu         $t7, 0x272($t0)
        ctx->r15 = MEM_HU(ctx->r8, 0X272);
            goto L_80307B34;
    }
    goto skip_14;
    // 0x80307B1C: lhu         $t7, 0x272($t0)
    ctx->r15 = MEM_HU(ctx->r8, 0X272);
    skip_14:
    // 0x80307B20: lb          $t5, 0x2A1($t0)
    ctx->r13 = MEM_B(ctx->r8, 0X2A1);
    // 0x80307B24: addiu       $at, $zero, -0x1
    ctx->r1 = ADD32(0, -0X1);
    // 0x80307B28: beq         $t5, $at, L_80307C84
    if (ctx->r13 == ctx->r1) {
        // 0x80307B2C: nop
    
            goto L_80307C84;
    }
    // 0x80307B2C: nop

    // 0x80307B30: lhu         $t7, 0x272($t0)
    ctx->r15 = MEM_HU(ctx->r8, 0X272);
L_80307B34:
    // 0x80307B34: andi        $t9, $t7, 0x2
    ctx->r25 = ctx->r15 & 0X2;
    // 0x80307B38: beq         $t9, $zero, L_80307C84
    if (ctx->r25 == 0) {
        // 0x80307B3C: lui         $t6, 0x803E
        ctx->r14 = S32(0X803E << 16);
            goto L_80307C84;
    }
    // 0x80307B3C: lui         $t6, 0x803E
    ctx->r14 = S32(0X803E << 16);
    // 0x80307B40: lhu         $t6, 0x4C18($t6)
    ctx->r14 = MEM_HU(ctx->r14, 0X4C18);
    // 0x80307B44: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x80307B48: blez        $t6, L_80307C84
    if (SIGNED(ctx->r14) <= 0) {
        // 0x80307B4C: lui         $t0, 0x803D
        ctx->r8 = S32(0X803D << 16);
            goto L_80307C84;
    }
L_80307B4C:
    // 0x80307B4C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80307B50: lw          $t0, 0x552C($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X552C);
    // 0x80307B54: sll         $t8, $a3, 2
    ctx->r24 = S32(ctx->r7 << 2);
    // 0x80307B58: addu        $a0, $s0, $t8
    ctx->r4 = ADD32(ctx->r16, ctx->r24);
    // 0x80307B5C: lw          $v0, 0x48($a0)
    ctx->r2 = MEM_W(ctx->r4, 0X48);
    // 0x80307B60: lw          $t5, 0x2CC($t0)
    ctx->r13 = MEM_W(ctx->r8, 0X2CC);
    // 0x80307B64: beq         $v0, $t5, L_80307B78
    if (ctx->r2 == ctx->r13) {
        // 0x80307B68: nop
    
            goto L_80307B78;
    }
    // 0x80307B68: nop

    // 0x80307B6C: lw          $t7, 0x2AC($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X2AC);
    // 0x80307B70: bnel        $v0, $t7, L_80307B84
    if (ctx->r2 != ctx->r15) {
        // 0x80307B74: lh          $t9, 0x4($v0)
        ctx->r25 = MEM_H(ctx->r2, 0X4);
            goto L_80307B84;
    }
    goto skip_15;
    // 0x80307B74: lh          $t9, 0x4($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X4);
    skip_15:
L_80307B78:
    // 0x80307B78: b           L_80307C6C
    // 0x80307B7C: lhu         $v0, 0x38($t3)
    ctx->r2 = MEM_HU(ctx->r11, 0X38);
        goto L_80307C6C;
    // 0x80307B7C: lhu         $v0, 0x38($t3)
    ctx->r2 = MEM_HU(ctx->r11, 0X38);
    // 0x80307B80: lh          $t9, 0x4($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X4);
L_80307B84:
    // 0x80307B84: lw          $v1, 0x3C($a0)
    ctx->r3 = MEM_W(ctx->r4, 0X3C);
    // 0x80307B88: subu        $t6, $t9, $s4
    ctx->r14 = SUB32(ctx->r25, ctx->r20);
    // 0x80307B8C: sw          $t6, 0xBC($sp)
    MEM_W(0XBC, ctx->r29) = ctx->r14;
    // 0x80307B90: lh          $t8, 0x8($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X8);
    // 0x80307B94: slti        $at, $v1, 0x80
    ctx->r1 = SIGNED(ctx->r3) < 0X80 ? 1 : 0;
    // 0x80307B98: subu        $t5, $t8, $s3
    ctx->r13 = SUB32(ctx->r24, ctx->r19);
    // 0x80307B9C: beq         $at, $zero, L_80307C68
    if (ctx->r1 == 0) {
        // 0x80307BA0: sw          $t5, 0xC0($sp)
        MEM_W(0XC0, ctx->r29) = ctx->r13;
            goto L_80307C68;
    }
    // 0x80307BA0: sw          $t5, 0xC0($sp)
    MEM_W(0XC0, ctx->r29) = ctx->r13;
    // 0x80307BA4: or          $a0, $s2, $zero
    ctx->r4 = ctx->r18 | 0;
    // 0x80307BA8: or          $a1, $s1, $zero
    ctx->r5 = ctx->r17 | 0;
    // 0x80307BAC: sw          $v1, 0xCC($sp)
    MEM_W(0XCC, ctx->r29) = ctx->r3;
    // 0x80307BB0: sh          $a3, 0xD6($sp)
    MEM_H(0XD6, ctx->r29) = ctx->r7;
    // 0x80307BB4: sw          $t1, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->r9;
    // 0x80307BB8: sw          $t2, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->r10;
    // 0x80307BBC: jal         0x80304EC4
    // 0x80307BC0: sw          $t3, 0x9C($sp)
    MEM_W(0X9C, ctx->r29) = ctx->r11;
    func_80304EC4_716574(rdram, ctx);
        goto after_10;
    // 0x80307BC0: sw          $t3, 0x9C($sp)
    MEM_W(0X9C, ctx->r29) = ctx->r11;
    after_10:
    // 0x80307BC4: lw          $v1, 0xCC($sp)
    ctx->r3 = MEM_W(ctx->r29, 0XCC);
    // 0x80307BC8: lw          $t8, 0xB4($sp)
    ctx->r24 = MEM_W(ctx->r29, 0XB4);
    // 0x80307BCC: addiu       $t6, $zero, 0xC0
    ctx->r14 = ADD32(0, 0XC0);
    // 0x80307BD0: sll         $t7, $v1, 2
    ctx->r15 = S32(ctx->r3 << 2);
    // 0x80307BD4: subu        $t7, $t7, $v1
    ctx->r15 = SUB32(ctx->r15, ctx->r3);
    // 0x80307BD8: sll         $t7, $t7, 6
    ctx->r15 = S32(ctx->r15 << 6);
    // 0x80307BDC: negu        $a0, $v1
    ctx->r4 = SUB32(0, ctx->r3);
    // 0x80307BE0: lw          $t2, 0xAC($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XAC);
    // 0x80307BE4: lw          $t1, 0xB0($sp)
    ctx->r9 = MEM_W(ctx->r29, 0XB0);
    // 0x80307BE8: lh          $a3, 0xD6($sp)
    ctx->r7 = MEM_H(ctx->r29, 0XD6);
    // 0x80307BEC: lw          $t3, 0x9C($sp)
    ctx->r11 = MEM_W(ctx->r29, 0X9C);
    // 0x80307BF0: bgez        $t7, L_80307C00
    if (SIGNED(ctx->r15) >= 0) {
        // 0x80307BF4: sra         $t9, $t7, 7
        ctx->r25 = S32(SIGNED(ctx->r15) >> 7);
            goto L_80307C00;
    }
    // 0x80307BF4: sra         $t9, $t7, 7
    ctx->r25 = S32(SIGNED(ctx->r15) >> 7);
    // 0x80307BF8: addiu       $at, $t7, 0x7F
    ctx->r1 = ADD32(ctx->r15, 0X7F);
    // 0x80307BFC: sra         $t9, $at, 7
    ctx->r25 = S32(SIGNED(ctx->r1) >> 7);
L_80307C00:
    // 0x80307C00: subu        $v0, $t6, $t9
    ctx->r2 = SUB32(ctx->r14, ctx->r25);
    // 0x80307C04: multu       $v0, $t8
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r24)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80307C08: lw          $t6, 0xB8($sp)
    ctx->r14 = MEM_W(ctx->r29, 0XB8);
    // 0x80307C0C: mflo        $t5
    ctx->r13 = lo;
    // 0x80307C10: sra         $t7, $t5, 8
    ctx->r15 = S32(SIGNED(ctx->r13) >> 8);
    // 0x80307C14: sll         $t5, $a0, 2
    ctx->r13 = S32(ctx->r4 << 2);
    // 0x80307C18: multu       $v0, $t6
    result = U64(U32(ctx->r2)) * U64(U32(ctx->r14)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80307C1C: addu        $t5, $t5, $a0
    ctx->r13 = ADD32(ctx->r13, ctx->r4);
    // 0x80307C20: sll         $t5, $t5, 1
    ctx->r13 = S32(ctx->r13 << 1);
    // 0x80307C24: addiu       $a0, $t5, 0x500
    ctx->r4 = ADD32(ctx->r13, 0X500);
    // 0x80307C28: subu        $t2, $t2, $t7
    ctx->r10 = SUB32(ctx->r10, ctx->r15);
    // 0x80307C2C: mflo        $t9
    ctx->r25 = lo;
    // 0x80307C30: sra         $t8, $t9, 8
    ctx->r24 = S32(SIGNED(ctx->r25) >> 8);
    // 0x80307C34: subu        $t1, $t1, $t8
    ctx->r9 = SUB32(ctx->r9, ctx->r24);
    // 0x80307C38: bgez        $a0, L_80307C48
    if (SIGNED(ctx->r4) >= 0) {
        // 0x80307C3C: sra         $t7, $a0, 7
        ctx->r15 = S32(SIGNED(ctx->r4) >> 7);
            goto L_80307C48;
    }
    // 0x80307C3C: sra         $t7, $a0, 7
    ctx->r15 = S32(SIGNED(ctx->r4) >> 7);
    // 0x80307C40: addiu       $at, $a0, 0x7F
    ctx->r1 = ADD32(ctx->r4, 0X7F);
    // 0x80307C44: sra         $t7, $at, 7
    ctx->r15 = S32(SIGNED(ctx->r1) >> 7);
L_80307C48:
    // 0x80307C48: sll         $t6, $t7, 16
    ctx->r14 = S32(ctx->r15 << 16);
    // 0x80307C4C: sra         $t9, $t6, 16
    ctx->r25 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80307C50: slt         $at, $s5, $t9
    ctx->r1 = SIGNED(ctx->r21) < SIGNED(ctx->r25) ? 1 : 0;
    // 0x80307C54: beql        $at, $zero, L_80307C6C
    if (ctx->r1 == 0) {
        // 0x80307C58: lhu         $v0, 0x38($t3)
        ctx->r2 = MEM_HU(ctx->r11, 0X38);
            goto L_80307C6C;
    }
    goto skip_16;
    // 0x80307C58: lhu         $v0, 0x38($t3)
    ctx->r2 = MEM_HU(ctx->r11, 0X38);
    skip_16:
    // 0x80307C5C: sll         $s5, $t9, 16
    ctx->r21 = S32(ctx->r25 << 16);
    // 0x80307C60: sra         $t8, $s5, 16
    ctx->r24 = S32(SIGNED(ctx->r21) >> 16);
    // 0x80307C64: or          $s5, $t8, $zero
    ctx->r21 = ctx->r24 | 0;
L_80307C68:
    // 0x80307C68: lhu         $v0, 0x38($t3)
    ctx->r2 = MEM_HU(ctx->r11, 0X38);
L_80307C6C:
    // 0x80307C6C: addiu       $a3, $a3, 0x1
    ctx->r7 = ADD32(ctx->r7, 0X1);
    // 0x80307C70: sll         $t5, $a3, 16
    ctx->r13 = S32(ctx->r7 << 16);
    // 0x80307C74: sra         $a3, $t5, 16
    ctx->r7 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80307C78: slt         $at, $a3, $v0
    ctx->r1 = SIGNED(ctx->r7) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x80307C7C: bne         $at, $zero, L_80307B4C
    if (ctx->r1 != 0) {
        // 0x80307C80: nop
    
            goto L_80307B4C;
    }
    // 0x80307C80: nop

L_80307C84:
    // 0x80307C84: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80307C88: lw          $t6, 0x5524($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5524);
    // 0x80307C8C: addiu       $at, $zero, 0x40
    ctx->r1 = ADD32(0, 0X40);
    // 0x80307C90: lhu         $v0, 0x9E($t6)
    ctx->r2 = MEM_HU(ctx->r14, 0X9E);
    // 0x80307C94: beq         $v0, $at, L_80307EDC
    if (ctx->r2 == ctx->r1) {
        // 0x80307C98: addiu       $at, $zero, 0x20
        ctx->r1 = ADD32(0, 0X20);
            goto L_80307EDC;
    }
    // 0x80307C98: addiu       $at, $zero, 0x20
    ctx->r1 = ADD32(0, 0X20);
    // 0x80307C9C: beq         $v0, $at, L_80307EDC
    if (ctx->r2 == ctx->r1) {
        // 0x80307CA0: addiu       $at, $zero, 0x80
        ctx->r1 = ADD32(0, 0X80);
            goto L_80307EDC;
    }
    // 0x80307CA0: addiu       $at, $zero, 0x80
    ctx->r1 = ADD32(0, 0X80);
    // 0x80307CA4: beq         $v0, $at, L_80307EDC
    if (ctx->r2 == ctx->r1) {
        // 0x80307CA8: lui         $t9, 0x803D
        ctx->r25 = S32(0X803D << 16);
            goto L_80307EDC;
    }
    // 0x80307CA8: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80307CAC: lw          $t9, 0x552C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X552C);
    // 0x80307CB0: lhu         $t8, 0x272($t9)
    ctx->r24 = MEM_HU(ctx->r25, 0X272);
    // 0x80307CB4: andi        $t5, $t8, 0x30
    ctx->r13 = ctx->r24 & 0X30;
    // 0x80307CB8: beq         $t5, $zero, L_80307EDC
    if (ctx->r13 == 0) {
        // 0x80307CBC: lui         $t0, 0x803D
        ctx->r8 = S32(0X803D << 16);
            goto L_80307EDC;
    }
    // 0x80307CBC: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80307CC0: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x80307CC4: lw          $v1, 0x6C($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X6C);
    // 0x80307CC8: beql        $v1, $zero, L_80307D28
    if (ctx->r3 == 0) {
        // 0x80307CCC: andi        $s1, $s4, 0xFFC0
        ctx->r17 = ctx->r20 & 0XFFC0;
            goto L_80307D28;
    }
    goto skip_17;
    // 0x80307CCC: andi        $s1, $s4, 0xFFC0
    ctx->r17 = ctx->r20 & 0XFFC0;
    skip_17:
    // 0x80307CD0: lw          $t7, 0x16C($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X16C);
    // 0x80307CD4: lw          $t6, 0x80($t7)
    ctx->r14 = MEM_W(ctx->r15, 0X80);
    // 0x80307CD8: sll         $t8, $t6, 17
    ctx->r24 = S32(ctx->r14 << 17);
    // 0x80307CDC: bgezl       $t8, L_80307D28
    if (SIGNED(ctx->r24) >= 0) {
        // 0x80307CE0: andi        $s1, $s4, 0xFFC0
        ctx->r17 = ctx->r20 & 0XFFC0;
            goto L_80307D28;
    }
    goto skip_18;
    // 0x80307CE0: andi        $s1, $s4, 0xFFC0
    ctx->r17 = ctx->r20 & 0XFFC0;
    skip_18:
    // 0x80307CE4: lh          $v0, 0x30($v1)
    ctx->r2 = MEM_H(ctx->r3, 0X30);
    // 0x80307CE8: addiu       $s2, $zero, -0x40
    ctx->r18 = ADD32(0, -0X40);
    // 0x80307CEC: sll         $t5, $v0, 1
    ctx->r13 = S32(ctx->r2 << 1);
    // 0x80307CF0: sll         $t4, $t5, 16
    ctx->r12 = S32(ctx->r13 << 16);
    // 0x80307CF4: sra         $t6, $t4, 16
    ctx->r14 = S32(SIGNED(ctx->r12) >> 16);
    // 0x80307CF8: sll         $t9, $t6, 2
    ctx->r25 = S32(ctx->r14 << 2);
    // 0x80307CFC: addiu       $t7, $t5, -0x1
    ctx->r15 = ADD32(ctx->r13, -0X1);
    // 0x80307D00: addu        $t9, $t9, $t6
    ctx->r25 = ADD32(ctx->r25, ctx->r14);
    // 0x80307D04: sh          $t5, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r13;
    // 0x80307D08: sra         $t8, $t9, 6
    ctx->r24 = S32(SIGNED(ctx->r25) >> 6);
    // 0x80307D0C: sh          $t7, 0x84($sp)
    MEM_H(0X84, ctx->r29) = ctx->r15;
    // 0x80307D10: sll         $t5, $t8, 16
    ctx->r13 = S32(ctx->r24 << 16);
    // 0x80307D14: sra         $t4, $t5, 16
    ctx->r12 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80307D18: lh          $s1, 0x4($v1)
    ctx->r17 = MEM_H(ctx->r3, 0X4);
    // 0x80307D1C: b           L_80307D5C
    // 0x80307D20: lh          $s0, 0x8($v1)
    ctx->r16 = MEM_H(ctx->r3, 0X8);
        goto L_80307D5C;
    // 0x80307D20: lh          $s0, 0x8($v1)
    ctx->r16 = MEM_H(ctx->r3, 0X8);
    // 0x80307D24: andi        $s1, $s4, 0xFFC0
    ctx->r17 = ctx->r20 & 0XFFC0;
L_80307D28:
    // 0x80307D28: andi        $s0, $s3, 0xFFC0
    ctx->r16 = ctx->r19 & 0XFFC0;
    // 0x80307D2C: addiu       $s1, $s1, 0x20
    ctx->r17 = ADD32(ctx->r17, 0X20);
    // 0x80307D30: addiu       $s0, $s0, 0x20
    ctx->r16 = ADD32(ctx->r16, 0X20);
    // 0x80307D34: addiu       $t6, $zero, 0x40
    ctx->r14 = ADD32(0, 0X40);
    // 0x80307D38: addiu       $t9, $zero, 0x3F
    ctx->r25 = ADD32(0, 0X3F);
    // 0x80307D3C: sll         $t8, $s1, 16
    ctx->r24 = S32(ctx->r17 << 16);
    // 0x80307D40: sll         $t7, $s0, 16
    ctx->r15 = S32(ctx->r16 << 16);
    // 0x80307D44: addiu       $s2, $zero, -0x40
    ctx->r18 = ADD32(0, -0X40);
    // 0x80307D48: sh          $t6, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r14;
    // 0x80307D4C: sh          $t9, 0x84($sp)
    MEM_H(0X84, ctx->r29) = ctx->r25;
    // 0x80307D50: addiu       $t4, $zero, 0x5
    ctx->r12 = ADD32(0, 0X5);
    // 0x80307D54: sra         $s1, $t8, 16
    ctx->r17 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80307D58: sra         $s0, $t7, 16
    ctx->r16 = S32(SIGNED(ctx->r15) >> 16);
L_80307D5C:
    // 0x80307D5C: lw          $a2, 0xC($t0)
    ctx->r6 = MEM_W(ctx->r8, 0XC);
    // 0x80307D60: lbu         $a3, 0x160($t0)
    ctx->r7 = MEM_BU(ctx->r8, 0X160);
    // 0x80307D64: lh          $t5, 0x86($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X86);
    // 0x80307D68: sll         $a0, $s1, 16
    ctx->r4 = S32(ctx->r17 << 16);
    // 0x80307D6C: sll         $a1, $s0, 16
    ctx->r5 = S32(ctx->r16 << 16);
    // 0x80307D70: sra         $t8, $a1, 16
    ctx->r24 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80307D74: sra         $t9, $a0, 16
    ctx->r25 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80307D78: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    // 0x80307D7C: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    // 0x80307D80: sh          $t4, 0x82($sp)
    MEM_H(0X82, ctx->r29) = ctx->r12;
    // 0x80307D84: sw          $t2, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->r10;
    // 0x80307D88: sw          $t1, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->r9;
    // 0x80307D8C: jal         0x803064BC
    // 0x80307D90: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    func_803064BC_717B6C(rdram, ctx);
        goto after_11;
    // 0x80307D90: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    after_11:
    // 0x80307D94: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80307D98: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x80307D9C: lw          $t1, 0xB0($sp)
    ctx->r9 = MEM_W(ctx->r29, 0XB0);
    // 0x80307DA0: lw          $t2, 0xAC($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XAC);
    // 0x80307DA4: lw          $v1, 0x6C($t0)
    ctx->r3 = MEM_W(ctx->r8, 0X6C);
    // 0x80307DA8: lh          $t4, 0x82($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X82);
    // 0x80307DAC: andi        $t3, $v0, 0xFF
    ctx->r11 = ctx->r2 & 0XFF;
    // 0x80307DB0: beql        $v1, $zero, L_80307DD0
    if (ctx->r3 == 0) {
        // 0x80307DB4: lw          $a2, 0xC($t0)
        ctx->r6 = MEM_W(ctx->r8, 0XC);
            goto L_80307DD0;
    }
    goto skip_19;
    // 0x80307DB4: lw          $a2, 0xC($t0)
    ctx->r6 = MEM_W(ctx->r8, 0XC);
    skip_19:
    // 0x80307DB8: lw          $t7, 0x16C($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X16C);
    // 0x80307DBC: lw          $t6, 0x80($t7)
    ctx->r14 = MEM_W(ctx->r15, 0X80);
    // 0x80307DC0: sll         $t8, $t6, 17
    ctx->r24 = S32(ctx->r14 << 17);
    // 0x80307DC4: bltz        $t8, L_80307ED4
    if (SIGNED(ctx->r24) < 0) {
        // 0x80307DC8: nop
    
            goto L_80307ED4;
    }
    // 0x80307DC8: nop

    // 0x80307DCC: lw          $a2, 0xC($t0)
    ctx->r6 = MEM_W(ctx->r8, 0XC);
L_80307DD0:
    // 0x80307DD0: sll         $a0, $s1, 16
    ctx->r4 = S32(ctx->r17 << 16);
    // 0x80307DD4: sll         $a1, $s0, 16
    ctx->r5 = S32(ctx->r16 << 16);
    // 0x80307DD8: sra         $t7, $a1, 16
    ctx->r15 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80307DDC: sra         $t5, $a0, 16
    ctx->r13 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80307DE0: or          $a0, $t5, $zero
    ctx->r4 = ctx->r13 | 0;
    // 0x80307DE4: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    // 0x80307DE8: sh          $t4, 0x82($sp)
    MEM_H(0X82, ctx->r29) = ctx->r12;
    // 0x80307DEC: sb          $t3, 0x8D($sp)
    MEM_B(0X8D, ctx->r29) = ctx->r11;
    // 0x80307DF0: sw          $t2, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->r10;
    // 0x80307DF4: sw          $t1, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->r9;
    // 0x80307DF8: sw          $t3, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r11;
    // 0x80307DFC: jal         0x803065F0
    // 0x80307E00: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    func_803065F0_717CA0(rdram, ctx);
        goto after_12;
    // 0x80307E00: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    after_12:
    // 0x80307E04: lw          $t1, 0xB0($sp)
    ctx->r9 = MEM_W(ctx->r29, 0XB0);
    // 0x80307E08: lw          $t2, 0xAC($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XAC);
    // 0x80307E0C: lbu         $t3, 0x8D($sp)
    ctx->r11 = MEM_BU(ctx->r29, 0X8D);
    // 0x80307E10: beq         $v0, $zero, L_80307ED4
    if (ctx->r2 == 0) {
        // 0x80307E14: lh          $t4, 0x82($sp)
        ctx->r12 = MEM_H(ctx->r29, 0X82);
            goto L_80307ED4;
    }
    // 0x80307E14: lh          $t4, 0x82($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X82);
    // 0x80307E18: addiu       $t6, $zero, 0x48
    ctx->r14 = ADD32(0, 0X48);
    // 0x80307E1C: and         $v1, $s4, $s2
    ctx->r3 = ctx->r20 & ctx->r18;
    // 0x80307E20: and         $a0, $s3, $s2
    ctx->r4 = ctx->r19 & ctx->r18;
    // 0x80307E24: sll         $a1, $v0, 16
    ctx->r5 = S32(ctx->r2 << 16);
    // 0x80307E28: sh          $t6, 0x86($sp)
    MEM_H(0X86, ctx->r29) = ctx->r14;
    // 0x80307E2C: sll         $s1, $v1, 16
    ctx->r17 = S32(ctx->r3 << 16);
    // 0x80307E30: sll         $s0, $a0, 16
    ctx->r16 = S32(ctx->r4 << 16);
    // 0x80307E34: sra         $t7, $a1, 16
    ctx->r15 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80307E38: addiu       $t9, $zero, 0x47
    ctx->r25 = ADD32(0, 0X47);
    // 0x80307E3C: sra         $t8, $s1, 16
    ctx->r24 = S32(SIGNED(ctx->r17) >> 16);
    // 0x80307E40: sra         $t5, $s0, 16
    ctx->r13 = S32(SIGNED(ctx->r16) >> 16);
    // 0x80307E44: andi        $t6, $t7, 0x4
    ctx->r14 = ctx->r15 & 0X4;
    // 0x80307E48: sh          $t9, 0x84($sp)
    MEM_H(0X84, ctx->r29) = ctx->r25;
    // 0x80307E4C: addiu       $t4, $zero, 0xA
    ctx->r12 = ADD32(0, 0XA);
    // 0x80307E50: or          $s1, $t8, $zero
    ctx->r17 = ctx->r24 | 0;
    // 0x80307E54: or          $s0, $t5, $zero
    ctx->r16 = ctx->r13 | 0;
    // 0x80307E58: beq         $t6, $zero, L_80307E6C
    if (ctx->r14 == 0) {
        // 0x80307E5C: or          $a1, $t7, $zero
        ctx->r5 = ctx->r15 | 0;
            goto L_80307E6C;
    }
    // 0x80307E5C: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    // 0x80307E60: addiu       $s0, $a0, 0x40
    ctx->r16 = ADD32(ctx->r4, 0X40);
    // 0x80307E64: sll         $t8, $s0, 16
    ctx->r24 = S32(ctx->r16 << 16);
    // 0x80307E68: sra         $s0, $t8, 16
    ctx->r16 = S32(SIGNED(ctx->r24) >> 16);
L_80307E6C:
    // 0x80307E6C: andi        $t7, $a1, 0x1
    ctx->r15 = ctx->r5 & 0X1;
    // 0x80307E70: beq         $t7, $zero, L_80307E84
    if (ctx->r15 == 0) {
        // 0x80307E74: nop
    
            goto L_80307E84;
    }
    // 0x80307E74: nop

    // 0x80307E78: addiu       $s1, $v1, 0x40
    ctx->r17 = ADD32(ctx->r3, 0X40);
    // 0x80307E7C: sll         $t9, $s1, 16
    ctx->r25 = S32(ctx->r17 << 16);
    // 0x80307E80: sra         $s1, $t9, 16
    ctx->r17 = S32(SIGNED(ctx->r25) >> 16);
L_80307E84:
    // 0x80307E84: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80307E88: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x80307E8C: sll         $a0, $s1, 16
    ctx->r4 = S32(ctx->r17 << 16);
    // 0x80307E90: sll         $a1, $s0, 16
    ctx->r5 = S32(ctx->r16 << 16);
    // 0x80307E94: lw          $a2, 0xC($t0)
    ctx->r6 = MEM_W(ctx->r8, 0XC);
    // 0x80307E98: lbu         $a3, 0x160($t0)
    ctx->r7 = MEM_BU(ctx->r8, 0X160);
    // 0x80307E9C: sra         $t7, $a1, 16
    ctx->r15 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80307EA0: sra         $t5, $a0, 16
    ctx->r13 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80307EA4: addiu       $t6, $zero, 0x48
    ctx->r14 = ADD32(0, 0X48);
    // 0x80307EA8: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80307EAC: or          $a0, $t5, $zero
    ctx->r4 = ctx->r13 | 0;
    // 0x80307EB0: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    // 0x80307EB4: sh          $t4, 0x82($sp)
    MEM_H(0X82, ctx->r29) = ctx->r12;
    // 0x80307EB8: sw          $t2, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->r10;
    // 0x80307EBC: jal         0x803064BC
    // 0x80307EC0: sw          $t1, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->r9;
    func_803064BC_717B6C(rdram, ctx);
        goto after_13;
    // 0x80307EC0: sw          $t1, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->r9;
    after_13:
    // 0x80307EC4: lw          $t1, 0xB0($sp)
    ctx->r9 = MEM_W(ctx->r29, 0XB0);
    // 0x80307EC8: lw          $t2, 0xAC($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XAC);
    // 0x80307ECC: lh          $t4, 0x82($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X82);
    // 0x80307ED0: andi        $t3, $v0, 0xFF
    ctx->r11 = ctx->r2 & 0XFF;
L_80307ED4:
    // 0x80307ED4: b           L_80307EEC
    // 0x80307ED8: or          $v1, $t3, $zero
    ctx->r3 = ctx->r11 | 0;
        goto L_80307EEC;
    // 0x80307ED8: or          $v1, $t3, $zero
    ctx->r3 = ctx->r11 | 0;
L_80307EDC:
    // 0x80307EDC: or          $v1, $zero, $zero
    ctx->r3 = 0 | 0;
    // 0x80307EE0: lh          $s1, 0x8A($sp)
    ctx->r17 = MEM_H(ctx->r29, 0X8A);
    // 0x80307EE4: lh          $s0, 0x88($sp)
    ctx->r16 = MEM_H(ctx->r29, 0X88);
    // 0x80307EE8: lh          $t4, 0x82($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X82);
L_80307EEC:
    // 0x80307EEC: or          $t9, $t2, $t1
    ctx->r25 = ctx->r10 | ctx->r9;
    // 0x80307EF0: bne         $t9, $zero, L_80307F04
    if (ctx->r25 != 0) {
        // 0x80307EF4: lui         $t8, 0x803D
        ctx->r24 = S32(0X803D << 16);
            goto L_80307F04;
    }
    // 0x80307EF4: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x80307EF8: lw          $t8, 0x5530($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5530);
    // 0x80307EFC: b           L_80307F58
    // 0x80307F00: lh          $t3, 0x2C($t8)
    ctx->r11 = MEM_H(ctx->r24, 0X2C);
        goto L_80307F58;
    // 0x80307F00: lh          $t3, 0x2C($t8)
    ctx->r11 = MEM_H(ctx->r24, 0X2C);
L_80307F04:
    // 0x80307F04: sll         $a0, $t2, 16
    ctx->r4 = S32(ctx->r10 << 16);
    // 0x80307F08: sll         $a1, $t1, 16
    ctx->r5 = S32(ctx->r9 << 16);
    // 0x80307F0C: sra         $t7, $a1, 16
    ctx->r15 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80307F10: sra         $t5, $a0, 16
    ctx->r13 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80307F14: or          $a0, $t5, $zero
    ctx->r4 = ctx->r13 | 0;
    // 0x80307F18: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    // 0x80307F1C: sw          $v1, 0x54($sp)
    MEM_W(0X54, ctx->r29) = ctx->r3;
    // 0x80307F20: sw          $t1, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->r9;
    // 0x80307F24: sw          $t2, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->r10;
    // 0x80307F28: jal         0x801284B8
    // 0x80307F2C: sh          $t4, 0x82($sp)
    MEM_H(0X82, ctx->r29) = ctx->r12;
    func_801284B8(rdram, ctx);
        goto after_14;
    // 0x80307F2C: sh          $t4, 0x82($sp)
    MEM_H(0X82, ctx->r29) = ctx->r12;
    after_14:
    // 0x80307F30: sll         $t3, $v0, 8
    ctx->r11 = S32(ctx->r2 << 8);
    // 0x80307F34: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80307F38: div         $zero, $t3, $at
    lo = S32(S64(S32(ctx->r11)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r11)) % S64(S32(ctx->r1)));
    // 0x80307F3C: mflo        $t6
    ctx->r14 = lo;
    // 0x80307F40: sll         $t9, $t6, 16
    ctx->r25 = S32(ctx->r14 << 16);
    // 0x80307F44: sra         $t3, $t9, 16
    ctx->r11 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80307F48: lw          $v1, 0x54($sp)
    ctx->r3 = MEM_W(ctx->r29, 0X54);
    // 0x80307F4C: lw          $t1, 0xB0($sp)
    ctx->r9 = MEM_W(ctx->r29, 0XB0);
    // 0x80307F50: lw          $t2, 0xAC($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XAC);
    // 0x80307F54: lh          $t4, 0x82($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X82);
L_80307F58:
    // 0x80307F58: sltiu       $at, $v1, 0x10
    ctx->r1 = ctx->r3 < 0X10 ? 1 : 0;
    // 0x80307F5C: beq         $at, $zero, L_8030941C
    if (ctx->r1 == 0) {
        // 0x80307F60: addiu       $s2, $zero, -0x1
        ctx->r18 = ADD32(0, -0X1);
            goto L_8030941C;
    }
    // 0x80307F60: addiu       $s2, $zero, -0x1
    ctx->r18 = ADD32(0, -0X1);
    // 0x80307F64: sll         $t5, $v1, 2
    ctx->r13 = S32(ctx->r3 << 2);
    // 0x80307F68: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x80307F6C: addu        $at, $at, $t5
    gpr jr_addend_80307F74 = ctx->r13;
    ctx->r1 = ADD32(ctx->r1, ctx->r13);
    // 0x80307F70: lw          $t5, -0x2F8C($at)
    ctx->r13 = ADD32(ctx->r1, -0X2F8C);
    // 0x80307F74: jr          $t5
    // 0x80307F78: nop

    switch (jr_addend_80307F74 >> 2) {
        case 0: goto L_80307F7C; break;
        case 1: goto L_80307F8C; break;
        case 2: goto L_803080C4; break;
        case 3: goto L_80308200; break;
        case 4: goto L_8030828C; break;
        case 5: goto L_803083CC; break;
        case 6: goto L_8030863C; break;
        case 7: goto L_803088A4; break;
        case 8: goto L_803089B4; break;
        case 9: goto L_80308AF8; break;
        case 10: goto L_80308D60; break;
        case 11: goto L_80308FD4; break;
        case 12: goto L_803090E4; break;
        case 13: goto L_80309168; break;
        case 14: goto L_80309270; break;
        case 15: goto L_80309378; break;
        default: switch_error(__func__, 0x80307F74, 0x803BD074);
    }
    // 0x80307F78: nop

L_80307F7C:
    // 0x80307F7C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80307F80: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x80307F84: b           L_80309428
    // 0x80307F88: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
        goto L_80309428;
    // 0x80307F88: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_80307F8C:
    // 0x80307F8C: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80307F90: lw          $t9, 0x5530($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5530);
    // 0x80307F94: sll         $a0, $s1, 16
    ctx->r4 = S32(ctx->r17 << 16);
    // 0x80307F98: sll         $a1, $s0, 16
    ctx->r5 = S32(ctx->r16 << 16);
    // 0x80307F9C: lw          $a2, 0xC($t9)
    ctx->r6 = MEM_W(ctx->r25, 0XC);
    // 0x80307FA0: sra         $t6, $a1, 16
    ctx->r14 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80307FA4: sra         $t7, $a0, 16
    ctx->r15 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80307FA8: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x80307FAC: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x80307FB0: sh          $t4, 0x82($sp)
    MEM_H(0X82, ctx->r29) = ctx->r12;
    // 0x80307FB4: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    // 0x80307FB8: sw          $t2, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->r10;
    // 0x80307FBC: sw          $t1, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->r9;
    // 0x80307FC0: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x80307FC4: jal         0x80305A70
    // 0x80307FC8: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    func_80305A70_717120(rdram, ctx);
        goto after_15;
    // 0x80307FC8: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    after_15:
    // 0x80307FCC: lw          $t1, 0xB0($sp)
    ctx->r9 = MEM_W(ctx->r29, 0XB0);
    // 0x80307FD0: lw          $t2, 0xAC($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XAC);
    // 0x80307FD4: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
    // 0x80307FD8: bne         $v0, $zero, L_80308038
    if (ctx->r2 != 0) {
        // 0x80307FDC: lh          $t4, 0x82($sp)
        ctx->r12 = MEM_H(ctx->r29, 0X82);
            goto L_80308038;
    }
    // 0x80307FDC: lh          $t4, 0x82($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X82);
    // 0x80307FE0: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80307FE4: lw          $t7, 0x5530($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5530);
    // 0x80307FE8: sll         $a0, $s1, 16
    ctx->r4 = S32(ctx->r17 << 16);
    // 0x80307FEC: sll         $a1, $s0, 16
    ctx->r5 = S32(ctx->r16 << 16);
    // 0x80307FF0: lw          $a2, 0xC($t7)
    ctx->r6 = MEM_W(ctx->r15, 0XC);
    // 0x80307FF4: sra         $t5, $a1, 16
    ctx->r13 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80307FF8: sra         $t8, $a0, 16
    ctx->r24 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80307FFC: addiu       $t6, $zero, 0x1
    ctx->r14 = ADD32(0, 0X1);
    // 0x80308000: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80308004: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    // 0x80308008: or          $a1, $t5, $zero
    ctx->r5 = ctx->r13 | 0;
    // 0x8030800C: sh          $t4, 0x82($sp)
    MEM_H(0X82, ctx->r29) = ctx->r12;
    // 0x80308010: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    // 0x80308014: sw          $t2, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->r10;
    // 0x80308018: sw          $t1, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->r9;
    // 0x8030801C: jal         0x80305A70
    // 0x80308020: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    func_80305A70_717120(rdram, ctx);
        goto after_16;
    // 0x80308020: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    after_16:
    // 0x80308024: lw          $t1, 0xB0($sp)
    ctx->r9 = MEM_W(ctx->r29, 0XB0);
    // 0x80308028: lw          $t2, 0xAC($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XAC);
    // 0x8030802C: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
    // 0x80308030: beq         $v0, $zero, L_80308058
    if (ctx->r2 == 0) {
        // 0x80308034: lh          $t4, 0x82($sp)
        ctx->r12 = MEM_H(ctx->r29, 0X82);
            goto L_80308058;
    }
    // 0x80308034: lh          $t4, 0x82($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X82);
L_80308038:
    // 0x80308038: slti        $at, $t3, 0x60
    ctx->r1 = SIGNED(ctx->r11) < 0X60 ? 1 : 0;
    // 0x8030803C: beq         $at, $zero, L_80308048
    if (ctx->r1 == 0) {
        // 0x80308040: slti        $at, $t3, 0x21
        ctx->r1 = SIGNED(ctx->r11) < 0X21 ? 1 : 0;
            goto L_80308048;
    }
    // 0x80308040: slti        $at, $t3, 0x21
    ctx->r1 = SIGNED(ctx->r11) < 0X21 ? 1 : 0;
    // 0x80308044: beq         $at, $zero, L_80309168
    if (ctx->r1 == 0) {
        // 0x80308048: lui         $t0, 0x803D
        ctx->r8 = S32(0X803D << 16);
            goto L_80309168;
    }
L_80308048:
    // 0x80308048: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030804C: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x80308050: b           L_8030820C
    // 0x80308054: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
        goto L_8030820C;
    // 0x80308054: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_80308058:
    // 0x80308058: slt         $at, $s1, $s4
    ctx->r1 = SIGNED(ctx->r17) < SIGNED(ctx->r20) ? 1 : 0;
    // 0x8030805C: bne         $at, $zero, L_80308068
    if (ctx->r1 != 0) {
        // 0x80308060: slti        $at, $t3, 0x80
        ctx->r1 = SIGNED(ctx->r11) < 0X80 ? 1 : 0;
            goto L_80308068;
    }
    // 0x80308060: slti        $at, $t3, 0x80
    ctx->r1 = SIGNED(ctx->r11) < 0X80 ? 1 : 0;
    // 0x80308064: beq         $at, $zero, L_803080B0
    if (ctx->r1 == 0) {
        // 0x80308068: addiu       $t2, $t2, 0x280
        ctx->r10 = ADD32(ctx->r10, 0X280);
            goto L_803080B0;
    }
L_80308068:
    // 0x80308068: addiu       $t2, $t2, 0x280
    ctx->r10 = ADD32(ctx->r10, 0X280);
    // 0x8030806C: sll         $a0, $t2, 16
    ctx->r4 = S32(ctx->r10 << 16);
    // 0x80308070: sll         $a1, $t1, 16
    ctx->r5 = S32(ctx->r9 << 16);
    // 0x80308074: sra         $t8, $a1, 16
    ctx->r24 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80308078: sra         $t9, $a0, 16
    ctx->r25 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8030807C: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    // 0x80308080: jal         0x801284B8
    // 0x80308084: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    func_801284B8(rdram, ctx);
        goto after_17;
    // 0x80308084: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    after_17:
    // 0x80308088: sll         $t3, $v0, 8
    ctx->r11 = S32(ctx->r2 << 8);
    // 0x8030808C: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80308090: div         $zero, $t3, $at
    lo = S32(S64(S32(ctx->r11)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r11)) % S64(S32(ctx->r1)));
    // 0x80308094: mflo        $t5
    ctx->r13 = lo;
    // 0x80308098: sll         $t7, $t5, 16
    ctx->r15 = S32(ctx->r13 << 16);
    // 0x8030809C: slti        $at, $s5, 0xA
    ctx->r1 = SIGNED(ctx->r21) < 0XA ? 1 : 0;
    // 0x803080A0: beq         $at, $zero, L_803080B4
    if (ctx->r1 == 0) {
        // 0x803080A4: sra         $t3, $t7, 16
        ctx->r11 = S32(SIGNED(ctx->r15) >> 16);
            goto L_803080B4;
    }
    // 0x803080A4: sra         $t3, $t7, 16
    ctx->r11 = S32(SIGNED(ctx->r15) >> 16);
    // 0x803080A8: b           L_803080B4
    // 0x803080AC: addiu       $s5, $zero, 0xA
    ctx->r21 = ADD32(0, 0XA);
        goto L_803080B4;
    // 0x803080AC: addiu       $s5, $zero, 0xA
    ctx->r21 = ADD32(0, 0XA);
L_803080B0:
    // 0x803080B0: addiu       $s2, $zero, 0x428
    ctx->r18 = ADD32(0, 0X428);
L_803080B4:
    // 0x803080B4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803080B8: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x803080BC: b           L_80309428
    // 0x803080C0: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
        goto L_80309428;
    // 0x803080C0: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_803080C4:
    // 0x803080C4: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x803080C8: lw          $t5, 0x5530($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5530);
    // 0x803080CC: sll         $a0, $s1, 16
    ctx->r4 = S32(ctx->r17 << 16);
    // 0x803080D0: sll         $a1, $s0, 16
    ctx->r5 = S32(ctx->r16 << 16);
    // 0x803080D4: lw          $a2, 0xC($t5)
    ctx->r6 = MEM_W(ctx->r13, 0XC);
    // 0x803080D8: sra         $t8, $a1, 16
    ctx->r24 = S32(SIGNED(ctx->r5) >> 16);
    // 0x803080DC: sra         $t9, $a0, 16
    ctx->r25 = S32(SIGNED(ctx->r4) >> 16);
    // 0x803080E0: addiu       $t7, $zero, 0x3
    ctx->r15 = ADD32(0, 0X3);
    // 0x803080E4: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x803080E8: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    // 0x803080EC: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    // 0x803080F0: sh          $t4, 0x82($sp)
    MEM_H(0X82, ctx->r29) = ctx->r12;
    // 0x803080F4: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    // 0x803080F8: sw          $t2, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->r10;
    // 0x803080FC: sw          $t1, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->r9;
    // 0x80308100: jal         0x80305A70
    // 0x80308104: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    func_80305A70_717120(rdram, ctx);
        goto after_18;
    // 0x80308104: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    after_18:
    // 0x80308108: lw          $t1, 0xB0($sp)
    ctx->r9 = MEM_W(ctx->r29, 0XB0);
    // 0x8030810C: lw          $t2, 0xAC($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XAC);
    // 0x80308110: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
    // 0x80308114: bne         $v0, $zero, L_80308174
    if (ctx->r2 != 0) {
        // 0x80308118: lh          $t4, 0x82($sp)
        ctx->r12 = MEM_H(ctx->r29, 0X82);
            goto L_80308174;
    }
    // 0x80308118: lh          $t4, 0x82($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X82);
    // 0x8030811C: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x80308120: lw          $t8, 0x5530($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5530);
    // 0x80308124: sll         $a0, $s1, 16
    ctx->r4 = S32(ctx->r17 << 16);
    // 0x80308128: sll         $a1, $s0, 16
    ctx->r5 = S32(ctx->r16 << 16);
    // 0x8030812C: lw          $a2, 0xC($t8)
    ctx->r6 = MEM_W(ctx->r24, 0XC);
    // 0x80308130: sra         $t9, $a1, 16
    ctx->r25 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80308134: sra         $t6, $a0, 16
    ctx->r14 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80308138: addiu       $t5, $zero, 0x2
    ctx->r13 = ADD32(0, 0X2);
    // 0x8030813C: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x80308140: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    // 0x80308144: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
    // 0x80308148: sh          $t4, 0x82($sp)
    MEM_H(0X82, ctx->r29) = ctx->r12;
    // 0x8030814C: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    // 0x80308150: sw          $t2, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->r10;
    // 0x80308154: sw          $t1, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->r9;
    // 0x80308158: jal         0x80305A70
    // 0x8030815C: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    func_80305A70_717120(rdram, ctx);
        goto after_19;
    // 0x8030815C: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    after_19:
    // 0x80308160: lw          $t1, 0xB0($sp)
    ctx->r9 = MEM_W(ctx->r29, 0XB0);
    // 0x80308164: lw          $t2, 0xAC($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XAC);
    // 0x80308168: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
    // 0x8030816C: beq         $v0, $zero, L_80308194
    if (ctx->r2 == 0) {
        // 0x80308170: lh          $t4, 0x82($sp)
        ctx->r12 = MEM_H(ctx->r29, 0X82);
            goto L_80308194;
    }
    // 0x80308170: lh          $t4, 0x82($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X82);
L_80308174:
    // 0x80308174: slti        $at, $t3, 0xA0
    ctx->r1 = SIGNED(ctx->r11) < 0XA0 ? 1 : 0;
    // 0x80308178: bne         $at, $zero, L_80308184
    if (ctx->r1 != 0) {
        // 0x8030817C: slti        $at, $t3, 0xE0
        ctx->r1 = SIGNED(ctx->r11) < 0XE0 ? 1 : 0;
            goto L_80308184;
    }
    // 0x8030817C: slti        $at, $t3, 0xE0
    ctx->r1 = SIGNED(ctx->r11) < 0XE0 ? 1 : 0;
    // 0x80308180: bne         $at, $zero, L_80309270
    if (ctx->r1 != 0) {
        // 0x80308184: lui         $t0, 0x803D
        ctx->r8 = S32(0X803D << 16);
            goto L_80309270;
    }
L_80308184:
    // 0x80308184: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80308188: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x8030818C: b           L_8030820C
    // 0x80308190: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
        goto L_8030820C;
    // 0x80308190: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_80308194:
    // 0x80308194: slt         $at, $s4, $s1
    ctx->r1 = SIGNED(ctx->r20) < SIGNED(ctx->r17) ? 1 : 0;
    // 0x80308198: bne         $at, $zero, L_803081A4
    if (ctx->r1 != 0) {
        // 0x8030819C: slti        $at, $t3, 0x80
        ctx->r1 = SIGNED(ctx->r11) < 0X80 ? 1 : 0;
            goto L_803081A4;
    }
    // 0x8030819C: slti        $at, $t3, 0x80
    ctx->r1 = SIGNED(ctx->r11) < 0X80 ? 1 : 0;
    // 0x803081A0: bne         $at, $zero, L_803081EC
    if (ctx->r1 != 0) {
        // 0x803081A4: addiu       $t2, $t2, -0x280
        ctx->r10 = ADD32(ctx->r10, -0X280);
            goto L_803081EC;
    }
L_803081A4:
    // 0x803081A4: addiu       $t2, $t2, -0x280
    ctx->r10 = ADD32(ctx->r10, -0X280);
    // 0x803081A8: sll         $a0, $t2, 16
    ctx->r4 = S32(ctx->r10 << 16);
    // 0x803081AC: sll         $a1, $t1, 16
    ctx->r5 = S32(ctx->r9 << 16);
    // 0x803081B0: sra         $t6, $a1, 16
    ctx->r14 = S32(SIGNED(ctx->r5) >> 16);
    // 0x803081B4: sra         $t7, $a0, 16
    ctx->r15 = S32(SIGNED(ctx->r4) >> 16);
    // 0x803081B8: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x803081BC: jal         0x801284B8
    // 0x803081C0: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    func_801284B8(rdram, ctx);
        goto after_20;
    // 0x803081C0: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    after_20:
    // 0x803081C4: sll         $t3, $v0, 8
    ctx->r11 = S32(ctx->r2 << 8);
    // 0x803081C8: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x803081CC: div         $zero, $t3, $at
    lo = S32(S64(S32(ctx->r11)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r11)) % S64(S32(ctx->r1)));
    // 0x803081D0: mflo        $t9
    ctx->r25 = lo;
    // 0x803081D4: sll         $t8, $t9, 16
    ctx->r24 = S32(ctx->r25 << 16);
    // 0x803081D8: slti        $at, $s5, 0xA
    ctx->r1 = SIGNED(ctx->r21) < 0XA ? 1 : 0;
    // 0x803081DC: beq         $at, $zero, L_803081F0
    if (ctx->r1 == 0) {
        // 0x803081E0: sra         $t3, $t8, 16
        ctx->r11 = S32(SIGNED(ctx->r24) >> 16);
            goto L_803081F0;
    }
    // 0x803081E0: sra         $t3, $t8, 16
    ctx->r11 = S32(SIGNED(ctx->r24) >> 16);
    // 0x803081E4: b           L_803081F0
    // 0x803081E8: addiu       $s5, $zero, 0xA
    ctx->r21 = ADD32(0, 0XA);
        goto L_803081F0;
    // 0x803081E8: addiu       $s5, $zero, 0xA
    ctx->r21 = ADD32(0, 0XA);
L_803081EC:
    // 0x803081EC: addiu       $s2, $zero, 0x4A8
    ctx->r18 = ADD32(0, 0X4A8);
L_803081F0:
    // 0x803081F0: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803081F4: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x803081F8: b           L_80309428
    // 0x803081FC: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
        goto L_80309428;
    // 0x803081FC: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_80308200:
    // 0x80308200: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80308204: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x80308208: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_8030820C:
    // 0x8030820C: slti        $at, $t3, 0x40
    ctx->r1 = SIGNED(ctx->r11) < 0X40 ? 1 : 0;
    // 0x80308210: bne         $at, $zero, L_8030821C
    if (ctx->r1 != 0) {
        // 0x80308214: slti        $at, $t3, 0xC0
        ctx->r1 = SIGNED(ctx->r11) < 0XC0 ? 1 : 0;
            goto L_8030821C;
    }
    // 0x80308214: slti        $at, $t3, 0xC0
    ctx->r1 = SIGNED(ctx->r11) < 0XC0 ? 1 : 0;
    // 0x80308218: bne         $at, $zero, L_80308254
    if (ctx->r1 != 0) {
        // 0x8030821C: subu        $t7, $s1, $t4
        ctx->r15 = SUB32(ctx->r17, ctx->r12);
            goto L_80308254;
    }
L_8030821C:
    // 0x8030821C: subu        $t7, $s1, $t4
    ctx->r15 = SUB32(ctx->r17, ctx->r12);
    // 0x80308220: slt         $at, $s4, $t7
    ctx->r1 = SIGNED(ctx->r20) < SIGNED(ctx->r15) ? 1 : 0;
    // 0x80308224: beql        $at, $zero, L_80308238
    if (ctx->r1 == 0) {
        // 0x80308228: addu        $t6, $s1, $t4
        ctx->r14 = ADD32(ctx->r17, ctx->r12);
            goto L_80308238;
    }
    goto skip_20;
    // 0x80308228: addu        $t6, $s1, $t4
    ctx->r14 = ADD32(ctx->r17, ctx->r12);
    skip_20:
    // 0x8030822C: b           L_80309428
    // 0x80308230: addiu       $s2, $zero, 0x408
    ctx->r18 = ADD32(0, 0X408);
        goto L_80309428;
    // 0x80308230: addiu       $s2, $zero, 0x408
    ctx->r18 = ADD32(0, 0X408);
    // 0x80308234: addu        $t6, $s1, $t4
    ctx->r14 = ADD32(ctx->r17, ctx->r12);
L_80308238:
    // 0x80308238: slt         $at, $t6, $s4
    ctx->r1 = SIGNED(ctx->r14) < SIGNED(ctx->r20) ? 1 : 0;
    // 0x8030823C: beq         $at, $zero, L_8030824C
    if (ctx->r1 == 0) {
        // 0x80308240: nop
    
            goto L_8030824C;
    }
    // 0x80308240: nop

    // 0x80308244: b           L_80309428
    // 0x80308248: addiu       $s2, $zero, 0x4C8
    ctx->r18 = ADD32(0, 0X4C8);
        goto L_80309428;
    // 0x80308248: addiu       $s2, $zero, 0x4C8
    ctx->r18 = ADD32(0, 0X4C8);
L_8030824C:
    // 0x8030824C: b           L_80309428
    // 0x80308250: or          $s2, $zero, $zero
    ctx->r18 = 0 | 0;
        goto L_80309428;
    // 0x80308250: or          $s2, $zero, $zero
    ctx->r18 = 0 | 0;
L_80308254:
    // 0x80308254: subu        $t9, $s1, $t4
    ctx->r25 = SUB32(ctx->r17, ctx->r12);
    // 0x80308258: slt         $at, $s4, $t9
    ctx->r1 = SIGNED(ctx->r20) < SIGNED(ctx->r25) ? 1 : 0;
    // 0x8030825C: beql        $at, $zero, L_80308270
    if (ctx->r1 == 0) {
        // 0x80308260: addu        $t8, $s1, $t4
        ctx->r24 = ADD32(ctx->r17, ctx->r12);
            goto L_80308270;
    }
    goto skip_21;
    // 0x80308260: addu        $t8, $s1, $t4
    ctx->r24 = ADD32(ctx->r17, ctx->r12);
    skip_21:
    // 0x80308264: b           L_80309428
    // 0x80308268: addiu       $s2, $zero, 0x448
    ctx->r18 = ADD32(0, 0X448);
        goto L_80309428;
    // 0x80308268: addiu       $s2, $zero, 0x448
    ctx->r18 = ADD32(0, 0X448);
    // 0x8030826C: addu        $t8, $s1, $t4
    ctx->r24 = ADD32(ctx->r17, ctx->r12);
L_80308270:
    // 0x80308270: slt         $at, $t8, $s4
    ctx->r1 = SIGNED(ctx->r24) < SIGNED(ctx->r20) ? 1 : 0;
    // 0x80308274: beq         $at, $zero, L_80308284
    if (ctx->r1 == 0) {
        // 0x80308278: nop
    
            goto L_80308284;
    }
    // 0x80308278: nop

    // 0x8030827C: b           L_80309428
    // 0x80308280: addiu       $s2, $zero, 0x488
    ctx->r18 = ADD32(0, 0X488);
        goto L_80309428;
    // 0x80308280: addiu       $s2, $zero, 0x488
    ctx->r18 = ADD32(0, 0X488);
L_80308284:
    // 0x80308284: b           L_80309428
    // 0x80308288: addiu       $s2, $zero, 0x80
    ctx->r18 = ADD32(0, 0X80);
        goto L_80309428;
    // 0x80308288: addiu       $s2, $zero, 0x80
    ctx->r18 = ADD32(0, 0X80);
L_8030828C:
    // 0x8030828C: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80308290: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x80308294: sll         $a0, $s1, 16
    ctx->r4 = S32(ctx->r17 << 16);
    // 0x80308298: sll         $a1, $s0, 16
    ctx->r5 = S32(ctx->r16 << 16);
    // 0x8030829C: lw          $a2, 0xC($t6)
    ctx->r6 = MEM_W(ctx->r14, 0XC);
    // 0x803082A0: sra         $t7, $a1, 16
    ctx->r15 = S32(SIGNED(ctx->r5) >> 16);
    // 0x803082A4: sra         $t5, $a0, 16
    ctx->r13 = S32(SIGNED(ctx->r4) >> 16);
    // 0x803082A8: addiu       $t9, $zero, 0x3
    ctx->r25 = ADD32(0, 0X3);
    // 0x803082AC: sw          $t9, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r25;
    // 0x803082B0: or          $a0, $t5, $zero
    ctx->r4 = ctx->r13 | 0;
    // 0x803082B4: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    // 0x803082B8: sh          $t4, 0x82($sp)
    MEM_H(0X82, ctx->r29) = ctx->r12;
    // 0x803082BC: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    // 0x803082C0: sw          $t2, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->r10;
    // 0x803082C4: sw          $t1, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->r9;
    // 0x803082C8: jal         0x80305A70
    // 0x803082CC: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    func_80305A70_717120(rdram, ctx);
        goto after_21;
    // 0x803082CC: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    after_21:
    // 0x803082D0: lw          $t1, 0xB0($sp)
    ctx->r9 = MEM_W(ctx->r29, 0XB0);
    // 0x803082D4: lw          $t2, 0xAC($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XAC);
    // 0x803082D8: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
    // 0x803082DC: bne         $v0, $zero, L_80308338
    if (ctx->r2 != 0) {
        // 0x803082E0: lh          $t4, 0x82($sp)
        ctx->r12 = MEM_H(ctx->r29, 0X82);
            goto L_80308338;
    }
    // 0x803082E0: lh          $t4, 0x82($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X82);
    // 0x803082E4: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x803082E8: lw          $t7, 0x5530($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5530);
    // 0x803082EC: sll         $a0, $s1, 16
    ctx->r4 = S32(ctx->r17 << 16);
    // 0x803082F0: sll         $a1, $s0, 16
    ctx->r5 = S32(ctx->r16 << 16);
    // 0x803082F4: lw          $a2, 0xC($t7)
    ctx->r6 = MEM_W(ctx->r15, 0XC);
    // 0x803082F8: sra         $t5, $a1, 16
    ctx->r13 = S32(SIGNED(ctx->r5) >> 16);
    // 0x803082FC: sra         $t8, $a0, 16
    ctx->r24 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80308300: or          $a0, $t8, $zero
    ctx->r4 = ctx->r24 | 0;
    // 0x80308304: or          $a1, $t5, $zero
    ctx->r5 = ctx->r13 | 0;
    // 0x80308308: sh          $t4, 0x82($sp)
    MEM_H(0X82, ctx->r29) = ctx->r12;
    // 0x8030830C: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    // 0x80308310: sw          $t2, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->r10;
    // 0x80308314: sw          $t1, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->r9;
    // 0x80308318: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x8030831C: jal         0x80305A70
    // 0x80308320: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    func_80305A70_717120(rdram, ctx);
        goto after_22;
    // 0x80308320: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    after_22:
    // 0x80308324: lw          $t1, 0xB0($sp)
    ctx->r9 = MEM_W(ctx->r29, 0XB0);
    // 0x80308328: lw          $t2, 0xAC($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XAC);
    // 0x8030832C: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
    // 0x80308330: beq         $v0, $zero, L_80308358
    if (ctx->r2 == 0) {
        // 0x80308334: lh          $t4, 0x82($sp)
        ctx->r12 = MEM_H(ctx->r29, 0X82);
            goto L_80308358;
    }
    // 0x80308334: lh          $t4, 0x82($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X82);
L_80308338:
    // 0x80308338: slti        $at, $t3, 0x20
    ctx->r1 = SIGNED(ctx->r11) < 0X20 ? 1 : 0;
    // 0x8030833C: bne         $at, $zero, L_803088A4
    if (ctx->r1 != 0) {
        // 0x80308340: slti        $at, $t3, 0xE0
        ctx->r1 = SIGNED(ctx->r11) < 0XE0 ? 1 : 0;
            goto L_803088A4;
    }
    // 0x80308340: slti        $at, $t3, 0xE0
    ctx->r1 = SIGNED(ctx->r11) < 0XE0 ? 1 : 0;
    // 0x80308344: beq         $at, $zero, L_803088A4
    if (ctx->r1 == 0) {
        // 0x80308348: lui         $t0, 0x803D
        ctx->r8 = S32(0X803D << 16);
            goto L_803088A4;
    }
    // 0x80308348: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030834C: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x80308350: b           L_803090F0
    // 0x80308354: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
        goto L_803090F0;
    // 0x80308354: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_80308358:
    // 0x80308358: slt         $at, $s0, $s3
    ctx->r1 = SIGNED(ctx->r16) < SIGNED(ctx->r19) ? 1 : 0;
    // 0x8030835C: bne         $at, $zero, L_80308370
    if (ctx->r1 != 0) {
        // 0x80308360: slti        $at, $t3, 0x40
        ctx->r1 = SIGNED(ctx->r11) < 0X40 ? 1 : 0;
            goto L_80308370;
    }
    // 0x80308360: slti        $at, $t3, 0x40
    ctx->r1 = SIGNED(ctx->r11) < 0X40 ? 1 : 0;
    // 0x80308364: bne         $at, $zero, L_80308370
    if (ctx->r1 != 0) {
        // 0x80308368: slti        $at, $t3, 0xC0
        ctx->r1 = SIGNED(ctx->r11) < 0XC0 ? 1 : 0;
            goto L_80308370;
    }
    // 0x80308368: slti        $at, $t3, 0xC0
    ctx->r1 = SIGNED(ctx->r11) < 0XC0 ? 1 : 0;
    // 0x8030836C: bne         $at, $zero, L_803083B8
    if (ctx->r1 != 0) {
        // 0x80308370: addiu       $t1, $t1, 0x280
        ctx->r9 = ADD32(ctx->r9, 0X280);
            goto L_803083B8;
    }
L_80308370:
    // 0x80308370: addiu       $t1, $t1, 0x280
    ctx->r9 = ADD32(ctx->r9, 0X280);
    // 0x80308374: sll         $a1, $t1, 16
    ctx->r5 = S32(ctx->r9 << 16);
    // 0x80308378: sll         $a0, $t2, 16
    ctx->r4 = S32(ctx->r10 << 16);
    // 0x8030837C: sra         $t6, $a0, 16
    ctx->r14 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80308380: sra         $t9, $a1, 16
    ctx->r25 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80308384: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
    // 0x80308388: jal         0x801284B8
    // 0x8030838C: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    func_801284B8(rdram, ctx);
        goto after_23;
    // 0x8030838C: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    after_23:
    // 0x80308390: sll         $t3, $v0, 8
    ctx->r11 = S32(ctx->r2 << 8);
    // 0x80308394: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80308398: div         $zero, $t3, $at
    lo = S32(S64(S32(ctx->r11)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r11)) % S64(S32(ctx->r1)));
    // 0x8030839C: mflo        $t8
    ctx->r24 = lo;
    // 0x803083A0: sll         $t5, $t8, 16
    ctx->r13 = S32(ctx->r24 << 16);
    // 0x803083A4: slti        $at, $s5, 0xA
    ctx->r1 = SIGNED(ctx->r21) < 0XA ? 1 : 0;
    // 0x803083A8: beq         $at, $zero, L_803083BC
    if (ctx->r1 == 0) {
        // 0x803083AC: sra         $t3, $t5, 16
        ctx->r11 = S32(SIGNED(ctx->r13) >> 16);
            goto L_803083BC;
    }
    // 0x803083AC: sra         $t3, $t5, 16
    ctx->r11 = S32(SIGNED(ctx->r13) >> 16);
    // 0x803083B0: b           L_803083BC
    // 0x803083B4: addiu       $s5, $zero, 0xA
    ctx->r21 = ADD32(0, 0XA);
        goto L_803083BC;
    // 0x803083B4: addiu       $s5, $zero, 0xA
    ctx->r21 = ADD32(0, 0XA);
L_803083B8:
    // 0x803083B8: addiu       $s2, $zero, 0x3E8
    ctx->r18 = ADD32(0, 0X3E8);
L_803083BC:
    // 0x803083BC: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803083C0: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x803083C4: b           L_80309428
    // 0x803083C8: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
        goto L_80309428;
    // 0x803083C8: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_803083CC:
    // 0x803083CC: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x803083D0: lw          $t8, 0x5530($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5530);
    // 0x803083D4: sll         $a0, $s1, 16
    ctx->r4 = S32(ctx->r17 << 16);
    // 0x803083D8: sll         $a1, $s0, 16
    ctx->r5 = S32(ctx->r16 << 16);
    // 0x803083DC: lw          $a2, 0xC($t8)
    ctx->r6 = MEM_W(ctx->r24, 0XC);
    // 0x803083E0: sra         $t9, $a1, 16
    ctx->r25 = S32(SIGNED(ctx->r5) >> 16);
    // 0x803083E4: sra         $t6, $a0, 16
    ctx->r14 = S32(SIGNED(ctx->r4) >> 16);
    // 0x803083E8: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    // 0x803083EC: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
    // 0x803083F0: sh          $t4, 0x82($sp)
    MEM_H(0X82, ctx->r29) = ctx->r12;
    // 0x803083F4: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    // 0x803083F8: sw          $t2, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->r10;
    // 0x803083FC: sw          $t1, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->r9;
    // 0x80308400: sw          $zero, 0x10($sp)
    MEM_W(0X10, ctx->r29) = 0;
    // 0x80308404: jal         0x80305A70
    // 0x80308408: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    func_80305A70_717120(rdram, ctx);
        goto after_24;
    // 0x80308408: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    after_24:
    // 0x8030840C: lw          $t1, 0xB0($sp)
    ctx->r9 = MEM_W(ctx->r29, 0XB0);
    // 0x80308410: lw          $t2, 0xAC($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XAC);
    // 0x80308414: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
    // 0x80308418: beq         $v0, $zero, L_803085CC
    if (ctx->r2 == 0) {
        // 0x8030841C: lh          $t4, 0x82($sp)
        ctx->r12 = MEM_H(ctx->r29, 0X82);
            goto L_803085CC;
    }
    // 0x8030841C: lh          $t4, 0x82($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X82);
    // 0x80308420: subu        $a0, $s4, $s1
    ctx->r4 = SUB32(ctx->r20, ctx->r17);
    // 0x80308424: bgezl       $a0, L_80308438
    if (SIGNED(ctx->r4) >= 0) {
        // 0x80308428: or          $v1, $a0, $zero
        ctx->r3 = ctx->r4 | 0;
            goto L_80308438;
    }
    goto skip_22;
    // 0x80308428: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
    skip_22:
    // 0x8030842C: b           L_80308438
    // 0x80308430: negu        $v1, $a0
    ctx->r3 = SUB32(0, ctx->r4);
        goto L_80308438;
    // 0x80308430: negu        $v1, $a0
    ctx->r3 = SUB32(0, ctx->r4);
    // 0x80308434: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
L_80308438:
    // 0x80308438: slt         $at, $v1, $t4
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x8030843C: beq         $at, $zero, L_80308484
    if (ctx->r1 == 0) {
        // 0x80308440: subu        $v0, $s3, $s0
        ctx->r2 = SUB32(ctx->r19, ctx->r16);
            goto L_80308484;
    }
    // 0x80308440: subu        $v0, $s3, $s0
    ctx->r2 = SUB32(ctx->r19, ctx->r16);
    // 0x80308444: bgezl       $v0, L_80308458
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80308448: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_80308458;
    }
    goto skip_23;
    // 0x80308448: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    skip_23:
    // 0x8030844C: b           L_80308458
    // 0x80308450: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_80308458;
    // 0x80308450: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
    // 0x80308454: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_80308458:
    // 0x80308458: slt         $at, $v1, $t4
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x8030845C: beq         $at, $zero, L_80308484
    if (ctx->r1 == 0) {
        // 0x80308460: slti        $at, $t3, 0x20
        ctx->r1 = SIGNED(ctx->r11) < 0X20 ? 1 : 0;
            goto L_80308484;
    }
    // 0x80308460: slti        $at, $t3, 0x20
    ctx->r1 = SIGNED(ctx->r11) < 0X20 ? 1 : 0;
    // 0x80308464: bne         $at, $zero, L_80308474
    if (ctx->r1 != 0) {
        // 0x80308468: slti        $at, $t3, 0xA0
        ctx->r1 = SIGNED(ctx->r11) < 0XA0 ? 1 : 0;
            goto L_80308474;
    }
    // 0x80308468: slti        $at, $t3, 0xA0
    ctx->r1 = SIGNED(ctx->r11) < 0XA0 ? 1 : 0;
    // 0x8030846C: bne         $at, $zero, L_8030847C
    if (ctx->r1 != 0) {
        // 0x80308470: nop
    
            goto L_8030847C;
    }
    // 0x80308470: nop

L_80308474:
    // 0x80308474: b           L_8030862C
    // 0x80308478: or          $s2, $zero, $zero
    ctx->r18 = 0 | 0;
        goto L_8030862C;
    // 0x80308478: or          $s2, $zero, $zero
    ctx->r18 = 0 | 0;
L_8030847C:
    // 0x8030847C: b           L_8030862C
    // 0x80308480: addiu       $s2, $zero, 0x40
    ctx->r18 = ADD32(0, 0X40);
        goto L_8030862C;
    // 0x80308480: addiu       $s2, $zero, 0x40
    ctx->r18 = ADD32(0, 0X40);
L_80308484:
    // 0x80308484: lh          $v0, 0x86($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X86);
    // 0x80308488: lh          $t7, 0x84($sp)
    ctx->r15 = MEM_H(ctx->r29, 0X84);
    // 0x8030848C: sra         $t5, $v0, 1
    ctx->r13 = S32(SIGNED(ctx->r2) >> 1);
    // 0x80308490: subu        $t6, $t7, $s4
    ctx->r14 = SUB32(ctx->r15, ctx->r20);
    // 0x80308494: addu        $t9, $t6, $s1
    ctx->r25 = ADD32(ctx->r14, ctx->r17);
    // 0x80308498: subu        $t8, $t9, $t5
    ctx->r24 = SUB32(ctx->r25, ctx->r13);
    // 0x8030849C: or          $v0, $t5, $zero
    ctx->r2 = ctx->r13 | 0;
    // 0x803084A0: addu        $t5, $t8, $s3
    ctx->r13 = ADD32(ctx->r24, ctx->r19);
    // 0x803084A4: subu        $t6, $t5, $s0
    ctx->r14 = SUB32(ctx->r13, ctx->r16);
    // 0x803084A8: addu        $t9, $t6, $v0
    ctx->r25 = ADD32(ctx->r14, ctx->r2);
    // 0x803084AC: slt         $at, $t9, $t7
    ctx->r1 = SIGNED(ctx->r25) < SIGNED(ctx->r15) ? 1 : 0;
    // 0x803084B0: bne         $at, $zero, L_80308540
    if (ctx->r1 != 0) {
        // 0x803084B4: slti        $at, $t3, 0x20
        ctx->r1 = SIGNED(ctx->r11) < 0X20 ? 1 : 0;
            goto L_80308540;
    }
    // 0x803084B4: slti        $at, $t3, 0x20
    ctx->r1 = SIGNED(ctx->r11) < 0X20 ? 1 : 0;
    // 0x803084B8: bne         $at, $zero, L_803084C4
    if (ctx->r1 != 0) {
        // 0x803084BC: slti        $at, $t3, 0xA0
        ctx->r1 = SIGNED(ctx->r11) < 0XA0 ? 1 : 0;
            goto L_803084C4;
    }
    // 0x803084BC: slti        $at, $t3, 0xA0
    ctx->r1 = SIGNED(ctx->r11) < 0XA0 ? 1 : 0;
    // 0x803084C0: bne         $at, $zero, L_803084FC
    if (ctx->r1 != 0) {
        // 0x803084C4: subu        $t8, $s1, $t4
        ctx->r24 = SUB32(ctx->r17, ctx->r12);
            goto L_803084FC;
    }
L_803084C4:
    // 0x803084C4: subu        $t8, $s1, $t4
    ctx->r24 = SUB32(ctx->r17, ctx->r12);
    // 0x803084C8: slt         $at, $s4, $t8
    ctx->r1 = SIGNED(ctx->r20) < SIGNED(ctx->r24) ? 1 : 0;
    // 0x803084CC: beql        $at, $zero, L_803084E0
    if (ctx->r1 == 0) {
        // 0x803084D0: addu        $t5, $s1, $t4
        ctx->r13 = ADD32(ctx->r17, ctx->r12);
            goto L_803084E0;
    }
    goto skip_24;
    // 0x803084D0: addu        $t5, $s1, $t4
    ctx->r13 = ADD32(ctx->r17, ctx->r12);
    skip_24:
    // 0x803084D4: b           L_8030862C
    // 0x803084D8: addiu       $s2, $zero, 0x408
    ctx->r18 = ADD32(0, 0X408);
        goto L_8030862C;
    // 0x803084D8: addiu       $s2, $zero, 0x408
    ctx->r18 = ADD32(0, 0X408);
    // 0x803084DC: addu        $t5, $s1, $t4
    ctx->r13 = ADD32(ctx->r17, ctx->r12);
L_803084E0:
    // 0x803084E0: slt         $at, $t5, $s4
    ctx->r1 = SIGNED(ctx->r13) < SIGNED(ctx->r20) ? 1 : 0;
    // 0x803084E4: beq         $at, $zero, L_803084F4
    if (ctx->r1 == 0) {
        // 0x803084E8: nop
    
            goto L_803084F4;
    }
    // 0x803084E8: nop

    // 0x803084EC: b           L_8030862C
    // 0x803084F0: addiu       $s2, $zero, 0x4C8
    ctx->r18 = ADD32(0, 0X4C8);
        goto L_8030862C;
    // 0x803084F0: addiu       $s2, $zero, 0x4C8
    ctx->r18 = ADD32(0, 0X4C8);
L_803084F4:
    // 0x803084F4: b           L_8030862C
    // 0x803084F8: or          $s2, $zero, $zero
    ctx->r18 = 0 | 0;
        goto L_8030862C;
    // 0x803084F8: or          $s2, $zero, $zero
    ctx->r18 = 0 | 0;
L_803084FC:
    // 0x803084FC: subu        $a0, $s1, $s4
    ctx->r4 = SUB32(ctx->r17, ctx->r20);
    // 0x80308500: subu        $a1, $s0, $s3
    ctx->r5 = SUB32(ctx->r16, ctx->r19);
    // 0x80308504: sll         $t7, $a1, 16
    ctx->r15 = S32(ctx->r5 << 16);
    // 0x80308508: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x8030850C: sra         $a0, $t6, 16
    ctx->r4 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80308510: sra         $a1, $t7, 16
    ctx->r5 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80308514: jal         0x801284B8
    // 0x80308518: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    func_801284B8(rdram, ctx);
        goto after_25;
    // 0x80308518: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    after_25:
    // 0x8030851C: sll         $s2, $v0, 8
    ctx->r18 = S32(ctx->r2 << 8);
    // 0x80308520: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80308524: div         $zero, $s2, $at
    lo = S32(S64(S32(ctx->r18)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r18)) % S64(S32(ctx->r1)));
    // 0x80308528: mflo        $t5
    ctx->r13 = lo;
    // 0x8030852C: addiu       $s2, $t5, 0x3E8
    ctx->r18 = ADD32(ctx->r13, 0X3E8);
    // 0x80308530: sll         $t6, $s2, 16
    ctx->r14 = S32(ctx->r18 << 16);
    // 0x80308534: sra         $s2, $t6, 16
    ctx->r18 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80308538: b           L_8030862C
    // 0x8030853C: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
        goto L_8030862C;
    // 0x8030853C: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
L_80308540:
    // 0x80308540: slti        $at, $t3, 0x20
    ctx->r1 = SIGNED(ctx->r11) < 0X20 ? 1 : 0;
    // 0x80308544: bne         $at, $zero, L_80308588
    if (ctx->r1 != 0) {
        // 0x80308548: slti        $at, $t3, 0xA0
        ctx->r1 = SIGNED(ctx->r11) < 0XA0 ? 1 : 0;
            goto L_80308588;
    }
    // 0x80308548: slti        $at, $t3, 0xA0
    ctx->r1 = SIGNED(ctx->r11) < 0XA0 ? 1 : 0;
    // 0x8030854C: beq         $at, $zero, L_80308588
    if (ctx->r1 == 0) {
        // 0x80308550: subu        $t7, $s0, $t4
        ctx->r15 = SUB32(ctx->r16, ctx->r12);
            goto L_80308588;
    }
    // 0x80308550: subu        $t7, $s0, $t4
    ctx->r15 = SUB32(ctx->r16, ctx->r12);
    // 0x80308554: slt         $at, $s3, $t7
    ctx->r1 = SIGNED(ctx->r19) < SIGNED(ctx->r15) ? 1 : 0;
    // 0x80308558: beql        $at, $zero, L_8030856C
    if (ctx->r1 == 0) {
        // 0x8030855C: addu        $t8, $s0, $t4
        ctx->r24 = ADD32(ctx->r16, ctx->r12);
            goto L_8030856C;
    }
    goto skip_25;
    // 0x8030855C: addu        $t8, $s0, $t4
    ctx->r24 = ADD32(ctx->r16, ctx->r12);
    skip_25:
    // 0x80308560: b           L_8030862C
    // 0x80308564: addiu       $s2, $zero, 0x408
    ctx->r18 = ADD32(0, 0X408);
        goto L_8030862C;
    // 0x80308564: addiu       $s2, $zero, 0x408
    ctx->r18 = ADD32(0, 0X408);
    // 0x80308568: addu        $t8, $s0, $t4
    ctx->r24 = ADD32(ctx->r16, ctx->r12);
L_8030856C:
    // 0x8030856C: slt         $at, $t8, $s3
    ctx->r1 = SIGNED(ctx->r24) < SIGNED(ctx->r19) ? 1 : 0;
    // 0x80308570: beq         $at, $zero, L_80308580
    if (ctx->r1 == 0) {
        // 0x80308574: nop
    
            goto L_80308580;
    }
    // 0x80308574: nop

    // 0x80308578: b           L_8030862C
    // 0x8030857C: addiu       $s2, $zero, 0x448
    ctx->r18 = ADD32(0, 0X448);
        goto L_8030862C;
    // 0x8030857C: addiu       $s2, $zero, 0x448
    ctx->r18 = ADD32(0, 0X448);
L_80308580:
    // 0x80308580: b           L_8030862C
    // 0x80308584: addiu       $s2, $zero, 0x40
    ctx->r18 = ADD32(0, 0X40);
        goto L_8030862C;
    // 0x80308584: addiu       $s2, $zero, 0x40
    ctx->r18 = ADD32(0, 0X40);
L_80308588:
    // 0x80308588: subu        $a0, $s1, $s4
    ctx->r4 = SUB32(ctx->r17, ctx->r20);
    // 0x8030858C: subu        $a1, $s0, $s3
    ctx->r5 = SUB32(ctx->r16, ctx->r19);
    // 0x80308590: sll         $t9, $a1, 16
    ctx->r25 = S32(ctx->r5 << 16);
    // 0x80308594: sll         $t5, $a0, 16
    ctx->r13 = S32(ctx->r4 << 16);
    // 0x80308598: sra         $a0, $t5, 16
    ctx->r4 = S32(SIGNED(ctx->r13) >> 16);
    // 0x8030859C: sra         $a1, $t9, 16
    ctx->r5 = S32(SIGNED(ctx->r25) >> 16);
    // 0x803085A0: jal         0x801284B8
    // 0x803085A4: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    func_801284B8(rdram, ctx);
        goto after_26;
    // 0x803085A4: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    after_26:
    // 0x803085A8: sll         $s2, $v0, 8
    ctx->r18 = S32(ctx->r2 << 8);
    // 0x803085AC: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x803085B0: div         $zero, $s2, $at
    lo = S32(S64(S32(ctx->r18)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r18)) % S64(S32(ctx->r1)));
    // 0x803085B4: mflo        $t8
    ctx->r24 = lo;
    // 0x803085B8: addiu       $s2, $t8, 0x3E8
    ctx->r18 = ADD32(ctx->r24, 0X3E8);
    // 0x803085BC: sll         $t5, $s2, 16
    ctx->r13 = S32(ctx->r18 << 16);
    // 0x803085C0: sra         $s2, $t5, 16
    ctx->r18 = S32(SIGNED(ctx->r13) >> 16);
    // 0x803085C4: b           L_8030862C
    // 0x803085C8: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
        goto L_8030862C;
    // 0x803085C8: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
L_803085CC:
    // 0x803085CC: slt         $at, $s1, $s4
    ctx->r1 = SIGNED(ctx->r17) < SIGNED(ctx->r20) ? 1 : 0;
    // 0x803085D0: beq         $at, $zero, L_80308628
    if (ctx->r1 == 0) {
        // 0x803085D4: slt         $at, $s0, $s3
        ctx->r1 = SIGNED(ctx->r16) < SIGNED(ctx->r19) ? 1 : 0;
            goto L_80308628;
    }
    // 0x803085D4: slt         $at, $s0, $s3
    ctx->r1 = SIGNED(ctx->r16) < SIGNED(ctx->r19) ? 1 : 0;
    // 0x803085D8: beq         $at, $zero, L_80308628
    if (ctx->r1 == 0) {
        // 0x803085DC: addiu       $t1, $t1, 0x280
        ctx->r9 = ADD32(ctx->r9, 0X280);
            goto L_80308628;
    }
    // 0x803085DC: addiu       $t1, $t1, 0x280
    ctx->r9 = ADD32(ctx->r9, 0X280);
    // 0x803085E0: addiu       $t2, $t2, 0x280
    ctx->r10 = ADD32(ctx->r10, 0X280);
    // 0x803085E4: sll         $a0, $t2, 16
    ctx->r4 = S32(ctx->r10 << 16);
    // 0x803085E8: sll         $a1, $t1, 16
    ctx->r5 = S32(ctx->r9 << 16);
    // 0x803085EC: sra         $t7, $a1, 16
    ctx->r15 = S32(SIGNED(ctx->r5) >> 16);
    // 0x803085F0: sra         $t9, $a0, 16
    ctx->r25 = S32(SIGNED(ctx->r4) >> 16);
    // 0x803085F4: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    // 0x803085F8: jal         0x801284B8
    // 0x803085FC: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    func_801284B8(rdram, ctx);
        goto after_27;
    // 0x803085FC: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    after_27:
    // 0x80308600: sll         $t3, $v0, 8
    ctx->r11 = S32(ctx->r2 << 8);
    // 0x80308604: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80308608: div         $zero, $t3, $at
    lo = S32(S64(S32(ctx->r11)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r11)) % S64(S32(ctx->r1)));
    // 0x8030860C: mflo        $t8
    ctx->r24 = lo;
    // 0x80308610: sll         $t5, $t8, 16
    ctx->r13 = S32(ctx->r24 << 16);
    // 0x80308614: slti        $at, $s5, 0xB
    ctx->r1 = SIGNED(ctx->r21) < 0XB ? 1 : 0;
    // 0x80308618: beq         $at, $zero, L_8030862C
    if (ctx->r1 == 0) {
        // 0x8030861C: sra         $t3, $t5, 16
        ctx->r11 = S32(SIGNED(ctx->r13) >> 16);
            goto L_8030862C;
    }
    // 0x8030861C: sra         $t3, $t5, 16
    ctx->r11 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80308620: b           L_8030862C
    // 0x80308624: addiu       $s5, $zero, 0xA
    ctx->r21 = ADD32(0, 0XA);
        goto L_8030862C;
    // 0x80308624: addiu       $s5, $zero, 0xA
    ctx->r21 = ADD32(0, 0XA);
L_80308628:
    // 0x80308628: addiu       $s2, $zero, 0x408
    ctx->r18 = ADD32(0, 0X408);
L_8030862C:
    // 0x8030862C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80308630: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x80308634: b           L_80309428
    // 0x80308638: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
        goto L_80309428;
    // 0x80308638: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_8030863C:
    // 0x8030863C: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x80308640: lw          $t8, 0x5530($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5530);
    // 0x80308644: sll         $a0, $s1, 16
    ctx->r4 = S32(ctx->r17 << 16);
    // 0x80308648: sll         $a1, $s0, 16
    ctx->r5 = S32(ctx->r16 << 16);
    // 0x8030864C: lw          $a2, 0xC($t8)
    ctx->r6 = MEM_W(ctx->r24, 0XC);
    // 0x80308650: sra         $t7, $a1, 16
    ctx->r15 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80308654: sra         $t9, $a0, 16
    ctx->r25 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80308658: addiu       $t5, $zero, 0x3
    ctx->r13 = ADD32(0, 0X3);
    // 0x8030865C: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x80308660: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    // 0x80308664: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    // 0x80308668: sh          $t4, 0x82($sp)
    MEM_H(0X82, ctx->r29) = ctx->r12;
    // 0x8030866C: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    // 0x80308670: sw          $t2, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->r10;
    // 0x80308674: sw          $t1, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->r9;
    // 0x80308678: jal         0x80305A70
    // 0x8030867C: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    func_80305A70_717120(rdram, ctx);
        goto after_28;
    // 0x8030867C: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    after_28:
    // 0x80308680: lw          $t1, 0xB0($sp)
    ctx->r9 = MEM_W(ctx->r29, 0XB0);
    // 0x80308684: lw          $t2, 0xAC($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XAC);
    // 0x80308688: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
    // 0x8030868C: beq         $v0, $zero, L_80308834
    if (ctx->r2 == 0) {
        // 0x80308690: lh          $t4, 0x82($sp)
        ctx->r12 = MEM_H(ctx->r29, 0X82);
            goto L_80308834;
    }
    // 0x80308690: lh          $t4, 0x82($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X82);
    // 0x80308694: subu        $a0, $s4, $s1
    ctx->r4 = SUB32(ctx->r20, ctx->r17);
    // 0x80308698: bgezl       $a0, L_803086AC
    if (SIGNED(ctx->r4) >= 0) {
        // 0x8030869C: or          $v1, $a0, $zero
        ctx->r3 = ctx->r4 | 0;
            goto L_803086AC;
    }
    goto skip_26;
    // 0x8030869C: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
    skip_26:
    // 0x803086A0: b           L_803086AC
    // 0x803086A4: negu        $v1, $a0
    ctx->r3 = SUB32(0, ctx->r4);
        goto L_803086AC;
    // 0x803086A4: negu        $v1, $a0
    ctx->r3 = SUB32(0, ctx->r4);
    // 0x803086A8: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
L_803086AC:
    // 0x803086AC: slt         $at, $v1, $t4
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x803086B0: beq         $at, $zero, L_803086F8
    if (ctx->r1 == 0) {
        // 0x803086B4: subu        $v0, $s3, $s0
        ctx->r2 = SUB32(ctx->r19, ctx->r16);
            goto L_803086F8;
    }
    // 0x803086B4: subu        $v0, $s3, $s0
    ctx->r2 = SUB32(ctx->r19, ctx->r16);
    // 0x803086B8: bgezl       $v0, L_803086CC
    if (SIGNED(ctx->r2) >= 0) {
        // 0x803086BC: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_803086CC;
    }
    goto skip_27;
    // 0x803086BC: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    skip_27:
    // 0x803086C0: b           L_803086CC
    // 0x803086C4: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_803086CC;
    // 0x803086C4: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
    // 0x803086C8: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_803086CC:
    // 0x803086CC: slt         $at, $v1, $t4
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x803086D0: beq         $at, $zero, L_803086F8
    if (ctx->r1 == 0) {
        // 0x803086D4: slti        $at, $t3, 0x60
        ctx->r1 = SIGNED(ctx->r11) < 0X60 ? 1 : 0;
            goto L_803086F8;
    }
    // 0x803086D4: slti        $at, $t3, 0x60
    ctx->r1 = SIGNED(ctx->r11) < 0X60 ? 1 : 0;
    // 0x803086D8: bne         $at, $zero, L_803086E8
    if (ctx->r1 != 0) {
        // 0x803086DC: slti        $at, $t3, 0xE0
        ctx->r1 = SIGNED(ctx->r11) < 0XE0 ? 1 : 0;
            goto L_803086E8;
    }
    // 0x803086DC: slti        $at, $t3, 0xE0
    ctx->r1 = SIGNED(ctx->r11) < 0XE0 ? 1 : 0;
    // 0x803086E0: bne         $at, $zero, L_803086F0
    if (ctx->r1 != 0) {
        // 0x803086E4: nop
    
            goto L_803086F0;
    }
    // 0x803086E4: nop

L_803086E8:
    // 0x803086E8: b           L_80308894
    // 0x803086EC: or          $s2, $zero, $zero
    ctx->r18 = 0 | 0;
        goto L_80308894;
    // 0x803086EC: or          $s2, $zero, $zero
    ctx->r18 = 0 | 0;
L_803086F0:
    // 0x803086F0: b           L_80308894
    // 0x803086F4: addiu       $s2, $zero, 0xC0
    ctx->r18 = ADD32(0, 0XC0);
        goto L_80308894;
    // 0x803086F4: addiu       $s2, $zero, 0xC0
    ctx->r18 = ADD32(0, 0XC0);
L_803086F8:
    // 0x803086F8: lh          $v0, 0x86($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X86);
    // 0x803086FC: sra         $t6, $v0, 1
    ctx->r14 = S32(SIGNED(ctx->r2) >> 1);
    // 0x80308700: addu        $t9, $a0, $t6
    ctx->r25 = ADD32(ctx->r4, ctx->r14);
    // 0x80308704: addu        $t7, $t9, $s3
    ctx->r15 = ADD32(ctx->r25, ctx->r19);
    // 0x80308708: subu        $t8, $t7, $s0
    ctx->r24 = SUB32(ctx->r15, ctx->r16);
    // 0x8030870C: addu        $t5, $t8, $t6
    ctx->r13 = ADD32(ctx->r24, ctx->r14);
    // 0x80308710: lh          $t6, 0x84($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X84);
    // 0x80308714: slt         $at, $t5, $t6
    ctx->r1 = SIGNED(ctx->r13) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x80308718: bne         $at, $zero, L_803087A8
    if (ctx->r1 != 0) {
        // 0x8030871C: slti        $at, $t3, 0x60
        ctx->r1 = SIGNED(ctx->r11) < 0X60 ? 1 : 0;
            goto L_803087A8;
    }
    // 0x8030871C: slti        $at, $t3, 0x60
    ctx->r1 = SIGNED(ctx->r11) < 0X60 ? 1 : 0;
    // 0x80308720: bne         $at, $zero, L_8030872C
    if (ctx->r1 != 0) {
        // 0x80308724: slti        $at, $t3, 0xE0
        ctx->r1 = SIGNED(ctx->r11) < 0XE0 ? 1 : 0;
            goto L_8030872C;
    }
    // 0x80308724: slti        $at, $t3, 0xE0
    ctx->r1 = SIGNED(ctx->r11) < 0XE0 ? 1 : 0;
    // 0x80308728: bne         $at, $zero, L_80308764
    if (ctx->r1 != 0) {
        // 0x8030872C: subu        $t9, $s1, $t4
        ctx->r25 = SUB32(ctx->r17, ctx->r12);
            goto L_80308764;
    }
L_8030872C:
    // 0x8030872C: subu        $t9, $s1, $t4
    ctx->r25 = SUB32(ctx->r17, ctx->r12);
    // 0x80308730: slt         $at, $s4, $t9
    ctx->r1 = SIGNED(ctx->r20) < SIGNED(ctx->r25) ? 1 : 0;
    // 0x80308734: beql        $at, $zero, L_80308748
    if (ctx->r1 == 0) {
        // 0x80308738: addu        $t7, $s1, $t4
        ctx->r15 = ADD32(ctx->r17, ctx->r12);
            goto L_80308748;
    }
    goto skip_28;
    // 0x80308738: addu        $t7, $s1, $t4
    ctx->r15 = ADD32(ctx->r17, ctx->r12);
    skip_28:
    // 0x8030873C: b           L_80308894
    // 0x80308740: addiu       $s2, $zero, 0x408
    ctx->r18 = ADD32(0, 0X408);
        goto L_80308894;
    // 0x80308740: addiu       $s2, $zero, 0x408
    ctx->r18 = ADD32(0, 0X408);
    // 0x80308744: addu        $t7, $s1, $t4
    ctx->r15 = ADD32(ctx->r17, ctx->r12);
L_80308748:
    // 0x80308748: slt         $at, $t7, $s4
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r20) ? 1 : 0;
    // 0x8030874C: beq         $at, $zero, L_8030875C
    if (ctx->r1 == 0) {
        // 0x80308750: nop
    
            goto L_8030875C;
    }
    // 0x80308750: nop

    // 0x80308754: b           L_80308894
    // 0x80308758: addiu       $s2, $zero, 0x4C8
    ctx->r18 = ADD32(0, 0X4C8);
        goto L_80308894;
    // 0x80308758: addiu       $s2, $zero, 0x4C8
    ctx->r18 = ADD32(0, 0X4C8);
L_8030875C:
    // 0x8030875C: b           L_80308894
    // 0x80308760: or          $s2, $zero, $zero
    ctx->r18 = 0 | 0;
        goto L_80308894;
    // 0x80308760: or          $s2, $zero, $zero
    ctx->r18 = 0 | 0;
L_80308764:
    // 0x80308764: subu        $a0, $s1, $s4
    ctx->r4 = SUB32(ctx->r17, ctx->r20);
    // 0x80308768: subu        $a1, $s0, $s3
    ctx->r5 = SUB32(ctx->r16, ctx->r19);
    // 0x8030876C: sll         $t6, $a1, 16
    ctx->r14 = S32(ctx->r5 << 16);
    // 0x80308770: sll         $t8, $a0, 16
    ctx->r24 = S32(ctx->r4 << 16);
    // 0x80308774: sra         $a0, $t8, 16
    ctx->r4 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80308778: sra         $a1, $t6, 16
    ctx->r5 = S32(SIGNED(ctx->r14) >> 16);
    // 0x8030877C: jal         0x801284B8
    // 0x80308780: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    func_801284B8(rdram, ctx);
        goto after_29;
    // 0x80308780: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    after_29:
    // 0x80308784: sll         $s2, $v0, 8
    ctx->r18 = S32(ctx->r2 << 8);
    // 0x80308788: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x8030878C: div         $zero, $s2, $at
    lo = S32(S64(S32(ctx->r18)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r18)) % S64(S32(ctx->r1)));
    // 0x80308790: mflo        $t7
    ctx->r15 = lo;
    // 0x80308794: addiu       $s2, $t7, 0x3E8
    ctx->r18 = ADD32(ctx->r15, 0X3E8);
    // 0x80308798: sll         $t8, $s2, 16
    ctx->r24 = S32(ctx->r18 << 16);
    // 0x8030879C: sra         $s2, $t8, 16
    ctx->r18 = S32(SIGNED(ctx->r24) >> 16);
    // 0x803087A0: b           L_80308894
    // 0x803087A4: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
        goto L_80308894;
    // 0x803087A4: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
L_803087A8:
    // 0x803087A8: slti        $at, $t3, 0x60
    ctx->r1 = SIGNED(ctx->r11) < 0X60 ? 1 : 0;
    // 0x803087AC: bne         $at, $zero, L_803087F0
    if (ctx->r1 != 0) {
        // 0x803087B0: slti        $at, $t3, 0xE0
        ctx->r1 = SIGNED(ctx->r11) < 0XE0 ? 1 : 0;
            goto L_803087F0;
    }
    // 0x803087B0: slti        $at, $t3, 0xE0
    ctx->r1 = SIGNED(ctx->r11) < 0XE0 ? 1 : 0;
    // 0x803087B4: beq         $at, $zero, L_803087F0
    if (ctx->r1 == 0) {
        // 0x803087B8: subu        $t6, $s0, $t4
        ctx->r14 = SUB32(ctx->r16, ctx->r12);
            goto L_803087F0;
    }
    // 0x803087B8: subu        $t6, $s0, $t4
    ctx->r14 = SUB32(ctx->r16, ctx->r12);
    // 0x803087BC: slt         $at, $s3, $t6
    ctx->r1 = SIGNED(ctx->r19) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x803087C0: beql        $at, $zero, L_803087D4
    if (ctx->r1 == 0) {
        // 0x803087C4: addu        $t9, $s0, $t4
        ctx->r25 = ADD32(ctx->r16, ctx->r12);
            goto L_803087D4;
    }
    goto skip_29;
    // 0x803087C4: addu        $t9, $s0, $t4
    ctx->r25 = ADD32(ctx->r16, ctx->r12);
    skip_29:
    // 0x803087C8: b           L_80308894
    // 0x803087CC: addiu       $s2, $zero, 0x4C8
    ctx->r18 = ADD32(0, 0X4C8);
        goto L_80308894;
    // 0x803087CC: addiu       $s2, $zero, 0x4C8
    ctx->r18 = ADD32(0, 0X4C8);
    // 0x803087D0: addu        $t9, $s0, $t4
    ctx->r25 = ADD32(ctx->r16, ctx->r12);
L_803087D4:
    // 0x803087D4: slt         $at, $t9, $s3
    ctx->r1 = SIGNED(ctx->r25) < SIGNED(ctx->r19) ? 1 : 0;
    // 0x803087D8: beq         $at, $zero, L_803087E8
    if (ctx->r1 == 0) {
        // 0x803087DC: nop
    
            goto L_803087E8;
    }
    // 0x803087DC: nop

    // 0x803087E0: b           L_80308894
    // 0x803087E4: addiu       $s2, $zero, 0x488
    ctx->r18 = ADD32(0, 0X488);
        goto L_80308894;
    // 0x803087E4: addiu       $s2, $zero, 0x488
    ctx->r18 = ADD32(0, 0X488);
L_803087E8:
    // 0x803087E8: b           L_80308894
    // 0x803087EC: addiu       $s2, $zero, 0xC0
    ctx->r18 = ADD32(0, 0XC0);
        goto L_80308894;
    // 0x803087EC: addiu       $s2, $zero, 0xC0
    ctx->r18 = ADD32(0, 0XC0);
L_803087F0:
    // 0x803087F0: subu        $a0, $s1, $s4
    ctx->r4 = SUB32(ctx->r17, ctx->r20);
    // 0x803087F4: subu        $a1, $s0, $s3
    ctx->r5 = SUB32(ctx->r16, ctx->r19);
    // 0x803087F8: sll         $t5, $a1, 16
    ctx->r13 = S32(ctx->r5 << 16);
    // 0x803087FC: sll         $t7, $a0, 16
    ctx->r15 = S32(ctx->r4 << 16);
    // 0x80308800: sra         $a0, $t7, 16
    ctx->r4 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80308804: sra         $a1, $t5, 16
    ctx->r5 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80308808: jal         0x801284B8
    // 0x8030880C: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    func_801284B8(rdram, ctx);
        goto after_30;
    // 0x8030880C: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    after_30:
    // 0x80308810: sll         $s2, $v0, 8
    ctx->r18 = S32(ctx->r2 << 8);
    // 0x80308814: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80308818: div         $zero, $s2, $at
    lo = S32(S64(S32(ctx->r18)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r18)) % S64(S32(ctx->r1)));
    // 0x8030881C: mflo        $t9
    ctx->r25 = lo;
    // 0x80308820: addiu       $s2, $t9, 0x3E8
    ctx->r18 = ADD32(ctx->r25, 0X3E8);
    // 0x80308824: sll         $t7, $s2, 16
    ctx->r15 = S32(ctx->r18 << 16);
    // 0x80308828: sra         $s2, $t7, 16
    ctx->r18 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8030882C: b           L_80308894
    // 0x80308830: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
        goto L_80308894;
    // 0x80308830: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
L_80308834:
    // 0x80308834: slt         $at, $s4, $s1
    ctx->r1 = SIGNED(ctx->r20) < SIGNED(ctx->r17) ? 1 : 0;
    // 0x80308838: beq         $at, $zero, L_80308890
    if (ctx->r1 == 0) {
        // 0x8030883C: slt         $at, $s0, $s3
        ctx->r1 = SIGNED(ctx->r16) < SIGNED(ctx->r19) ? 1 : 0;
            goto L_80308890;
    }
    // 0x8030883C: slt         $at, $s0, $s3
    ctx->r1 = SIGNED(ctx->r16) < SIGNED(ctx->r19) ? 1 : 0;
    // 0x80308840: beq         $at, $zero, L_80308890
    if (ctx->r1 == 0) {
        // 0x80308844: addiu       $t1, $t1, 0x280
        ctx->r9 = ADD32(ctx->r9, 0X280);
            goto L_80308890;
    }
    // 0x80308844: addiu       $t1, $t1, 0x280
    ctx->r9 = ADD32(ctx->r9, 0X280);
    // 0x80308848: addiu       $t2, $t2, -0x280
    ctx->r10 = ADD32(ctx->r10, -0X280);
    // 0x8030884C: sll         $a0, $t2, 16
    ctx->r4 = S32(ctx->r10 << 16);
    // 0x80308850: sll         $a1, $t1, 16
    ctx->r5 = S32(ctx->r9 << 16);
    // 0x80308854: sra         $t6, $a1, 16
    ctx->r14 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80308858: sra         $t5, $a0, 16
    ctx->r13 = S32(SIGNED(ctx->r4) >> 16);
    // 0x8030885C: or          $a0, $t5, $zero
    ctx->r4 = ctx->r13 | 0;
    // 0x80308860: jal         0x801284B8
    // 0x80308864: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    func_801284B8(rdram, ctx);
        goto after_31;
    // 0x80308864: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    after_31:
    // 0x80308868: sll         $t3, $v0, 8
    ctx->r11 = S32(ctx->r2 << 8);
    // 0x8030886C: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80308870: div         $zero, $t3, $at
    lo = S32(S64(S32(ctx->r11)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r11)) % S64(S32(ctx->r1)));
    // 0x80308874: mflo        $t9
    ctx->r25 = lo;
    // 0x80308878: sll         $t7, $t9, 16
    ctx->r15 = S32(ctx->r25 << 16);
    // 0x8030887C: slti        $at, $s5, 0xB
    ctx->r1 = SIGNED(ctx->r21) < 0XB ? 1 : 0;
    // 0x80308880: beq         $at, $zero, L_80308894
    if (ctx->r1 == 0) {
        // 0x80308884: sra         $t3, $t7, 16
        ctx->r11 = S32(SIGNED(ctx->r15) >> 16);
            goto L_80308894;
    }
    // 0x80308884: sra         $t3, $t7, 16
    ctx->r11 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80308888: b           L_80308894
    // 0x8030888C: addiu       $s5, $zero, 0xA
    ctx->r21 = ADD32(0, 0XA);
        goto L_80308894;
    // 0x8030888C: addiu       $s5, $zero, 0xA
    ctx->r21 = ADD32(0, 0XA);
L_80308890:
    // 0x80308890: addiu       $s2, $zero, 0x4C8
    ctx->r18 = ADD32(0, 0X4C8);
L_80308894:
    // 0x80308894: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80308898: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x8030889C: b           L_80309428
    // 0x803088A0: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
        goto L_80309428;
    // 0x803088A0: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_803088A4:
    // 0x803088A4: slti        $at, $t3, 0x40
    ctx->r1 = SIGNED(ctx->r11) < 0X40 ? 1 : 0;
    // 0x803088A8: bne         $at, $zero, L_80308958
    if (ctx->r1 != 0) {
        // 0x803088AC: slti        $at, $t3, 0xC0
        ctx->r1 = SIGNED(ctx->r11) < 0XC0 ? 1 : 0;
            goto L_80308958;
    }
    // 0x803088AC: slti        $at, $t3, 0xC0
    ctx->r1 = SIGNED(ctx->r11) < 0XC0 ? 1 : 0;
    // 0x803088B0: beq         $at, $zero, L_80308958
    if (ctx->r1 == 0) {
        // 0x803088B4: subu        $a0, $s4, $s1
        ctx->r4 = SUB32(ctx->r20, ctx->r17);
            goto L_80308958;
    }
    // 0x803088B4: subu        $a0, $s4, $s1
    ctx->r4 = SUB32(ctx->r20, ctx->r17);
    // 0x803088B8: bgezl       $a0, L_803088CC
    if (SIGNED(ctx->r4) >= 0) {
        // 0x803088BC: or          $v1, $a0, $zero
        ctx->r3 = ctx->r4 | 0;
            goto L_803088CC;
    }
    goto skip_30;
    // 0x803088BC: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
    skip_30:
    // 0x803088C0: b           L_803088CC
    // 0x803088C4: negu        $v1, $a0
    ctx->r3 = SUB32(0, ctx->r4);
        goto L_803088CC;
    // 0x803088C4: negu        $v1, $a0
    ctx->r3 = SUB32(0, ctx->r4);
    // 0x803088C8: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
L_803088CC:
    // 0x803088CC: slt         $at, $v1, $t4
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x803088D0: beq         $at, $zero, L_80308908
    if (ctx->r1 == 0) {
        // 0x803088D4: subu        $v0, $s3, $s0
        ctx->r2 = SUB32(ctx->r19, ctx->r16);
            goto L_80308908;
    }
    // 0x803088D4: subu        $v0, $s3, $s0
    ctx->r2 = SUB32(ctx->r19, ctx->r16);
    // 0x803088D8: bgezl       $v0, L_803088EC
    if (SIGNED(ctx->r2) >= 0) {
        // 0x803088DC: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_803088EC;
    }
    goto skip_31;
    // 0x803088DC: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    skip_31:
    // 0x803088E0: b           L_803088EC
    // 0x803088E4: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_803088EC;
    // 0x803088E4: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
    // 0x803088E8: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_803088EC:
    // 0x803088EC: slt         $at, $v1, $t4
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x803088F0: beq         $at, $zero, L_80308908
    if (ctx->r1 == 0) {
        // 0x803088F4: lui         $t0, 0x803D
        ctx->r8 = S32(0X803D << 16);
            goto L_80308908;
    }
    // 0x803088F4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803088F8: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x803088FC: addiu       $s5, $zero, -0x1
    ctx->r21 = ADD32(0, -0X1);
    // 0x80308900: b           L_80309428
    // 0x80308904: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
        goto L_80309428;
    // 0x80308904: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_80308908:
    // 0x80308908: subu        $a0, $s1, $s4
    ctx->r4 = SUB32(ctx->r17, ctx->r20);
    // 0x8030890C: subu        $a1, $s0, $s3
    ctx->r5 = SUB32(ctx->r16, ctx->r19);
    // 0x80308910: sll         $t9, $a1, 16
    ctx->r25 = S32(ctx->r5 << 16);
    // 0x80308914: sll         $t5, $a0, 16
    ctx->r13 = S32(ctx->r4 << 16);
    // 0x80308918: sra         $a0, $t5, 16
    ctx->r4 = S32(SIGNED(ctx->r13) >> 16);
    // 0x8030891C: sra         $a1, $t9, 16
    ctx->r5 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80308920: jal         0x801284B8
    // 0x80308924: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    func_801284B8(rdram, ctx);
        goto after_32;
    // 0x80308924: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    after_32:
    // 0x80308928: sll         $s2, $v0, 8
    ctx->r18 = S32(ctx->r2 << 8);
    // 0x8030892C: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80308930: div         $zero, $s2, $at
    lo = S32(S64(S32(ctx->r18)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r18)) % S64(S32(ctx->r1)));
    // 0x80308934: mflo        $t8
    ctx->r24 = lo;
    // 0x80308938: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030893C: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x80308940: addiu       $s2, $t8, 0x3E8
    ctx->r18 = ADD32(ctx->r24, 0X3E8);
    // 0x80308944: sll         $t5, $s2, 16
    ctx->r13 = S32(ctx->r18 << 16);
    // 0x80308948: sra         $s2, $t5, 16
    ctx->r18 = S32(SIGNED(ctx->r13) >> 16);
    // 0x8030894C: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
    // 0x80308950: b           L_80309428
    // 0x80308954: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
        goto L_80309428;
    // 0x80308954: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_80308958:
    // 0x80308958: lh          $t8, 0x86($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X86);
    // 0x8030895C: subu        $a0, $s1, $s4
    ctx->r4 = SUB32(ctx->r17, ctx->r20);
    // 0x80308960: sll         $t9, $a0, 16
    ctx->r25 = S32(ctx->r4 << 16);
    // 0x80308964: sra         $t5, $t8, 1
    ctx->r13 = S32(SIGNED(ctx->r24) >> 1);
    // 0x80308968: addu        $t6, $s0, $t5
    ctx->r14 = ADD32(ctx->r16, ctx->r13);
    // 0x8030896C: subu        $a1, $t6, $s3
    ctx->r5 = SUB32(ctx->r14, ctx->r19);
    // 0x80308970: sra         $a0, $t9, 16
    ctx->r4 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80308974: sll         $t9, $a1, 16
    ctx->r25 = S32(ctx->r5 << 16);
    // 0x80308978: sra         $a1, $t9, 16
    ctx->r5 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8030897C: jal         0x801284B8
    // 0x80308980: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    func_801284B8(rdram, ctx);
        goto after_33;
    // 0x80308980: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    after_33:
    // 0x80308984: sll         $s2, $v0, 8
    ctx->r18 = S32(ctx->r2 << 8);
    // 0x80308988: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x8030898C: div         $zero, $s2, $at
    lo = S32(S64(S32(ctx->r18)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r18)) % S64(S32(ctx->r1)));
    // 0x80308990: mflo        $t8
    ctx->r24 = lo;
    // 0x80308994: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80308998: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x8030899C: addiu       $s2, $t8, 0x3E8
    ctx->r18 = ADD32(ctx->r24, 0X3E8);
    // 0x803089A0: sll         $t5, $s2, 16
    ctx->r13 = S32(ctx->r18 << 16);
    // 0x803089A4: sra         $s2, $t5, 16
    ctx->r18 = S32(SIGNED(ctx->r13) >> 16);
    // 0x803089A8: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
    // 0x803089AC: b           L_80309428
    // 0x803089B0: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
        goto L_80309428;
    // 0x803089B0: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_803089B4:
    // 0x803089B4: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x803089B8: lw          $t8, 0x5530($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5530);
    // 0x803089BC: sll         $a0, $s1, 16
    ctx->r4 = S32(ctx->r17 << 16);
    // 0x803089C0: sll         $a1, $s0, 16
    ctx->r5 = S32(ctx->r16 << 16);
    // 0x803089C4: lw          $a2, 0xC($t8)
    ctx->r6 = MEM_W(ctx->r24, 0XC);
    // 0x803089C8: sra         $t7, $a1, 16
    ctx->r15 = S32(SIGNED(ctx->r5) >> 16);
    // 0x803089CC: sra         $t9, $a0, 16
    ctx->r25 = S32(SIGNED(ctx->r4) >> 16);
    // 0x803089D0: addiu       $t5, $zero, 0x2
    ctx->r13 = ADD32(0, 0X2);
    // 0x803089D4: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x803089D8: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    // 0x803089DC: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    // 0x803089E0: sh          $t4, 0x82($sp)
    MEM_H(0X82, ctx->r29) = ctx->r12;
    // 0x803089E4: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    // 0x803089E8: sw          $t2, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->r10;
    // 0x803089EC: sw          $t1, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->r9;
    // 0x803089F0: jal         0x80305A70
    // 0x803089F4: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    func_80305A70_717120(rdram, ctx);
        goto after_34;
    // 0x803089F4: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    after_34:
    // 0x803089F8: lw          $t1, 0xB0($sp)
    ctx->r9 = MEM_W(ctx->r29, 0XB0);
    // 0x803089FC: lw          $t2, 0xAC($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XAC);
    // 0x80308A00: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
    // 0x80308A04: bne         $v0, $zero, L_80308A64
    if (ctx->r2 != 0) {
        // 0x80308A08: lh          $t4, 0x82($sp)
        ctx->r12 = MEM_H(ctx->r29, 0X82);
            goto L_80308A64;
    }
    // 0x80308A08: lh          $t4, 0x82($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X82);
    // 0x80308A0C: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80308A10: lw          $t7, 0x5530($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5530);
    // 0x80308A14: sll         $a0, $s1, 16
    ctx->r4 = S32(ctx->r17 << 16);
    // 0x80308A18: sll         $a1, $s0, 16
    ctx->r5 = S32(ctx->r16 << 16);
    // 0x80308A1C: lw          $a2, 0xC($t7)
    ctx->r6 = MEM_W(ctx->r15, 0XC);
    // 0x80308A20: sra         $t9, $a1, 16
    ctx->r25 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80308A24: sra         $t6, $a0, 16
    ctx->r14 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80308A28: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x80308A2C: sw          $t8, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r24;
    // 0x80308A30: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    // 0x80308A34: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
    // 0x80308A38: sh          $t4, 0x82($sp)
    MEM_H(0X82, ctx->r29) = ctx->r12;
    // 0x80308A3C: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    // 0x80308A40: sw          $t2, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->r10;
    // 0x80308A44: sw          $t1, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->r9;
    // 0x80308A48: jal         0x80305A70
    // 0x80308A4C: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    func_80305A70_717120(rdram, ctx);
        goto after_35;
    // 0x80308A4C: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    after_35:
    // 0x80308A50: lw          $t1, 0xB0($sp)
    ctx->r9 = MEM_W(ctx->r29, 0XB0);
    // 0x80308A54: lw          $t2, 0xAC($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XAC);
    // 0x80308A58: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
    // 0x80308A5C: beq         $v0, $zero, L_80308A84
    if (ctx->r2 == 0) {
        // 0x80308A60: lh          $t4, 0x82($sp)
        ctx->r12 = MEM_H(ctx->r29, 0X82);
            goto L_80308A84;
    }
    // 0x80308A60: lh          $t4, 0x82($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X82);
L_80308A64:
    // 0x80308A64: slti        $at, $t3, 0x60
    ctx->r1 = SIGNED(ctx->r11) < 0X60 ? 1 : 0;
    // 0x80308A68: bne         $at, $zero, L_80308A74
    if (ctx->r1 != 0) {
        // 0x80308A6C: slti        $at, $t3, 0xA0
        ctx->r1 = SIGNED(ctx->r11) < 0XA0 ? 1 : 0;
            goto L_80308A74;
    }
    // 0x80308A6C: slti        $at, $t3, 0xA0
    ctx->r1 = SIGNED(ctx->r11) < 0XA0 ? 1 : 0;
    // 0x80308A70: bne         $at, $zero, L_80308FD4
    if (ctx->r1 != 0) {
        // 0x80308A74: lui         $t0, 0x803D
        ctx->r8 = S32(0X803D << 16);
            goto L_80308FD4;
    }
L_80308A74:
    // 0x80308A74: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80308A78: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x80308A7C: b           L_803090F0
    // 0x80308A80: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
        goto L_803090F0;
    // 0x80308A80: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_80308A84:
    // 0x80308A84: slt         $at, $s3, $s0
    ctx->r1 = SIGNED(ctx->r19) < SIGNED(ctx->r16) ? 1 : 0;
    // 0x80308A88: bne         $at, $zero, L_80308A9C
    if (ctx->r1 != 0) {
        // 0x80308A8C: slti        $at, $t3, 0x40
        ctx->r1 = SIGNED(ctx->r11) < 0X40 ? 1 : 0;
            goto L_80308A9C;
    }
    // 0x80308A8C: slti        $at, $t3, 0x40
    ctx->r1 = SIGNED(ctx->r11) < 0X40 ? 1 : 0;
    // 0x80308A90: bne         $at, $zero, L_80308AE4
    if (ctx->r1 != 0) {
        // 0x80308A94: slti        $at, $t3, 0xC0
        ctx->r1 = SIGNED(ctx->r11) < 0XC0 ? 1 : 0;
            goto L_80308AE4;
    }
    // 0x80308A94: slti        $at, $t3, 0xC0
    ctx->r1 = SIGNED(ctx->r11) < 0XC0 ? 1 : 0;
    // 0x80308A98: beq         $at, $zero, L_80308AE4
    if (ctx->r1 == 0) {
        // 0x80308A9C: addiu       $t1, $t1, -0x280
        ctx->r9 = ADD32(ctx->r9, -0X280);
            goto L_80308AE4;
    }
L_80308A9C:
    // 0x80308A9C: addiu       $t1, $t1, -0x280
    ctx->r9 = ADD32(ctx->r9, -0X280);
    // 0x80308AA0: sll         $a1, $t1, 16
    ctx->r5 = S32(ctx->r9 << 16);
    // 0x80308AA4: sll         $a0, $t2, 16
    ctx->r4 = S32(ctx->r10 << 16);
    // 0x80308AA8: sra         $t5, $a0, 16
    ctx->r13 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80308AAC: sra         $t6, $a1, 16
    ctx->r14 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80308AB0: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x80308AB4: jal         0x801284B8
    // 0x80308AB8: or          $a0, $t5, $zero
    ctx->r4 = ctx->r13 | 0;
    func_801284B8(rdram, ctx);
        goto after_36;
    // 0x80308AB8: or          $a0, $t5, $zero
    ctx->r4 = ctx->r13 | 0;
    after_36:
    // 0x80308ABC: sll         $t3, $v0, 8
    ctx->r11 = S32(ctx->r2 << 8);
    // 0x80308AC0: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80308AC4: div         $zero, $t3, $at
    lo = S32(S64(S32(ctx->r11)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r11)) % S64(S32(ctx->r1)));
    // 0x80308AC8: mflo        $t9
    ctx->r25 = lo;
    // 0x80308ACC: sll         $t7, $t9, 16
    ctx->r15 = S32(ctx->r25 << 16);
    // 0x80308AD0: slti        $at, $s5, 0xB
    ctx->r1 = SIGNED(ctx->r21) < 0XB ? 1 : 0;
    // 0x80308AD4: beq         $at, $zero, L_80308AE8
    if (ctx->r1 == 0) {
        // 0x80308AD8: sra         $t3, $t7, 16
        ctx->r11 = S32(SIGNED(ctx->r15) >> 16);
            goto L_80308AE8;
    }
    // 0x80308AD8: sra         $t3, $t7, 16
    ctx->r11 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80308ADC: b           L_80308AE8
    // 0x80308AE0: addiu       $s5, $zero, 0xA
    ctx->r21 = ADD32(0, 0XA);
        goto L_80308AE8;
    // 0x80308AE0: addiu       $s5, $zero, 0xA
    ctx->r21 = ADD32(0, 0XA);
L_80308AE4:
    // 0x80308AE4: addiu       $s2, $zero, 0x468
    ctx->r18 = ADD32(0, 0X468);
L_80308AE8:
    // 0x80308AE8: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80308AEC: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x80308AF0: b           L_80309428
    // 0x80308AF4: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
        goto L_80309428;
    // 0x80308AF4: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_80308AF8:
    // 0x80308AF8: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x80308AFC: lw          $t9, 0x5530($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5530);
    // 0x80308B00: sll         $a0, $s1, 16
    ctx->r4 = S32(ctx->r17 << 16);
    // 0x80308B04: sll         $a1, $s0, 16
    ctx->r5 = S32(ctx->r16 << 16);
    // 0x80308B08: lw          $a2, 0xC($t9)
    ctx->r6 = MEM_W(ctx->r25, 0XC);
    // 0x80308B0C: sra         $t6, $a1, 16
    ctx->r14 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80308B10: sra         $t5, $a0, 16
    ctx->r13 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80308B14: addiu       $t7, $zero, 0x1
    ctx->r15 = ADD32(0, 0X1);
    // 0x80308B18: sw          $t7, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r15;
    // 0x80308B1C: or          $a0, $t5, $zero
    ctx->r4 = ctx->r13 | 0;
    // 0x80308B20: or          $a1, $t6, $zero
    ctx->r5 = ctx->r14 | 0;
    // 0x80308B24: sh          $t4, 0x82($sp)
    MEM_H(0X82, ctx->r29) = ctx->r12;
    // 0x80308B28: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    // 0x80308B2C: sw          $t2, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->r10;
    // 0x80308B30: sw          $t1, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->r9;
    // 0x80308B34: jal         0x80305A70
    // 0x80308B38: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    func_80305A70_717120(rdram, ctx);
        goto after_37;
    // 0x80308B38: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    after_37:
    // 0x80308B3C: lw          $t1, 0xB0($sp)
    ctx->r9 = MEM_W(ctx->r29, 0XB0);
    // 0x80308B40: lw          $t2, 0xAC($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XAC);
    // 0x80308B44: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
    // 0x80308B48: beq         $v0, $zero, L_80308CF0
    if (ctx->r2 == 0) {
        // 0x80308B4C: lh          $t4, 0x82($sp)
        ctx->r12 = MEM_H(ctx->r29, 0X82);
            goto L_80308CF0;
    }
    // 0x80308B4C: lh          $t4, 0x82($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X82);
    // 0x80308B50: subu        $a0, $s4, $s1
    ctx->r4 = SUB32(ctx->r20, ctx->r17);
    // 0x80308B54: bgezl       $a0, L_80308B68
    if (SIGNED(ctx->r4) >= 0) {
        // 0x80308B58: or          $v1, $a0, $zero
        ctx->r3 = ctx->r4 | 0;
            goto L_80308B68;
    }
    goto skip_32;
    // 0x80308B58: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
    skip_32:
    // 0x80308B5C: b           L_80308B68
    // 0x80308B60: negu        $v1, $a0
    ctx->r3 = SUB32(0, ctx->r4);
        goto L_80308B68;
    // 0x80308B60: negu        $v1, $a0
    ctx->r3 = SUB32(0, ctx->r4);
    // 0x80308B64: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
L_80308B68:
    // 0x80308B68: slt         $at, $v1, $t4
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x80308B6C: beq         $at, $zero, L_80308BB4
    if (ctx->r1 == 0) {
        // 0x80308B70: subu        $v0, $s3, $s0
        ctx->r2 = SUB32(ctx->r19, ctx->r16);
            goto L_80308BB4;
    }
    // 0x80308B70: subu        $v0, $s3, $s0
    ctx->r2 = SUB32(ctx->r19, ctx->r16);
    // 0x80308B74: bgezl       $v0, L_80308B88
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80308B78: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_80308B88;
    }
    goto skip_33;
    // 0x80308B78: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    skip_33:
    // 0x80308B7C: b           L_80308B88
    // 0x80308B80: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_80308B88;
    // 0x80308B80: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
    // 0x80308B84: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_80308B88:
    // 0x80308B88: slt         $at, $v1, $t4
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x80308B8C: beq         $at, $zero, L_80308BB4
    if (ctx->r1 == 0) {
        // 0x80308B90: slti        $at, $t3, 0x60
        ctx->r1 = SIGNED(ctx->r11) < 0X60 ? 1 : 0;
            goto L_80308BB4;
    }
    // 0x80308B90: slti        $at, $t3, 0x60
    ctx->r1 = SIGNED(ctx->r11) < 0X60 ? 1 : 0;
    // 0x80308B94: bne         $at, $zero, L_80308BA4
    if (ctx->r1 != 0) {
        // 0x80308B98: slti        $at, $t3, 0xE0
        ctx->r1 = SIGNED(ctx->r11) < 0XE0 ? 1 : 0;
            goto L_80308BA4;
    }
    // 0x80308B98: slti        $at, $t3, 0xE0
    ctx->r1 = SIGNED(ctx->r11) < 0XE0 ? 1 : 0;
    // 0x80308B9C: bne         $at, $zero, L_80308BAC
    if (ctx->r1 != 0) {
        // 0x80308BA0: nop
    
            goto L_80308BAC;
    }
    // 0x80308BA0: nop

L_80308BA4:
    // 0x80308BA4: b           L_80308D50
    // 0x80308BA8: addiu       $s2, $zero, 0x40
    ctx->r18 = ADD32(0, 0X40);
        goto L_80308D50;
    // 0x80308BA8: addiu       $s2, $zero, 0x40
    ctx->r18 = ADD32(0, 0X40);
L_80308BAC:
    // 0x80308BAC: b           L_80308D50
    // 0x80308BB0: addiu       $s2, $zero, 0x80
    ctx->r18 = ADD32(0, 0X80);
        goto L_80308D50;
    // 0x80308BB0: addiu       $s2, $zero, 0x80
    ctx->r18 = ADD32(0, 0X80);
L_80308BB4:
    // 0x80308BB4: lh          $v0, 0x86($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X86);
    // 0x80308BB8: sra         $t8, $v0, 1
    ctx->r24 = S32(SIGNED(ctx->r2) >> 1);
    // 0x80308BBC: addu        $t5, $a0, $t8
    ctx->r13 = ADD32(ctx->r4, ctx->r24);
    // 0x80308BC0: addu        $t6, $t5, $s3
    ctx->r14 = ADD32(ctx->r13, ctx->r19);
    // 0x80308BC4: subu        $t9, $t6, $s0
    ctx->r25 = SUB32(ctx->r14, ctx->r16);
    // 0x80308BC8: addu        $t7, $t9, $t8
    ctx->r15 = ADD32(ctx->r25, ctx->r24);
    // 0x80308BCC: lh          $t8, 0x84($sp)
    ctx->r24 = MEM_H(ctx->r29, 0X84);
    // 0x80308BD0: slt         $at, $t7, $t8
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r24) ? 1 : 0;
    // 0x80308BD4: bne         $at, $zero, L_80308C64
    if (ctx->r1 != 0) {
        // 0x80308BD8: slti        $at, $t3, 0x60
        ctx->r1 = SIGNED(ctx->r11) < 0X60 ? 1 : 0;
            goto L_80308C64;
    }
    // 0x80308BD8: slti        $at, $t3, 0x60
    ctx->r1 = SIGNED(ctx->r11) < 0X60 ? 1 : 0;
    // 0x80308BDC: bne         $at, $zero, L_80308BE8
    if (ctx->r1 != 0) {
        // 0x80308BE0: slti        $at, $t3, 0xE0
        ctx->r1 = SIGNED(ctx->r11) < 0XE0 ? 1 : 0;
            goto L_80308BE8;
    }
    // 0x80308BE0: slti        $at, $t3, 0xE0
    ctx->r1 = SIGNED(ctx->r11) < 0XE0 ? 1 : 0;
    // 0x80308BE4: bne         $at, $zero, L_80308C20
    if (ctx->r1 != 0) {
        // 0x80308BE8: subu        $t5, $s0, $t4
        ctx->r13 = SUB32(ctx->r16, ctx->r12);
            goto L_80308C20;
    }
L_80308BE8:
    // 0x80308BE8: subu        $t5, $s0, $t4
    ctx->r13 = SUB32(ctx->r16, ctx->r12);
    // 0x80308BEC: slt         $at, $s3, $t5
    ctx->r1 = SIGNED(ctx->r19) < SIGNED(ctx->r13) ? 1 : 0;
    // 0x80308BF0: beql        $at, $zero, L_80308C04
    if (ctx->r1 == 0) {
        // 0x80308BF4: addu        $t6, $s0, $t4
        ctx->r14 = ADD32(ctx->r16, ctx->r12);
            goto L_80308C04;
    }
    goto skip_34;
    // 0x80308BF4: addu        $t6, $s0, $t4
    ctx->r14 = ADD32(ctx->r16, ctx->r12);
    skip_34:
    // 0x80308BF8: b           L_80308D50
    // 0x80308BFC: addiu       $s2, $zero, 0x408
    ctx->r18 = ADD32(0, 0X408);
        goto L_80308D50;
    // 0x80308BFC: addiu       $s2, $zero, 0x408
    ctx->r18 = ADD32(0, 0X408);
    // 0x80308C00: addu        $t6, $s0, $t4
    ctx->r14 = ADD32(ctx->r16, ctx->r12);
L_80308C04:
    // 0x80308C04: slt         $at, $t6, $s3
    ctx->r1 = SIGNED(ctx->r14) < SIGNED(ctx->r19) ? 1 : 0;
    // 0x80308C08: beq         $at, $zero, L_80308C18
    if (ctx->r1 == 0) {
        // 0x80308C0C: nop
    
            goto L_80308C18;
    }
    // 0x80308C0C: nop

    // 0x80308C10: b           L_80308D50
    // 0x80308C14: addiu       $s2, $zero, 0x448
    ctx->r18 = ADD32(0, 0X448);
        goto L_80308D50;
    // 0x80308C14: addiu       $s2, $zero, 0x448
    ctx->r18 = ADD32(0, 0X448);
L_80308C18:
    // 0x80308C18: b           L_80308D50
    // 0x80308C1C: addiu       $s2, $zero, 0x40
    ctx->r18 = ADD32(0, 0X40);
        goto L_80308D50;
    // 0x80308C1C: addiu       $s2, $zero, 0x40
    ctx->r18 = ADD32(0, 0X40);
L_80308C20:
    // 0x80308C20: subu        $a0, $s1, $s4
    ctx->r4 = SUB32(ctx->r17, ctx->r20);
    // 0x80308C24: subu        $a1, $s0, $s3
    ctx->r5 = SUB32(ctx->r16, ctx->r19);
    // 0x80308C28: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x80308C2C: sll         $t9, $a0, 16
    ctx->r25 = S32(ctx->r4 << 16);
    // 0x80308C30: sra         $a0, $t9, 16
    ctx->r4 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80308C34: sra         $a1, $t8, 16
    ctx->r5 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80308C38: jal         0x801284B8
    // 0x80308C3C: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    func_801284B8(rdram, ctx);
        goto after_38;
    // 0x80308C3C: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    after_38:
    // 0x80308C40: sll         $s2, $v0, 8
    ctx->r18 = S32(ctx->r2 << 8);
    // 0x80308C44: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80308C48: div         $zero, $s2, $at
    lo = S32(S64(S32(ctx->r18)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r18)) % S64(S32(ctx->r1)));
    // 0x80308C4C: mflo        $t6
    ctx->r14 = lo;
    // 0x80308C50: addiu       $s2, $t6, 0x3E8
    ctx->r18 = ADD32(ctx->r14, 0X3E8);
    // 0x80308C54: sll         $t9, $s2, 16
    ctx->r25 = S32(ctx->r18 << 16);
    // 0x80308C58: sra         $s2, $t9, 16
    ctx->r18 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80308C5C: b           L_80308D50
    // 0x80308C60: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
        goto L_80308D50;
    // 0x80308C60: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
L_80308C64:
    // 0x80308C64: slti        $at, $t3, 0x60
    ctx->r1 = SIGNED(ctx->r11) < 0X60 ? 1 : 0;
    // 0x80308C68: bne         $at, $zero, L_80308CAC
    if (ctx->r1 != 0) {
        // 0x80308C6C: slti        $at, $t3, 0xE0
        ctx->r1 = SIGNED(ctx->r11) < 0XE0 ? 1 : 0;
            goto L_80308CAC;
    }
    // 0x80308C6C: slti        $at, $t3, 0xE0
    ctx->r1 = SIGNED(ctx->r11) < 0XE0 ? 1 : 0;
    // 0x80308C70: beq         $at, $zero, L_80308CAC
    if (ctx->r1 == 0) {
        // 0x80308C74: subu        $t8, $s1, $t4
        ctx->r24 = SUB32(ctx->r17, ctx->r12);
            goto L_80308CAC;
    }
    // 0x80308C74: subu        $t8, $s1, $t4
    ctx->r24 = SUB32(ctx->r17, ctx->r12);
    // 0x80308C78: slt         $at, $s4, $t8
    ctx->r1 = SIGNED(ctx->r20) < SIGNED(ctx->r24) ? 1 : 0;
    // 0x80308C7C: beql        $at, $zero, L_80308C90
    if (ctx->r1 == 0) {
        // 0x80308C80: addu        $t5, $s1, $t4
        ctx->r13 = ADD32(ctx->r17, ctx->r12);
            goto L_80308C90;
    }
    goto skip_35;
    // 0x80308C80: addu        $t5, $s1, $t4
    ctx->r13 = ADD32(ctx->r17, ctx->r12);
    skip_35:
    // 0x80308C84: b           L_80308D50
    // 0x80308C88: addiu       $s2, $zero, 0x448
    ctx->r18 = ADD32(0, 0X448);
        goto L_80308D50;
    // 0x80308C88: addiu       $s2, $zero, 0x448
    ctx->r18 = ADD32(0, 0X448);
    // 0x80308C8C: addu        $t5, $s1, $t4
    ctx->r13 = ADD32(ctx->r17, ctx->r12);
L_80308C90:
    // 0x80308C90: slt         $at, $t5, $s4
    ctx->r1 = SIGNED(ctx->r13) < SIGNED(ctx->r20) ? 1 : 0;
    // 0x80308C94: beq         $at, $zero, L_80308CA4
    if (ctx->r1 == 0) {
        // 0x80308C98: nop
    
            goto L_80308CA4;
    }
    // 0x80308C98: nop

    // 0x80308C9C: b           L_80308D50
    // 0x80308CA0: addiu       $s2, $zero, 0x488
    ctx->r18 = ADD32(0, 0X488);
        goto L_80308D50;
    // 0x80308CA0: addiu       $s2, $zero, 0x488
    ctx->r18 = ADD32(0, 0X488);
L_80308CA4:
    // 0x80308CA4: b           L_80308D50
    // 0x80308CA8: addiu       $s2, $zero, 0x80
    ctx->r18 = ADD32(0, 0X80);
        goto L_80308D50;
    // 0x80308CA8: addiu       $s2, $zero, 0x80
    ctx->r18 = ADD32(0, 0X80);
L_80308CAC:
    // 0x80308CAC: subu        $a0, $s1, $s4
    ctx->r4 = SUB32(ctx->r17, ctx->r20);
    // 0x80308CB0: subu        $a1, $s0, $s3
    ctx->r5 = SUB32(ctx->r16, ctx->r19);
    // 0x80308CB4: sll         $t7, $a1, 16
    ctx->r15 = S32(ctx->r5 << 16);
    // 0x80308CB8: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x80308CBC: sra         $a0, $t6, 16
    ctx->r4 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80308CC0: sra         $a1, $t7, 16
    ctx->r5 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80308CC4: jal         0x801284B8
    // 0x80308CC8: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    func_801284B8(rdram, ctx);
        goto after_39;
    // 0x80308CC8: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    after_39:
    // 0x80308CCC: sll         $s2, $v0, 8
    ctx->r18 = S32(ctx->r2 << 8);
    // 0x80308CD0: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80308CD4: div         $zero, $s2, $at
    lo = S32(S64(S32(ctx->r18)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r18)) % S64(S32(ctx->r1)));
    // 0x80308CD8: mflo        $t5
    ctx->r13 = lo;
    // 0x80308CDC: addiu       $s2, $t5, 0x3E8
    ctx->r18 = ADD32(ctx->r13, 0X3E8);
    // 0x80308CE0: sll         $t6, $s2, 16
    ctx->r14 = S32(ctx->r18 << 16);
    // 0x80308CE4: sra         $s2, $t6, 16
    ctx->r18 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80308CE8: b           L_80308D50
    // 0x80308CEC: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
        goto L_80308D50;
    // 0x80308CEC: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
L_80308CF0:
    // 0x80308CF0: slt         $at, $s1, $s4
    ctx->r1 = SIGNED(ctx->r17) < SIGNED(ctx->r20) ? 1 : 0;
    // 0x80308CF4: beq         $at, $zero, L_80308D4C
    if (ctx->r1 == 0) {
        // 0x80308CF8: slt         $at, $s3, $s0
        ctx->r1 = SIGNED(ctx->r19) < SIGNED(ctx->r16) ? 1 : 0;
            goto L_80308D4C;
    }
    // 0x80308CF8: slt         $at, $s3, $s0
    ctx->r1 = SIGNED(ctx->r19) < SIGNED(ctx->r16) ? 1 : 0;
    // 0x80308CFC: beq         $at, $zero, L_80308D4C
    if (ctx->r1 == 0) {
        // 0x80308D00: addiu       $t1, $t1, -0x280
        ctx->r9 = ADD32(ctx->r9, -0X280);
            goto L_80308D4C;
    }
    // 0x80308D00: addiu       $t1, $t1, -0x280
    ctx->r9 = ADD32(ctx->r9, -0X280);
    // 0x80308D04: addiu       $t2, $t2, 0x280
    ctx->r10 = ADD32(ctx->r10, 0X280);
    // 0x80308D08: sll         $a0, $t2, 16
    ctx->r4 = S32(ctx->r10 << 16);
    // 0x80308D0C: sll         $a1, $t1, 16
    ctx->r5 = S32(ctx->r9 << 16);
    // 0x80308D10: sra         $t8, $a1, 16
    ctx->r24 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80308D14: sra         $t7, $a0, 16
    ctx->r15 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80308D18: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x80308D1C: jal         0x801284B8
    // 0x80308D20: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    func_801284B8(rdram, ctx);
        goto after_40;
    // 0x80308D20: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    after_40:
    // 0x80308D24: sll         $t3, $v0, 8
    ctx->r11 = S32(ctx->r2 << 8);
    // 0x80308D28: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80308D2C: div         $zero, $t3, $at
    lo = S32(S64(S32(ctx->r11)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r11)) % S64(S32(ctx->r1)));
    // 0x80308D30: mflo        $t5
    ctx->r13 = lo;
    // 0x80308D34: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x80308D38: slti        $at, $s5, 0xB
    ctx->r1 = SIGNED(ctx->r21) < 0XB ? 1 : 0;
    // 0x80308D3C: beq         $at, $zero, L_80308D50
    if (ctx->r1 == 0) {
        // 0x80308D40: sra         $t3, $t6, 16
        ctx->r11 = S32(SIGNED(ctx->r14) >> 16);
            goto L_80308D50;
    }
    // 0x80308D40: sra         $t3, $t6, 16
    ctx->r11 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80308D44: b           L_80308D50
    // 0x80308D48: addiu       $s5, $zero, 0xA
    ctx->r21 = ADD32(0, 0XA);
        goto L_80308D50;
    // 0x80308D48: addiu       $s5, $zero, 0xA
    ctx->r21 = ADD32(0, 0XA);
L_80308D4C:
    // 0x80308D4C: addiu       $s2, $zero, 0x448
    ctx->r18 = ADD32(0, 0X448);
L_80308D50:
    // 0x80308D50: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80308D54: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x80308D58: b           L_80309428
    // 0x80308D5C: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
        goto L_80309428;
    // 0x80308D5C: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_80308D60:
    // 0x80308D60: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x80308D64: lw          $t5, 0x5530($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5530);
    // 0x80308D68: sll         $a0, $s1, 16
    ctx->r4 = S32(ctx->r17 << 16);
    // 0x80308D6C: sll         $a1, $s0, 16
    ctx->r5 = S32(ctx->r16 << 16);
    // 0x80308D70: lw          $a2, 0xC($t5)
    ctx->r6 = MEM_W(ctx->r13, 0XC);
    // 0x80308D74: sra         $t8, $a1, 16
    ctx->r24 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80308D78: sra         $t7, $a0, 16
    ctx->r15 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80308D7C: addiu       $t6, $zero, 0x2
    ctx->r14 = ADD32(0, 0X2);
    // 0x80308D80: sw          $t6, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r14;
    // 0x80308D84: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x80308D88: or          $a1, $t8, $zero
    ctx->r5 = ctx->r24 | 0;
    // 0x80308D8C: sh          $t4, 0x82($sp)
    MEM_H(0X82, ctx->r29) = ctx->r12;
    // 0x80308D90: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    // 0x80308D94: sw          $t2, 0xAC($sp)
    MEM_W(0XAC, ctx->r29) = ctx->r10;
    // 0x80308D98: sw          $t1, 0xB0($sp)
    MEM_W(0XB0, ctx->r29) = ctx->r9;
    // 0x80308D9C: jal         0x80305A70
    // 0x80308DA0: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    func_80305A70_717120(rdram, ctx);
        goto after_41;
    // 0x80308DA0: lh          $a3, 0x86($sp)
    ctx->r7 = MEM_H(ctx->r29, 0X86);
    after_41:
    // 0x80308DA4: lw          $t1, 0xB0($sp)
    ctx->r9 = MEM_W(ctx->r29, 0XB0);
    // 0x80308DA8: lw          $t2, 0xAC($sp)
    ctx->r10 = MEM_W(ctx->r29, 0XAC);
    // 0x80308DAC: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
    // 0x80308DB0: beq         $v0, $zero, L_80308F64
    if (ctx->r2 == 0) {
        // 0x80308DB4: lh          $t4, 0x82($sp)
        ctx->r12 = MEM_H(ctx->r29, 0X82);
            goto L_80308F64;
    }
    // 0x80308DB4: lh          $t4, 0x82($sp)
    ctx->r12 = MEM_H(ctx->r29, 0X82);
    // 0x80308DB8: subu        $a0, $s4, $s1
    ctx->r4 = SUB32(ctx->r20, ctx->r17);
    // 0x80308DBC: bgezl       $a0, L_80308DD0
    if (SIGNED(ctx->r4) >= 0) {
        // 0x80308DC0: or          $v1, $a0, $zero
        ctx->r3 = ctx->r4 | 0;
            goto L_80308DD0;
    }
    goto skip_36;
    // 0x80308DC0: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
    skip_36:
    // 0x80308DC4: b           L_80308DD0
    // 0x80308DC8: negu        $v1, $a0
    ctx->r3 = SUB32(0, ctx->r4);
        goto L_80308DD0;
    // 0x80308DC8: negu        $v1, $a0
    ctx->r3 = SUB32(0, ctx->r4);
    // 0x80308DCC: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
L_80308DD0:
    // 0x80308DD0: slt         $at, $v1, $t4
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x80308DD4: beq         $at, $zero, L_80308E1C
    if (ctx->r1 == 0) {
        // 0x80308DD8: subu        $v0, $s3, $s0
        ctx->r2 = SUB32(ctx->r19, ctx->r16);
            goto L_80308E1C;
    }
    // 0x80308DD8: subu        $v0, $s3, $s0
    ctx->r2 = SUB32(ctx->r19, ctx->r16);
    // 0x80308DDC: bgezl       $v0, L_80308DF0
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80308DE0: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_80308DF0;
    }
    goto skip_37;
    // 0x80308DE0: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    skip_37:
    // 0x80308DE4: b           L_80308DF0
    // 0x80308DE8: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_80308DF0;
    // 0x80308DE8: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
    // 0x80308DEC: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_80308DF0:
    // 0x80308DF0: slt         $at, $v1, $t4
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x80308DF4: beq         $at, $zero, L_80308E1C
    if (ctx->r1 == 0) {
        // 0x80308DF8: slti        $at, $t3, 0x20
        ctx->r1 = SIGNED(ctx->r11) < 0X20 ? 1 : 0;
            goto L_80308E1C;
    }
    // 0x80308DF8: slti        $at, $t3, 0x20
    ctx->r1 = SIGNED(ctx->r11) < 0X20 ? 1 : 0;
    // 0x80308DFC: bne         $at, $zero, L_80308E0C
    if (ctx->r1 != 0) {
        // 0x80308E00: slti        $at, $t3, 0xA0
        ctx->r1 = SIGNED(ctx->r11) < 0XA0 ? 1 : 0;
            goto L_80308E0C;
    }
    // 0x80308E00: slti        $at, $t3, 0xA0
    ctx->r1 = SIGNED(ctx->r11) < 0XA0 ? 1 : 0;
    // 0x80308E04: bne         $at, $zero, L_80308E14
    if (ctx->r1 != 0) {
        // 0x80308E08: nop
    
            goto L_80308E14;
    }
    // 0x80308E08: nop

L_80308E0C:
    // 0x80308E0C: b           L_80308FC4
    // 0x80308E10: addiu       $s2, $zero, 0xC0
    ctx->r18 = ADD32(0, 0XC0);
        goto L_80308FC4;
    // 0x80308E10: addiu       $s2, $zero, 0xC0
    ctx->r18 = ADD32(0, 0XC0);
L_80308E14:
    // 0x80308E14: b           L_80308FC4
    // 0x80308E18: addiu       $s2, $zero, 0x80
    ctx->r18 = ADD32(0, 0X80);
        goto L_80308FC4;
    // 0x80308E18: addiu       $s2, $zero, 0x80
    ctx->r18 = ADD32(0, 0X80);
L_80308E1C:
    // 0x80308E1C: lh          $v1, 0x84($sp)
    ctx->r3 = MEM_H(ctx->r29, 0X84);
    // 0x80308E20: lh          $v0, 0x86($sp)
    ctx->r2 = MEM_H(ctx->r29, 0X86);
    // 0x80308E24: subu        $t7, $v1, $s4
    ctx->r15 = SUB32(ctx->r3, ctx->r20);
    // 0x80308E28: addu        $t8, $t7, $s1
    ctx->r24 = ADD32(ctx->r15, ctx->r17);
    // 0x80308E2C: sra         $t9, $v0, 1
    ctx->r25 = S32(SIGNED(ctx->r2) >> 1);
    // 0x80308E30: subu        $t5, $t8, $t9
    ctx->r13 = SUB32(ctx->r24, ctx->r25);
    // 0x80308E34: addu        $t6, $t5, $s3
    ctx->r14 = ADD32(ctx->r13, ctx->r19);
    // 0x80308E38: or          $v0, $t9, $zero
    ctx->r2 = ctx->r25 | 0;
    // 0x80308E3C: subu        $t9, $t6, $s0
    ctx->r25 = SUB32(ctx->r14, ctx->r16);
    // 0x80308E40: addu        $t7, $t9, $v0
    ctx->r15 = ADD32(ctx->r25, ctx->r2);
    // 0x80308E44: slt         $at, $t7, $v1
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x80308E48: bne         $at, $zero, L_80308ED8
    if (ctx->r1 != 0) {
        // 0x80308E4C: slti        $at, $t3, 0x20
        ctx->r1 = SIGNED(ctx->r11) < 0X20 ? 1 : 0;
            goto L_80308ED8;
    }
    // 0x80308E4C: slti        $at, $t3, 0x20
    ctx->r1 = SIGNED(ctx->r11) < 0X20 ? 1 : 0;
    // 0x80308E50: bne         $at, $zero, L_80308E5C
    if (ctx->r1 != 0) {
        // 0x80308E54: slti        $at, $t3, 0xA0
        ctx->r1 = SIGNED(ctx->r11) < 0XA0 ? 1 : 0;
            goto L_80308E5C;
    }
    // 0x80308E54: slti        $at, $t3, 0xA0
    ctx->r1 = SIGNED(ctx->r11) < 0XA0 ? 1 : 0;
    // 0x80308E58: bne         $at, $zero, L_80308E94
    if (ctx->r1 != 0) {
        // 0x80308E5C: subu        $t8, $s0, $t4
        ctx->r24 = SUB32(ctx->r16, ctx->r12);
            goto L_80308E94;
    }
L_80308E5C:
    // 0x80308E5C: subu        $t8, $s0, $t4
    ctx->r24 = SUB32(ctx->r16, ctx->r12);
    // 0x80308E60: slt         $at, $s3, $t8
    ctx->r1 = SIGNED(ctx->r19) < SIGNED(ctx->r24) ? 1 : 0;
    // 0x80308E64: beql        $at, $zero, L_80308E78
    if (ctx->r1 == 0) {
        // 0x80308E68: addu        $t5, $s0, $t4
        ctx->r13 = ADD32(ctx->r16, ctx->r12);
            goto L_80308E78;
    }
    goto skip_38;
    // 0x80308E68: addu        $t5, $s0, $t4
    ctx->r13 = ADD32(ctx->r16, ctx->r12);
    skip_38:
    // 0x80308E6C: b           L_80308FC4
    // 0x80308E70: addiu       $s2, $zero, 0x4C8
    ctx->r18 = ADD32(0, 0X4C8);
        goto L_80308FC4;
    // 0x80308E70: addiu       $s2, $zero, 0x4C8
    ctx->r18 = ADD32(0, 0X4C8);
    // 0x80308E74: addu        $t5, $s0, $t4
    ctx->r13 = ADD32(ctx->r16, ctx->r12);
L_80308E78:
    // 0x80308E78: slt         $at, $t5, $s3
    ctx->r1 = SIGNED(ctx->r13) < SIGNED(ctx->r19) ? 1 : 0;
    // 0x80308E7C: beq         $at, $zero, L_80308E8C
    if (ctx->r1 == 0) {
        // 0x80308E80: nop
    
            goto L_80308E8C;
    }
    // 0x80308E80: nop

    // 0x80308E84: b           L_80308FC4
    // 0x80308E88: addiu       $s2, $zero, 0x488
    ctx->r18 = ADD32(0, 0X488);
        goto L_80308FC4;
    // 0x80308E88: addiu       $s2, $zero, 0x488
    ctx->r18 = ADD32(0, 0X488);
L_80308E8C:
    // 0x80308E8C: b           L_80308FC4
    // 0x80308E90: addiu       $s2, $zero, 0xC0
    ctx->r18 = ADD32(0, 0XC0);
        goto L_80308FC4;
    // 0x80308E90: addiu       $s2, $zero, 0xC0
    ctx->r18 = ADD32(0, 0XC0);
L_80308E94:
    // 0x80308E94: subu        $a0, $s1, $s4
    ctx->r4 = SUB32(ctx->r17, ctx->r20);
    // 0x80308E98: subu        $a1, $s0, $s3
    ctx->r5 = SUB32(ctx->r16, ctx->r19);
    // 0x80308E9C: sll         $t7, $a1, 16
    ctx->r15 = S32(ctx->r5 << 16);
    // 0x80308EA0: sll         $t6, $a0, 16
    ctx->r14 = S32(ctx->r4 << 16);
    // 0x80308EA4: sra         $a0, $t6, 16
    ctx->r4 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80308EA8: sra         $a1, $t7, 16
    ctx->r5 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80308EAC: jal         0x801284B8
    // 0x80308EB0: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    func_801284B8(rdram, ctx);
        goto after_42;
    // 0x80308EB0: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    after_42:
    // 0x80308EB4: sll         $s2, $v0, 8
    ctx->r18 = S32(ctx->r2 << 8);
    // 0x80308EB8: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80308EBC: div         $zero, $s2, $at
    lo = S32(S64(S32(ctx->r18)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r18)) % S64(S32(ctx->r1)));
    // 0x80308EC0: mflo        $t5
    ctx->r13 = lo;
    // 0x80308EC4: addiu       $s2, $t5, 0x3E8
    ctx->r18 = ADD32(ctx->r13, 0X3E8);
    // 0x80308EC8: sll         $t6, $s2, 16
    ctx->r14 = S32(ctx->r18 << 16);
    // 0x80308ECC: sra         $s2, $t6, 16
    ctx->r18 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80308ED0: b           L_80308FC4
    // 0x80308ED4: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
        goto L_80308FC4;
    // 0x80308ED4: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
L_80308ED8:
    // 0x80308ED8: slti        $at, $t3, 0x20
    ctx->r1 = SIGNED(ctx->r11) < 0X20 ? 1 : 0;
    // 0x80308EDC: bne         $at, $zero, L_80308F20
    if (ctx->r1 != 0) {
        // 0x80308EE0: slti        $at, $t3, 0xA0
        ctx->r1 = SIGNED(ctx->r11) < 0XA0 ? 1 : 0;
            goto L_80308F20;
    }
    // 0x80308EE0: slti        $at, $t3, 0xA0
    ctx->r1 = SIGNED(ctx->r11) < 0XA0 ? 1 : 0;
    // 0x80308EE4: beq         $at, $zero, L_80308F20
    if (ctx->r1 == 0) {
        // 0x80308EE8: subu        $t7, $s1, $t4
        ctx->r15 = SUB32(ctx->r17, ctx->r12);
            goto L_80308F20;
    }
    // 0x80308EE8: subu        $t7, $s1, $t4
    ctx->r15 = SUB32(ctx->r17, ctx->r12);
    // 0x80308EEC: slt         $at, $s4, $t7
    ctx->r1 = SIGNED(ctx->r20) < SIGNED(ctx->r15) ? 1 : 0;
    // 0x80308EF0: beql        $at, $zero, L_80308F04
    if (ctx->r1 == 0) {
        // 0x80308EF4: addu        $t8, $s1, $t4
        ctx->r24 = ADD32(ctx->r17, ctx->r12);
            goto L_80308F04;
    }
    goto skip_39;
    // 0x80308EF4: addu        $t8, $s1, $t4
    ctx->r24 = ADD32(ctx->r17, ctx->r12);
    skip_39:
    // 0x80308EF8: b           L_80308FC4
    // 0x80308EFC: addiu       $s2, $zero, 0x448
    ctx->r18 = ADD32(0, 0X448);
        goto L_80308FC4;
    // 0x80308EFC: addiu       $s2, $zero, 0x448
    ctx->r18 = ADD32(0, 0X448);
    // 0x80308F00: addu        $t8, $s1, $t4
    ctx->r24 = ADD32(ctx->r17, ctx->r12);
L_80308F04:
    // 0x80308F04: slt         $at, $t8, $s4
    ctx->r1 = SIGNED(ctx->r24) < SIGNED(ctx->r20) ? 1 : 0;
    // 0x80308F08: beq         $at, $zero, L_80308F18
    if (ctx->r1 == 0) {
        // 0x80308F0C: nop
    
            goto L_80308F18;
    }
    // 0x80308F0C: nop

    // 0x80308F10: b           L_80308FC4
    // 0x80308F14: addiu       $s2, $zero, 0x488
    ctx->r18 = ADD32(0, 0X488);
        goto L_80308FC4;
    // 0x80308F14: addiu       $s2, $zero, 0x488
    ctx->r18 = ADD32(0, 0X488);
L_80308F18:
    // 0x80308F18: b           L_80308FC4
    // 0x80308F1C: addiu       $s2, $zero, 0x80
    ctx->r18 = ADD32(0, 0X80);
        goto L_80308FC4;
    // 0x80308F1C: addiu       $s2, $zero, 0x80
    ctx->r18 = ADD32(0, 0X80);
L_80308F20:
    // 0x80308F20: subu        $a0, $s1, $s4
    ctx->r4 = SUB32(ctx->r17, ctx->r20);
    // 0x80308F24: subu        $a1, $s0, $s3
    ctx->r5 = SUB32(ctx->r16, ctx->r19);
    // 0x80308F28: sll         $t9, $a1, 16
    ctx->r25 = S32(ctx->r5 << 16);
    // 0x80308F2C: sll         $t5, $a0, 16
    ctx->r13 = S32(ctx->r4 << 16);
    // 0x80308F30: sra         $a0, $t5, 16
    ctx->r4 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80308F34: sra         $a1, $t9, 16
    ctx->r5 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80308F38: jal         0x801284B8
    // 0x80308F3C: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    func_801284B8(rdram, ctx);
        goto after_43;
    // 0x80308F3C: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    after_43:
    // 0x80308F40: sll         $s2, $v0, 8
    ctx->r18 = S32(ctx->r2 << 8);
    // 0x80308F44: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80308F48: div         $zero, $s2, $at
    lo = S32(S64(S32(ctx->r18)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r18)) % S64(S32(ctx->r1)));
    // 0x80308F4C: mflo        $t8
    ctx->r24 = lo;
    // 0x80308F50: addiu       $s2, $t8, 0x3E8
    ctx->r18 = ADD32(ctx->r24, 0X3E8);
    // 0x80308F54: sll         $t5, $s2, 16
    ctx->r13 = S32(ctx->r18 << 16);
    // 0x80308F58: sra         $s2, $t5, 16
    ctx->r18 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80308F5C: b           L_80308FC4
    // 0x80308F60: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
        goto L_80308FC4;
    // 0x80308F60: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
L_80308F64:
    // 0x80308F64: slt         $at, $s4, $s1
    ctx->r1 = SIGNED(ctx->r20) < SIGNED(ctx->r17) ? 1 : 0;
    // 0x80308F68: beq         $at, $zero, L_80308FC0
    if (ctx->r1 == 0) {
        // 0x80308F6C: slt         $at, $s3, $s0
        ctx->r1 = SIGNED(ctx->r19) < SIGNED(ctx->r16) ? 1 : 0;
            goto L_80308FC0;
    }
    // 0x80308F6C: slt         $at, $s3, $s0
    ctx->r1 = SIGNED(ctx->r19) < SIGNED(ctx->r16) ? 1 : 0;
    // 0x80308F70: beq         $at, $zero, L_80308FC0
    if (ctx->r1 == 0) {
        // 0x80308F74: addiu       $t1, $t1, -0x280
        ctx->r9 = ADD32(ctx->r9, -0X280);
            goto L_80308FC0;
    }
    // 0x80308F74: addiu       $t1, $t1, -0x280
    ctx->r9 = ADD32(ctx->r9, -0X280);
    // 0x80308F78: addiu       $t2, $t2, -0x280
    ctx->r10 = ADD32(ctx->r10, -0X280);
    // 0x80308F7C: sll         $a0, $t2, 16
    ctx->r4 = S32(ctx->r10 << 16);
    // 0x80308F80: sll         $a1, $t1, 16
    ctx->r5 = S32(ctx->r9 << 16);
    // 0x80308F84: sra         $t7, $a1, 16
    ctx->r15 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80308F88: sra         $t9, $a0, 16
    ctx->r25 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80308F8C: or          $a0, $t9, $zero
    ctx->r4 = ctx->r25 | 0;
    // 0x80308F90: jal         0x801284B8
    // 0x80308F94: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    func_801284B8(rdram, ctx);
        goto after_44;
    // 0x80308F94: or          $a1, $t7, $zero
    ctx->r5 = ctx->r15 | 0;
    after_44:
    // 0x80308F98: sll         $t3, $v0, 8
    ctx->r11 = S32(ctx->r2 << 8);
    // 0x80308F9C: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80308FA0: div         $zero, $t3, $at
    lo = S32(S64(S32(ctx->r11)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r11)) % S64(S32(ctx->r1)));
    // 0x80308FA4: mflo        $t8
    ctx->r24 = lo;
    // 0x80308FA8: sll         $t5, $t8, 16
    ctx->r13 = S32(ctx->r24 << 16);
    // 0x80308FAC: slti        $at, $s5, 0xB
    ctx->r1 = SIGNED(ctx->r21) < 0XB ? 1 : 0;
    // 0x80308FB0: beq         $at, $zero, L_80308FC4
    if (ctx->r1 == 0) {
        // 0x80308FB4: sra         $t3, $t5, 16
        ctx->r11 = S32(SIGNED(ctx->r13) >> 16);
            goto L_80308FC4;
    }
    // 0x80308FB4: sra         $t3, $t5, 16
    ctx->r11 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80308FB8: b           L_80308FC4
    // 0x80308FBC: addiu       $s5, $zero, 0xA
    ctx->r21 = ADD32(0, 0XA);
        goto L_80308FC4;
    // 0x80308FBC: addiu       $s5, $zero, 0xA
    ctx->r21 = ADD32(0, 0XA);
L_80308FC0:
    // 0x80308FC0: addiu       $s2, $zero, 0x488
    ctx->r18 = ADD32(0, 0X488);
L_80308FC4:
    // 0x80308FC4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80308FC8: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x80308FCC: b           L_80309428
    // 0x80308FD0: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
        goto L_80309428;
    // 0x80308FD0: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_80308FD4:
    // 0x80308FD4: slti        $at, $t3, 0x40
    ctx->r1 = SIGNED(ctx->r11) < 0X40 ? 1 : 0;
    // 0x80308FD8: bne         $at, $zero, L_80308FE4
    if (ctx->r1 != 0) {
        // 0x80308FDC: slti        $at, $t3, 0xC0
        ctx->r1 = SIGNED(ctx->r11) < 0XC0 ? 1 : 0;
            goto L_80308FE4;
    }
    // 0x80308FDC: slti        $at, $t3, 0xC0
    ctx->r1 = SIGNED(ctx->r11) < 0XC0 ? 1 : 0;
    // 0x80308FE0: bne         $at, $zero, L_80309088
    if (ctx->r1 != 0) {
        // 0x80308FE4: subu        $a0, $s4, $s1
        ctx->r4 = SUB32(ctx->r20, ctx->r17);
            goto L_80309088;
    }
L_80308FE4:
    // 0x80308FE4: subu        $a0, $s4, $s1
    ctx->r4 = SUB32(ctx->r20, ctx->r17);
    // 0x80308FE8: bgezl       $a0, L_80308FFC
    if (SIGNED(ctx->r4) >= 0) {
        // 0x80308FEC: or          $v1, $a0, $zero
        ctx->r3 = ctx->r4 | 0;
            goto L_80308FFC;
    }
    goto skip_40;
    // 0x80308FEC: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
    skip_40:
    // 0x80308FF0: b           L_80308FFC
    // 0x80308FF4: negu        $v1, $a0
    ctx->r3 = SUB32(0, ctx->r4);
        goto L_80308FFC;
    // 0x80308FF4: negu        $v1, $a0
    ctx->r3 = SUB32(0, ctx->r4);
    // 0x80308FF8: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
L_80308FFC:
    // 0x80308FFC: slt         $at, $v1, $t4
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x80309000: beq         $at, $zero, L_80309038
    if (ctx->r1 == 0) {
        // 0x80309004: subu        $v0, $s3, $s0
        ctx->r2 = SUB32(ctx->r19, ctx->r16);
            goto L_80309038;
    }
    // 0x80309004: subu        $v0, $s3, $s0
    ctx->r2 = SUB32(ctx->r19, ctx->r16);
    // 0x80309008: bgezl       $v0, L_8030901C
    if (SIGNED(ctx->r2) >= 0) {
        // 0x8030900C: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_8030901C;
    }
    goto skip_41;
    // 0x8030900C: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    skip_41:
    // 0x80309010: b           L_8030901C
    // 0x80309014: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_8030901C;
    // 0x80309014: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
    // 0x80309018: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_8030901C:
    // 0x8030901C: slt         $at, $v1, $t4
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x80309020: beq         $at, $zero, L_80309038
    if (ctx->r1 == 0) {
        // 0x80309024: lui         $t0, 0x803D
        ctx->r8 = S32(0X803D << 16);
            goto L_80309038;
    }
    // 0x80309024: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80309028: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x8030902C: addiu       $s5, $zero, -0x1
    ctx->r21 = ADD32(0, -0X1);
    // 0x80309030: b           L_80309428
    // 0x80309034: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
        goto L_80309428;
    // 0x80309034: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_80309038:
    // 0x80309038: subu        $a0, $s1, $s4
    ctx->r4 = SUB32(ctx->r17, ctx->r20);
    // 0x8030903C: subu        $a1, $s0, $s3
    ctx->r5 = SUB32(ctx->r16, ctx->r19);
    // 0x80309040: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x80309044: sll         $t9, $a0, 16
    ctx->r25 = S32(ctx->r4 << 16);
    // 0x80309048: sra         $a0, $t9, 16
    ctx->r4 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8030904C: sra         $a1, $t8, 16
    ctx->r5 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80309050: jal         0x801284B8
    // 0x80309054: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    func_801284B8(rdram, ctx);
        goto after_45;
    // 0x80309054: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    after_45:
    // 0x80309058: sll         $s2, $v0, 8
    ctx->r18 = S32(ctx->r2 << 8);
    // 0x8030905C: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80309060: div         $zero, $s2, $at
    lo = S32(S64(S32(ctx->r18)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r18)) % S64(S32(ctx->r1)));
    // 0x80309064: mflo        $t6
    ctx->r14 = lo;
    // 0x80309068: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030906C: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x80309070: addiu       $s2, $t6, 0x3E8
    ctx->r18 = ADD32(ctx->r14, 0X3E8);
    // 0x80309074: sll         $t9, $s2, 16
    ctx->r25 = S32(ctx->r18 << 16);
    // 0x80309078: sra         $s2, $t9, 16
    ctx->r18 = S32(SIGNED(ctx->r25) >> 16);
    // 0x8030907C: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
    // 0x80309080: b           L_80309428
    // 0x80309084: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
        goto L_80309428;
    // 0x80309084: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_80309088:
    // 0x80309088: lh          $t6, 0x86($sp)
    ctx->r14 = MEM_H(ctx->r29, 0X86);
    // 0x8030908C: subu        $a0, $s1, $s4
    ctx->r4 = SUB32(ctx->r17, ctx->r20);
    // 0x80309090: sll         $t8, $a0, 16
    ctx->r24 = S32(ctx->r4 << 16);
    // 0x80309094: sra         $t9, $t6, 1
    ctx->r25 = S32(SIGNED(ctx->r14) >> 1);
    // 0x80309098: subu        $t7, $s0, $t9
    ctx->r15 = SUB32(ctx->r16, ctx->r25);
    // 0x8030909C: subu        $a1, $t7, $s3
    ctx->r5 = SUB32(ctx->r15, ctx->r19);
    // 0x803090A0: sra         $a0, $t8, 16
    ctx->r4 = S32(SIGNED(ctx->r24) >> 16);
    // 0x803090A4: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x803090A8: sra         $a1, $t8, 16
    ctx->r5 = S32(SIGNED(ctx->r24) >> 16);
    // 0x803090AC: jal         0x801284B8
    // 0x803090B0: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    func_801284B8(rdram, ctx);
        goto after_46;
    // 0x803090B0: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    after_46:
    // 0x803090B4: sll         $s2, $v0, 8
    ctx->r18 = S32(ctx->r2 << 8);
    // 0x803090B8: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x803090BC: div         $zero, $s2, $at
    lo = S32(S64(S32(ctx->r18)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r18)) % S64(S32(ctx->r1)));
    // 0x803090C0: mflo        $t6
    ctx->r14 = lo;
    // 0x803090C4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803090C8: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x803090CC: addiu       $s2, $t6, 0x3E8
    ctx->r18 = ADD32(ctx->r14, 0X3E8);
    // 0x803090D0: sll         $t9, $s2, 16
    ctx->r25 = S32(ctx->r18 << 16);
    // 0x803090D4: sra         $s2, $t9, 16
    ctx->r18 = S32(SIGNED(ctx->r25) >> 16);
    // 0x803090D8: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
    // 0x803090DC: b           L_80309428
    // 0x803090E0: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
        goto L_80309428;
    // 0x803090E0: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_803090E4:
    // 0x803090E4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803090E8: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x803090EC: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_803090F0:
    // 0x803090F0: slti        $at, $t3, 0x80
    ctx->r1 = SIGNED(ctx->r11) < 0X80 ? 1 : 0;
    // 0x803090F4: beq         $at, $zero, L_80309130
    if (ctx->r1 == 0) {
        // 0x803090F8: subu        $t8, $s0, $t4
        ctx->r24 = SUB32(ctx->r16, ctx->r12);
            goto L_80309130;
    }
    // 0x803090F8: subu        $t8, $s0, $t4
    ctx->r24 = SUB32(ctx->r16, ctx->r12);
    // 0x803090FC: slt         $at, $s3, $t8
    ctx->r1 = SIGNED(ctx->r19) < SIGNED(ctx->r24) ? 1 : 0;
    // 0x80309100: beql        $at, $zero, L_80309114
    if (ctx->r1 == 0) {
        // 0x80309104: addu        $t5, $s0, $t4
        ctx->r13 = ADD32(ctx->r16, ctx->r12);
            goto L_80309114;
    }
    goto skip_42;
    // 0x80309104: addu        $t5, $s0, $t4
    ctx->r13 = ADD32(ctx->r16, ctx->r12);
    skip_42:
    // 0x80309108: b           L_80309428
    // 0x8030910C: addiu       $s2, $zero, 0x408
    ctx->r18 = ADD32(0, 0X408);
        goto L_80309428;
    // 0x8030910C: addiu       $s2, $zero, 0x408
    ctx->r18 = ADD32(0, 0X408);
    // 0x80309110: addu        $t5, $s0, $t4
    ctx->r13 = ADD32(ctx->r16, ctx->r12);
L_80309114:
    // 0x80309114: slt         $at, $t5, $s3
    ctx->r1 = SIGNED(ctx->r13) < SIGNED(ctx->r19) ? 1 : 0;
    // 0x80309118: beq         $at, $zero, L_80309128
    if (ctx->r1 == 0) {
        // 0x8030911C: nop
    
            goto L_80309128;
    }
    // 0x8030911C: nop

    // 0x80309120: b           L_80309428
    // 0x80309124: addiu       $s2, $zero, 0x448
    ctx->r18 = ADD32(0, 0X448);
        goto L_80309428;
    // 0x80309124: addiu       $s2, $zero, 0x448
    ctx->r18 = ADD32(0, 0X448);
L_80309128:
    // 0x80309128: b           L_80309428
    // 0x8030912C: addiu       $s2, $zero, 0x40
    ctx->r18 = ADD32(0, 0X40);
        goto L_80309428;
    // 0x8030912C: addiu       $s2, $zero, 0x40
    ctx->r18 = ADD32(0, 0X40);
L_80309130:
    // 0x80309130: subu        $t6, $s0, $t4
    ctx->r14 = SUB32(ctx->r16, ctx->r12);
    // 0x80309134: slt         $at, $s3, $t6
    ctx->r1 = SIGNED(ctx->r19) < SIGNED(ctx->r14) ? 1 : 0;
    // 0x80309138: beql        $at, $zero, L_8030914C
    if (ctx->r1 == 0) {
        // 0x8030913C: addu        $t9, $s0, $t4
        ctx->r25 = ADD32(ctx->r16, ctx->r12);
            goto L_8030914C;
    }
    goto skip_43;
    // 0x8030913C: addu        $t9, $s0, $t4
    ctx->r25 = ADD32(ctx->r16, ctx->r12);
    skip_43:
    // 0x80309140: b           L_80309428
    // 0x80309144: addiu       $s2, $zero, 0x4C8
    ctx->r18 = ADD32(0, 0X4C8);
        goto L_80309428;
    // 0x80309144: addiu       $s2, $zero, 0x4C8
    ctx->r18 = ADD32(0, 0X4C8);
    // 0x80309148: addu        $t9, $s0, $t4
    ctx->r25 = ADD32(ctx->r16, ctx->r12);
L_8030914C:
    // 0x8030914C: slt         $at, $t9, $s3
    ctx->r1 = SIGNED(ctx->r25) < SIGNED(ctx->r19) ? 1 : 0;
    // 0x80309150: beq         $at, $zero, L_80309160
    if (ctx->r1 == 0) {
        // 0x80309154: nop
    
            goto L_80309160;
    }
    // 0x80309154: nop

    // 0x80309158: b           L_80309428
    // 0x8030915C: addiu       $s2, $zero, 0x488
    ctx->r18 = ADD32(0, 0X488);
        goto L_80309428;
    // 0x8030915C: addiu       $s2, $zero, 0x488
    ctx->r18 = ADD32(0, 0X488);
L_80309160:
    // 0x80309160: b           L_80309428
    // 0x80309164: addiu       $s2, $zero, 0xC0
    ctx->r18 = ADD32(0, 0XC0);
        goto L_80309428;
    // 0x80309164: addiu       $s2, $zero, 0xC0
    ctx->r18 = ADD32(0, 0XC0);
L_80309168:
    // 0x80309168: slti        $at, $t3, 0x80
    ctx->r1 = SIGNED(ctx->r11) < 0X80 ? 1 : 0;
    // 0x8030916C: bne         $at, $zero, L_80309214
    if (ctx->r1 != 0) {
        // 0x80309170: subu        $a0, $s4, $s1
        ctx->r4 = SUB32(ctx->r20, ctx->r17);
            goto L_80309214;
    }
    // 0x80309170: subu        $a0, $s4, $s1
    ctx->r4 = SUB32(ctx->r20, ctx->r17);
    // 0x80309174: bgezl       $a0, L_80309188
    if (SIGNED(ctx->r4) >= 0) {
        // 0x80309178: or          $v1, $a0, $zero
        ctx->r3 = ctx->r4 | 0;
            goto L_80309188;
    }
    goto skip_44;
    // 0x80309178: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
    skip_44:
    // 0x8030917C: b           L_80309188
    // 0x80309180: negu        $v1, $a0
    ctx->r3 = SUB32(0, ctx->r4);
        goto L_80309188;
    // 0x80309180: negu        $v1, $a0
    ctx->r3 = SUB32(0, ctx->r4);
    // 0x80309184: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
L_80309188:
    // 0x80309188: slt         $at, $v1, $t4
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x8030918C: beq         $at, $zero, L_803091C4
    if (ctx->r1 == 0) {
        // 0x80309190: subu        $v0, $s3, $s0
        ctx->r2 = SUB32(ctx->r19, ctx->r16);
            goto L_803091C4;
    }
    // 0x80309190: subu        $v0, $s3, $s0
    ctx->r2 = SUB32(ctx->r19, ctx->r16);
    // 0x80309194: bgezl       $v0, L_803091A8
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80309198: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_803091A8;
    }
    goto skip_45;
    // 0x80309198: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    skip_45:
    // 0x8030919C: b           L_803091A8
    // 0x803091A0: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_803091A8;
    // 0x803091A0: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
    // 0x803091A4: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_803091A8:
    // 0x803091A8: slt         $at, $v1, $t4
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x803091AC: beq         $at, $zero, L_803091C4
    if (ctx->r1 == 0) {
        // 0x803091B0: lui         $t0, 0x803D
        ctx->r8 = S32(0X803D << 16);
            goto L_803091C4;
    }
    // 0x803091B0: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803091B4: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x803091B8: addiu       $s5, $zero, -0x1
    ctx->r21 = ADD32(0, -0X1);
    // 0x803091BC: b           L_80309428
    // 0x803091C0: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
        goto L_80309428;
    // 0x803091C0: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_803091C4:
    // 0x803091C4: subu        $a0, $s1, $s4
    ctx->r4 = SUB32(ctx->r17, ctx->r20);
    // 0x803091C8: subu        $a1, $s0, $s3
    ctx->r5 = SUB32(ctx->r16, ctx->r19);
    // 0x803091CC: sll         $t5, $a1, 16
    ctx->r13 = S32(ctx->r5 << 16);
    // 0x803091D0: sll         $t7, $a0, 16
    ctx->r15 = S32(ctx->r4 << 16);
    // 0x803091D4: sra         $a0, $t7, 16
    ctx->r4 = S32(SIGNED(ctx->r15) >> 16);
    // 0x803091D8: sra         $a1, $t5, 16
    ctx->r5 = S32(SIGNED(ctx->r13) >> 16);
    // 0x803091DC: jal         0x801284B8
    // 0x803091E0: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    func_801284B8(rdram, ctx);
        goto after_47;
    // 0x803091E0: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    after_47:
    // 0x803091E4: sll         $s2, $v0, 8
    ctx->r18 = S32(ctx->r2 << 8);
    // 0x803091E8: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x803091EC: div         $zero, $s2, $at
    lo = S32(S64(S32(ctx->r18)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r18)) % S64(S32(ctx->r1)));
    // 0x803091F0: mflo        $t9
    ctx->r25 = lo;
    // 0x803091F4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803091F8: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x803091FC: addiu       $s2, $t9, 0x3E8
    ctx->r18 = ADD32(ctx->r25, 0X3E8);
    // 0x80309200: sll         $t7, $s2, 16
    ctx->r15 = S32(ctx->r18 << 16);
    // 0x80309204: sra         $s2, $t7, 16
    ctx->r18 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80309208: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
    // 0x8030920C: b           L_80309428
    // 0x80309210: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
        goto L_80309428;
    // 0x80309210: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_80309214:
    // 0x80309214: lh          $t5, 0x86($sp)
    ctx->r13 = MEM_H(ctx->r29, 0X86);
    // 0x80309218: subu        $a1, $s0, $s3
    ctx->r5 = SUB32(ctx->r16, ctx->r19);
    // 0x8030921C: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    // 0x80309220: sra         $t6, $t5, 1
    ctx->r14 = S32(SIGNED(ctx->r13) >> 1);
    // 0x80309224: addu        $t9, $s1, $t6
    ctx->r25 = ADD32(ctx->r17, ctx->r14);
    // 0x80309228: subu        $a0, $t9, $s4
    ctx->r4 = SUB32(ctx->r25, ctx->r20);
    // 0x8030922C: sll         $t7, $a0, 16
    ctx->r15 = S32(ctx->r4 << 16);
    // 0x80309230: sll         $t5, $a1, 16
    ctx->r13 = S32(ctx->r5 << 16);
    // 0x80309234: sra         $a1, $t5, 16
    ctx->r5 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80309238: jal         0x801284B8
    // 0x8030923C: sra         $a0, $t7, 16
    ctx->r4 = S32(SIGNED(ctx->r15) >> 16);
    func_801284B8(rdram, ctx);
        goto after_48;
    // 0x8030923C: sra         $a0, $t7, 16
    ctx->r4 = S32(SIGNED(ctx->r15) >> 16);
    after_48:
    // 0x80309240: sll         $s2, $v0, 8
    ctx->r18 = S32(ctx->r2 << 8);
    // 0x80309244: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80309248: div         $zero, $s2, $at
    lo = S32(S64(S32(ctx->r18)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r18)) % S64(S32(ctx->r1)));
    // 0x8030924C: mflo        $t9
    ctx->r25 = lo;
    // 0x80309250: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80309254: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x80309258: addiu       $s2, $t9, 0x3E8
    ctx->r18 = ADD32(ctx->r25, 0X3E8);
    // 0x8030925C: sll         $t7, $s2, 16
    ctx->r15 = S32(ctx->r18 << 16);
    // 0x80309260: sra         $s2, $t7, 16
    ctx->r18 = S32(SIGNED(ctx->r15) >> 16);
    // 0x80309264: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
    // 0x80309268: b           L_80309428
    // 0x8030926C: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
        goto L_80309428;
    // 0x8030926C: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_80309270:
    // 0x80309270: slti        $at, $t3, 0x80
    ctx->r1 = SIGNED(ctx->r11) < 0X80 ? 1 : 0;
    // 0x80309274: beq         $at, $zero, L_8030931C
    if (ctx->r1 == 0) {
        // 0x80309278: subu        $a0, $s4, $s1
        ctx->r4 = SUB32(ctx->r20, ctx->r17);
            goto L_8030931C;
    }
    // 0x80309278: subu        $a0, $s4, $s1
    ctx->r4 = SUB32(ctx->r20, ctx->r17);
    // 0x8030927C: bgezl       $a0, L_80309290
    if (SIGNED(ctx->r4) >= 0) {
        // 0x80309280: or          $v1, $a0, $zero
        ctx->r3 = ctx->r4 | 0;
            goto L_80309290;
    }
    goto skip_46;
    // 0x80309280: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
    skip_46:
    // 0x80309284: b           L_80309290
    // 0x80309288: negu        $v1, $a0
    ctx->r3 = SUB32(0, ctx->r4);
        goto L_80309290;
    // 0x80309288: negu        $v1, $a0
    ctx->r3 = SUB32(0, ctx->r4);
    // 0x8030928C: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
L_80309290:
    // 0x80309290: slt         $at, $v1, $t4
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x80309294: beq         $at, $zero, L_803092CC
    if (ctx->r1 == 0) {
        // 0x80309298: subu        $v0, $s3, $s0
        ctx->r2 = SUB32(ctx->r19, ctx->r16);
            goto L_803092CC;
    }
    // 0x80309298: subu        $v0, $s3, $s0
    ctx->r2 = SUB32(ctx->r19, ctx->r16);
    // 0x8030929C: bgezl       $v0, L_803092B0
    if (SIGNED(ctx->r2) >= 0) {
        // 0x803092A0: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_803092B0;
    }
    goto skip_47;
    // 0x803092A0: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    skip_47:
    // 0x803092A4: b           L_803092B0
    // 0x803092A8: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_803092B0;
    // 0x803092A8: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
    // 0x803092AC: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_803092B0:
    // 0x803092B0: slt         $at, $v1, $t4
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x803092B4: beq         $at, $zero, L_803092CC
    if (ctx->r1 == 0) {
        // 0x803092B8: lui         $t0, 0x803D
        ctx->r8 = S32(0X803D << 16);
            goto L_803092CC;
    }
    // 0x803092B8: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803092BC: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x803092C0: addiu       $s5, $zero, -0x1
    ctx->r21 = ADD32(0, -0X1);
    // 0x803092C4: b           L_80309428
    // 0x803092C8: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
        goto L_80309428;
    // 0x803092C8: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_803092CC:
    // 0x803092CC: subu        $a0, $s1, $s4
    ctx->r4 = SUB32(ctx->r17, ctx->r20);
    // 0x803092D0: subu        $a1, $s0, $s3
    ctx->r5 = SUB32(ctx->r16, ctx->r19);
    // 0x803092D4: sll         $t9, $a1, 16
    ctx->r25 = S32(ctx->r5 << 16);
    // 0x803092D8: sll         $t5, $a0, 16
    ctx->r13 = S32(ctx->r4 << 16);
    // 0x803092DC: sra         $a0, $t5, 16
    ctx->r4 = S32(SIGNED(ctx->r13) >> 16);
    // 0x803092E0: sra         $a1, $t9, 16
    ctx->r5 = S32(SIGNED(ctx->r25) >> 16);
    // 0x803092E4: jal         0x801284B8
    // 0x803092E8: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    func_801284B8(rdram, ctx);
        goto after_49;
    // 0x803092E8: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    after_49:
    // 0x803092EC: sll         $s2, $v0, 8
    ctx->r18 = S32(ctx->r2 << 8);
    // 0x803092F0: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x803092F4: div         $zero, $s2, $at
    lo = S32(S64(S32(ctx->r18)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r18)) % S64(S32(ctx->r1)));
    // 0x803092F8: mflo        $t8
    ctx->r24 = lo;
    // 0x803092FC: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80309300: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x80309304: addiu       $s2, $t8, 0x3E8
    ctx->r18 = ADD32(ctx->r24, 0X3E8);
    // 0x80309308: sll         $t5, $s2, 16
    ctx->r13 = S32(ctx->r18 << 16);
    // 0x8030930C: sra         $s2, $t5, 16
    ctx->r18 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80309310: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
    // 0x80309314: b           L_80309428
    // 0x80309318: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
        goto L_80309428;
    // 0x80309318: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_8030931C:
    // 0x8030931C: lh          $t9, 0x86($sp)
    ctx->r25 = MEM_H(ctx->r29, 0X86);
    // 0x80309320: subu        $a1, $s0, $s3
    ctx->r5 = SUB32(ctx->r16, ctx->r19);
    // 0x80309324: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    // 0x80309328: sra         $t7, $t9, 1
    ctx->r15 = S32(SIGNED(ctx->r25) >> 1);
    // 0x8030932C: subu        $t8, $s1, $t7
    ctx->r24 = SUB32(ctx->r17, ctx->r15);
    // 0x80309330: subu        $a0, $t8, $s4
    ctx->r4 = SUB32(ctx->r24, ctx->r20);
    // 0x80309334: sll         $t5, $a0, 16
    ctx->r13 = S32(ctx->r4 << 16);
    // 0x80309338: sll         $t9, $a1, 16
    ctx->r25 = S32(ctx->r5 << 16);
    // 0x8030933C: sra         $a1, $t9, 16
    ctx->r5 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80309340: jal         0x801284B8
    // 0x80309344: sra         $a0, $t5, 16
    ctx->r4 = S32(SIGNED(ctx->r13) >> 16);
    func_801284B8(rdram, ctx);
        goto after_50;
    // 0x80309344: sra         $a0, $t5, 16
    ctx->r4 = S32(SIGNED(ctx->r13) >> 16);
    after_50:
    // 0x80309348: sll         $s2, $v0, 8
    ctx->r18 = S32(ctx->r2 << 8);
    // 0x8030934C: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x80309350: div         $zero, $s2, $at
    lo = S32(S64(S32(ctx->r18)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r18)) % S64(S32(ctx->r1)));
    // 0x80309354: mflo        $t8
    ctx->r24 = lo;
    // 0x80309358: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030935C: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x80309360: addiu       $s2, $t8, 0x3E8
    ctx->r18 = ADD32(ctx->r24, 0X3E8);
    // 0x80309364: sll         $t5, $s2, 16
    ctx->r13 = S32(ctx->r18 << 16);
    // 0x80309368: sra         $s2, $t5, 16
    ctx->r18 = S32(SIGNED(ctx->r13) >> 16);
    // 0x8030936C: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
    // 0x80309370: b           L_80309428
    // 0x80309374: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
        goto L_80309428;
    // 0x80309374: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_80309378:
    // 0x80309378: subu        $a0, $s4, $s1
    ctx->r4 = SUB32(ctx->r20, ctx->r17);
    // 0x8030937C: bgezl       $a0, L_80309390
    if (SIGNED(ctx->r4) >= 0) {
        // 0x80309380: or          $v1, $a0, $zero
        ctx->r3 = ctx->r4 | 0;
            goto L_80309390;
    }
    goto skip_48;
    // 0x80309380: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
    skip_48:
    // 0x80309384: b           L_80309390
    // 0x80309388: negu        $v1, $a0
    ctx->r3 = SUB32(0, ctx->r4);
        goto L_80309390;
    // 0x80309388: negu        $v1, $a0
    ctx->r3 = SUB32(0, ctx->r4);
    // 0x8030938C: or          $v1, $a0, $zero
    ctx->r3 = ctx->r4 | 0;
L_80309390:
    // 0x80309390: slt         $at, $v1, $t4
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x80309394: beq         $at, $zero, L_803093CC
    if (ctx->r1 == 0) {
        // 0x80309398: subu        $v0, $s3, $s0
        ctx->r2 = SUB32(ctx->r19, ctx->r16);
            goto L_803093CC;
    }
    // 0x80309398: subu        $v0, $s3, $s0
    ctx->r2 = SUB32(ctx->r19, ctx->r16);
    // 0x8030939C: bgezl       $v0, L_803093B0
    if (SIGNED(ctx->r2) >= 0) {
        // 0x803093A0: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_803093B0;
    }
    goto skip_49;
    // 0x803093A0: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    skip_49:
    // 0x803093A4: b           L_803093B0
    // 0x803093A8: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_803093B0;
    // 0x803093A8: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
    // 0x803093AC: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
L_803093B0:
    // 0x803093B0: slt         $at, $v1, $t4
    ctx->r1 = SIGNED(ctx->r3) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x803093B4: beq         $at, $zero, L_803093CC
    if (ctx->r1 == 0) {
        // 0x803093B8: lui         $t0, 0x803D
        ctx->r8 = S32(0X803D << 16);
            goto L_803093CC;
    }
    // 0x803093B8: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x803093BC: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x803093C0: addiu       $s5, $zero, -0x1
    ctx->r21 = ADD32(0, -0X1);
    // 0x803093C4: b           L_80309428
    // 0x803093C8: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
        goto L_80309428;
    // 0x803093C8: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_803093CC:
    // 0x803093CC: subu        $a0, $s1, $s4
    ctx->r4 = SUB32(ctx->r17, ctx->r20);
    // 0x803093D0: subu        $a1, $s0, $s3
    ctx->r5 = SUB32(ctx->r16, ctx->r19);
    // 0x803093D4: sll         $t8, $a1, 16
    ctx->r24 = S32(ctx->r5 << 16);
    // 0x803093D8: sll         $t9, $a0, 16
    ctx->r25 = S32(ctx->r4 << 16);
    // 0x803093DC: sra         $a0, $t9, 16
    ctx->r4 = S32(SIGNED(ctx->r25) >> 16);
    // 0x803093E0: sra         $a1, $t8, 16
    ctx->r5 = S32(SIGNED(ctx->r24) >> 16);
    // 0x803093E4: jal         0x801284B8
    // 0x803093E8: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    func_801284B8(rdram, ctx);
        goto after_51;
    // 0x803093E8: sh          $t3, 0x8E($sp)
    MEM_H(0X8E, ctx->r29) = ctx->r11;
    after_51:
    // 0x803093EC: sll         $s2, $v0, 8
    ctx->r18 = S32(ctx->r2 << 8);
    // 0x803093F0: addiu       $at, $zero, 0x168
    ctx->r1 = ADD32(0, 0X168);
    // 0x803093F4: div         $zero, $s2, $at
    lo = S32(S64(S32(ctx->r18)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r18)) % S64(S32(ctx->r1)));
    // 0x803093F8: mflo        $t6
    ctx->r14 = lo;
    // 0x803093FC: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80309400: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x80309404: addiu       $s2, $t6, 0x3E8
    ctx->r18 = ADD32(ctx->r14, 0X3E8);
    // 0x80309408: sll         $t9, $s2, 16
    ctx->r25 = S32(ctx->r18 << 16);
    // 0x8030940C: sra         $s2, $t9, 16
    ctx->r18 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80309410: lh          $t3, 0x8E($sp)
    ctx->r11 = MEM_H(ctx->r29, 0X8E);
    // 0x80309414: b           L_80309428
    // 0x80309418: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
        goto L_80309428;
    // 0x80309418: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_8030941C:
    // 0x8030941C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80309420: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x80309424: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_80309428:
    // 0x80309428: bltz        $s2, L_8030949C
    if (SIGNED(ctx->r18) < 0) {
        // 0x8030942C: nop
    
            goto L_8030949C;
    }
    // 0x8030942C: nop

    // 0x80309430: blez        $s5, L_8030949C
    if (SIGNED(ctx->r21) <= 0) {
        // 0x80309434: slti        $at, $s2, 0x3E8
        ctx->r1 = SIGNED(ctx->r18) < 0X3E8 ? 1 : 0;
            goto L_8030949C;
    }
    // 0x80309434: slti        $at, $s2, 0x3E8
    ctx->r1 = SIGNED(ctx->r18) < 0X3E8 ? 1 : 0;
    // 0x80309438: bnel        $at, $zero, L_8030945C
    if (ctx->r1 != 0) {
        // 0x8030943C: sll         $a0, $a2, 16
        ctx->r4 = S32(ctx->r6 << 16);
            goto L_8030945C;
    }
    goto skip_50;
    // 0x8030943C: sll         $a0, $a2, 16
    ctx->r4 = S32(ctx->r6 << 16);
    skip_50:
    // 0x80309440: addiu       $s2, $s2, -0x3E8
    ctx->r18 = ADD32(ctx->r18, -0X3E8);
    // 0x80309444: sll         $t8, $s2, 16
    ctx->r24 = S32(ctx->r18 << 16);
    // 0x80309448: slti        $at, $s5, 0xB
    ctx->r1 = SIGNED(ctx->r21) < 0XB ? 1 : 0;
    // 0x8030944C: beq         $at, $zero, L_80309458
    if (ctx->r1 == 0) {
        // 0x80309450: sra         $s2, $t8, 16
        ctx->r18 = S32(SIGNED(ctx->r24) >> 16);
            goto L_80309458;
    }
    // 0x80309450: sra         $s2, $t8, 16
    ctx->r18 = S32(SIGNED(ctx->r24) >> 16);
    // 0x80309454: addiu       $s5, $zero, 0xA
    ctx->r21 = ADD32(0, 0XA);
L_80309458:
    // 0x80309458: sll         $a0, $a2, 16
    ctx->r4 = S32(ctx->r6 << 16);
L_8030945C:
    // 0x8030945C: sll         $a1, $s2, 16
    ctx->r5 = S32(ctx->r18 << 16);
    // 0x80309460: sra         $t9, $a1, 16
    ctx->r25 = S32(SIGNED(ctx->r5) >> 16);
    // 0x80309464: sra         $t6, $a0, 16
    ctx->r14 = S32(SIGNED(ctx->r4) >> 16);
    // 0x80309468: or          $a0, $t6, $zero
    ctx->r4 = ctx->r14 | 0;
    // 0x8030946C: jal         0x803051F0
    // 0x80309470: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
    func_803051F0_7168A0(rdram, ctx);
        goto after_52;
    // 0x80309470: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
    after_52:
    // 0x80309474: slti        $at, $v0, 0x6
    ctx->r1 = SIGNED(ctx->r2) < 0X6 ? 1 : 0;
    // 0x80309478: bne         $at, $zero, L_80309484
    if (ctx->r1 != 0) {
        // 0x8030947C: nop
    
            goto L_80309484;
    }
    // 0x8030947C: nop

    // 0x80309480: addiu       $s5, $zero, -0x1
    ctx->r21 = ADD32(0, -0X1);
L_80309484:
    // 0x80309484: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80309488: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x8030948C: sll         $t3, $s2, 16
    ctx->r11 = S32(ctx->r18 << 16);
    // 0x80309490: sra         $t7, $t3, 16
    ctx->r15 = S32(SIGNED(ctx->r11) >> 16);
    // 0x80309494: or          $t3, $t7, $zero
    ctx->r11 = ctx->r15 | 0;
    // 0x80309498: lh          $a2, 0x2C($t0)
    ctx->r6 = MEM_H(ctx->r8, 0X2C);
L_8030949C:
    // 0x8030949C: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x803094A0: lh          $t8, 0x5534($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X5534);
    // 0x803094A4: lui         $t6, 0x801E
    ctx->r14 = S32(0X801E << 16);
    // 0x803094A8: addiu       $t6, $t6, -0x6128
    ctx->r14 = ADD32(ctx->r14, -0X6128);
    // 0x803094AC: sll         $t5, $t8, 3
    ctx->r13 = S32(ctx->r24 << 3);
    // 0x803094B0: addu        $v0, $t5, $t6
    ctx->r2 = ADD32(ctx->r13, ctx->r14);
    // 0x803094B4: lw          $t9, 0x3EB0($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X3EB0);
    // 0x803094B8: addiu       $at, $zero, 0x14
    ctx->r1 = ADD32(0, 0X14);
    // 0x803094BC: lhu         $t7, 0x9C($t9)
    ctx->r15 = MEM_HU(ctx->r25, 0X9C);
    // 0x803094C0: bne         $t7, $at, L_803095EC
    if (ctx->r15 != ctx->r1) {
        // 0x803094C4: nop
    
            goto L_803095EC;
    }
    // 0x803094C4: nop

    // 0x803094C8: lw          $a1, 0x3EB4($v0)
    ctx->r5 = MEM_W(ctx->r2, 0X3EB4);
    // 0x803094CC: lh          $t5, 0x4($t0)
    ctx->r13 = MEM_H(ctx->r8, 0X4);
    // 0x803094D0: lh          $t8, 0x4($a1)
    ctx->r24 = MEM_H(ctx->r5, 0X4);
    // 0x803094D4: subu        $v1, $t8, $t5
    ctx->r3 = SUB32(ctx->r24, ctx->r13);
    // 0x803094D8: bgez        $v1, L_803094EC
    if (SIGNED(ctx->r3) >= 0) {
        // 0x803094DC: negu        $v0, $v1
        ctx->r2 = SUB32(0, ctx->r3);
            goto L_803094EC;
    }
    // 0x803094DC: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
    // 0x803094E0: sll         $t6, $v0, 16
    ctx->r14 = S32(ctx->r2 << 16);
    // 0x803094E4: b           L_803094F8
    // 0x803094E8: sra         $v0, $t6, 16
    ctx->r2 = S32(SIGNED(ctx->r14) >> 16);
        goto L_803094F8;
    // 0x803094E8: sra         $v0, $t6, 16
    ctx->r2 = S32(SIGNED(ctx->r14) >> 16);
L_803094EC:
    // 0x803094EC: sll         $v0, $v1, 16
    ctx->r2 = S32(ctx->r3 << 16);
    // 0x803094F0: sra         $t7, $v0, 16
    ctx->r15 = S32(SIGNED(ctx->r2) >> 16);
    // 0x803094F4: or          $v0, $t7, $zero
    ctx->r2 = ctx->r15 | 0;
L_803094F8:
    // 0x803094F8: slti        $at, $v0, 0x280
    ctx->r1 = SIGNED(ctx->r2) < 0X280 ? 1 : 0;
    // 0x803094FC: beq         $at, $zero, L_803095EC
    if (ctx->r1 == 0) {
        // 0x80309500: nop
    
            goto L_803095EC;
    }
    // 0x80309500: nop

    // 0x80309504: lh          $t8, 0x8($a1)
    ctx->r24 = MEM_H(ctx->r5, 0X8);
    // 0x80309508: lh          $t5, 0x8($t0)
    ctx->r13 = MEM_H(ctx->r8, 0X8);
    // 0x8030950C: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x80309510: subu        $v1, $t8, $t5
    ctx->r3 = SUB32(ctx->r24, ctx->r13);
    // 0x80309514: bgez        $v1, L_80309528
    if (SIGNED(ctx->r3) >= 0) {
        // 0x80309518: negu        $v0, $v1
        ctx->r2 = SUB32(0, ctx->r3);
            goto L_80309528;
    }
    // 0x80309518: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
    // 0x8030951C: sll         $t6, $v0, 16
    ctx->r14 = S32(ctx->r2 << 16);
    // 0x80309520: b           L_80309534
    // 0x80309524: sra         $v0, $t6, 16
    ctx->r2 = S32(SIGNED(ctx->r14) >> 16);
        goto L_80309534;
    // 0x80309524: sra         $v0, $t6, 16
    ctx->r2 = S32(SIGNED(ctx->r14) >> 16);
L_80309528:
    // 0x80309528: sll         $v0, $v1, 16
    ctx->r2 = S32(ctx->r3 << 16);
    // 0x8030952C: sra         $t7, $v0, 16
    ctx->r15 = S32(SIGNED(ctx->r2) >> 16);
    // 0x80309530: or          $v0, $t7, $zero
    ctx->r2 = ctx->r15 | 0;
L_80309534:
    // 0x80309534: slti        $at, $v0, 0x280
    ctx->r1 = SIGNED(ctx->r2) < 0X280 ? 1 : 0;
    // 0x80309538: beq         $at, $zero, L_803095EC
    if (ctx->r1 == 0) {
        // 0x8030953C: slt         $at, $v0, $a0
        ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r4) ? 1 : 0;
            goto L_803095EC;
    }
    // 0x8030953C: slt         $at, $v0, $a0
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x80309540: bnel        $at, $zero, L_80309550
    if (ctx->r1 != 0) {
        // 0x80309544: lh          $t8, 0xC($a1)
        ctx->r24 = MEM_H(ctx->r5, 0XC);
            goto L_80309550;
    }
    goto skip_51;
    // 0x80309544: lh          $t8, 0xC($a1)
    ctx->r24 = MEM_H(ctx->r5, 0XC);
    skip_51:
    // 0x80309548: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
    // 0x8030954C: lh          $t8, 0xC($a1)
    ctx->r24 = MEM_H(ctx->r5, 0XC);
L_80309550:
    // 0x80309550: lh          $t5, 0xC($t0)
    ctx->r13 = MEM_H(ctx->r8, 0XC);
    // 0x80309554: subu        $v1, $t8, $t5
    ctx->r3 = SUB32(ctx->r24, ctx->r13);
    // 0x80309558: bgez        $v1, L_8030956C
    if (SIGNED(ctx->r3) >= 0) {
        // 0x8030955C: negu        $v0, $v1
        ctx->r2 = SUB32(0, ctx->r3);
            goto L_8030956C;
    }
    // 0x8030955C: negu        $v0, $v1
    ctx->r2 = SUB32(0, ctx->r3);
    // 0x80309560: sll         $t6, $v0, 16
    ctx->r14 = S32(ctx->r2 << 16);
    // 0x80309564: b           L_80309578
    // 0x80309568: sra         $v0, $t6, 16
    ctx->r2 = S32(SIGNED(ctx->r14) >> 16);
        goto L_80309578;
    // 0x80309568: sra         $v0, $t6, 16
    ctx->r2 = S32(SIGNED(ctx->r14) >> 16);
L_8030956C:
    // 0x8030956C: sll         $v0, $v1, 16
    ctx->r2 = S32(ctx->r3 << 16);
    // 0x80309570: sra         $t7, $v0, 16
    ctx->r15 = S32(SIGNED(ctx->r2) >> 16);
    // 0x80309574: or          $v0, $t7, $zero
    ctx->r2 = ctx->r15 | 0;
L_80309578:
    // 0x80309578: slti        $at, $v0, 0x280
    ctx->r1 = SIGNED(ctx->r2) < 0X280 ? 1 : 0;
    // 0x8030957C: beq         $at, $zero, L_803095EC
    if (ctx->r1 == 0) {
        // 0x80309580: slt         $at, $v0, $a0
        ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r4) ? 1 : 0;
            goto L_803095EC;
    }
    // 0x80309580: slt         $at, $v0, $a0
    ctx->r1 = SIGNED(ctx->r2) < SIGNED(ctx->r4) ? 1 : 0;
    // 0x80309584: bne         $at, $zero, L_80309590
    if (ctx->r1 != 0) {
        // 0x80309588: nop
    
            goto L_80309590;
    }
    // 0x80309588: nop

    // 0x8030958C: or          $a0, $v0, $zero
    ctx->r4 = ctx->r2 | 0;
L_80309590:
    // 0x80309590: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x80309594: lh          $t8, 0x5540($t8)
    ctx->r24 = MEM_H(ctx->r24, 0X5540);
    // 0x80309598: andi        $t5, $t8, 0x40
    ctx->r13 = ctx->r24 & 0X40;
    // 0x8030959C: beq         $t5, $zero, L_803095C8
    if (ctx->r13 == 0) {
        // 0x803095A0: sll         $t6, $a0, 7
        ctx->r14 = S32(ctx->r4 << 7);
            goto L_803095C8;
    }
    // 0x803095A0: sll         $t6, $a0, 7
    ctx->r14 = S32(ctx->r4 << 7);
    // 0x803095A4: addiu       $at, $zero, 0x280
    ctx->r1 = ADD32(0, 0X280);
    // 0x803095A8: div         $zero, $t6, $at
    lo = S32(S64(S32(ctx->r14)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r14)) % S64(S32(ctx->r1)));
    // 0x803095AC: mflo        $t9
    ctx->r25 = lo;
    // 0x803095B0: addiu       $t7, $zero, 0x80
    ctx->r15 = ADD32(0, 0X80);
    // 0x803095B4: subu        $t6, $t7, $t9
    ctx->r14 = SUB32(ctx->r15, ctx->r25);
    // 0x803095B8: addu        $t3, $t3, $t6
    ctx->r11 = ADD32(ctx->r11, ctx->r14);
    // 0x803095BC: sll         $t7, $t3, 16
    ctx->r15 = S32(ctx->r11 << 16);
    // 0x803095C0: b           L_803095EC
    // 0x803095C4: sra         $t3, $t7, 16
    ctx->r11 = S32(SIGNED(ctx->r15) >> 16);
        goto L_803095EC;
    // 0x803095C4: sra         $t3, $t7, 16
    ctx->r11 = S32(SIGNED(ctx->r15) >> 16);
L_803095C8:
    // 0x803095C8: sll         $t8, $a0, 7
    ctx->r24 = S32(ctx->r4 << 7);
    // 0x803095CC: addiu       $at, $zero, 0x280
    ctx->r1 = ADD32(0, 0X280);
    // 0x803095D0: div         $zero, $t8, $at
    lo = S32(S64(S32(ctx->r24)) / S64(S32(ctx->r1))); hi = S32(S64(S32(ctx->r24)) % S64(S32(ctx->r1)));
    // 0x803095D4: mflo        $t5
    ctx->r13 = lo;
    // 0x803095D8: addiu       $t6, $zero, 0x80
    ctx->r14 = ADD32(0, 0X80);
    // 0x803095DC: subu        $t8, $t6, $t5
    ctx->r24 = SUB32(ctx->r14, ctx->r13);
    // 0x803095E0: subu        $t3, $t3, $t8
    ctx->r11 = SUB32(ctx->r11, ctx->r24);
    // 0x803095E4: sll         $t6, $t3, 16
    ctx->r14 = S32(ctx->r11 << 16);
    // 0x803095E8: sra         $t3, $t6, 16
    ctx->r11 = S32(SIGNED(ctx->r14) >> 16);
L_803095EC:
    // 0x803095EC: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x803095F0: lw          $t7, 0x5528($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X5528);
    // 0x803095F4: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x803095F8: lh          $t6, 0x5540($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X5540);
    // 0x803095FC: lh          $t9, 0x348($t7)
    ctx->r25 = MEM_H(ctx->r15, 0X348);
    // 0x80309600: lui         $t7, 0x8015
    ctx->r15 = S32(0X8015 << 16);
    // 0x80309604: sll         $a3, $a2, 16
    ctx->r7 = S32(ctx->r6 << 16);
    // 0x80309608: sra         $t8, $t9, 2
    ctx->r24 = S32(SIGNED(ctx->r25) >> 2);
    // 0x8030960C: sll         $t9, $t6, 2
    ctx->r25 = S32(ctx->r14 << 2);
    // 0x80309610: andi        $t6, $t9, 0xFF
    ctx->r14 = ctx->r25 & 0XFF;
    // 0x80309614: sll         $t5, $t6, 1
    ctx->r13 = S32(ctx->r14 << 1);
    // 0x80309618: addu        $t7, $t7, $t5
    ctx->r15 = ADD32(ctx->r15, ctx->r13);
    // 0x8030961C: lh          $t7, 0x2C78($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X2C78);
    // 0x80309620: sra         $t9, $t7, 7
    ctx->r25 = S32(SIGNED(ctx->r15) >> 7);
    // 0x80309624: multu       $t8, $t9
    result = U64(U32(ctx->r24)) * U64(U32(ctx->r25)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80309628: sra         $t9, $a3, 16
    ctx->r25 = S32(SIGNED(ctx->r7) >> 16);
    // 0x8030962C: or          $a3, $t9, $zero
    ctx->r7 = ctx->r25 | 0;
    // 0x80309630: mflo        $t6
    ctx->r14 = lo;
    // 0x80309634: sra         $t5, $t6, 10
    ctx->r13 = S32(SIGNED(ctx->r14) >> 10);
    // 0x80309638: addu        $t8, $t3, $t5
    ctx->r24 = ADD32(ctx->r11, ctx->r13);
    // 0x8030963C: subu        $a0, $a2, $t8
    ctx->r4 = SUB32(ctx->r6, ctx->r24);
    // 0x80309640: andi        $t6, $a0, 0xFF
    ctx->r14 = ctx->r4 & 0XFF;
    // 0x80309644: sll         $t5, $t6, 16
    ctx->r13 = S32(ctx->r14 << 16);
    // 0x80309648: sra         $t7, $t5, 16
    ctx->r15 = S32(SIGNED(ctx->r13) >> 16);
    // 0x8030964C: beq         $t7, $zero, L_803096D8
    if (ctx->r15 == 0) {
        // 0x80309650: or          $a0, $t7, $zero
        ctx->r4 = ctx->r15 | 0;
            goto L_803096D8;
    }
    // 0x80309650: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x80309654: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x80309658: lw          $t8, 0x5524($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5524);
    // 0x8030965C: lui         $v0, 0x803A
    ctx->r2 = S32(0X803A << 16);
    // 0x80309660: slti        $at, $t7, 0x80
    ctx->r1 = SIGNED(ctx->r15) < 0X80 ? 1 : 0;
    // 0x80309664: lhu         $t9, 0x9C($t8)
    ctx->r25 = MEM_HU(ctx->r24, 0X9C);
    // 0x80309668: addu        $v0, $v0, $t9
    ctx->r2 = ADD32(ctx->r2, ctx->r25);
    // 0x8030966C: bne         $at, $zero, L_803096B0
    if (ctx->r1 != 0) {
        // 0x80309670: lbu         $v0, 0x47F4($v0)
        ctx->r2 = MEM_BU(ctx->r2, 0X47F4);
            goto L_803096B0;
    }
    // 0x80309670: lbu         $v0, 0x47F4($v0)
    ctx->r2 = MEM_BU(ctx->r2, 0X47F4);
    // 0x80309674: addiu       $t6, $zero, 0x100
    ctx->r14 = ADD32(0, 0X100);
    // 0x80309678: subu        $a0, $t6, $t7
    ctx->r4 = SUB32(ctx->r14, ctx->r15);
    // 0x8030967C: sll         $t5, $a0, 16
    ctx->r13 = S32(ctx->r4 << 16);
    // 0x80309680: sra         $t7, $t5, 16
    ctx->r15 = S32(SIGNED(ctx->r13) >> 16);
    // 0x80309684: slt         $at, $t7, $v0
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x80309688: beq         $at, $zero, L_803096A0
    if (ctx->r1 == 0) {
        // 0x8030968C: or          $a0, $t7, $zero
        ctx->r4 = ctx->r15 | 0;
            goto L_803096A0;
    }
    // 0x8030968C: or          $a0, $t7, $zero
    ctx->r4 = ctx->r15 | 0;
    // 0x80309690: addu        $a3, $a3, $t7
    ctx->r7 = ADD32(ctx->r7, ctx->r15);
    // 0x80309694: sll         $t8, $a3, 16
    ctx->r24 = S32(ctx->r7 << 16);
    // 0x80309698: b           L_803096D8
    // 0x8030969C: sra         $a3, $t8, 16
    ctx->r7 = S32(SIGNED(ctx->r24) >> 16);
        goto L_803096D8;
    // 0x8030969C: sra         $a3, $t8, 16
    ctx->r7 = S32(SIGNED(ctx->r24) >> 16);
L_803096A0:
    // 0x803096A0: addu        $a3, $a3, $v0
    ctx->r7 = ADD32(ctx->r7, ctx->r2);
    // 0x803096A4: sll         $t6, $a3, 16
    ctx->r14 = S32(ctx->r7 << 16);
    // 0x803096A8: b           L_803096D8
    // 0x803096AC: sra         $a3, $t6, 16
    ctx->r7 = S32(SIGNED(ctx->r14) >> 16);
        goto L_803096D8;
    // 0x803096AC: sra         $a3, $t6, 16
    ctx->r7 = S32(SIGNED(ctx->r14) >> 16);
L_803096B0:
    // 0x803096B0: slt         $at, $a0, $v0
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r2) ? 1 : 0;
    // 0x803096B4: beql        $at, $zero, L_803096D0
    if (ctx->r1 == 0) {
        // 0x803096B8: subu        $a3, $a3, $v0
        ctx->r7 = SUB32(ctx->r7, ctx->r2);
            goto L_803096D0;
    }
    goto skip_52;
    // 0x803096B8: subu        $a3, $a3, $v0
    ctx->r7 = SUB32(ctx->r7, ctx->r2);
    skip_52:
    // 0x803096BC: subu        $a3, $a3, $a0
    ctx->r7 = SUB32(ctx->r7, ctx->r4);
    // 0x803096C0: sll         $t7, $a3, 16
    ctx->r15 = S32(ctx->r7 << 16);
    // 0x803096C4: b           L_803096D8
    // 0x803096C8: sra         $a3, $t7, 16
    ctx->r7 = S32(SIGNED(ctx->r15) >> 16);
        goto L_803096D8;
    // 0x803096C8: sra         $a3, $t7, 16
    ctx->r7 = S32(SIGNED(ctx->r15) >> 16);
    // 0x803096CC: subu        $a3, $a3, $v0
    ctx->r7 = SUB32(ctx->r7, ctx->r2);
L_803096D0:
    // 0x803096D0: sll         $t9, $a3, 16
    ctx->r25 = S32(ctx->r7 << 16);
    // 0x803096D4: sra         $a3, $t9, 16
    ctx->r7 = S32(SIGNED(ctx->r25) >> 16);
L_803096D8:
    // 0x803096D8: andi        $t5, $a3, 0xFF
    ctx->r13 = ctx->r7 & 0XFF;
    // 0x803096DC: sll         $t7, $t5, 16
    ctx->r15 = S32(ctx->r13 << 16);
    // 0x803096E0: blez        $s5, L_80309748
    if (SIGNED(ctx->r21) <= 0) {
        // 0x803096E4: sra         $a3, $t7, 16
        ctx->r7 = S32(SIGNED(ctx->r15) >> 16);
            goto L_80309748;
    }
    // 0x803096E4: sra         $a3, $t7, 16
    ctx->r7 = S32(SIGNED(ctx->r15) >> 16);
    // 0x803096E8: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x803096EC: lw          $t9, 0x552C($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X552C);
    // 0x803096F0: lhu         $v1, 0x272($t9)
    ctx->r3 = MEM_HU(ctx->r25, 0X272);
    // 0x803096F4: andi        $t6, $v1, 0xC0
    ctx->r14 = ctx->r3 & 0XC0;
    // 0x803096F8: beq         $t6, $zero, L_80309748
    if (ctx->r14 == 0) {
        // 0x803096FC: andi        $t5, $v1, 0x40
        ctx->r13 = ctx->r3 & 0X40;
            goto L_80309748;
    }
    // 0x803096FC: andi        $t5, $v1, 0x40
    ctx->r13 = ctx->r3 & 0X40;
    // 0x80309700: beq         $t5, $zero, L_8030970C
    if (ctx->r13 == 0) {
        // 0x80309704: addiu       $v0, $zero, 0x7
        ctx->r2 = ADD32(0, 0X7);
            goto L_8030970C;
    }
    // 0x80309704: addiu       $v0, $zero, 0x7
    ctx->r2 = ADD32(0, 0X7);
    // 0x80309708: addiu       $v0, $zero, 0x6
    ctx->r2 = ADD32(0, 0X6);
L_8030970C:
    // 0x8030970C: andi        $t7, $v1, 0x80
    ctx->r15 = ctx->r3 & 0X80;
    // 0x80309710: beq         $t7, $zero, L_80309724
    if (ctx->r15 == 0) {
        // 0x80309714: nop
    
            goto L_80309724;
    }
    // 0x80309714: nop

    // 0x80309718: addiu       $v0, $v0, -0x1
    ctx->r2 = ADD32(ctx->r2, -0X1);
    // 0x8030971C: sll         $t8, $v0, 16
    ctx->r24 = S32(ctx->r2 << 16);
    // 0x80309720: sra         $v0, $t8, 16
    ctx->r2 = S32(SIGNED(ctx->r24) >> 16);
L_80309724:
    // 0x80309724: multu       $s5, $a0
    result = U64(U32(ctx->r21)) * U64(U32(ctx->r4)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x80309728: mflo        $t6
    ctx->r14 = lo;
    // 0x8030972C: srav        $t5, $t6, $v0
    ctx->r13 = S32(SIGNED(ctx->r14) >> (ctx->r2 & 31));
    // 0x80309730: subu        $s5, $s5, $t5
    ctx->r21 = SUB32(ctx->r21, ctx->r13);
    // 0x80309734: sll         $t7, $s5, 16
    ctx->r15 = S32(ctx->r21 << 16);
    // 0x80309738: sra         $s5, $t7, 16
    ctx->r21 = S32(SIGNED(ctx->r15) >> 16);
    // 0x8030973C: bgtz        $s5, L_80309748
    if (SIGNED(ctx->r21) > 0) {
        // 0x80309740: nop
    
            goto L_80309748;
    }
    // 0x80309740: nop

    // 0x80309744: addiu       $s5, $zero, -0x1
    ctx->r21 = ADD32(0, -0X1);
L_80309748:
    // 0x80309748: blez        $s5, L_8030975C
    if (SIGNED(ctx->r21) <= 0) {
        // 0x8030974C: slti        $at, $s5, 0x4
        ctx->r1 = SIGNED(ctx->r21) < 0X4 ? 1 : 0;
            goto L_8030975C;
    }
    // 0x8030974C: slti        $at, $s5, 0x4
    ctx->r1 = SIGNED(ctx->r21) < 0X4 ? 1 : 0;
    // 0x80309750: beql        $at, $zero, L_80309760
    if (ctx->r1 == 0) {
        // 0x80309754: sll         $a1, $s5, 24
        ctx->r5 = S32(ctx->r21 << 24);
            goto L_80309760;
    }
    goto skip_53;
    // 0x80309754: sll         $a1, $s5, 24
    ctx->r5 = S32(ctx->r21 << 24);
    skip_53:
    // 0x80309758: addiu       $s5, $zero, 0x4
    ctx->r21 = ADD32(0, 0X4);
L_8030975C:
    // 0x8030975C: sll         $a1, $s5, 24
    ctx->r5 = S32(ctx->r21 << 24);
L_80309760:
    // 0x80309760: sra         $t9, $a1, 24
    ctx->r25 = S32(SIGNED(ctx->r5) >> 24);
    // 0x80309764: or          $a1, $t9, $zero
    ctx->r5 = ctx->r25 | 0;
    // 0x80309768: andi        $a0, $a3, 0xFF
    ctx->r4 = ctx->r7 & 0XFF;
    // 0x8030976C: jal         0x802AB8EC
    // 0x80309770: lh          $a2, 0x9A($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X9A);
    func_802AB8EC_6BCF9C(rdram, ctx);
        goto after_53;
    // 0x80309770: lh          $a2, 0x9A($sp)
    ctx->r6 = MEM_H(ctx->r29, 0X9A);
    after_53:
    // 0x80309774: lw          $ra, 0x34($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X34);
    // 0x80309778: lw          $s0, 0x1C($sp)
    ctx->r16 = MEM_W(ctx->r29, 0X1C);
    // 0x8030977C: lw          $s1, 0x20($sp)
    ctx->r17 = MEM_W(ctx->r29, 0X20);
    // 0x80309780: lw          $s2, 0x24($sp)
    ctx->r18 = MEM_W(ctx->r29, 0X24);
    // 0x80309784: lw          $s3, 0x28($sp)
    ctx->r19 = MEM_W(ctx->r29, 0X28);
    // 0x80309788: lw          $s4, 0x2C($sp)
    ctx->r20 = MEM_W(ctx->r29, 0X2C);
    // 0x8030978C: lw          $s5, 0x30($sp)
    ctx->r21 = MEM_W(ctx->r29, 0X30);
    // 0x80309790: jr          $ra
    // 0x80309794: addiu       $sp, $sp, 0xD8
    ctx->r29 = ADD32(ctx->r29, 0XD8);
    return;
    // 0x80309794: addiu       $sp, $sp, 0xD8
    ctx->r29 = ADD32(ctx->r29, 0XD8);
;}
RECOMP_FUNC void func_80309798_71AE48(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80309798: lb          $t6, 0x4A($a0)
    ctx->r14 = MEM_B(ctx->r4, 0X4A);
    // 0x8030979C: or          $v0, $a0, $zero
    ctx->r2 = ctx->r4 | 0;
    // 0x803097A0: bnel        $t6, $zero, L_80309860
    if (ctx->r14 != 0) {
        // 0x803097A4: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80309860;
    }
    goto skip_0;
    // 0x803097A4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_0:
    // 0x803097A8: lw          $t7, 0x16C($a0)
    ctx->r15 = MEM_W(ctx->r4, 0X16C);
    // 0x803097AC: addiu       $at, $zero, 0x13E
    ctx->r1 = ADD32(0, 0X13E);
    // 0x803097B0: lhu         $v1, 0x0($t7)
    ctx->r3 = MEM_HU(ctx->r15, 0X0);
    // 0x803097B4: beq         $v1, $at, L_8030985C
    if (ctx->r3 == ctx->r1) {
        // 0x803097B8: addiu       $at, $zero, 0x13F
        ctx->r1 = ADD32(0, 0X13F);
            goto L_8030985C;
    }
    // 0x803097B8: addiu       $at, $zero, 0x13F
    ctx->r1 = ADD32(0, 0X13F);
    // 0x803097BC: beq         $v1, $at, L_8030985C
    if (ctx->r3 == ctx->r1) {
        // 0x803097C0: addiu       $at, $zero, 0x13D
        ctx->r1 = ADD32(0, 0X13D);
            goto L_8030985C;
    }
    // 0x803097C0: addiu       $at, $zero, 0x13D
    ctx->r1 = ADD32(0, 0X13D);
    // 0x803097C4: beql        $v1, $at, L_80309860
    if (ctx->r3 == ctx->r1) {
        // 0x803097C8: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80309860;
    }
    goto skip_1;
    // 0x803097C8: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_1:
    // 0x803097CC: lbu         $v1, 0x366($a0)
    ctx->r3 = MEM_BU(ctx->r4, 0X366);
    // 0x803097D0: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x803097D4: beq         $v1, $at, L_8030985C
    if (ctx->r3 == ctx->r1) {
        // 0x803097D8: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_8030985C;
    }
    // 0x803097D8: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x803097DC: beq         $v1, $at, L_8030985C
    if (ctx->r3 == ctx->r1) {
        // 0x803097E0: lui         $v1, 0x803D
        ctx->r3 = S32(0X803D << 16);
            goto L_8030985C;
    }
    // 0x803097E0: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x803097E4: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x803097E8: lbu         $a1, 0x18C($v1)
    ctx->r5 = MEM_BU(ctx->r3, 0X18C);
    // 0x803097EC: bne         $a1, $zero, L_803097FC
    if (ctx->r5 != 0) {
        // 0x803097F0: nop
    
            goto L_803097FC;
    }
    // 0x803097F0: nop

    // 0x803097F4: jr          $ra
    // 0x803097F8: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    return;
    // 0x803097F8: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_803097FC:
    // 0x803097FC: blez        $a1, L_8030985C
    if (SIGNED(ctx->r5) <= 0) {
        // 0x80309800: or          $a2, $zero, $zero
        ctx->r6 = 0 | 0;
            goto L_8030985C;
    }
    // 0x80309800: or          $a2, $zero, $zero
    ctx->r6 = 0 | 0;
    // 0x80309804: lbu         $t1, 0x192($a0)
    ctx->r9 = MEM_BU(ctx->r4, 0X192);
L_80309808:
    // 0x80309808: blez        $t1, L_80309848
    if (SIGNED(ctx->r9) <= 0) {
        // 0x8030980C: or          $a3, $zero, $zero
        ctx->r7 = 0 | 0;
            goto L_80309848;
    }
    // 0x8030980C: or          $a3, $zero, $zero
    ctx->r7 = 0 | 0;
    // 0x80309810: addu        $t8, $v1, $a2
    ctx->r24 = ADD32(ctx->r3, ctx->r6);
    // 0x80309814: lbu         $t0, 0x18D($t8)
    ctx->r8 = MEM_BU(ctx->r24, 0X18D);
L_80309818:
    // 0x80309818: addu        $t9, $a0, $a3
    ctx->r25 = ADD32(ctx->r4, ctx->r7);
    // 0x8030981C: lbu         $t2, 0x193($t9)
    ctx->r10 = MEM_BU(ctx->r25, 0X193);
    // 0x80309820: bnel        $t0, $t2, L_80309834
    if (ctx->r8 != ctx->r10) {
        // 0x80309824: lbu         $t4, 0x192($v0)
        ctx->r12 = MEM_BU(ctx->r2, 0X192);
            goto L_80309834;
    }
    goto skip_2;
    // 0x80309824: lbu         $t4, 0x192($v0)
    ctx->r12 = MEM_BU(ctx->r2, 0X192);
    skip_2:
    // 0x80309828: jr          $ra
    // 0x8030982C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    return;
    // 0x8030982C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    // 0x80309830: lbu         $t4, 0x192($v0)
    ctx->r12 = MEM_BU(ctx->r2, 0X192);
L_80309834:
    // 0x80309834: addiu       $a3, $a3, 0x1
    ctx->r7 = ADD32(ctx->r7, 0X1);
    // 0x80309838: andi        $t3, $a3, 0xFF
    ctx->r11 = ctx->r7 & 0XFF;
    // 0x8030983C: slt         $at, $t3, $t4
    ctx->r1 = SIGNED(ctx->r11) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x80309840: bne         $at, $zero, L_80309818
    if (ctx->r1 != 0) {
        // 0x80309844: or          $a3, $t3, $zero
        ctx->r7 = ctx->r11 | 0;
            goto L_80309818;
    }
    // 0x80309844: or          $a3, $t3, $zero
    ctx->r7 = ctx->r11 | 0;
L_80309848:
    // 0x80309848: addiu       $a2, $a2, 0x1
    ctx->r6 = ADD32(ctx->r6, 0X1);
    // 0x8030984C: andi        $t5, $a2, 0xFF
    ctx->r13 = ctx->r6 & 0XFF;
    // 0x80309850: slt         $at, $t5, $a1
    ctx->r1 = SIGNED(ctx->r13) < SIGNED(ctx->r5) ? 1 : 0;
    // 0x80309854: bne         $at, $zero, L_80309808
    if (ctx->r1 != 0) {
        // 0x80309858: or          $a2, $t5, $zero
        ctx->r6 = ctx->r13 | 0;
            goto L_80309808;
    }
    // 0x80309858: or          $a2, $t5, $zero
    ctx->r6 = ctx->r13 | 0;
L_8030985C:
    // 0x8030985C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80309860:
    // 0x80309860: jr          $ra
    // 0x80309864: nop

    return;
    // 0x80309864: nop

;}
RECOMP_FUNC void func_80309868_71AF18(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80309868: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8030986C: lw          $t6, 0x552C($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X552C);
    // 0x80309870: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80309874: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80309878: lhu         $t7, 0x272($t6)
    ctx->r15 = MEM_HU(ctx->r14, 0X272);
    // 0x8030987C: lui         $v0, 0x803E
    ctx->r2 = S32(0X803E << 16);
    // 0x80309880: addiu       $v0, $v0, 0x4BE0
    ctx->r2 = ADD32(ctx->r2, 0X4BE0);
    // 0x80309884: andi        $t8, $t7, 0x1
    ctx->r24 = ctx->r15 & 0X1;
    // 0x80309888: beql        $t8, $zero, L_803098E0
    if (ctx->r24 == 0) {
        // 0x8030988C: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_803098E0;
    }
    goto skip_0;
    // 0x8030988C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_0:
    // 0x80309890: lw          $a0, 0x58($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X58);
    // 0x80309894: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80309898: beql        $a0, $zero, L_803098E0
    if (ctx->r4 == 0) {
        // 0x8030989C: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_803098E0;
    }
    goto skip_1;
    // 0x8030989C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_1:
    // 0x803098A0: lw          $t0, 0x5530($t0)
    ctx->r8 = MEM_W(ctx->r8, 0X5530);
    // 0x803098A4: lui         $t4, 0x803A
    ctx->r12 = S32(0X803A << 16);
    // 0x803098A8: lw          $t9, 0x54($v0)
    ctx->r25 = MEM_W(ctx->r2, 0X54);
    // 0x803098AC: lw          $t1, 0x16C($t0)
    ctx->r9 = MEM_W(ctx->r8, 0X16C);
    // 0x803098B0: lhu         $t2, 0x0($t1)
    ctx->r10 = MEM_HU(ctx->r9, 0X0);
    // 0x803098B4: sll         $t3, $t2, 1
    ctx->r11 = S32(ctx->r10 << 1);
    // 0x803098B8: addu        $t4, $t4, $t3
    ctx->r12 = ADD32(ctx->r12, ctx->r11);
    // 0x803098BC: lhu         $t4, 0x4638($t4)
    ctx->r12 = MEM_HU(ctx->r12, 0X4638);
    // 0x803098C0: slt         $at, $t9, $t4
    ctx->r1 = SIGNED(ctx->r25) < SIGNED(ctx->r12) ? 1 : 0;
    // 0x803098C4: beql        $at, $zero, L_803098E0
    if (ctx->r1 == 0) {
        // 0x803098C8: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_803098E0;
    }
    goto skip_2;
    // 0x803098C8: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_2:
    // 0x803098CC: jal         0x80309798
    // 0x803098D0: nop

    func_80309798_71AE48(rdram, ctx);
        goto after_0;
    // 0x803098D0: nop

    after_0:
    // 0x803098D4: b           L_803098E4
    // 0x803098D8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_803098E4;
    // 0x803098D8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x803098DC: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_803098E0:
    // 0x803098E0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_803098E4:
    // 0x803098E4: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x803098E8: jr          $ra
    // 0x803098EC: nop

    return;
    // 0x803098EC: nop

;}
RECOMP_FUNC void func_803098F0_71AFA0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803098F0: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x803098F4: lh          $t6, 0x5534($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X5534);
    // 0x803098F8: lui         $a1, 0x801E
    ctx->r5 = S32(0X801E << 16);
    // 0x803098FC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80309900: sll         $t7, $t6, 3
    ctx->r15 = S32(ctx->r14 << 3);
    // 0x80309904: addu        $a1, $a1, $t7
    ctx->r5 = ADD32(ctx->r5, ctx->r15);
    // 0x80309908: lw          $a1, -0x2274($a1)
    ctx->r5 = MEM_W(ctx->r5, -0X2274);
    // 0x8030990C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80309910: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80309914: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80309918: lh          $t9, 0x4($a1)
    ctx->r25 = MEM_H(ctx->r5, 0X4);
    // 0x8030991C: lh          $t8, 0x4($a0)
    ctx->r24 = MEM_H(ctx->r4, 0X4);
    // 0x80309920: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x80309924: subu        $v0, $t8, $t9
    ctx->r2 = SUB32(ctx->r24, ctx->r25);
    // 0x80309928: bgez        $v0, L_80309938
    if (SIGNED(ctx->r2) >= 0) {
        // 0x8030992C: or          $a2, $v0, $zero
        ctx->r6 = ctx->r2 | 0;
            goto L_80309938;
    }
    // 0x8030992C: or          $a2, $v0, $zero
    ctx->r6 = ctx->r2 | 0;
    // 0x80309930: b           L_80309938
    // 0x80309934: negu        $a2, $v0
    ctx->r6 = SUB32(0, ctx->r2);
        goto L_80309938;
    // 0x80309934: negu        $a2, $v0
    ctx->r6 = SUB32(0, ctx->r2);
L_80309938:
    // 0x80309938: lh          $t0, 0x8($a0)
    ctx->r8 = MEM_H(ctx->r4, 0X8);
    // 0x8030993C: lh          $t1, 0x8($a1)
    ctx->r9 = MEM_H(ctx->r5, 0X8);
    // 0x80309940: subu        $v0, $t0, $t1
    ctx->r2 = SUB32(ctx->r8, ctx->r9);
    // 0x80309944: bgez        $v0, L_80309954
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80309948: or          $v1, $v0, $zero
        ctx->r3 = ctx->r2 | 0;
            goto L_80309954;
    }
    // 0x80309948: or          $v1, $v0, $zero
    ctx->r3 = ctx->r2 | 0;
    // 0x8030994C: b           L_80309954
    // 0x80309950: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
        goto L_80309954;
    // 0x80309950: negu        $v1, $v0
    ctx->r3 = SUB32(0, ctx->r2);
L_80309954:
    // 0x80309954: lw          $t2, 0x552C($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X552C);
    // 0x80309958: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x8030995C: lhu         $t3, 0x272($t2)
    ctx->r11 = MEM_HU(ctx->r10, 0X272);
    // 0x80309960: andi        $t4, $t3, 0x1
    ctx->r12 = ctx->r11 & 0X1;
    // 0x80309964: beq         $t4, $zero, L_803099AC
    if (ctx->r12 == 0) {
        // 0x80309968: nop
    
            goto L_803099AC;
    }
    // 0x80309968: nop

    // 0x8030996C: lw          $t8, 0x16C($a0)
    ctx->r24 = MEM_W(ctx->r4, 0X16C);
    // 0x80309970: lui         $t1, 0x803A
    ctx->r9 = S32(0X803A << 16);
    // 0x80309974: addu        $t5, $v1, $a2
    ctx->r13 = ADD32(ctx->r3, ctx->r6);
    // 0x80309978: lhu         $t9, 0x0($t8)
    ctx->r25 = MEM_HU(ctx->r24, 0X0);
    // 0x8030997C: sll         $t6, $t5, 16
    ctx->r14 = S32(ctx->r13 << 16);
    // 0x80309980: sra         $t7, $t6, 16
    ctx->r15 = S32(SIGNED(ctx->r14) >> 16);
    // 0x80309984: sll         $t0, $t9, 1
    ctx->r8 = S32(ctx->r25 << 1);
    // 0x80309988: addu        $t1, $t1, $t0
    ctx->r9 = ADD32(ctx->r9, ctx->r8);
    // 0x8030998C: lhu         $t1, 0x4638($t1)
    ctx->r9 = MEM_HU(ctx->r9, 0X4638);
    // 0x80309990: slt         $at, $t7, $t1
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r9) ? 1 : 0;
    // 0x80309994: beq         $at, $zero, L_803099AC
    if (ctx->r1 == 0) {
        // 0x80309998: nop
    
            goto L_803099AC;
    }
    // 0x80309998: nop

    // 0x8030999C: jal         0x80309798
    // 0x803099A0: or          $a0, $a1, $zero
    ctx->r4 = ctx->r5 | 0;
    func_80309798_71AE48(rdram, ctx);
        goto after_0;
    // 0x803099A0: or          $a0, $a1, $zero
    ctx->r4 = ctx->r5 | 0;
    after_0:
    // 0x803099A4: b           L_803099B0
    // 0x803099A8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_803099B0;
    // 0x803099A8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_803099AC:
    // 0x803099AC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_803099B0:
    // 0x803099B0: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x803099B4: jr          $ra
    // 0x803099B8: nop

    return;
    // 0x803099B8: nop

;}
RECOMP_FUNC void func_803099BC_71B06C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x803099BC: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x803099C0: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x803099C4: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x803099C8: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x803099CC: lhu         $t6, 0x28C($v0)
    ctx->r14 = MEM_HU(ctx->r2, 0X28C);
    // 0x803099D0: addiu       $at, $zero, 0x8
    ctx->r1 = ADD32(0, 0X8);
    // 0x803099D4: bnel        $t6, $at, L_80309A4C
    if (ctx->r14 != ctx->r1) {
        // 0x803099D8: lhu         $t0, 0x272($v0)
        ctx->r8 = MEM_HU(ctx->r2, 0X272);
            goto L_80309A4C;
    }
    goto skip_0;
    // 0x803099D8: lhu         $t0, 0x272($v0)
    ctx->r8 = MEM_HU(ctx->r2, 0X272);
    skip_0:
    // 0x803099DC: lhu         $t7, 0x272($v0)
    ctx->r15 = MEM_HU(ctx->r2, 0X272);
    // 0x803099E0: andi        $t8, $t7, 0x1
    ctx->r24 = ctx->r15 & 0X1;
    // 0x803099E4: beq         $t8, $zero, L_80309A40
    if (ctx->r24 == 0) {
        // 0x803099E8: nop
    
            goto L_80309A40;
    }
    // 0x803099E8: nop

    // 0x803099EC: lw          $a0, 0x2CC($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X2CC);
    // 0x803099F0: lui         $t9, 0x803D
    ctx->r25 = S32(0X803D << 16);
    // 0x803099F4: beq         $a0, $zero, L_80309A40
    if (ctx->r4 == 0) {
        // 0x803099F8: nop
    
            goto L_80309A40;
    }
    // 0x803099F8: nop

    // 0x803099FC: lw          $t9, 0x5524($t9)
    ctx->r25 = MEM_W(ctx->r25, 0X5524);
    // 0x80309A00: addiu       $at, $zero, 0x3E
    ctx->r1 = ADD32(0, 0X3E);
    // 0x80309A04: lhu         $v0, 0x9C($t9)
    ctx->r2 = MEM_HU(ctx->r25, 0X9C);
    // 0x80309A08: beq         $v0, $at, L_80309A40
    if (ctx->r2 == ctx->r1) {
        // 0x80309A0C: addiu       $at, $zero, 0x3F
        ctx->r1 = ADD32(0, 0X3F);
            goto L_80309A40;
    }
    // 0x80309A0C: addiu       $at, $zero, 0x3F
    ctx->r1 = ADD32(0, 0X3F);
    // 0x80309A10: beq         $v0, $at, L_80309A40
    if (ctx->r2 == ctx->r1) {
        // 0x80309A14: addiu       $at, $zero, 0x3D
        ctx->r1 = ADD32(0, 0X3D);
            goto L_80309A40;
    }
    // 0x80309A14: addiu       $at, $zero, 0x3D
    ctx->r1 = ADD32(0, 0X3D);
    // 0x80309A18: beq         $v0, $at, L_80309A40
    if (ctx->r2 == ctx->r1) {
        // 0x80309A1C: nop
    
            goto L_80309A40;
    }
    // 0x80309A1C: nop

    // 0x80309A20: lbu         $v0, 0x366($a0)
    ctx->r2 = MEM_BU(ctx->r4, 0X366);
    // 0x80309A24: addiu       $at, $zero, 0x5
    ctx->r1 = ADD32(0, 0X5);
    // 0x80309A28: beq         $v0, $at, L_80309A40
    if (ctx->r2 == ctx->r1) {
        // 0x80309A2C: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80309A40;
    }
    // 0x80309A2C: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80309A30: beq         $v0, $at, L_80309A40
    if (ctx->r2 == ctx->r1) {
        // 0x80309A34: nop
    
            goto L_80309A40;
    }
    // 0x80309A34: nop

    // 0x80309A38: b           L_80309ABC
    // 0x80309A3C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
        goto L_80309ABC;
    // 0x80309A3C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_80309A40:
    // 0x80309A40: b           L_80309ABC
    // 0x80309A44: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
        goto L_80309ABC;
    // 0x80309A44: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x80309A48: lhu         $t0, 0x272($v0)
    ctx->r8 = MEM_HU(ctx->r2, 0X272);
L_80309A4C:
    // 0x80309A4C: andi        $t1, $t0, 0x1
    ctx->r9 = ctx->r8 & 0X1;
    // 0x80309A50: beql        $t1, $zero, L_80309ABC
    if (ctx->r9 == 0) {
        // 0x80309A54: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80309ABC;
    }
    goto skip_1;
    // 0x80309A54: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_1:
    // 0x80309A58: lw          $a0, 0x2CC($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X2CC);
    // 0x80309A5C: beql        $a0, $zero, L_80309ABC
    if (ctx->r4 == 0) {
        // 0x80309A60: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80309ABC;
    }
    goto skip_2;
    // 0x80309A60: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_2:
    // 0x80309A64: lw          $t2, 0x16C($a0)
    ctx->r10 = MEM_W(ctx->r4, 0X16C);
    // 0x80309A68: addiu       $at, $zero, 0x13C
    ctx->r1 = ADD32(0, 0X13C);
    // 0x80309A6C: lui         $t5, 0x803D
    ctx->r13 = S32(0X803D << 16);
    // 0x80309A70: lhu         $t3, 0x0($t2)
    ctx->r11 = MEM_HU(ctx->r10, 0X0);
    // 0x80309A74: beql        $t3, $at, L_80309ABC
    if (ctx->r11 == ctx->r1) {
        // 0x80309A78: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80309ABC;
    }
    goto skip_3;
    // 0x80309A78: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_3:
    // 0x80309A7C: lw          $t5, 0x5530($t5)
    ctx->r13 = MEM_W(ctx->r13, 0X5530);
    // 0x80309A80: lui         $t9, 0x803A
    ctx->r25 = S32(0X803A << 16);
    // 0x80309A84: lh          $t4, 0x2D0($v0)
    ctx->r12 = MEM_H(ctx->r2, 0X2D0);
    // 0x80309A88: lw          $t6, 0x16C($t5)
    ctx->r14 = MEM_W(ctx->r13, 0X16C);
    // 0x80309A8C: lhu         $t7, 0x0($t6)
    ctx->r15 = MEM_HU(ctx->r14, 0X0);
    // 0x80309A90: sll         $t8, $t7, 1
    ctx->r24 = S32(ctx->r15 << 1);
    // 0x80309A94: addu        $t9, $t9, $t8
    ctx->r25 = ADD32(ctx->r25, ctx->r24);
    // 0x80309A98: lhu         $t9, 0x4638($t9)
    ctx->r25 = MEM_HU(ctx->r25, 0X4638);
    // 0x80309A9C: slt         $at, $t4, $t9
    ctx->r1 = SIGNED(ctx->r12) < SIGNED(ctx->r25) ? 1 : 0;
    // 0x80309AA0: beql        $at, $zero, L_80309ABC
    if (ctx->r1 == 0) {
        // 0x80309AA4: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80309ABC;
    }
    goto skip_4;
    // 0x80309AA4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_4:
    // 0x80309AA8: jal         0x80309798
    // 0x80309AAC: nop

    func_80309798_71AE48(rdram, ctx);
        goto after_0;
    // 0x80309AAC: nop

    after_0:
    // 0x80309AB0: b           L_80309AC0
    // 0x80309AB4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80309AC0;
    // 0x80309AB4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80309AB8: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80309ABC:
    // 0x80309ABC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80309AC0:
    // 0x80309AC0: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80309AC4: jr          $ra
    // 0x80309AC8: nop

    return;
    // 0x80309AC8: nop

;}
RECOMP_FUNC void func_80309ACC_71B17C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80309ACC: lui         $v0, 0x803E
    ctx->r2 = S32(0X803E << 16);
    // 0x80309AD0: addiu       $v0, $v0, 0x4BE0
    ctx->r2 = ADD32(ctx->r2, 0X4BE0);
    // 0x80309AD4: lbu         $t6, 0x64($v0)
    ctx->r14 = MEM_BU(ctx->r2, 0X64);
    // 0x80309AD8: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80309ADC: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80309AE0: beql        $t6, $zero, L_80309B30
    if (ctx->r14 == 0) {
        // 0x80309AE4: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80309B30;
    }
    goto skip_0;
    // 0x80309AE4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_0:
    // 0x80309AE8: lw          $a0, 0x60($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X60);
    // 0x80309AEC: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80309AF0: beql        $a0, $zero, L_80309B30
    if (ctx->r4 == 0) {
        // 0x80309AF4: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80309B30;
    }
    goto skip_1;
    // 0x80309AF4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_1:
    // 0x80309AF8: lw          $t7, 0x552C($t7)
    ctx->r15 = MEM_W(ctx->r15, 0X552C);
    // 0x80309AFC: lhu         $t8, 0x272($t7)
    ctx->r24 = MEM_HU(ctx->r15, 0X272);
    // 0x80309B00: andi        $t9, $t8, 0x8
    ctx->r25 = ctx->r24 & 0X8;
    // 0x80309B04: beql        $t9, $zero, L_80309B30
    if (ctx->r25 == 0) {
        // 0x80309B08: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80309B30;
    }
    goto skip_2;
    // 0x80309B08: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_2:
    // 0x80309B0C: lw          $t0, 0x5C($v0)
    ctx->r8 = MEM_W(ctx->r2, 0X5C);
    // 0x80309B10: slti        $at, $t0, 0x280
    ctx->r1 = SIGNED(ctx->r8) < 0X280 ? 1 : 0;
    // 0x80309B14: beql        $at, $zero, L_80309B30
    if (ctx->r1 == 0) {
        // 0x80309B18: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80309B30;
    }
    goto skip_3;
    // 0x80309B18: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_3:
    // 0x80309B1C: jal         0x80309798
    // 0x80309B20: nop

    func_80309798_71AE48(rdram, ctx);
        goto after_0;
    // 0x80309B20: nop

    after_0:
    // 0x80309B24: b           L_80309B34
    // 0x80309B28: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80309B34;
    // 0x80309B28: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80309B2C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80309B30:
    // 0x80309B30: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80309B34:
    // 0x80309B34: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80309B38: jr          $ra
    // 0x80309B3C: nop

    return;
    // 0x80309B3C: nop

;}
RECOMP_FUNC void func_80309B40_71B1F0(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80309B40: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80309B44: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x80309B48: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80309B4C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80309B50: lhu         $t6, 0x272($v0)
    ctx->r14 = MEM_HU(ctx->r2, 0X272);
    // 0x80309B54: andi        $t7, $t6, 0x8
    ctx->r15 = ctx->r14 & 0X8;
    // 0x80309B58: beql        $t7, $zero, L_80309B90
    if (ctx->r15 == 0) {
        // 0x80309B5C: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80309B90;
    }
    goto skip_0;
    // 0x80309B5C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_0:
    // 0x80309B60: lw          $a0, 0x280($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X280);
    // 0x80309B64: beql        $a0, $zero, L_80309B90
    if (ctx->r4 == 0) {
        // 0x80309B68: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80309B90;
    }
    goto skip_1;
    // 0x80309B68: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_1:
    // 0x80309B6C: lh          $t8, 0x284($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X284);
    // 0x80309B70: slti        $at, $t8, 0x280
    ctx->r1 = SIGNED(ctx->r24) < 0X280 ? 1 : 0;
    // 0x80309B74: beql        $at, $zero, L_80309B90
    if (ctx->r1 == 0) {
        // 0x80309B78: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80309B90;
    }
    goto skip_2;
    // 0x80309B78: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_2:
    // 0x80309B7C: jal         0x80309798
    // 0x80309B80: nop

    func_80309798_71AE48(rdram, ctx);
        goto after_0;
    // 0x80309B80: nop

    after_0:
    // 0x80309B84: b           L_80309B94
    // 0x80309B88: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80309B94;
    // 0x80309B88: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80309B8C: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80309B90:
    // 0x80309B90: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80309B94:
    // 0x80309B94: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80309B98: jr          $ra
    // 0x80309B9C: nop

    return;
    // 0x80309B9C: nop

;}
RECOMP_FUNC void func_80309BA0_71B250(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80309BA0: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80309BA4: lw          $v1, 0x552C($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X552C);
    // 0x80309BA8: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80309BAC: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80309BB0: lhu         $t6, 0x272($v1)
    ctx->r14 = MEM_HU(ctx->r3, 0X272);
    // 0x80309BB4: lui         $t0, 0x803E
    ctx->r8 = S32(0X803E << 16);
    // 0x80309BB8: addiu       $t0, $t0, 0x4BE0
    ctx->r8 = ADD32(ctx->r8, 0X4BE0);
    // 0x80309BBC: andi        $t7, $t6, 0x1
    ctx->r15 = ctx->r14 & 0X1;
    // 0x80309BC0: beql        $t7, $zero, L_80309C7C
    if (ctx->r15 == 0) {
        // 0x80309BC4: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80309C7C;
    }
    goto skip_0;
    // 0x80309BC4: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_0:
    // 0x80309BC8: lw          $a0, 0x58($t0)
    ctx->r4 = MEM_W(ctx->r8, 0X58);
    // 0x80309BCC: beql        $a0, $zero, L_80309C7C
    if (ctx->r4 == 0) {
        // 0x80309BD0: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80309C7C;
    }
    goto skip_1;
    // 0x80309BD0: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_1:
    // 0x80309BD4: lw          $a1, 0x280($v1)
    ctx->r5 = MEM_W(ctx->r3, 0X280);
    // 0x80309BD8: lh          $t9, 0x4($a0)
    ctx->r25 = MEM_H(ctx->r4, 0X4);
    // 0x80309BDC: lh          $t2, 0x8($a0)
    ctx->r10 = MEM_H(ctx->r4, 0X8);
    // 0x80309BE0: lh          $t8, 0x4($a1)
    ctx->r24 = MEM_H(ctx->r5, 0X4);
    // 0x80309BE4: lh          $t1, 0x8($a1)
    ctx->r9 = MEM_H(ctx->r5, 0X8);
    // 0x80309BE8: subu        $v0, $t8, $t9
    ctx->r2 = SUB32(ctx->r24, ctx->r25);
    // 0x80309BEC: bgez        $v0, L_80309BFC
    if (SIGNED(ctx->r2) >= 0) {
        // 0x80309BF0: subu        $a2, $t1, $t2
        ctx->r6 = SUB32(ctx->r9, ctx->r10);
            goto L_80309BFC;
    }
    // 0x80309BF0: subu        $a2, $t1, $t2
    ctx->r6 = SUB32(ctx->r9, ctx->r10);
    // 0x80309BF4: b           L_80309C00
    // 0x80309BF8: negu        $a3, $v0
    ctx->r7 = SUB32(0, ctx->r2);
        goto L_80309C00;
    // 0x80309BF8: negu        $a3, $v0
    ctx->r7 = SUB32(0, ctx->r2);
L_80309BFC:
    // 0x80309BFC: or          $a3, $v0, $zero
    ctx->r7 = ctx->r2 | 0;
L_80309C00:
    // 0x80309C00: bgez        $a2, L_80309C10
    if (SIGNED(ctx->r6) >= 0) {
        // 0x80309C04: or          $v1, $a2, $zero
        ctx->r3 = ctx->r6 | 0;
            goto L_80309C10;
    }
    // 0x80309C04: or          $v1, $a2, $zero
    ctx->r3 = ctx->r6 | 0;
    // 0x80309C08: b           L_80309C10
    // 0x80309C0C: negu        $v1, $a2
    ctx->r3 = SUB32(0, ctx->r6);
        goto L_80309C10;
    // 0x80309C0C: negu        $v1, $a2
    ctx->r3 = SUB32(0, ctx->r6);
L_80309C10:
    // 0x80309C10: lh          $t4, 0x30($a1)
    ctx->r12 = MEM_H(ctx->r5, 0X30);
    // 0x80309C14: lh          $t6, 0x30($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X30);
    // 0x80309C18: addu        $t3, $v1, $a3
    ctx->r11 = ADD32(ctx->r3, ctx->r7);
    // 0x80309C1C: subu        $t5, $t3, $t4
    ctx->r13 = SUB32(ctx->r11, ctx->r12);
    // 0x80309C20: subu        $v0, $t5, $t6
    ctx->r2 = SUB32(ctx->r13, ctx->r14);
    // 0x80309C24: bgtz        $v0, L_80309C30
    if (SIGNED(ctx->r2) > 0) {
        // 0x80309C28: lui         $t8, 0x803D
        ctx->r24 = S32(0X803D << 16);
            goto L_80309C30;
    }
    // 0x80309C28: lui         $t8, 0x803D
    ctx->r24 = S32(0X803D << 16);
    // 0x80309C2C: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_80309C30:
    // 0x80309C30: slti        $at, $v0, 0x140
    ctx->r1 = SIGNED(ctx->r2) < 0X140 ? 1 : 0;
    // 0x80309C34: beql        $at, $zero, L_80309C7C
    if (ctx->r1 == 0) {
        // 0x80309C38: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80309C7C;
    }
    goto skip_2;
    // 0x80309C38: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_2:
    // 0x80309C3C: lw          $t8, 0x5530($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X5530);
    // 0x80309C40: lui         $t3, 0x803A
    ctx->r11 = S32(0X803A << 16);
    // 0x80309C44: lw          $t7, 0x54($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X54);
    // 0x80309C48: lw          $t9, 0x16C($t8)
    ctx->r25 = MEM_W(ctx->r24, 0X16C);
    // 0x80309C4C: lhu         $t1, 0x0($t9)
    ctx->r9 = MEM_HU(ctx->r25, 0X0);
    // 0x80309C50: sll         $t2, $t1, 1
    ctx->r10 = S32(ctx->r9 << 1);
    // 0x80309C54: addu        $t3, $t3, $t2
    ctx->r11 = ADD32(ctx->r11, ctx->r10);
    // 0x80309C58: lhu         $t3, 0x4638($t3)
    ctx->r11 = MEM_HU(ctx->r11, 0X4638);
    // 0x80309C5C: slt         $at, $t7, $t3
    ctx->r1 = SIGNED(ctx->r15) < SIGNED(ctx->r11) ? 1 : 0;
    // 0x80309C60: beql        $at, $zero, L_80309C7C
    if (ctx->r1 == 0) {
        // 0x80309C64: or          $v0, $zero, $zero
        ctx->r2 = 0 | 0;
            goto L_80309C7C;
    }
    goto skip_3;
    // 0x80309C64: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    skip_3:
    // 0x80309C68: jal         0x80309798
    // 0x80309C6C: nop

    func_80309798_71AE48(rdram, ctx);
        goto after_0;
    // 0x80309C6C: nop

    after_0:
    // 0x80309C70: b           L_80309C80
    // 0x80309C74: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80309C80;
    // 0x80309C74: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80309C78: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
L_80309C7C:
    // 0x80309C7C: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80309C80:
    // 0x80309C80: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80309C84: jr          $ra
    // 0x80309C88: nop

    return;
    // 0x80309C88: nop

;}
RECOMP_FUNC void func_80309C8C_71B33C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80309C8C: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x80309C90: addiu       $a1, $a1, 0x552C
    ctx->r5 = ADD32(ctx->r5, 0X552C);
    // 0x80309C94: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x80309C98: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x80309C9C: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x80309CA0: lbu         $t6, 0x270($v0)
    ctx->r14 = MEM_BU(ctx->r2, 0X270);
    // 0x80309CA4: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x80309CA8: beql        $t6, $zero, L_80309CBC
    if (ctx->r14 == 0) {
        // 0x80309CAC: lbu         $v1, 0x287($v0)
        ctx->r3 = MEM_BU(ctx->r2, 0X287);
            goto L_80309CBC;
    }
    goto skip_0;
    // 0x80309CAC: lbu         $v1, 0x287($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X287);
    skip_0:
    // 0x80309CB0: sb          $zero, 0x287($v0)
    MEM_B(0X287, ctx->r2) = 0;
    // 0x80309CB4: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x80309CB8: lbu         $v1, 0x287($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X287);
L_80309CBC:
    // 0x80309CBC: beql        $v1, $zero, L_80309DB8
    if (ctx->r3 == 0) {
        // 0x80309CC0: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80309DB8;
    }
    goto skip_1;
    // 0x80309CC0: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_1:
    // 0x80309CC4: beq         $v1, $at, L_80309CDC
    if (ctx->r3 == ctx->r1) {
        // 0x80309CC8: addiu       $at, $zero, 0x2
        ctx->r1 = ADD32(0, 0X2);
            goto L_80309CDC;
    }
    // 0x80309CC8: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80309CCC: beql        $v1, $at, L_80309D7C
    if (ctx->r3 == ctx->r1) {
        // 0x80309CD0: lbu         $t7, 0x28A($v0)
        ctx->r15 = MEM_BU(ctx->r2, 0X28A);
            goto L_80309D7C;
    }
    goto skip_2;
    // 0x80309CD0: lbu         $t7, 0x28A($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X28A);
    skip_2:
    // 0x80309CD4: b           L_80309DB8
    // 0x80309CD8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80309DB8;
    // 0x80309CD8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80309CDC:
    // 0x80309CDC: lbu         $t7, 0x28A($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X28A);
    // 0x80309CE0: lui         $t8, 0x803E
    ctx->r24 = S32(0X803E << 16);
    // 0x80309CE4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80309CE8: bnel        $t7, $zero, L_80309D04
    if (ctx->r15 != 0) {
        // 0x80309CEC: sb          $zero, 0x287($v0)
        MEM_B(0X287, ctx->r2) = 0;
            goto L_80309D04;
    }
    goto skip_3;
    // 0x80309CEC: sb          $zero, 0x287($v0)
    MEM_B(0X287, ctx->r2) = 0;
    skip_3:
    // 0x80309CF0: lw          $t8, 0x4C3C($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X4C3C);
    // 0x80309CF4: slti        $at, $t8, 0x280
    ctx->r1 = SIGNED(ctx->r24) < 0X280 ? 1 : 0;
    // 0x80309CF8: beql        $at, $zero, L_80309D18
    if (ctx->r1 == 0) {
        // 0x80309CFC: lhu         $t9, 0x288($v0)
        ctx->r25 = MEM_HU(ctx->r2, 0X288);
            goto L_80309D18;
    }
    goto skip_4;
    // 0x80309CFC: lhu         $t9, 0x288($v0)
    ctx->r25 = MEM_HU(ctx->r2, 0X288);
    skip_4:
    // 0x80309D00: sb          $zero, 0x287($v0)
    MEM_B(0X287, ctx->r2) = 0;
L_80309D04:
    // 0x80309D04: jal         0x80363CC8
    // 0x80309D08: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    set_nav_state_idle(rdram, ctx);
        goto after_0;
    // 0x80309D08: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    after_0:
    // 0x80309D0C: b           L_80309DB8
    // 0x80309D10: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_80309DB8;
    // 0x80309D10: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    // 0x80309D14: lhu         $t9, 0x288($v0)
    ctx->r25 = MEM_HU(ctx->r2, 0X288);
L_80309D18:
    // 0x80309D18: lui         $a0, 0x803A
    ctx->r4 = S32(0X803A << 16);
    // 0x80309D1C: addiu       $t0, $t9, -0x1
    ctx->r8 = ADD32(ctx->r25, -0X1);
    // 0x80309D20: sh          $t0, 0x288($v0)
    MEM_H(0X288, ctx->r2) = ctx->r8;
    // 0x80309D24: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x80309D28: lhu         $t1, 0x288($v0)
    ctx->r9 = MEM_HU(ctx->r2, 0X288);
    // 0x80309D2C: bgtzl       $t1, L_80309DB8
    if (SIGNED(ctx->r9) > 0) {
        // 0x80309D30: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80309DB8;
    }
    goto skip_5;
    // 0x80309D30: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_5:
    // 0x80309D34: lb          $a0, 0x5580($a0)
    ctx->r4 = MEM_B(ctx->r4, 0X5580);
    // 0x80309D38: lui         $at, 0x803A
    ctx->r1 = S32(0X803A << 16);
    // 0x80309D3C: andi        $v1, $a0, 0x3
    ctx->r3 = ctx->r4 & 0X3;
    // 0x80309D40: sltiu       $t2, $v1, 0x1
    ctx->r10 = ctx->r3 < 0X1 ? 1 : 0;
    // 0x80309D44: addiu       $t4, $a0, 0x1
    ctx->r12 = ADD32(ctx->r4, 0X1);
    // 0x80309D48: beq         $t2, $zero, L_80309D64
    if (ctx->r10 == 0) {
        // 0x80309D4C: sb          $t4, 0x5580($at)
        MEM_B(0X5580, ctx->r1) = ctx->r12;
            goto L_80309D64;
    }
    // 0x80309D4C: sb          $t4, 0x5580($at)
    MEM_B(0X5580, ctx->r1) = ctx->r12;
    // 0x80309D50: jal         0x8037FEDC
    // 0x80309D54: nop

    sheep_follow_leader(rdram, ctx);
        goto after_1;
    // 0x80309D54: nop

    after_1:
    // 0x80309D58: lui         $a1, 0x803D
    ctx->r5 = S32(0X803D << 16);
    // 0x80309D5C: addiu       $a1, $a1, 0x552C
    ctx->r5 = ADD32(ctx->r5, 0X552C);
    // 0x80309D60: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
L_80309D64:
    // 0x80309D64: addiu       $t5, $zero, 0x2
    ctx->r13 = ADD32(0, 0X2);
    // 0x80309D68: sb          $t5, 0x287($v0)
    MEM_B(0X287, ctx->r2) = ctx->r13;
    // 0x80309D6C: lw          $t6, 0x0($a1)
    ctx->r14 = MEM_W(ctx->r5, 0X0);
    // 0x80309D70: b           L_80309DB4
    // 0x80309D74: sh          $zero, 0x288($t6)
    MEM_H(0X288, ctx->r14) = 0;
        goto L_80309DB4;
    // 0x80309D74: sh          $zero, 0x288($t6)
    MEM_H(0X288, ctx->r14) = 0;
    // 0x80309D78: lbu         $t7, 0x28A($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X28A);
L_80309D7C:
    // 0x80309D7C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80309D80: bnel        $t7, $zero, L_80309DAC
    if (ctx->r15 != 0) {
        // 0x80309D84: sb          $zero, 0x287($v0)
        MEM_B(0X287, ctx->r2) = 0;
            goto L_80309DAC;
    }
    goto skip_6;
    // 0x80309D84: sb          $zero, 0x287($v0)
    MEM_B(0X287, ctx->r2) = 0;
    skip_6:
    // 0x80309D88: lhu         $t8, 0x288($v0)
    ctx->r24 = MEM_HU(ctx->r2, 0X288);
    // 0x80309D8C: addiu       $t9, $t8, 0x1
    ctx->r25 = ADD32(ctx->r24, 0X1);
    // 0x80309D90: sh          $t9, 0x288($v0)
    MEM_H(0X288, ctx->r2) = ctx->r25;
    // 0x80309D94: lw          $v0, 0x0($a1)
    ctx->r2 = MEM_W(ctx->r5, 0X0);
    // 0x80309D98: lhu         $t0, 0x288($v0)
    ctx->r8 = MEM_HU(ctx->r2, 0X288);
    // 0x80309D9C: slti        $at, $t0, 0x46
    ctx->r1 = SIGNED(ctx->r8) < 0X46 ? 1 : 0;
    // 0x80309DA0: bnel        $at, $zero, L_80309DB8
    if (ctx->r1 != 0) {
        // 0x80309DA4: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_80309DB8;
    }
    goto skip_7;
    // 0x80309DA4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_7:
    // 0x80309DA8: sb          $zero, 0x287($v0)
    MEM_B(0X287, ctx->r2) = 0;
L_80309DAC:
    // 0x80309DAC: jal         0x80363CC8
    // 0x80309DB0: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    set_nav_state_idle(rdram, ctx);
        goto after_2;
    // 0x80309DB0: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    after_2:
L_80309DB4:
    // 0x80309DB4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_80309DB8:
    // 0x80309DB8: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x80309DBC: jr          $ra
    // 0x80309DC0: nop

    return;
    // 0x80309DC0: nop

;}
RECOMP_FUNC void func_80309DC4_71B474(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80309DC4: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80309DC8: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80309DCC: lbu         $v1, 0x18C($v0)
    ctx->r3 = MEM_BU(ctx->r2, 0X18C);
    // 0x80309DD0: bne         $v1, $zero, L_80309DE0
    if (ctx->r3 != 0) {
        // 0x80309DD4: nop
    
            goto L_80309DE0;
    }
    // 0x80309DD4: nop

    // 0x80309DD8: jr          $ra
    // 0x80309DDC: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    return;
    // 0x80309DDC: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_80309DE0:
    // 0x80309DE0: blez        $v1, L_80309E40
    if (SIGNED(ctx->r3) <= 0) {
        // 0x80309DE4: or          $a0, $zero, $zero
        ctx->r4 = 0 | 0;
            goto L_80309E40;
    }
    // 0x80309DE4: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    // 0x80309DE8: lbu         $a2, 0x192($v0)
    ctx->r6 = MEM_BU(ctx->r2, 0X192);
L_80309DEC:
    // 0x80309DEC: blez        $a2, L_80309E28
    if (SIGNED(ctx->r6) <= 0) {
        // 0x80309DF0: or          $a1, $zero, $zero
        ctx->r5 = 0 | 0;
            goto L_80309E28;
    }
    // 0x80309DF0: or          $a1, $zero, $zero
    ctx->r5 = 0 | 0;
    // 0x80309DF4: addu        $t6, $v0, $a0
    ctx->r14 = ADD32(ctx->r2, ctx->r4);
    // 0x80309DF8: lbu         $a3, 0x18D($t6)
    ctx->r7 = MEM_BU(ctx->r14, 0X18D);
    // 0x80309DFC: addu        $t7, $v0, $a1
    ctx->r15 = ADD32(ctx->r2, ctx->r5);
L_80309E00:
    // 0x80309E00: lbu         $t8, 0x193($t7)
    ctx->r24 = MEM_BU(ctx->r15, 0X193);
    // 0x80309E04: addiu       $a1, $a1, 0x1
    ctx->r5 = ADD32(ctx->r5, 0X1);
    // 0x80309E08: sll         $t9, $a1, 16
    ctx->r25 = S32(ctx->r5 << 16);
    // 0x80309E0C: bne         $t8, $a3, L_80309E1C
    if (ctx->r24 != ctx->r7) {
        // 0x80309E10: sra         $a1, $t9, 16
        ctx->r5 = S32(SIGNED(ctx->r25) >> 16);
            goto L_80309E1C;
    }
    // 0x80309E10: sra         $a1, $t9, 16
    ctx->r5 = S32(SIGNED(ctx->r25) >> 16);
    // 0x80309E14: jr          $ra
    // 0x80309E18: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
    return;
    // 0x80309E18: addiu       $v0, $zero, 0x1
    ctx->r2 = ADD32(0, 0X1);
L_80309E1C:
    // 0x80309E1C: slt         $at, $a1, $a2
    ctx->r1 = SIGNED(ctx->r5) < SIGNED(ctx->r6) ? 1 : 0;
    // 0x80309E20: bnel        $at, $zero, L_80309E00
    if (ctx->r1 != 0) {
        // 0x80309E24: addu        $t7, $v0, $a1
        ctx->r15 = ADD32(ctx->r2, ctx->r5);
            goto L_80309E00;
    }
    goto skip_0;
    // 0x80309E24: addu        $t7, $v0, $a1
    ctx->r15 = ADD32(ctx->r2, ctx->r5);
    skip_0:
L_80309E28:
    // 0x80309E28: addiu       $a0, $a0, 0x1
    ctx->r4 = ADD32(ctx->r4, 0X1);
    // 0x80309E2C: sll         $t1, $a0, 16
    ctx->r9 = S32(ctx->r4 << 16);
    // 0x80309E30: sra         $a0, $t1, 16
    ctx->r4 = S32(SIGNED(ctx->r9) >> 16);
    // 0x80309E34: slt         $at, $a0, $v1
    ctx->r1 = SIGNED(ctx->r4) < SIGNED(ctx->r3) ? 1 : 0;
    // 0x80309E38: bne         $at, $zero, L_80309DEC
    if (ctx->r1 != 0) {
        // 0x80309E3C: nop
    
            goto L_80309DEC;
    }
    // 0x80309E3C: nop

L_80309E40:
    // 0x80309E40: or          $v0, $zero, $zero
    ctx->r2 = 0 | 0;
    // 0x80309E44: jr          $ra
    // 0x80309E48: nop

    return;
    // 0x80309E48: nop

;}
RECOMP_FUNC void func_80309E4C_71B4FC(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80309E4C: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80309E50: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x80309E54: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
    // 0x80309E58: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x80309E5C: lui         $t5, 0x801E
    ctx->r13 = S32(0X801E << 16);
    // 0x80309E60: sw          $zero, 0x2B8($t6)
    MEM_W(0X2B8, ctx->r14) = 0;
    // 0x80309E64: lw          $t7, 0x0($v1)
    ctx->r15 = MEM_W(ctx->r3, 0X0);
    // 0x80309E68: sw          $zero, 0x2BC($t7)
    MEM_W(0X2BC, ctx->r15) = 0;
    // 0x80309E6C: lw          $t8, 0x0($v1)
    ctx->r24 = MEM_W(ctx->r3, 0X0);
    // 0x80309E70: sw          $zero, 0x2C0($t8)
    MEM_W(0X2C0, ctx->r24) = 0;
    // 0x80309E74: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x80309E78: lbu         $t9, 0x2B4($v0)
    ctx->r25 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80309E7C: andi        $t0, $t9, 0xFF0F
    ctx->r8 = ctx->r25 & 0XFF0F;
    // 0x80309E80: sb          $t0, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r8;
    // 0x80309E84: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x80309E88: lhu         $t1, 0x272($v0)
    ctx->r9 = MEM_HU(ctx->r2, 0X272);
    // 0x80309E8C: sh          $t1, 0x2C8($v0)
    MEM_H(0X2C8, ctx->r2) = ctx->r9;
    // 0x80309E90: lw          $t2, 0x0($v1)
    ctx->r10 = MEM_W(ctx->r3, 0X0);
    // 0x80309E94: sw          $a0, 0x2CC($t2)
    MEM_W(0X2CC, ctx->r10) = ctx->r4;
    // 0x80309E98: lh          $t3, 0x5534($t3)
    ctx->r11 = MEM_H(ctx->r11, 0X5534);
    // 0x80309E9C: sll         $t4, $t3, 3
    ctx->r12 = S32(ctx->r11 << 3);
    // 0x80309EA0: addu        $t5, $t5, $t4
    ctx->r13 = ADD32(ctx->r13, ctx->r12);
    // 0x80309EA4: lw          $t5, -0x2274($t5)
    ctx->r13 = MEM_W(ctx->r13, -0X2274);
    // 0x80309EA8: bnel        $a0, $t5, L_80309EC8
    if (ctx->r4 != ctx->r13) {
        // 0x80309EAC: lw          $v0, 0x0($v1)
        ctx->r2 = MEM_W(ctx->r3, 0X0);
            goto L_80309EC8;
    }
    goto skip_0;
    // 0x80309EAC: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    skip_0:
    // 0x80309EB0: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x80309EB4: lbu         $t7, 0x2B4($v0)
    ctx->r15 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80309EB8: ori         $t8, $t7, 0x1
    ctx->r24 = ctx->r15 | 0X1;
    // 0x80309EBC: jr          $ra
    // 0x80309EC0: sb          $t8, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r24;
    return;
    // 0x80309EC0: sb          $t8, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r24;
    // 0x80309EC4: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
L_80309EC8:
    // 0x80309EC8: lbu         $t9, 0x2B4($v0)
    ctx->r25 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80309ECC: andi        $t0, $t9, 0xFFFE
    ctx->r8 = ctx->r25 & 0XFFFE;
    // 0x80309ED0: sb          $t0, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r8;
    // 0x80309ED4: jr          $ra
    // 0x80309ED8: nop

    return;
    // 0x80309ED8: nop

;}
RECOMP_FUNC void func_80309EDC_71B58C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80309EDC: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x80309EE0: addiu       $v1, $v1, 0x552C
    ctx->r3 = ADD32(ctx->r3, 0X552C);
    // 0x80309EE4: lw          $t6, 0x0($v1)
    ctx->r14 = MEM_W(ctx->r3, 0X0);
    // 0x80309EE8: lui         $t7, 0x803D
    ctx->r15 = S32(0X803D << 16);
    // 0x80309EEC: lui         $t9, 0x801E
    ctx->r25 = S32(0X801E << 16);
    // 0x80309EF0: sw          $a0, 0x2CC($t6)
    MEM_W(0X2CC, ctx->r14) = ctx->r4;
    // 0x80309EF4: lh          $t7, 0x5534($t7)
    ctx->r15 = MEM_H(ctx->r15, 0X5534);
    // 0x80309EF8: sll         $t8, $t7, 3
    ctx->r24 = S32(ctx->r15 << 3);
    // 0x80309EFC: addu        $t9, $t9, $t8
    ctx->r25 = ADD32(ctx->r25, ctx->r24);
    // 0x80309F00: lw          $t9, -0x2274($t9)
    ctx->r25 = MEM_W(ctx->r25, -0X2274);
    // 0x80309F04: bnel        $a0, $t9, L_80309F24
    if (ctx->r4 != ctx->r25) {
        // 0x80309F08: lw          $v0, 0x0($v1)
        ctx->r2 = MEM_W(ctx->r3, 0X0);
            goto L_80309F24;
    }
    goto skip_0;
    // 0x80309F08: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    skip_0:
    // 0x80309F0C: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
    // 0x80309F10: lbu         $t1, 0x2B4($v0)
    ctx->r9 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80309F14: ori         $t2, $t1, 0x1
    ctx->r10 = ctx->r9 | 0X1;
    // 0x80309F18: jr          $ra
    // 0x80309F1C: sb          $t2, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r10;
    return;
    // 0x80309F1C: sb          $t2, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r10;
    // 0x80309F20: lw          $v0, 0x0($v1)
    ctx->r2 = MEM_W(ctx->r3, 0X0);
L_80309F24:
    // 0x80309F24: lbu         $t3, 0x2B4($v0)
    ctx->r11 = MEM_BU(ctx->r2, 0X2B4);
    // 0x80309F28: andi        $t4, $t3, 0xFFFE
    ctx->r12 = ctx->r11 & 0XFFFE;
    // 0x80309F2C: sb          $t4, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r12;
    // 0x80309F30: jr          $ra
    // 0x80309F34: nop

    return;
    // 0x80309F34: nop

;}
RECOMP_FUNC void func_80309F38_71B5E8(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x80309F38: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80309F3C: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80309F40: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x80309F44: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x80309F48: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x80309F4C: lw          $v1, 0x2C4($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X2C4);
    // 0x80309F50: blez        $v1, L_80309F5C
    if (SIGNED(ctx->r3) <= 0) {
        // 0x80309F54: addiu       $t6, $v1, -0x1
        ctx->r14 = ADD32(ctx->r3, -0X1);
            goto L_80309F5C;
    }
    // 0x80309F54: addiu       $t6, $v1, -0x1
    ctx->r14 = ADD32(ctx->r3, -0X1);
    // 0x80309F58: sw          $t6, 0x2C4($v0)
    MEM_W(0X2C4, ctx->r2) = ctx->r14;
L_80309F5C:
    // 0x80309F5C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x80309F60: lw          $v0, 0x5530($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5530);
    // 0x80309F64: lh          $a0, 0x4($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X4);
    // 0x80309F68: lh          $a1, 0x8($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X8);
    // 0x80309F6C: lh          $a2, 0xC($v0)
    ctx->r6 = MEM_H(ctx->r2, 0XC);
    // 0x80309F70: addiu       $t4, $v0, 0x192
    ctx->r12 = ADD32(ctx->r2, 0X192);
    // 0x80309F74: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x80309F78: lbu         $t5, 0x160($v0)
    ctx->r13 = MEM_BU(ctx->r2, 0X160);
    // 0x80309F7C: sra         $t7, $a0, 6
    ctx->r15 = S32(SIGNED(ctx->r4) >> 6);
    // 0x80309F80: sra         $t9, $a1, 6
    ctx->r25 = S32(SIGNED(ctx->r5) >> 6);
    // 0x80309F84: sra         $t2, $a2, 6
    ctx->r10 = S32(SIGNED(ctx->r6) >> 6);
    // 0x80309F88: andi        $a2, $t2, 0xFF
    ctx->r6 = ctx->r10 & 0XFF;
    // 0x80309F8C: andi        $a1, $t9, 0xFF
    ctx->r5 = ctx->r25 & 0XFF;
    // 0x80309F90: andi        $a0, $t7, 0xFF
    ctx->r4 = ctx->r15 & 0XFF;
    // 0x80309F94: addiu       $a3, $v0, 0x193
    ctx->r7 = ADD32(ctx->r2, 0X193);
    // 0x80309F98: jal         0x80319C38
    // 0x80309F9C: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    func_80319C38_72B2E8(rdram, ctx);
        goto after_0;
    // 0x80309F9C: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    after_0:
    // 0x80309FA0: jal         0x80309DC4
    // 0x80309FA4: nop

    func_80309DC4_71B474(rdram, ctx);
        goto after_1;
    // 0x80309FA4: nop

    after_1:
    // 0x80309FA8: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x80309FAC: lw          $t6, 0x5530($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X5530);
    // 0x80309FB0: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x80309FB4: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x80309FB8: sb          $v0, 0x197($t6)
    MEM_B(0X197, ctx->r14) = ctx->r2;
    // 0x80309FBC: lw          $t7, 0x0($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X0);
    // 0x80309FC0: addiu       $at, $zero, 0x2
    ctx->r1 = ADD32(0, 0X2);
    // 0x80309FC4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x80309FC8: lbu         $t8, 0x270($t7)
    ctx->r24 = MEM_BU(ctx->r15, 0X270);
    // 0x80309FCC: beq         $t8, $at, L_8030A060
    if (ctx->r24 == ctx->r1) {
        // 0x80309FD0: nop
    
            goto L_8030A060;
    }
    // 0x80309FD0: nop

    // 0x80309FD4: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    // 0x80309FD8: lui         $t3, 0x803F
    ctx->r11 = S32(0X803F << 16);
    // 0x80309FDC: lbu         $t9, 0x197($a0)
    ctx->r25 = MEM_BU(ctx->r4, 0X197);
    // 0x80309FE0: bnel        $t9, $zero, L_8030A05C
    if (ctx->r25 != 0) {
        // 0x80309FE4: lbu         $t1, 0x193($a0)
        ctx->r9 = MEM_BU(ctx->r4, 0X193);
            goto L_8030A05C;
    }
    goto skip_0;
    // 0x80309FE4: lbu         $t1, 0x193($a0)
    ctx->r9 = MEM_BU(ctx->r4, 0X193);
    skip_0:
    // 0x80309FE8: lbu         $t1, 0x191($a0)
    ctx->r9 = MEM_BU(ctx->r4, 0X191);
    // 0x80309FEC: addiu       $t3, $t3, -0x6C50
    ctx->r11 = ADD32(ctx->r11, -0X6C50);
    // 0x80309FF0: addiu       $a3, $zero, -0x1
    ctx->r7 = ADD32(0, -0X1);
    // 0x80309FF4: sll         $t2, $t1, 3
    ctx->r10 = S32(ctx->r9 << 3);
    // 0x80309FF8: addu        $v0, $t2, $t3
    ctx->r2 = ADD32(ctx->r10, ctx->r11);
    // 0x80309FFC: lbu         $t4, 0x3($v0)
    ctx->r12 = MEM_BU(ctx->r2, 0X3);
    // 0x8030A000: lbu         $t5, 0x0($v0)
    ctx->r13 = MEM_BU(ctx->r2, 0X0);
    // 0x8030A004: lbu         $t9, 0x4($v0)
    ctx->r25 = MEM_BU(ctx->r2, 0X4);
    // 0x8030A008: lbu         $t1, 0x1($v0)
    ctx->r9 = MEM_BU(ctx->r2, 0X1);
    // 0x8030A00C: addu        $t6, $t4, $t5
    ctx->r14 = ADD32(ctx->r12, ctx->r13);
    // 0x8030A010: sll         $t7, $t6, 21
    ctx->r15 = S32(ctx->r14 << 21);
    // 0x8030A014: addu        $t2, $t9, $t1
    ctx->r10 = ADD32(ctx->r25, ctx->r9);
    // 0x8030A018: sll         $t3, $t2, 21
    ctx->r11 = S32(ctx->r10 << 21);
    // 0x8030A01C: addiu       $t6, $zero, 0x20
    ctx->r14 = ADD32(0, 0X20);
    // 0x8030A020: addiu       $t5, $zero, 0x10
    ctx->r13 = ADD32(0, 0X10);
    // 0x8030A024: sw          $t5, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r13;
    // 0x8030A028: sw          $t6, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r14;
    // 0x8030A02C: sra         $a2, $t3, 16
    ctx->r6 = S32(SIGNED(ctx->r11) >> 16);
    // 0x8030A030: jal         0x80363C48
    // 0x8030A034: sra         $a1, $t7, 16
    ctx->r5 = S32(SIGNED(ctx->r15) >> 16);
    set_nav_state_goto_point(rdram, ctx);
        goto after_2;
    // 0x8030A034: sra         $a1, $t7, 16
    ctx->r5 = S32(SIGNED(ctx->r15) >> 16);
    after_2:
    // 0x8030A038: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030A03C: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8030A040: lw          $t8, 0x0($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X0);
    // 0x8030A044: addiu       $t7, $zero, 0x2
    ctx->r15 = ADD32(0, 0X2);
    // 0x8030A048: sb          $t7, 0x270($t8)
    MEM_B(0X270, ctx->r24) = ctx->r15;
    // 0x8030A04C: lw          $t9, 0x0($t0)
    ctx->r25 = MEM_W(ctx->r8, 0X0);
    // 0x8030A050: b           L_8030A060
    // 0x8030A054: sw          $zero, 0x2CC($t9)
    MEM_W(0X2CC, ctx->r25) = 0;
        goto L_8030A060;
    // 0x8030A054: sw          $zero, 0x2CC($t9)
    MEM_W(0X2CC, ctx->r25) = 0;
    // 0x8030A058: lbu         $t1, 0x193($a0)
    ctx->r9 = MEM_BU(ctx->r4, 0X193);
L_8030A05C:
    // 0x8030A05C: sb          $t1, 0x191($a0)
    MEM_B(0X191, ctx->r4) = ctx->r9;
L_8030A060:
    // 0x8030A060: lui         $a0, 0x803E
    ctx->r4 = S32(0X803E << 16);
    // 0x8030A064: jal         0x80305368
    // 0x8030A068: addiu       $a0, $a0, 0x4BE0
    ctx->r4 = ADD32(ctx->r4, 0X4BE0);
    func_80305368_716A18(rdram, ctx);
        goto after_3;
    // 0x8030A068: addiu       $a0, $a0, 0x4BE0
    ctx->r4 = ADD32(ctx->r4, 0X4BE0);
    after_3:
    // 0x8030A06C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030A070: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8030A074: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8030A078: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x8030A07C: addiu       $a3, $a3, 0x5530
    ctx->r7 = ADD32(ctx->r7, 0X5530);
    // 0x8030A080: lw          $a2, 0x2CC($v0)
    ctx->r6 = MEM_W(ctx->r2, 0X2CC);
    // 0x8030A084: beql        $a2, $zero, L_8030A12C
    if (ctx->r6 == 0) {
        // 0x8030A088: lw          $v1, 0x280($v0)
        ctx->r3 = MEM_W(ctx->r2, 0X280);
            goto L_8030A12C;
    }
    goto skip_1;
    // 0x8030A088: lw          $v1, 0x280($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X280);
    skip_1:
    // 0x8030A08C: lw          $a0, 0x0($a3)
    ctx->r4 = MEM_W(ctx->r7, 0X0);
    // 0x8030A090: lh          $t2, 0x4($a2)
    ctx->r10 = MEM_H(ctx->r6, 0X4);
    // 0x8030A094: lh          $t4, 0x8($a2)
    ctx->r12 = MEM_H(ctx->r6, 0X8);
    // 0x8030A098: lh          $t3, 0x4($a0)
    ctx->r11 = MEM_H(ctx->r4, 0X4);
    // 0x8030A09C: lh          $t5, 0x8($a0)
    ctx->r13 = MEM_H(ctx->r4, 0X8);
    // 0x8030A0A0: subu        $v1, $t2, $t3
    ctx->r3 = SUB32(ctx->r10, ctx->r11);
    // 0x8030A0A4: multu       $v1, $v1
    result = U64(U32(ctx->r3)) * U64(U32(ctx->r3)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8030A0A8: subu        $a1, $t4, $t5
    ctx->r5 = SUB32(ctx->r12, ctx->r13);
    // 0x8030A0AC: lui         $t3, 0x803D
    ctx->r11 = S32(0X803D << 16);
    // 0x8030A0B0: mflo        $t6
    ctx->r14 = lo;
    // 0x8030A0B4: nop

    // 0x8030A0B8: nop

    // 0x8030A0BC: multu       $a1, $a1
    result = U64(U32(ctx->r5)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8030A0C0: mflo        $t7
    ctx->r15 = lo;
    // 0x8030A0C4: addu        $t8, $t6, $t7
    ctx->r24 = ADD32(ctx->r14, ctx->r15);
    // 0x8030A0C8: mtc1        $t8, $f4
    ctx->f4.u32l = ctx->r24;
    // 0x8030A0CC: nop

    // 0x8030A0D0: cvt.s.w     $f0, $f4
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 4);
    ctx->f0.fl = CVT_S_W(ctx->f4.u32l);
    // 0x8030A0D4: sqrt.s      $f0, $f0
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f0.fl = sqrtf(ctx->f0.fl);
    // 0x8030A0D8: trunc.w.s   $f6, $f0
    CHECK_FR(ctx, 6);
    CHECK_FR(ctx, 0);
    ctx->f6.u32l = TRUNC_W_S(ctx->f0.fl);
    // 0x8030A0DC: mfc1        $t1, $f6
    ctx->r9 = (int32_t)ctx->f6.u32l;
    // 0x8030A0E0: nop

    // 0x8030A0E4: sh          $t1, 0x2D0($v0)
    MEM_H(0X2D0, ctx->r2) = ctx->r9;
    // 0x8030A0E8: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8030A0EC: lw          $t3, 0x5524($t3)
    ctx->r11 = MEM_W(ctx->r11, 0X5524);
    // 0x8030A0F0: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
    // 0x8030A0F4: lw          $t6, 0x2CC($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X2CC);
    // 0x8030A0F8: lh          $t2, 0x2D0($v0)
    ctx->r10 = MEM_H(ctx->r2, 0X2D0);
    // 0x8030A0FC: lhu         $t4, 0xBE($t3)
    ctx->r12 = MEM_HU(ctx->r11, 0XBE);
    // 0x8030A100: lh          $t7, 0x30($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X30);
    // 0x8030A104: subu        $t5, $t2, $t4
    ctx->r13 = SUB32(ctx->r10, ctx->r12);
    // 0x8030A108: subu        $t8, $t5, $t7
    ctx->r24 = SUB32(ctx->r13, ctx->r15);
    // 0x8030A10C: sh          $t8, 0x2D0($v0)
    MEM_H(0X2D0, ctx->r2) = ctx->r24;
    // 0x8030A110: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8030A114: lh          $t9, 0x2D0($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X2D0);
    // 0x8030A118: bgezl       $t9, L_8030A12C
    if (SIGNED(ctx->r25) >= 0) {
        // 0x8030A11C: lw          $v1, 0x280($v0)
        ctx->r3 = MEM_W(ctx->r2, 0X280);
            goto L_8030A12C;
    }
    goto skip_2;
    // 0x8030A11C: lw          $v1, 0x280($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X280);
    skip_2:
    // 0x8030A120: sh          $t1, 0x2D0($v0)
    MEM_H(0X2D0, ctx->r2) = ctx->r9;
    // 0x8030A124: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8030A128: lw          $v1, 0x280($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X280);
L_8030A12C:
    // 0x8030A12C: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x8030A130: addiu       $a3, $a3, 0x5530
    ctx->r7 = ADD32(ctx->r7, 0X5530);
    // 0x8030A134: beql        $v1, $zero, L_8030A1DC
    if (ctx->r3 == 0) {
        // 0x8030A138: lbu         $t2, 0x270($v0)
        ctx->r10 = MEM_BU(ctx->r2, 0X270);
            goto L_8030A1DC;
    }
    goto skip_3;
    // 0x8030A138: lbu         $t2, 0x270($v0)
    ctx->r10 = MEM_BU(ctx->r2, 0X270);
    skip_3:
    // 0x8030A13C: lw          $a0, 0x0($a3)
    ctx->r4 = MEM_W(ctx->r7, 0X0);
    // 0x8030A140: lh          $t3, 0x4($v1)
    ctx->r11 = MEM_H(ctx->r3, 0X4);
    // 0x8030A144: lh          $t4, 0x8($v1)
    ctx->r12 = MEM_H(ctx->r3, 0X8);
    // 0x8030A148: lh          $t2, 0x4($a0)
    ctx->r10 = MEM_H(ctx->r4, 0X4);
    // 0x8030A14C: lh          $t6, 0x8($a0)
    ctx->r14 = MEM_H(ctx->r4, 0X8);
    // 0x8030A150: subu        $a1, $t3, $t2
    ctx->r5 = SUB32(ctx->r11, ctx->r10);
    // 0x8030A154: multu       $a1, $a1
    result = U64(U32(ctx->r5)) * U64(U32(ctx->r5)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8030A158: subu        $a2, $t4, $t6
    ctx->r6 = SUB32(ctx->r12, ctx->r14);
    // 0x8030A15C: lui         $t2, 0x803D
    ctx->r10 = S32(0X803D << 16);
    // 0x8030A160: mflo        $t5
    ctx->r13 = lo;
    // 0x8030A164: nop

    // 0x8030A168: nop

    // 0x8030A16C: multu       $a2, $a2
    result = U64(U32(ctx->r6)) * U64(U32(ctx->r6)); lo = S32(result >> 0); hi = S32(result >> 32);
    // 0x8030A170: mflo        $t7
    ctx->r15 = lo;
    // 0x8030A174: addu        $t8, $t5, $t7
    ctx->r24 = ADD32(ctx->r13, ctx->r15);
    // 0x8030A178: mtc1        $t8, $f8
    ctx->f8.u32l = ctx->r24;
    // 0x8030A17C: nop

    // 0x8030A180: cvt.s.w     $f0, $f8
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 8);
    ctx->f0.fl = CVT_S_W(ctx->f8.u32l);
    // 0x8030A184: sqrt.s      $f0, $f0
    CHECK_FR(ctx, 0);
    CHECK_FR(ctx, 0);
    NAN_CHECK(ctx->f0.fl); 
    ctx->f0.fl = sqrtf(ctx->f0.fl);
    // 0x8030A188: trunc.w.s   $f10, $f0
    CHECK_FR(ctx, 10);
    CHECK_FR(ctx, 0);
    ctx->f10.u32l = TRUNC_W_S(ctx->f0.fl);
    // 0x8030A18C: mfc1        $t1, $f10
    ctx->r9 = (int32_t)ctx->f10.u32l;
    // 0x8030A190: nop

    // 0x8030A194: sh          $t1, 0x284($v0)
    MEM_H(0X284, ctx->r2) = ctx->r9;
    // 0x8030A198: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8030A19C: lw          $t2, 0x5524($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X5524);
    // 0x8030A1A0: addiu       $t1, $zero, 0x1
    ctx->r9 = ADD32(0, 0X1);
    // 0x8030A1A4: lw          $t5, 0x280($v0)
    ctx->r13 = MEM_W(ctx->r2, 0X280);
    // 0x8030A1A8: lh          $t3, 0x284($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X284);
    // 0x8030A1AC: lhu         $t4, 0xBE($t2)
    ctx->r12 = MEM_HU(ctx->r10, 0XBE);
    // 0x8030A1B0: lh          $t7, 0x30($t5)
    ctx->r15 = MEM_H(ctx->r13, 0X30);
    // 0x8030A1B4: subu        $t6, $t3, $t4
    ctx->r14 = SUB32(ctx->r11, ctx->r12);
    // 0x8030A1B8: subu        $t8, $t6, $t7
    ctx->r24 = SUB32(ctx->r14, ctx->r15);
    // 0x8030A1BC: sh          $t8, 0x284($v0)
    MEM_H(0X284, ctx->r2) = ctx->r24;
    // 0x8030A1C0: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8030A1C4: lh          $t9, 0x284($v0)
    ctx->r25 = MEM_H(ctx->r2, 0X284);
    // 0x8030A1C8: bgezl       $t9, L_8030A1DC
    if (SIGNED(ctx->r25) >= 0) {
        // 0x8030A1CC: lbu         $t2, 0x270($v0)
        ctx->r10 = MEM_BU(ctx->r2, 0X270);
            goto L_8030A1DC;
    }
    goto skip_4;
    // 0x8030A1CC: lbu         $t2, 0x270($v0)
    ctx->r10 = MEM_BU(ctx->r2, 0X270);
    skip_4:
    // 0x8030A1D0: sh          $t1, 0x284($v0)
    MEM_H(0X284, ctx->r2) = ctx->r9;
    // 0x8030A1D4: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8030A1D8: lbu         $t2, 0x270($v0)
    ctx->r10 = MEM_BU(ctx->r2, 0X270);
L_8030A1DC:
    // 0x8030A1DC: sltiu       $at, $t2, 0x7
    ctx->r1 = ctx->r10 < 0X7 ? 1 : 0;
    // 0x8030A1E0: beq         $at, $zero, L_8030A8D8
    if (ctx->r1 == 0) {
        // 0x8030A1E4: sll         $t2, $t2, 2
        ctx->r10 = S32(ctx->r10 << 2);
            goto L_8030A8D8;
    }
    // 0x8030A1E4: sll         $t2, $t2, 2
    ctx->r10 = S32(ctx->r10 << 2);
    // 0x8030A1E8: lui         $at, 0x803C
    ctx->r1 = S32(0X803C << 16);
    // 0x8030A1EC: addu        $at, $at, $t2
    gpr jr_addend_8030A1F4 = ctx->r10;
    ctx->r1 = ADD32(ctx->r1, ctx->r10);
    // 0x8030A1F0: lw          $t2, -0x2F4C($at)
    ctx->r10 = ADD32(ctx->r1, -0X2F4C);
    // 0x8030A1F4: jr          $t2
    // 0x8030A1F8: nop

    switch (jr_addend_8030A1F4 >> 2) {
        case 0: goto L_8030A1FC; break;
        case 1: goto L_8030A390; break;
        case 2: goto L_8030A478; break;
        case 3: goto L_8030A4CC; break;
        case 4: goto L_8030A5C4; break;
        case 5: goto L_8030A6C4; break;
        case 6: goto L_8030A7D0; break;
        default: switch_error(__func__, 0x8030A1F4, 0x803BD0B4);
    }
    // 0x8030A1F8: nop

L_8030A1FC:
    // 0x8030A1FC: lhu         $t3, 0x28C($v0)
    ctx->r11 = MEM_HU(ctx->r2, 0X28C);
    // 0x8030A200: addiu       $at, $zero, 0x8
    ctx->r1 = ADD32(0, 0X8);
    // 0x8030A204: beq         $t3, $at, L_8030A33C
    if (ctx->r11 == ctx->r1) {
        // 0x8030A208: nop
    
            goto L_8030A33C;
    }
    // 0x8030A208: nop

    // 0x8030A20C: jal         0x80309868
    // 0x8030A210: nop

    func_80309868_71AF18(rdram, ctx);
        goto after_4;
    // 0x8030A210: nop

    after_4:
    // 0x8030A214: beq         $v0, $zero, L_8030A240
    if (ctx->r2 == 0) {
        // 0x8030A218: lui         $a0, 0x803E
        ctx->r4 = S32(0X803E << 16);
            goto L_8030A240;
    }
    // 0x8030A218: lui         $a0, 0x803E
    ctx->r4 = S32(0X803E << 16);
    // 0x8030A21C: jal         0x80309E4C
    // 0x8030A220: lw          $a0, 0x4C38($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X4C38);
    func_80309E4C_71B4FC(rdram, ctx);
        goto after_5;
    // 0x8030A220: lw          $a0, 0x4C38($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X4C38);
    after_5:
    // 0x8030A224: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030A228: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8030A22C: lw          $t5, 0x0($t0)
    ctx->r13 = MEM_W(ctx->r8, 0X0);
    // 0x8030A230: addiu       $t4, $zero, 0x1
    ctx->r12 = ADD32(0, 0X1);
    // 0x8030A234: sb          $t4, 0x270($t5)
    MEM_B(0X270, ctx->r13) = ctx->r12;
    // 0x8030A238: b           L_8030A8D8
    // 0x8030A23C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
        goto L_8030A8D8;
    // 0x8030A23C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_8030A240:
    // 0x8030A240: jal         0x80309ACC
    // 0x8030A244: nop

    func_80309ACC_71B17C(rdram, ctx);
        goto after_6;
    // 0x8030A244: nop

    after_6:
    // 0x8030A248: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030A24C: beq         $v0, $zero, L_8030A278
    if (ctx->r2 == 0) {
        // 0x8030A250: addiu       $t0, $t0, 0x552C
        ctx->r8 = ADD32(ctx->r8, 0X552C);
            goto L_8030A278;
    }
    // 0x8030A250: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8030A254: lui         $t6, 0x803E
    ctx->r14 = S32(0X803E << 16);
    // 0x8030A258: lw          $t6, 0x4C40($t6)
    ctx->r14 = MEM_W(ctx->r14, 0X4C40);
    // 0x8030A25C: lw          $t7, 0x0($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X0);
    // 0x8030A260: addiu       $t8, $zero, 0x3
    ctx->r24 = ADD32(0, 0X3);
    // 0x8030A264: sw          $t6, 0x280($t7)
    MEM_W(0X280, ctx->r15) = ctx->r14;
    // 0x8030A268: lw          $t9, 0x0($t0)
    ctx->r25 = MEM_W(ctx->r8, 0X0);
    // 0x8030A26C: sb          $t8, 0x270($t9)
    MEM_B(0X270, ctx->r25) = ctx->r24;
    // 0x8030A270: b           L_8030A8D8
    // 0x8030A274: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
        goto L_8030A8D8;
    // 0x8030A274: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_8030A278:
    // 0x8030A278: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8030A27C: lb          $v1, 0x2EB($v0)
    ctx->r3 = MEM_B(ctx->r2, 0X2EB);
    // 0x8030A280: beq         $v1, $zero, L_8030A33C
    if (ctx->r3 == 0) {
        // 0x8030A284: nop
    
            goto L_8030A33C;
    }
    // 0x8030A284: nop

    // 0x8030A288: lbu         $t1, 0x271($v0)
    ctx->r9 = MEM_BU(ctx->r2, 0X271);
    // 0x8030A28C: addu        $t2, $t1, $v1
    ctx->r10 = ADD32(ctx->r9, ctx->r3);
    // 0x8030A290: sb          $t2, 0x271($v0)
    MEM_B(0X271, ctx->r2) = ctx->r10;
    // 0x8030A294: lw          $t3, 0x0($t0)
    ctx->r11 = MEM_W(ctx->r8, 0X0);
    // 0x8030A298: sb          $zero, 0x2EB($t3)
    MEM_B(0X2EB, ctx->r11) = 0;
    // 0x8030A29C: lw          $t4, 0x0($t0)
    ctx->r12 = MEM_W(ctx->r8, 0X0);
    // 0x8030A2A0: lbu         $t5, 0x271($t4)
    ctx->r13 = MEM_BU(ctx->r12, 0X271);
    // 0x8030A2A4: slti        $at, $t5, 0x3
    ctx->r1 = SIGNED(ctx->r13) < 0X3 ? 1 : 0;
    // 0x8030A2A8: bnel        $at, $zero, L_8030A30C
    if (ctx->r1 != 0) {
        // 0x8030A2AC: lw          $v0, 0x0($t0)
        ctx->r2 = MEM_W(ctx->r8, 0X0);
            goto L_8030A30C;
    }
    goto skip_5;
    // 0x8030A2AC: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    skip_5:
    // 0x8030A2B0: jal         0x803098F0
    // 0x8030A2B4: nop

    func_803098F0_71AFA0(rdram, ctx);
        goto after_7;
    // 0x8030A2B4: nop

    after_7:
    // 0x8030A2B8: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030A2BC: beq         $v0, $zero, L_8030A308
    if (ctx->r2 == 0) {
        // 0x8030A2C0: addiu       $t0, $t0, 0x552C
        ctx->r8 = ADD32(ctx->r8, 0X552C);
            goto L_8030A308;
    }
    // 0x8030A2C0: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8030A2C4: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8030A2C8: lh          $t6, 0x5534($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X5534);
    // 0x8030A2CC: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8030A2D0: sll         $t7, $t6, 3
    ctx->r15 = S32(ctx->r14 << 3);
    // 0x8030A2D4: addu        $a0, $a0, $t7
    ctx->r4 = ADD32(ctx->r4, ctx->r15);
    // 0x8030A2D8: jal         0x80309E4C
    // 0x8030A2DC: lw          $a0, -0x2274($a0)
    ctx->r4 = MEM_W(ctx->r4, -0X2274);
    func_80309E4C_71B4FC(rdram, ctx);
        goto after_8;
    // 0x8030A2DC: lw          $a0, -0x2274($a0)
    ctx->r4 = MEM_W(ctx->r4, -0X2274);
    after_8:
    // 0x8030A2E0: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030A2E4: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8030A2E8: lw          $t9, 0x0($t0)
    ctx->r25 = MEM_W(ctx->r8, 0X0);
    // 0x8030A2EC: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x8030A2F0: addiu       $t1, $zero, 0x2
    ctx->r9 = ADD32(0, 0X2);
    // 0x8030A2F4: sb          $t8, 0x270($t9)
    MEM_B(0X270, ctx->r25) = ctx->r24;
    // 0x8030A2F8: lw          $t2, 0x0($t0)
    ctx->r10 = MEM_W(ctx->r8, 0X0);
    // 0x8030A2FC: sb          $t1, 0x271($t2)
    MEM_B(0X271, ctx->r10) = ctx->r9;
    // 0x8030A300: b           L_8030A8D8
    // 0x8030A304: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
        goto L_8030A8D8;
    // 0x8030A304: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_8030A308:
    // 0x8030A308: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_8030A30C:
    // 0x8030A30C: lhu         $t3, 0x272($v0)
    ctx->r11 = MEM_HU(ctx->r2, 0X272);
    // 0x8030A310: andi        $t4, $t3, 0x400
    ctx->r12 = ctx->r11 & 0X400;
    // 0x8030A314: beq         $t4, $zero, L_8030A33C
    if (ctx->r12 == 0) {
        // 0x8030A318: nop
    
            goto L_8030A33C;
    }
    // 0x8030A318: nop

    // 0x8030A31C: lbu         $t5, 0x2B4($v0)
    ctx->r13 = MEM_BU(ctx->r2, 0X2B4);
    // 0x8030A320: addiu       $t7, $zero, 0x6
    ctx->r15 = ADD32(0, 0X6);
    // 0x8030A324: andi        $t6, $t5, 0xFF0F
    ctx->r14 = ctx->r13 & 0XFF0F;
    // 0x8030A328: sb          $t6, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r14;
    // 0x8030A32C: lw          $t8, 0x0($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X0);
    // 0x8030A330: sb          $t7, 0x270($t8)
    MEM_B(0X270, ctx->r24) = ctx->r15;
    // 0x8030A334: b           L_8030A8D8
    // 0x8030A338: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
        goto L_8030A8D8;
    // 0x8030A338: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_8030A33C:
    // 0x8030A33C: lui         $a3, 0x803D
    ctx->r7 = S32(0X803D << 16);
    // 0x8030A340: addiu       $a3, $a3, 0x5530
    ctx->r7 = ADD32(ctx->r7, 0X5530);
    // 0x8030A344: lw          $a0, 0x0($a3)
    ctx->r4 = MEM_W(ctx->r7, 0X0);
    // 0x8030A348: lw          $t9, 0x1A8($a0)
    ctx->r25 = MEM_W(ctx->r4, 0X1A8);
    // 0x8030A34C: beq         $t9, $zero, L_8030A35C
    if (ctx->r25 == 0) {
        // 0x8030A350: nop
    
            goto L_8030A35C;
    }
    // 0x8030A350: nop

    // 0x8030A354: jal         0x803191B0
    // 0x8030A358: nop

    func_803191B0_72A860(rdram, ctx);
        goto after_9;
    // 0x8030A358: nop

    after_9:
L_8030A35C:
    // 0x8030A35C: jal         0x80309C8C
    // 0x8030A360: nop

    func_80309C8C_71B33C(rdram, ctx);
        goto after_10;
    // 0x8030A360: nop

    after_10:
    // 0x8030A364: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8030A368: jal         0x80362CC4
    // 0x8030A36C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    func_80362CC4_774374(rdram, ctx);
        goto after_11;
    // 0x8030A36C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    after_11:
    // 0x8030A370: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8030A374: jal         0x803633C4
    // 0x8030A378: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    func_803633C4_774A74(rdram, ctx);
        goto after_12;
    // 0x8030A378: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    after_12:
    // 0x8030A37C: jal         0x803071BC
    // 0x8030A380: nop

    func_803071BC_71886C(rdram, ctx);
        goto after_13;
    // 0x8030A380: nop

    after_13:
    // 0x8030A384: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8030A388: b           L_8030A8D8
    // 0x8030A38C: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
        goto L_8030A8D8;
    // 0x8030A38C: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
L_8030A390:
    // 0x8030A390: jal         0x803099BC
    // 0x8030A394: nop

    func_803099BC_71B06C(rdram, ctx);
        goto after_14;
    // 0x8030A394: nop

    after_14:
    // 0x8030A398: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030A39C: beq         $v0, $zero, L_8030A3EC
    if (ctx->r2 == 0) {
        // 0x8030A3A0: addiu       $t0, $t0, 0x552C
        ctx->r8 = ADD32(ctx->r8, 0X552C);
            goto L_8030A3EC;
    }
    // 0x8030A3A0: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8030A3A4: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8030A3A8: addiu       $at, $zero, 0x8
    ctx->r1 = ADD32(0, 0X8);
    // 0x8030A3AC: lui         $t2, 0x803E
    ctx->r10 = S32(0X803E << 16);
    // 0x8030A3B0: lhu         $t1, 0x28C($v0)
    ctx->r9 = MEM_HU(ctx->r2, 0X28C);
    // 0x8030A3B4: beq         $t1, $at, L_8030A450
    if (ctx->r9 == ctx->r1) {
        // 0x8030A3B8: nop
    
            goto L_8030A450;
    }
    // 0x8030A3B8: nop

    // 0x8030A3BC: lw          $t2, 0x4C38($t2)
    ctx->r10 = MEM_W(ctx->r10, 0X4C38);
    // 0x8030A3C0: lw          $t3, 0x2CC($v0)
    ctx->r11 = MEM_W(ctx->r2, 0X2CC);
    // 0x8030A3C4: beq         $t2, $t3, L_8030A450
    if (ctx->r10 == ctx->r11) {
        // 0x8030A3C8: nop
    
            goto L_8030A450;
    }
    // 0x8030A3C8: nop

    // 0x8030A3CC: jal         0x80309868
    // 0x8030A3D0: nop

    func_80309868_71AF18(rdram, ctx);
        goto after_15;
    // 0x8030A3D0: nop

    after_15:
    // 0x8030A3D4: beq         $v0, $zero, L_8030A450
    if (ctx->r2 == 0) {
        // 0x8030A3D8: lui         $a0, 0x803E
        ctx->r4 = S32(0X803E << 16);
            goto L_8030A450;
    }
    // 0x8030A3D8: lui         $a0, 0x803E
    ctx->r4 = S32(0X803E << 16);
    // 0x8030A3DC: jal         0x80309EDC
    // 0x8030A3E0: lw          $a0, 0x4C38($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X4C38);
    func_80309EDC_71B58C(rdram, ctx);
        goto after_16;
    // 0x8030A3E0: lw          $a0, 0x4C38($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X4C38);
    after_16:
    // 0x8030A3E4: b           L_8030A450
    // 0x8030A3E8: nop

        goto L_8030A450;
    // 0x8030A3E8: nop

L_8030A3EC:
    // 0x8030A3EC: lw          $t4, 0x0($t0)
    ctx->r12 = MEM_W(ctx->r8, 0X0);
    // 0x8030A3F0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8030A3F4: sb          $zero, 0x270($t4)
    MEM_B(0X270, ctx->r12) = 0;
    // 0x8030A3F8: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8030A3FC: lhu         $t5, 0x2C8($v0)
    ctx->r13 = MEM_HU(ctx->r2, 0X2C8);
    // 0x8030A400: sh          $t5, 0x272($v0)
    MEM_H(0X272, ctx->r2) = ctx->r13;
    // 0x8030A404: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8030A408: lbu         $t6, 0x2B4($v0)
    ctx->r14 = MEM_BU(ctx->r2, 0X2B4);
    // 0x8030A40C: andi        $t7, $t6, 0xFFF1
    ctx->r15 = ctx->r14 & 0XFFF1;
    // 0x8030A410: sb          $t7, 0x2B4($v0)
    MEM_B(0X2B4, ctx->r2) = ctx->r15;
    // 0x8030A414: lw          $t8, 0x0($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X0);
    // 0x8030A418: sw          $zero, 0x2CC($t8)
    MEM_W(0X2CC, ctx->r24) = 0;
    // 0x8030A41C: lw          $t9, 0x0($t0)
    ctx->r25 = MEM_W(ctx->r8, 0X0);
    // 0x8030A420: sb          $zero, 0x287($t9)
    MEM_B(0X287, ctx->r25) = 0;
    // 0x8030A424: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8030A428: lbu         $t1, 0x271($v0)
    ctx->r9 = MEM_BU(ctx->r2, 0X271);
    // 0x8030A42C: slti        $at, $t1, 0x3
    ctx->r1 = SIGNED(ctx->r9) < 0X3 ? 1 : 0;
    // 0x8030A430: bne         $at, $zero, L_8030A43C
    if (ctx->r1 != 0) {
        // 0x8030A434: nop
    
            goto L_8030A43C;
    }
    // 0x8030A434: nop

    // 0x8030A438: sb          $zero, 0x271($v0)
    MEM_B(0X271, ctx->r2) = 0;
L_8030A43C:
    // 0x8030A43C: jal         0x80363FF0
    // 0x8030A440: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    func_80363FF0_7756A0(rdram, ctx);
        goto after_17;
    // 0x8030A440: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    after_17:
    // 0x8030A444: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8030A448: b           L_8030A8D8
    // 0x8030A44C: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
        goto L_8030A8D8;
    // 0x8030A44C: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
L_8030A450:
    // 0x8030A450: jal         0x80389764
    // 0x8030A454: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    func_80389764_79AE14(rdram, ctx);
        goto after_18;
    // 0x8030A454: or          $a0, $zero, $zero
    ctx->r4 = 0 | 0;
    after_18:
    // 0x8030A458: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8030A45C: jal         0x803633C4
    // 0x8030A460: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    func_803633C4_774A74(rdram, ctx);
        goto after_19;
    // 0x8030A460: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    after_19:
    // 0x8030A464: jal         0x803071BC
    // 0x8030A468: nop

    func_803071BC_71886C(rdram, ctx);
        goto after_20;
    // 0x8030A468: nop

    after_20:
    // 0x8030A46C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8030A470: b           L_8030A8D8
    // 0x8030A474: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
        goto L_8030A8D8;
    // 0x8030A474: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
L_8030A478:
    // 0x8030A478: lw          $a0, 0x0($a3)
    ctx->r4 = MEM_W(ctx->r7, 0X0);
    // 0x8030A47C: lbu         $t2, 0x197($a0)
    ctx->r10 = MEM_BU(ctx->r4, 0X197);
    // 0x8030A480: beq         $t2, $zero, L_8030A4B0
    if (ctx->r10 == 0) {
        // 0x8030A484: nop
    
            goto L_8030A4B0;
    }
    // 0x8030A484: nop

    // 0x8030A488: jal         0x80363FF0
    // 0x8030A48C: nop

    func_80363FF0_7756A0(rdram, ctx);
        goto after_21;
    // 0x8030A48C: nop

    after_21:
    // 0x8030A490: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030A494: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8030A498: lw          $t3, 0x0($t0)
    ctx->r11 = MEM_W(ctx->r8, 0X0);
    // 0x8030A49C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8030A4A0: sb          $zero, 0x270($t3)
    MEM_B(0X270, ctx->r11) = 0;
    // 0x8030A4A4: lw          $t4, 0x0($t0)
    ctx->r12 = MEM_W(ctx->r8, 0X0);
    // 0x8030A4A8: sb          $zero, 0x287($t4)
    MEM_B(0X287, ctx->r12) = 0;
    // 0x8030A4AC: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
L_8030A4B0:
    // 0x8030A4B0: jal         0x803633C4
    // 0x8030A4B4: nop

    func_803633C4_774A74(rdram, ctx);
        goto after_22;
    // 0x8030A4B4: nop

    after_22:
    // 0x8030A4B8: jal         0x803071BC
    // 0x8030A4BC: nop

    func_803071BC_71886C(rdram, ctx);
        goto after_23;
    // 0x8030A4BC: nop

    after_23:
    // 0x8030A4C0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8030A4C4: b           L_8030A8D8
    // 0x8030A4C8: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
        goto L_8030A8D8;
    // 0x8030A4C8: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
L_8030A4CC:
    // 0x8030A4CC: jal         0x80309B40
    // 0x8030A4D0: nop

    func_80309B40_71B1F0(rdram, ctx);
        goto after_24;
    // 0x8030A4D0: nop

    after_24:
    // 0x8030A4D4: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030A4D8: bne         $v0, $zero, L_8030A514
    if (ctx->r2 != 0) {
        // 0x8030A4DC: addiu       $t0, $t0, 0x552C
        ctx->r8 = ADD32(ctx->r8, 0X552C);
            goto L_8030A514;
    }
    // 0x8030A4DC: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8030A4E0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8030A4E4: jal         0x80363FF0
    // 0x8030A4E8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    func_80363FF0_7756A0(rdram, ctx);
        goto after_25;
    // 0x8030A4E8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    after_25:
    // 0x8030A4EC: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030A4F0: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8030A4F4: lw          $t5, 0x0($t0)
    ctx->r13 = MEM_W(ctx->r8, 0X0);
    // 0x8030A4F8: sb          $zero, 0x270($t5)
    MEM_B(0X270, ctx->r13) = 0;
    // 0x8030A4FC: lw          $t6, 0x0($t0)
    ctx->r14 = MEM_W(ctx->r8, 0X0);
    // 0x8030A500: sw          $zero, 0x280($t6)
    MEM_W(0X280, ctx->r14) = 0;
    // 0x8030A504: lw          $t7, 0x0($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X0);
    // 0x8030A508: sb          $zero, 0x287($t7)
    MEM_B(0X287, ctx->r15) = 0;
    // 0x8030A50C: b           L_8030A8D8
    // 0x8030A510: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
        goto L_8030A8D8;
    // 0x8030A510: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_8030A514:
    // 0x8030A514: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8030A518: lui         $a1, 0x803E
    ctx->r5 = S32(0X803E << 16);
    // 0x8030A51C: addiu       $a1, $a1, 0x4BE0
    ctx->r5 = ADD32(ctx->r5, 0X4BE0);
    // 0x8030A520: lw          $a0, 0x60($a1)
    ctx->r4 = MEM_W(ctx->r5, 0X60);
    // 0x8030A524: lw          $v1, 0x280($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X280);
    // 0x8030A528: beql        $a0, $v1, L_8030A550
    if (ctx->r4 == ctx->r3) {
        // 0x8030A52C: lw          $t9, 0x2B4($v1)
        ctx->r25 = MEM_W(ctx->r3, 0X2B4);
            goto L_8030A550;
    }
    goto skip_6;
    // 0x8030A52C: lw          $t9, 0x2B4($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X2B4);
    skip_6:
    // 0x8030A530: lbu         $t8, 0x64($a1)
    ctx->r24 = MEM_BU(ctx->r5, 0X64);
    // 0x8030A534: beql        $t8, $zero, L_8030A550
    if (ctx->r24 == 0) {
        // 0x8030A538: lw          $t9, 0x2B4($v1)
        ctx->r25 = MEM_W(ctx->r3, 0X2B4);
            goto L_8030A550;
    }
    goto skip_7;
    // 0x8030A538: lw          $t9, 0x2B4($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X2B4);
    skip_7:
    // 0x8030A53C: sw          $a0, 0x280($v0)
    MEM_W(0X280, ctx->r2) = ctx->r4;
    // 0x8030A540: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8030A544: b           L_8030A8D8
    // 0x8030A548: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
        goto L_8030A8D8;
    // 0x8030A548: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
    // 0x8030A54C: lw          $t9, 0x2B4($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X2B4);
L_8030A550:
    // 0x8030A550: sll         $t1, $t9, 4
    ctx->r9 = S32(ctx->r25 << 4);
    // 0x8030A554: srl         $t2, $t1, 29
    ctx->r10 = S32(U32(ctx->r9) >> 29);
    // 0x8030A558: beq         $t2, $zero, L_8030A58C
    if (ctx->r10 == 0) {
        // 0x8030A55C: nop
    
            goto L_8030A58C;
    }
    // 0x8030A55C: nop

    // 0x8030A560: lh          $t3, 0x284($v0)
    ctx->r11 = MEM_H(ctx->r2, 0X284);
    // 0x8030A564: slti        $at, $t3, 0x1E0
    ctx->r1 = SIGNED(ctx->r11) < 0X1E0 ? 1 : 0;
    // 0x8030A568: beq         $at, $zero, L_8030A58C
    if (ctx->r1 == 0) {
        // 0x8030A56C: nop
    
            goto L_8030A58C;
    }
    // 0x8030A56C: nop

    // 0x8030A570: jal         0x80309E4C
    // 0x8030A574: lw          $a0, 0x2CC($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X2CC);
    func_80309E4C_71B4FC(rdram, ctx);
        goto after_26;
    // 0x8030A574: lw          $a0, 0x2CC($v1)
    ctx->r4 = MEM_W(ctx->r3, 0X2CC);
    after_26:
    // 0x8030A578: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030A57C: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8030A580: lw          $t5, 0x0($t0)
    ctx->r13 = MEM_W(ctx->r8, 0X0);
    // 0x8030A584: addiu       $t4, $zero, 0x4
    ctx->r12 = ADD32(0, 0X4);
    // 0x8030A588: sb          $t4, 0x270($t5)
    MEM_B(0X270, ctx->r13) = ctx->r12;
L_8030A58C:
    // 0x8030A58C: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8030A590: jal         0x803633C4
    // 0x8030A594: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    func_803633C4_774A74(rdram, ctx);
        goto after_27;
    // 0x8030A594: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    after_27:
    // 0x8030A598: jal         0x803071BC
    // 0x8030A59C: nop

    func_803071BC_71886C(rdram, ctx);
        goto after_28;
    // 0x8030A59C: nop

    after_28:
    // 0x8030A5A0: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030A5A4: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8030A5A8: lw          $t6, 0x0($t0)
    ctx->r14 = MEM_W(ctx->r8, 0X0);
    // 0x8030A5AC: lw          $v1, 0x280($t6)
    ctx->r3 = MEM_W(ctx->r14, 0X280);
    // 0x8030A5B0: lb          $t7, 0x2B5($v1)
    ctx->r15 = MEM_B(ctx->r3, 0X2B5);
    // 0x8030A5B4: addiu       $t8, $t7, 0x1
    ctx->r24 = ADD32(ctx->r15, 0X1);
    // 0x8030A5B8: sb          $t8, 0x2B5($v1)
    MEM_B(0X2B5, ctx->r3) = ctx->r24;
    // 0x8030A5BC: b           L_8030A8D8
    // 0x8030A5C0: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
        goto L_8030A8D8;
    // 0x8030A5C0: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
L_8030A5C4:
    // 0x8030A5C4: jal         0x80309B40
    // 0x8030A5C8: nop

    func_80309B40_71B1F0(rdram, ctx);
        goto after_29;
    // 0x8030A5C8: nop

    after_29:
    // 0x8030A5CC: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030A5D0: bne         $v0, $zero, L_8030A61C
    if (ctx->r2 != 0) {
        // 0x8030A5D4: addiu       $t0, $t0, 0x552C
        ctx->r8 = ADD32(ctx->r8, 0X552C);
            goto L_8030A61C;
    }
    // 0x8030A5D4: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8030A5D8: lw          $t9, 0x0($t0)
    ctx->r25 = MEM_W(ctx->r8, 0X0);
    // 0x8030A5DC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8030A5E0: sb          $zero, 0x270($t9)
    MEM_B(0X270, ctx->r25) = 0;
    // 0x8030A5E4: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8030A5E8: lhu         $t1, 0x2C8($v0)
    ctx->r9 = MEM_HU(ctx->r2, 0X2C8);
    // 0x8030A5EC: sh          $t1, 0x272($v0)
    MEM_H(0X272, ctx->r2) = ctx->r9;
    // 0x8030A5F0: lw          $t2, 0x0($t0)
    ctx->r10 = MEM_W(ctx->r8, 0X0);
    // 0x8030A5F4: sw          $zero, 0x2CC($t2)
    MEM_W(0X2CC, ctx->r10) = 0;
    // 0x8030A5F8: lw          $t3, 0x0($t0)
    ctx->r11 = MEM_W(ctx->r8, 0X0);
    // 0x8030A5FC: sw          $zero, 0x280($t3)
    MEM_W(0X280, ctx->r11) = 0;
    // 0x8030A600: lw          $t4, 0x0($t0)
    ctx->r12 = MEM_W(ctx->r8, 0X0);
    // 0x8030A604: sb          $zero, 0x287($t4)
    MEM_B(0X287, ctx->r12) = 0;
    // 0x8030A608: jal         0x80363FF0
    // 0x8030A60C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    func_80363FF0_7756A0(rdram, ctx);
        goto after_30;
    // 0x8030A60C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    after_30:
    // 0x8030A610: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8030A614: b           L_8030A8D8
    // 0x8030A618: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
        goto L_8030A8D8;
    // 0x8030A618: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
L_8030A61C:
    // 0x8030A61C: lw          $t5, 0x0($t0)
    ctx->r13 = MEM_W(ctx->r8, 0X0);
    // 0x8030A620: addiu       $t4, $zero, 0x3
    ctx->r12 = ADD32(0, 0X3);
    // 0x8030A624: lw          $v1, 0x280($t5)
    ctx->r3 = MEM_W(ctx->r13, 0X280);
    // 0x8030A628: lb          $t6, 0x2B5($v1)
    ctx->r14 = MEM_B(ctx->r3, 0X2B5);
    // 0x8030A62C: addiu       $t7, $t6, 0x1
    ctx->r15 = ADD32(ctx->r14, 0X1);
    // 0x8030A630: sb          $t7, 0x2B5($v1)
    MEM_B(0X2B5, ctx->r3) = ctx->r15;
    // 0x8030A634: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8030A638: lh          $t8, 0x284($v0)
    ctx->r24 = MEM_H(ctx->r2, 0X284);
    // 0x8030A63C: slti        $at, $t8, 0x1EB
    ctx->r1 = SIGNED(ctx->r24) < 0X1EB ? 1 : 0;
    // 0x8030A640: beql        $at, $zero, L_8030A670
    if (ctx->r1 == 0) {
        // 0x8030A644: sb          $t4, 0x270($v0)
        MEM_B(0X270, ctx->r2) = ctx->r12;
            goto L_8030A670;
    }
    goto skip_8;
    // 0x8030A644: sb          $t4, 0x270($v0)
    MEM_B(0X270, ctx->r2) = ctx->r12;
    skip_8:
    // 0x8030A648: lw          $v1, 0x280($v0)
    ctx->r3 = MEM_W(ctx->r2, 0X280);
    // 0x8030A64C: lw          $t9, 0x2CC($v1)
    ctx->r25 = MEM_W(ctx->r3, 0X2CC);
    // 0x8030A650: beql        $t9, $zero, L_8030A670
    if (ctx->r25 == 0) {
        // 0x8030A654: sb          $t4, 0x270($v0)
        MEM_B(0X270, ctx->r2) = ctx->r12;
            goto L_8030A670;
    }
    goto skip_9;
    // 0x8030A654: sb          $t4, 0x270($v0)
    MEM_B(0X270, ctx->r2) = ctx->r12;
    skip_9:
    // 0x8030A658: lw          $t1, 0x2B4($v1)
    ctx->r9 = MEM_W(ctx->r3, 0X2B4);
    // 0x8030A65C: sll         $t2, $t1, 4
    ctx->r10 = S32(ctx->r9 << 4);
    // 0x8030A660: srl         $t3, $t2, 29
    ctx->r11 = S32(U32(ctx->r10) >> 29);
    // 0x8030A664: bne         $t3, $zero, L_8030A69C
    if (ctx->r11 != 0) {
        // 0x8030A668: nop
    
            goto L_8030A69C;
    }
    // 0x8030A668: nop

    // 0x8030A66C: sb          $t4, 0x270($v0)
    MEM_B(0X270, ctx->r2) = ctx->r12;
L_8030A670:
    // 0x8030A670: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8030A674: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8030A678: lhu         $t5, 0x2C8($v0)
    ctx->r13 = MEM_HU(ctx->r2, 0X2C8);
    // 0x8030A67C: sh          $t5, 0x272($v0)
    MEM_H(0X272, ctx->r2) = ctx->r13;
    // 0x8030A680: lw          $t6, 0x0($t0)
    ctx->r14 = MEM_W(ctx->r8, 0X0);
    // 0x8030A684: sw          $zero, 0x2CC($t6)
    MEM_W(0X2CC, ctx->r14) = 0;
    // 0x8030A688: jal         0x80363CC8
    // 0x8030A68C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    set_nav_state_idle(rdram, ctx);
        goto after_31;
    // 0x8030A68C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    after_31:
    // 0x8030A690: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8030A694: b           L_8030A8D8
    // 0x8030A698: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
        goto L_8030A8D8;
    // 0x8030A698: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
L_8030A69C:
    // 0x8030A69C: jal         0x80389764
    // 0x8030A6A0: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    func_80389764_79AE14(rdram, ctx);
        goto after_32;
    // 0x8030A6A0: addiu       $a0, $zero, 0x1
    ctx->r4 = ADD32(0, 0X1);
    after_32:
    // 0x8030A6A4: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8030A6A8: jal         0x803633C4
    // 0x8030A6AC: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    func_803633C4_774A74(rdram, ctx);
        goto after_33;
    // 0x8030A6AC: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    after_33:
    // 0x8030A6B0: jal         0x803071BC
    // 0x8030A6B4: nop

    func_803071BC_71886C(rdram, ctx);
        goto after_34;
    // 0x8030A6B4: nop

    after_34:
    // 0x8030A6B8: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8030A6BC: b           L_8030A8D8
    // 0x8030A6C0: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
        goto L_8030A8D8;
    // 0x8030A6C0: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
L_8030A6C4:
    // 0x8030A6C4: jal         0x80309B40
    // 0x8030A6C8: nop

    func_80309B40_71B1F0(rdram, ctx);
        goto after_35;
    // 0x8030A6C8: nop

    after_35:
    // 0x8030A6CC: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030A6D0: bne         $v0, $zero, L_8030A71C
    if (ctx->r2 != 0) {
        // 0x8030A6D4: addiu       $t0, $t0, 0x552C
        ctx->r8 = ADD32(ctx->r8, 0X552C);
            goto L_8030A71C;
    }
    // 0x8030A6D4: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8030A6D8: lw          $t7, 0x0($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X0);
    // 0x8030A6DC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8030A6E0: sb          $zero, 0x270($t7)
    MEM_B(0X270, ctx->r15) = 0;
    // 0x8030A6E4: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8030A6E8: lhu         $t8, 0x2C8($v0)
    ctx->r24 = MEM_HU(ctx->r2, 0X2C8);
    // 0x8030A6EC: sh          $t8, 0x272($v0)
    MEM_H(0X272, ctx->r2) = ctx->r24;
    // 0x8030A6F0: lw          $t9, 0x0($t0)
    ctx->r25 = MEM_W(ctx->r8, 0X0);
    // 0x8030A6F4: sw          $zero, 0x2CC($t9)
    MEM_W(0X2CC, ctx->r25) = 0;
    // 0x8030A6F8: lw          $t1, 0x0($t0)
    ctx->r9 = MEM_W(ctx->r8, 0X0);
    // 0x8030A6FC: sw          $zero, 0x280($t1)
    MEM_W(0X280, ctx->r9) = 0;
    // 0x8030A700: lw          $t2, 0x0($t0)
    ctx->r10 = MEM_W(ctx->r8, 0X0);
    // 0x8030A704: sb          $zero, 0x287($t2)
    MEM_B(0X287, ctx->r10) = 0;
    // 0x8030A708: jal         0x80363FF0
    // 0x8030A70C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    func_80363FF0_7756A0(rdram, ctx);
        goto after_36;
    // 0x8030A70C: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    after_36:
    // 0x8030A710: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8030A714: b           L_8030A8D8
    // 0x8030A718: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
        goto L_8030A8D8;
    // 0x8030A718: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
L_8030A71C:
    // 0x8030A71C: lw          $t3, 0x0($t0)
    ctx->r11 = MEM_W(ctx->r8, 0X0);
    // 0x8030A720: lui         $t8, 0x803E
    ctx->r24 = S32(0X803E << 16);
    // 0x8030A724: lw          $v1, 0x280($t3)
    ctx->r3 = MEM_W(ctx->r11, 0X280);
    // 0x8030A728: lb          $t4, 0x2B5($v1)
    ctx->r12 = MEM_B(ctx->r3, 0X2B5);
    // 0x8030A72C: addiu       $t5, $t4, 0x1
    ctx->r13 = ADD32(ctx->r12, 0X1);
    // 0x8030A730: sb          $t5, 0x2B5($v1)
    MEM_B(0X2B5, ctx->r3) = ctx->r13;
    // 0x8030A734: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8030A738: lw          $t6, 0x280($v0)
    ctx->r14 = MEM_W(ctx->r2, 0X280);
    // 0x8030A73C: lh          $t7, 0x2D0($t6)
    ctx->r15 = MEM_H(ctx->r14, 0X2D0);
    // 0x8030A740: slti        $at, $t7, 0x141
    ctx->r1 = SIGNED(ctx->r15) < 0X141 ? 1 : 0;
    // 0x8030A744: beql        $at, $zero, L_8030A778
    if (ctx->r1 == 0) {
        // 0x8030A748: addiu       $t9, $zero, 0x3
        ctx->r25 = ADD32(0, 0X3);
            goto L_8030A778;
    }
    goto skip_10;
    // 0x8030A748: addiu       $t9, $zero, 0x3
    ctx->r25 = ADD32(0, 0X3);
    skip_10:
    // 0x8030A74C: lw          $t8, 0x4C3C($t8)
    ctx->r24 = MEM_W(ctx->r24, 0X4C3C);
    // 0x8030A750: slti        $at, $t8, 0x1EB
    ctx->r1 = SIGNED(ctx->r24) < 0X1EB ? 1 : 0;
    // 0x8030A754: beql        $at, $zero, L_8030A778
    if (ctx->r1 == 0) {
        // 0x8030A758: addiu       $t9, $zero, 0x3
        ctx->r25 = ADD32(0, 0X3);
            goto L_8030A778;
    }
    goto skip_11;
    // 0x8030A758: addiu       $t9, $zero, 0x3
    ctx->r25 = ADD32(0, 0X3);
    skip_11:
    // 0x8030A75C: jal         0x80362B00
    // 0x8030A760: lw          $a0, 0x2CC($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X2CC);
    func_80362B00_7741B0(rdram, ctx);
        goto after_37;
    // 0x8030A760: lw          $a0, 0x2CC($v0)
    ctx->r4 = MEM_W(ctx->r2, 0X2CC);
    after_37:
    // 0x8030A764: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030A768: beq         $v0, $zero, L_8030A7A8
    if (ctx->r2 == 0) {
        // 0x8030A76C: addiu       $t0, $t0, 0x552C
        ctx->r8 = ADD32(ctx->r8, 0X552C);
            goto L_8030A7A8;
    }
    // 0x8030A76C: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8030A770: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8030A774: addiu       $t9, $zero, 0x3
    ctx->r25 = ADD32(0, 0X3);
L_8030A778:
    // 0x8030A778: sb          $t9, 0x270($v0)
    MEM_B(0X270, ctx->r2) = ctx->r25;
    // 0x8030A77C: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8030A780: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8030A784: lhu         $t1, 0x2C8($v0)
    ctx->r9 = MEM_HU(ctx->r2, 0X2C8);
    // 0x8030A788: sh          $t1, 0x272($v0)
    MEM_H(0X272, ctx->r2) = ctx->r9;
    // 0x8030A78C: lw          $t2, 0x0($t0)
    ctx->r10 = MEM_W(ctx->r8, 0X0);
    // 0x8030A790: sw          $zero, 0x2CC($t2)
    MEM_W(0X2CC, ctx->r10) = 0;
    // 0x8030A794: jal         0x80363CC8
    // 0x8030A798: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    set_nav_state_idle(rdram, ctx);
        goto after_38;
    // 0x8030A798: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    after_38:
    // 0x8030A79C: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8030A7A0: b           L_8030A8D8
    // 0x8030A7A4: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
        goto L_8030A8D8;
    // 0x8030A7A4: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
L_8030A7A8:
    // 0x8030A7A8: jal         0x80389764
    // 0x8030A7AC: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    func_80389764_79AE14(rdram, ctx);
        goto after_39;
    // 0x8030A7AC: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    after_39:
    // 0x8030A7B0: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8030A7B4: jal         0x803633C4
    // 0x8030A7B8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    func_803633C4_774A74(rdram, ctx);
        goto after_40;
    // 0x8030A7B8: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    after_40:
    // 0x8030A7BC: jal         0x803071BC
    // 0x8030A7C0: nop

    func_803071BC_71886C(rdram, ctx);
        goto after_41;
    // 0x8030A7C0: nop

    after_41:
    // 0x8030A7C4: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8030A7C8: b           L_8030A8D8
    // 0x8030A7CC: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
        goto L_8030A8D8;
    // 0x8030A7CC: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
L_8030A7D0:
    // 0x8030A7D0: lhu         $t3, 0x272($v0)
    ctx->r11 = MEM_HU(ctx->r2, 0X272);
    // 0x8030A7D4: andi        $t4, $t3, 0x400
    ctx->r12 = ctx->r11 & 0X400;
    // 0x8030A7D8: bne         $t4, $zero, L_8030A80C
    if (ctx->r12 != 0) {
        // 0x8030A7DC: nop
    
            goto L_8030A80C;
    }
    // 0x8030A7DC: nop

    // 0x8030A7E0: jal         0x80363FF0
    // 0x8030A7E4: lw          $a0, 0x0($a3)
    ctx->r4 = MEM_W(ctx->r7, 0X0);
    func_80363FF0_7756A0(rdram, ctx);
        goto after_42;
    // 0x8030A7E4: lw          $a0, 0x0($a3)
    ctx->r4 = MEM_W(ctx->r7, 0X0);
    after_42:
    // 0x8030A7E8: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030A7EC: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8030A7F0: lw          $t5, 0x0($t0)
    ctx->r13 = MEM_W(ctx->r8, 0X0);
    // 0x8030A7F4: sb          $zero, 0x270($t5)
    MEM_B(0X270, ctx->r13) = 0;
    // 0x8030A7F8: lw          $t6, 0x0($t0)
    ctx->r14 = MEM_W(ctx->r8, 0X0);
    // 0x8030A7FC: sb          $zero, 0x2EB($t6)
    MEM_B(0X2EB, ctx->r14) = 0;
    // 0x8030A800: lw          $t7, 0x0($t0)
    ctx->r15 = MEM_W(ctx->r8, 0X0);
    // 0x8030A804: b           L_8030A8BC
    // 0x8030A808: sb          $zero, 0x287($t7)
    MEM_B(0X287, ctx->r15) = 0;
        goto L_8030A8BC;
    // 0x8030A808: sb          $zero, 0x287($t7)
    MEM_B(0X287, ctx->r15) = 0;
L_8030A80C:
    // 0x8030A80C: jal         0x803897B0
    // 0x8030A810: lbu         $a0, 0x271($v0)
    ctx->r4 = MEM_BU(ctx->r2, 0X271);
    func_803897B0_79AE60(rdram, ctx);
        goto after_43;
    // 0x8030A810: lbu         $a0, 0x271($v0)
    ctx->r4 = MEM_BU(ctx->r2, 0X271);
    after_43:
    // 0x8030A814: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030A818: beq         $v0, $zero, L_8030A848
    if (ctx->r2 == 0) {
        // 0x8030A81C: addiu       $t0, $t0, 0x552C
        ctx->r8 = ADD32(ctx->r8, 0X552C);
            goto L_8030A848;
    }
    // 0x8030A81C: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8030A820: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8030A824: jal         0x80363FF0
    // 0x8030A828: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    func_80363FF0_7756A0(rdram, ctx);
        goto after_44;
    // 0x8030A828: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    after_44:
    // 0x8030A82C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030A830: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8030A834: lw          $t8, 0x0($t0)
    ctx->r24 = MEM_W(ctx->r8, 0X0);
    // 0x8030A838: sb          $zero, 0x270($t8)
    MEM_B(0X270, ctx->r24) = 0;
    // 0x8030A83C: lw          $t9, 0x0($t0)
    ctx->r25 = MEM_W(ctx->r8, 0X0);
    // 0x8030A840: b           L_8030A8BC
    // 0x8030A844: sb          $zero, 0x287($t9)
    MEM_B(0X287, ctx->r25) = 0;
        goto L_8030A8BC;
    // 0x8030A844: sb          $zero, 0x287($t9)
    MEM_B(0X287, ctx->r25) = 0;
L_8030A848:
    // 0x8030A848: lw          $v0, 0x0($t0)
    ctx->r2 = MEM_W(ctx->r8, 0X0);
    // 0x8030A84C: lb          $v1, 0x2EB($v0)
    ctx->r3 = MEM_B(ctx->r2, 0X2EB);
    // 0x8030A850: beq         $v1, $zero, L_8030A8BC
    if (ctx->r3 == 0) {
        // 0x8030A854: nop
    
            goto L_8030A8BC;
    }
    // 0x8030A854: nop

    // 0x8030A858: lbu         $t1, 0x271($v0)
    ctx->r9 = MEM_BU(ctx->r2, 0X271);
    // 0x8030A85C: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8030A860: addu        $t2, $t1, $v1
    ctx->r10 = ADD32(ctx->r9, ctx->r3);
    // 0x8030A864: sb          $t2, 0x271($v0)
    MEM_B(0X271, ctx->r2) = ctx->r10;
    // 0x8030A868: lw          $t3, 0x0($t0)
    ctx->r11 = MEM_W(ctx->r8, 0X0);
    // 0x8030A86C: sb          $zero, 0x2EB($t3)
    MEM_B(0X2EB, ctx->r11) = 0;
    // 0x8030A870: lw          $t4, 0x0($t0)
    ctx->r12 = MEM_W(ctx->r8, 0X0);
    // 0x8030A874: lbu         $t5, 0x271($t4)
    ctx->r13 = MEM_BU(ctx->r12, 0X271);
    // 0x8030A878: slti        $at, $t5, 0x3
    ctx->r1 = SIGNED(ctx->r13) < 0X3 ? 1 : 0;
    // 0x8030A87C: bne         $at, $zero, L_8030A8BC
    if (ctx->r1 != 0) {
        // 0x8030A880: nop
    
            goto L_8030A8BC;
    }
    // 0x8030A880: nop

    // 0x8030A884: lh          $t6, 0x5534($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X5534);
    // 0x8030A888: lui         $a0, 0x801E
    ctx->r4 = S32(0X801E << 16);
    // 0x8030A88C: sll         $t7, $t6, 3
    ctx->r15 = S32(ctx->r14 << 3);
    // 0x8030A890: addu        $a0, $a0, $t7
    ctx->r4 = ADD32(ctx->r4, ctx->r15);
    // 0x8030A894: jal         0x80309E4C
    // 0x8030A898: lw          $a0, -0x2274($a0)
    ctx->r4 = MEM_W(ctx->r4, -0X2274);
    func_80309E4C_71B4FC(rdram, ctx);
        goto after_45;
    // 0x8030A898: lw          $a0, -0x2274($a0)
    ctx->r4 = MEM_W(ctx->r4, -0X2274);
    after_45:
    // 0x8030A89C: lui         $t0, 0x803D
    ctx->r8 = S32(0X803D << 16);
    // 0x8030A8A0: addiu       $t0, $t0, 0x552C
    ctx->r8 = ADD32(ctx->r8, 0X552C);
    // 0x8030A8A4: lw          $t9, 0x0($t0)
    ctx->r25 = MEM_W(ctx->r8, 0X0);
    // 0x8030A8A8: addiu       $t8, $zero, 0x1
    ctx->r24 = ADD32(0, 0X1);
    // 0x8030A8AC: addiu       $t1, $zero, 0x2
    ctx->r9 = ADD32(0, 0X2);
    // 0x8030A8B0: sb          $t8, 0x270($t9)
    MEM_B(0X270, ctx->r25) = ctx->r24;
    // 0x8030A8B4: lw          $t2, 0x0($t0)
    ctx->r10 = MEM_W(ctx->r8, 0X0);
    // 0x8030A8B8: sb          $t1, 0x271($t2)
    MEM_B(0X271, ctx->r10) = ctx->r9;
L_8030A8BC:
    // 0x8030A8BC: lui         $a0, 0x803D
    ctx->r4 = S32(0X803D << 16);
    // 0x8030A8C0: jal         0x803633C4
    // 0x8030A8C4: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    func_803633C4_774A74(rdram, ctx);
        goto after_46;
    // 0x8030A8C4: lw          $a0, 0x5530($a0)
    ctx->r4 = MEM_W(ctx->r4, 0X5530);
    after_46:
    // 0x8030A8C8: jal         0x803071BC
    // 0x8030A8CC: nop

    func_803071BC_71886C(rdram, ctx);
        goto after_47;
    // 0x8030A8CC: nop

    after_47:
    // 0x8030A8D0: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8030A8D4: lw          $v0, 0x552C($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X552C);
L_8030A8D8:
    // 0x8030A8D8: sb          $zero, 0x2B5($v0)
    MEM_B(0X2B5, ctx->r2) = 0;
    // 0x8030A8DC: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x8030A8E0: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x8030A8E4: jr          $ra
    // 0x8030A8E8: nop

    return;
    // 0x8030A8E8: nop

;}
RECOMP_FUNC void func_8030A8EC_71BF9C(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8030A8EC: lui         $t6, 0x803D
    ctx->r14 = S32(0X803D << 16);
    // 0x8030A8F0: lh          $t6, 0x5534($t6)
    ctx->r14 = MEM_H(ctx->r14, 0X5534);
    // 0x8030A8F4: lui         $v0, 0x801E
    ctx->r2 = S32(0X801E << 16);
    // 0x8030A8F8: addiu       $sp, $sp, -0x20
    ctx->r29 = ADD32(ctx->r29, -0X20);
    // 0x8030A8FC: sll         $t7, $t6, 3
    ctx->r15 = S32(ctx->r14 << 3);
    // 0x8030A900: addu        $v0, $v0, $t7
    ctx->r2 = ADD32(ctx->r2, ctx->r15);
    // 0x8030A904: lw          $v0, -0x2274($v0)
    ctx->r2 = MEM_W(ctx->r2, -0X2274);
    // 0x8030A908: sw          $ra, 0x1C($sp)
    MEM_W(0X1C, ctx->r29) = ctx->r31;
    // 0x8030A90C: lh          $a2, 0xC($v0)
    ctx->r6 = MEM_H(ctx->r2, 0XC);
    // 0x8030A910: lh          $a1, 0x8($v0)
    ctx->r5 = MEM_H(ctx->r2, 0X8);
    // 0x8030A914: lh          $a0, 0x4($v0)
    ctx->r4 = MEM_H(ctx->r2, 0X4);
    // 0x8030A918: addiu       $t4, $v0, 0x192
    ctx->r12 = ADD32(ctx->r2, 0X192);
    // 0x8030A91C: sw          $t4, 0x10($sp)
    MEM_W(0X10, ctx->r29) = ctx->r12;
    // 0x8030A920: lbu         $t5, 0x160($v0)
    ctx->r13 = MEM_BU(ctx->r2, 0X160);
    // 0x8030A924: sra         $t2, $a2, 6
    ctx->r10 = S32(SIGNED(ctx->r6) >> 6);
    // 0x8030A928: sra         $t0, $a1, 6
    ctx->r8 = S32(SIGNED(ctx->r5) >> 6);
    // 0x8030A92C: sra         $t8, $a0, 6
    ctx->r24 = S32(SIGNED(ctx->r4) >> 6);
    // 0x8030A930: andi        $a0, $t8, 0xFF
    ctx->r4 = ctx->r24 & 0XFF;
    // 0x8030A934: andi        $a1, $t0, 0xFF
    ctx->r5 = ctx->r8 & 0XFF;
    // 0x8030A938: andi        $a2, $t2, 0xFF
    ctx->r6 = ctx->r10 & 0XFF;
    // 0x8030A93C: addiu       $a3, $v0, 0x193
    ctx->r7 = ADD32(ctx->r2, 0X193);
    // 0x8030A940: jal         0x80319C38
    // 0x8030A944: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    func_80319C38_72B2E8(rdram, ctx);
        goto after_0;
    // 0x8030A944: sw          $t5, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r13;
    after_0:
    // 0x8030A948: lw          $ra, 0x1C($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X1C);
    // 0x8030A94C: addiu       $sp, $sp, 0x20
    ctx->r29 = ADD32(ctx->r29, 0X20);
    // 0x8030A950: jr          $ra
    // 0x8030A954: nop

    return;
    // 0x8030A954: nop

;}
RECOMP_FUNC void animal_jump(uint8_t* rdram, recomp_context* ctx) {
    uint64_t hi = 0, lo = 0, result = 0;
    int c1cs = 0;
    // 0x8030A958: lui         $v0, 0x803D
    ctx->r2 = S32(0X803D << 16);
    // 0x8030A95C: lw          $v0, 0x5524($v0)
    ctx->r2 = MEM_W(ctx->r2, 0X5524);
    // 0x8030A960: addiu       $sp, $sp, -0x18
    ctx->r29 = ADD32(ctx->r29, -0X18);
    // 0x8030A964: sw          $ra, 0x14($sp)
    MEM_W(0X14, ctx->r29) = ctx->r31;
    // 0x8030A968: lhu         $t6, 0xA2($v0)
    ctx->r14 = MEM_HU(ctx->r2, 0XA2);
    // 0x8030A96C: andi        $t7, $t6, 0x1
    ctx->r15 = ctx->r14 & 0X1;
    // 0x8030A970: beql        $t7, $zero, L_8030A9FC
    if (ctx->r15 == 0) {
        // 0x8030A974: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_8030A9FC;
    }
    goto skip_0;
    // 0x8030A974: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_0:
    // 0x8030A978: lhu         $t8, 0x9E($v0)
    ctx->r24 = MEM_HU(ctx->r2, 0X9E);
    // 0x8030A97C: addiu       $a0, $zero, 0x2
    ctx->r4 = ADD32(0, 0X2);
    // 0x8030A980: lui         $v1, 0x803D
    ctx->r3 = S32(0X803D << 16);
    // 0x8030A984: bnel        $a0, $t8, L_8030A9FC
    if (ctx->r4 != ctx->r24) {
        // 0x8030A988: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_8030A9FC;
    }
    goto skip_1;
    // 0x8030A988: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_1:
    // 0x8030A98C: lw          $v1, 0x5530($v1)
    ctx->r3 = MEM_W(ctx->r3, 0X5530);
    // 0x8030A990: addiu       $at, $zero, 0x1
    ctx->r1 = ADD32(0, 0X1);
    // 0x8030A994: lbu         $v0, 0x162($v1)
    ctx->r2 = MEM_BU(ctx->r3, 0X162);
    // 0x8030A998: beq         $v0, $at, L_8030A9A8
    if (ctx->r2 == ctx->r1) {
        // 0x8030A99C: addiu       $at, $zero, 0x6
        ctx->r1 = ADD32(0, 0X6);
            goto L_8030A9A8;
    }
    // 0x8030A99C: addiu       $at, $zero, 0x6
    ctx->r1 = ADD32(0, 0X6);
    // 0x8030A9A0: bnel        $v0, $at, L_8030A9FC
    if (ctx->r2 != ctx->r1) {
        // 0x8030A9A4: lw          $ra, 0x14($sp)
        ctx->r31 = MEM_W(ctx->r29, 0X14);
            goto L_8030A9FC;
    }
    goto skip_2;
    // 0x8030A9A4: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
    skip_2:
L_8030A9A8:
    // 0x8030A9A8: lhu         $v0, 0x0($v1)
    ctx->r2 = MEM_HU(ctx->r3, 0X0);
    // 0x8030A9AC: addiu       $at, $zero, 0x3
    ctx->r1 = ADD32(0, 0X3);
    // 0x8030A9B0: beq         $v0, $a0, L_8030A9D0
    if (ctx->r2 == ctx->r4) {
        // 0x8030A9B4: nop
    
            goto L_8030A9D0;
    }
    // 0x8030A9B4: nop

    // 0x8030A9B8: beq         $v0, $at, L_8030A9E0
    if (ctx->r2 == ctx->r1) {
        // 0x8030A9BC: addiu       $at, $zero, 0x4
        ctx->r1 = ADD32(0, 0X4);
            goto L_8030A9E0;
    }
    // 0x8030A9BC: addiu       $at, $zero, 0x4
    ctx->r1 = ADD32(0, 0X4);
    // 0x8030A9C0: beq         $v0, $at, L_8030A9F0
    if (ctx->r2 == ctx->r1) {
        // 0x8030A9C4: nop
    
            goto L_8030A9F0;
    }
    // 0x8030A9C4: nop

    // 0x8030A9C8: b           L_8030A9FC
    // 0x8030A9CC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_8030A9FC;
    // 0x8030A9CC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_8030A9D0:
    // 0x8030A9D0: jal         0x802A6390
    // 0x8030A9D4: nop

    func_802A6390_6B7A40(rdram, ctx);
        goto after_0;
    // 0x8030A9D4: nop

    after_0:
    // 0x8030A9D8: b           L_8030A9FC
    // 0x8030A9DC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_8030A9FC;
    // 0x8030A9DC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_8030A9E0:
    // 0x8030A9E0: jal         0x802A6390
    // 0x8030A9E4: nop

    func_802A6390_6B7A40(rdram, ctx);
        goto after_1;
    // 0x8030A9E4: nop

    after_1:
    // 0x8030A9E8: b           L_8030A9FC
    // 0x8030A9EC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
        goto L_8030A9FC;
    // 0x8030A9EC: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_8030A9F0:
    // 0x8030A9F0: jal         0x802A63C0
    // 0x8030A9F4: nop

    func_802A63C0_6B7A70(rdram, ctx);
        goto after_2;
    // 0x8030A9F4: nop

    after_2:
    // 0x8030A9F8: lw          $ra, 0x14($sp)
    ctx->r31 = MEM_W(ctx->r29, 0X14);
L_8030A9FC:
    // 0x8030A9FC: addiu       $sp, $sp, 0x18
    ctx->r29 = ADD32(ctx->r29, 0X18);
    // 0x8030AA00: jr          $ra
    // 0x8030AA04: nop

    return;
    // 0x8030AA04: nop

;}
